-- Church Management System Database Schema
-- Create this database and run these SQL commands to set up all required tables

-- Create database
CREATE DATABASE IF NOT EXISTS church_management;
USE church_management;

-- Users table (authentication and basic user info)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'pastor', 'accountant', 'leader', 'member') NOT NULL DEFAULT 'member',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Members table (extended member information)
CREATE TABLE members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    birth_date DATE,
    baptism_date DATE,
    ministry ENUM('worship', 'youth', 'children', 'outreach', 'prayer', 'ushering', 'technical', 'none') DEFAULT 'none',
    emergency_contact VARCHAR(255),
    emergency_phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sermons table
CREATE TABLE sermons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    scripture VARCHAR(255),
    date DATE NOT NULL,
    uploaded_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

-- Events table
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    date DATE NOT NULL,
    time TIME NOT NULL,
    location VARCHAR(255),
    max_participants INT,
    is_public BOOLEAN DEFAULT TRUE,
    organizer_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organizer_id) REFERENCES users(id)
);

-- Event registrations
CREATE TABLE event_registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_registration (event_id, user_id)
);

-- Announcements table
CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    priority ENUM('normal', 'important', 'urgent') DEFAULT 'normal',
    is_public BOOLEAN DEFAULT TRUE,
    author_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id)
);

-- Attendance table
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_date DATE NOT NULL,
    service_type ENUM('sunday_service', 'wednesday_prayer', 'youth_service', 'bible_study', 'prayer_meeting', 'special_event') NOT NULL,
    marked_by INT NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (marked_by) REFERENCES users(id)
);

-- Attendance members (many-to-many relationship)
CREATE TABLE attendance_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    attendance_id INT NOT NULL,
    member_id INT NOT NULL,
    status ENUM('present', 'absent', 'late') DEFAULT 'present',
    FOREIGN KEY (attendance_id) REFERENCES attendance(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_attendance (attendance_id, member_id)
);

-- Donations table
CREATE TABLE donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    donor_name VARCHAR(255),
    date DATE NOT NULL,
    recorded_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recorded_by) REFERENCES users(id)
);

-- Expenses table
CREATE TABLE expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('utilities', 'maintenance', 'equipment', 'supplies', 'events', 'other') NOT NULL,
    date DATE NOT NULL,
    recorded_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recorded_by) REFERENCES users(id)
);

-- Prayer Requests table
CREATE TABLE IF NOT EXISTS prayer_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    request TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert default admin user
-- Password: admin123 (hashed with password_hash)
INSERT INTO users (name, email, password, role) VALUES 
('Administrator', 'admin@church.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Insert sample data for testing
INSERT INTO users (name, email, password, role) VALUES 
('Pastor John', 'pastor@church.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'pastor'),
('Accountant Mary', 'accountant@church.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'accountant'),
('Ministry Leader David', 'leader@church.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'leader'),
('Church Member Sarah', 'member@church.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member');

-- Insert sample members
INSERT INTO members (user_id, phone, address, ministry) VALUES 
(5, '+1234567890', '123 Church Street, City, State', 'worship'),
(6, '+1234567891', '456 Faith Avenue, City, State', 'youth');

-- Insert sample sermons
INSERT INTO sermons (title, content, scripture, date, uploaded_by) VALUES 
('The Power of Faith', 'This sermon explores the transformative power of faith in our daily lives...', 'Hebrews 11:1', '2024-01-15', 2),
('Walking in Love', 'Understanding how to walk in love as Christ commanded us...', '1 Corinthians 13:4-7', '2024-01-22', 2);

-- Insert sample events
INSERT INTO events (name, description, date, time, location, organizer_id) VALUES 
('Sunday Service', 'Weekly Sunday worship service', '2024-01-28', '10:00:00', 'Main Sanctuary', 2),
('Youth Bible Study', 'Weekly youth group meeting', '2024-01-25', '18:00:00', 'Youth Room', 4);

-- Insert sample announcements
INSERT INTO announcements (title, content, priority, author_id) VALUES 
('Welcome to Our Church', 'We welcome all new members to our church family...', 'normal', 2),
('Important Meeting', 'There will be a leadership meeting this Saturday...', 'important', 1);

-- Insert sample donations
INSERT INTO donations (amount, description, donor_name, date, recorded_by) VALUES 
(100.00, 'Tithe offering', 'John Doe', '2024-01-15', 3),
(50.00, 'Building fund', 'Jane Smith', '2024-01-20', 3);

-- Insert sample expenses
INSERT INTO expenses (amount, description, category, date, recorded_by) VALUES 
(75.00, 'Sound system maintenance', 'equipment', '2024-01-18', 3),
(25.00, 'Office supplies', 'supplies', '2024-01-22', 3);

-- Insert sample attendance
INSERT INTO attendance (service_date, service_type, marked_by) VALUES 
('2024-01-21', 'sunday_service', 1);

-- Insert sample attendance members
INSERT INTO attendance_members (attendance_id, member_id, status) VALUES 
(1, 5, 'present'),
(1, 6, 'present'); 