<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['accountant']);
$user = get_user();

// Get financial statistics
$total_donations = $conn->query("SELECT SUM(amount) as total FROM donations")->fetch_assoc()['total'] ?? 0;
$monthly_donations = $conn->query("SELECT SUM(amount) as total FROM donations WHERE MONTH(date) = MONTH(CURRENT_DATE())")->fetch_assoc()['total'] ?? 0;
$total_tithes = $conn->query("SELECT SUM(amount) as total FROM donations WHERE type = 'tithe'")->fetch_assoc()['total'] ?? 0;
$total_offerings = $conn->query("SELECT SUM(amount) as total FROM donations WHERE type = 'offering'")->fetch_assoc()['total'] ?? 0;

// Get recent transactions
$recent_donations = $conn->query("SELECT * FROM donations ORDER BY date DESC LIMIT 5");

// Get monthly data for the chart
$monthly_data = [];
$result = $conn->query("SELECT 
    DATE_FORMAT(date, '%b %Y') as month,
    SUM(CASE WHEN type = 'tithe' THEN amount ELSE 0 END) as tithes,
    SUM(CASE WHEN type = 'offering' THEN amount ELSE 0 END) as offerings,
    SUM(amount) as total
    FROM donations 
    WHERE date >= DATE_SUB(NOW(), INTERVAL 5 MONTH)
    GROUP BY DATE_FORMAT(date, '%Y-%m')
    ORDER BY date ASC");

while($row = $result->fetch_assoc()) {
    $monthly_data[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Dashboard - Apostolic Church Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/apexcharts@3.35.0/dist/apexcharts.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2c3e50;
            --primary-hover: #1a252f;
            --secondary: #e67e22;
            --secondary-hover: #d35400;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
        }
        
        body {
            background-color: #f5f7fa;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            line-height: 1.6;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
        }
        
        .sidebar {
            background: var(--primary);
            min-height: 100vh;
            color: white;
            transition: all 0.3s;
            position: sticky;
            top: 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            margin: 0.25rem 0.5rem;
            border-radius: 0.5rem;
            transition: all 0.3s;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            transform: translateX(5px);
        }
        
        .sidebar .nav-link i {
            width: 20px;
            text-align: center;
            margin-right: 10px;
        }
        
        .main-content {
            padding: 2rem;
            background-color: #f5f7fa;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.5rem rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            transition: transform 0.2s, box-shadow 0.2s;
            border: 1px solid rgba(0,0,0,0.05);
            background: white;
        }
        
        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 0.5rem 1.5rem rgba(0, 0, 0, 0.08);
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            font-weight: 600;
            padding: 1.25rem 1.5rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .stat-card {
            position: relative;
            overflow: hidden;
            border-left: 4px solid var(--primary);
            background: white;
        }
        
        .stat-card .card-body {
            padding: 1.5rem;
        }
        
        .stat-card .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0.5rem 0;
            font-family: 'Montserrat', sans-serif;
        }
        
        .stat-card .stat-label {
            color: #6c757d;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 500;
        }
        
        .stat-card .stat-icon {
            font-size: 2.5rem;
            opacity: 0.1;
            position: absolute;
            right: 1.25rem;
            top: 1.25rem;
            color: var(--primary);
        }
        
        .recent-transactions {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .transaction-item {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.2s;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .transaction-item:last-child {
            border-bottom: none;
        }
        
        .transaction-item:hover {
            background-color: #f8f9fa;
        }
        
        .transaction-amount {
            font-weight: 600;
            font-family: 'Montserrat', sans-serif;
        }
        
        .transaction-date {
            font-size: 0.8rem;
            color: #6c757d;
        }
        
        .badge {
            padding: 0.35em 0.65em;
            font-weight: 500;
            border-radius: 0.25rem;
            font-size: 0.75rem;
        }
        
        .badge-tithe {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .badge-offering {
            background-color: rgba(23, 162, 184, 0.1);
            color: #17a2b8;
        }
        
        .badge-other {
            background-color: rgba(108, 117, 125, 0.1);
            color: #6c757d;
        }
        
        .search-box {
            position: relative;
            max-width: 300px;
        }
        
        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 10;
        }
        
        .search-box input {
            padding-left: 40px;
            border-radius: 20px !important;
            border: 1px solid #e1e5ee;
            height: 40px;
            font-size: 0.9rem;
        }
        
        .chart-container {
            height: 300px;
            position: relative;
            margin: 1rem 0;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            font-weight: 500;
            padding: 0.5rem 1.25rem;
            border-radius: 20px;
            transition: all 0.2s;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-1px);
        }
        
        .btn-outline-primary {
            color: var(--primary);
            border-color: var(--primary);
            font-weight: 500;
        }
        
        .btn-outline-primary:hover {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table th {
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #6c757d;
            border-top: none;
            padding: 1rem 1.5rem;
            background-color: #f8f9fa;
        }
        
        .table td {
            padding: 1rem 1.5rem;
            vertical-align: middle;
            border-color: #f0f0f0;
        }
        
        .table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .user-profile {
            text-align: center;
            padding: 1.5rem 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255,255,255,0.2);
            margin-bottom: 1rem;
        }
        
        .user-name {
            color: white;
            font-weight: 600;
            margin-bottom: 0.25rem;
            font-size: 1.1rem;
        }
        
        .user-role {
            color: rgba(255,255,255,0.7);
            font-size: 0.85rem;
        }
        
        .logo-container {
            padding: 1.5rem 1rem;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .logo-icon {
            font-size: 2rem;
            color: var(--accent);
            margin-bottom: 0.5rem;
            display: inline-block;
        }
        
        .logo-text {
            color: white;
            font-weight: 700;
            font-size: 1.25rem;
            letter-spacing: 0.5px;
        }
        
        @media (max-width: 992px) {
            .sidebar {
                position: fixed;
                z-index: 1050;
                width: 280px;
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out;
            }
            
            .sidebar.show {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .navbar-toggler {
                margin-right: 1rem;
            }
            
            .stat-card .stat-value {
                font-size: 1.5rem;
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 1.5rem;
            }
            
            .card {
                margin-bottom: 1rem;
            }
            
            .stat-card .stat-value {
                font-size: 1.5rem;
            }
            
            .search-box {
                max-width: 100%;
                margin-bottom: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="logo-container">
                    <div class="logo-icon">
                        <i class="fas fa-church"></i>
                    </div>
                    <div class="logo-text">Apostolic Church</div>
                </div>
                
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>" alt="User" class="user-avatar">
                    <h5 class="user-name"><?php echo htmlspecialchars($user['name']); ?></h5>
                    <div class="user-role">Accountant</div>
                </div>
                
                <nav class="nav flex-column mt-3">
                    <a class="nav-link active" href="#">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a class="nav-link" href="../financial/records.php">
                        <i class="fas fa-book"></i> Financial Records
                    </a>
                    <a class="nav-link" href="../financial/budgets.php">
                        <i class="fas fa-chart-pie"></i> Budgets
                    </a>
                    <a class="nav-link" href="../financial/reports.php">
                        <i class="fas fa-file-alt"></i> Reports
                    </a>
                    <a class="nav-link" href="../donations/">
                        <i class="fas fa-hand-holding-usd"></i> Donations
                    </a>
                    <a class="nav-link" href="../financial/feedback.php">
                        <i class="fas fa-comments"></i> Feedback
                    </a>
                    <hr class="text-white-50 my-2">
                    <a class="nav-link" href="../profile.php">
                        <i class="fas fa-user"></i> Profile
                    </a>
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 ms-sm-auto px-0">
                <!-- Top Navigation -->
                <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <button class="btn btn-link d-md-none" type="button" id="sidebarToggle">
                            <i class="fas fa-bars"></i>
                        </button>
                        
                        <div class="d-flex align-items-center ms-auto">
                            <div class="dropdown">
                                <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>" width="32" height="32" class="rounded-circle me-2">
                                    <span class="d-none d-md-inline"><?php echo htmlspecialchars($user['name']); ?></span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                    <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                                    <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>

                <div class="main-content">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="mb-1">Financial Dashboard</h2>
                            <p class="text-muted mb-0">Welcome back, <?php echo htmlspecialchars($user['name']); ?>! Here's what's happening with your finances.</p>
                        </div>
                        <div class="d-flex
                        <div class="search-box me-3">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" placeholder="Search transactions...">
                        </div>
                        <a href="../donations/manage.php" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i> New Transaction
                        </a>
                    </div>
                    
                    <!-- Stats Cards -->
                    <div class="row mb-4">
                        <div class="col-md-6 col-lg-3">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h6 class="stat-label">Total Donations</h6>
                                    <h2 class="stat-value">GHS <?php echo number_format($total_donations, 2); ?></h2>
                                    <div class="d-flex align-items-center mt-2">
                                        <span class="text-success me-2"><i class="fas fa-arrow-up"></i> 12%</span>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                    <i class="fas fa-donate stat-icon"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 col-lg-3">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h6 class="stat-label">This Month</h6>
                                    <h2 class="stat-value">GHS <?php echo number_format($monthly_donations, 2); ?></h2>
                                    <div class="d-flex align-items-center mt-2">
                                        <span class="text-success me-2"><i class="fas fa-arrow-up"></i> 5%</span>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                    <i class="fas fa-calendar-alt stat-icon"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 col-lg-3">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h6 class="stat-label">Total Tithes</h6>
                                    <h2 class="stat-value">GHS <?php echo number_format($total_tithes, 2); ?></h2>
                                    <div class="d-flex align-items-center mt-2">
                                        <span class="text-success me-2"><i class="fas fa-arrow-up"></i> 8%</span>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                    <i class="fas fa-hand-holding-usd stat-icon"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 col-lg-3">
                            <div class="card stat-card">
                                <div class="card-body">
                                    <h6 class="stat-label">Total Offerings</h6>
                                    <h2 class="stat-value">GHS <?php echo number_format($total_offerings, 2); ?></h2>
                                    <div class="d-flex align-items-center mt-2">
                                        <span class="text-success me-2"><i class="fas fa-arrow-up"></i> 15%</span>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                    <i class="fas fa-gift stat-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <!-- Financial Overview Chart -->
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0">Financial Overview</h5>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary active">Monthly</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary">Quarterly</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary">Yearly</button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div id="financialChart" class="chart-container"></div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Recent Transactions -->
                        <div class="col-lg-4">
                            <div class="card h-100">
                                <div class="card-header">
                                    <h5 class="mb-0">Recent Transactions</h5>
                                    <a href="../donations/" class="btn btn-sm btn-link">View All</a>
                                </div>
                                <div class="card-body p-0">
                                    <div class="recent-transactions">
                                        <?php if ($recent_donations && $recent_donations->num_rows > 0): ?>
                                            <?php while($donation = $recent_donations->fetch_assoc()): ?>
                                                <div class="transaction-item">
                                                    <div>
                                                        <div class="d-flex align-items-center">
                                                            <span class="badge <?php echo $donation['type'] === 'tithe' ? 'badge-tithe' : ($donation['type'] === 'offering' ? 'badge-offering' : 'badge-other'); ?> me-2">
                                                                <?php echo ucfirst($donation['type']); ?>
                                                            </span>
                                                            <span class="text-truncate" style="max-width: 120px;" title="<?php echo htmlspecialchars($donation['donor_name']); ?>">
                                                                <?php echo htmlspecialchars($donation['donor_name']); ?>
                                                            </span>
                                                        </div>
                                                        <div class="transaction-date">
                                                            <?php echo date('M d, Y', strtotime($donation['date'])); ?>
                                                        </div>
                                                    </div>
                                                    <div class="transaction-amount">
                                                        $<?php echo number_format($donation['amount'], 2); ?>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <div class="text-center p-4 text-muted">
                                                <i class="fas fa-inbox fa-2x mb-2"></i>
                                                <p class="mb-0">No recent transactions found</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Recent Donations Table -->
                    <div class="card mt-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Recent Donations</h5>
                            <div>
                                <button class="btn btn-sm btn-outline-secondary me-2">
                                    <i class="fas fa-filter me-1"></i> Filter
                                </button>
                                <a href="?export=csv" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-download me-1"></i> Export
                                </a>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Donor</th>
                                            <th>Type</th>
                                            <th>Description</th>
                                            <th class="text-end">Amount</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $recent_donations = $conn->query("SELECT * FROM donations ORDER BY date DESC LIMIT 5");
                                        if ($recent_donations && $recent_donations->num_rows > 0): 
                                            while($donation = $recent_donations->fetch_assoc()): 
                                        ?>
                                            <tr>
                                                <td><?php echo date('M d, Y', strtotime($donation['date'])); ?></td>
                                                <td><?php echo htmlspecialchars($donation['donor_name']); ?></td>
                                                <td>
                                                    <span class="badge <?php echo $donation['type'] === 'tithe' ? 'badge-tithe' : ($donation['type'] === 'offering' ? 'badge-offering' : 'badge-other'); ?>">
                                                        <?php echo ucfirst($donation['type']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo htmlspecialchars($donation['description']); ?></td>
                                                <td class="text-end fw-bold">$<?php echo number_format($donation['amount'], 2); ?></td>
                                                <td class="text-center">
                                                    <div class="btn-group">
                                                        <button class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-outline-secondary">
                                                            <i class="fas fa-print"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php 
                                            endwhile; 
                                        else: 
                                        ?>
                                            <tr>
                                                <td colspan="6" class="text-center py-4 text-muted">
                                                    <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                                    No donation records found
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer bg-white border-top-0 pt-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="text-muted small">Showing 1 to 5 of 50 entries</span>
                                </div>
                                <nav aria-label="Page navigation">
                                    <ul class="pagination pagination-sm mb-0">
                                        <li class="page-item disabled">
                                            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                                        </li>
                                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item">
                                            <a class="page-link" href="#">Next</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.35.0/dist/apexcharts.min.js"></script>
    <script>
        // Toggle sidebar on mobile
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('show');
        });

        // Financial Chart
        var options = {
            series: [
                {
                    name: 'Tithes',
                    data: [
                        <?php 
                        $data = [];
                        foreach($monthly_data as $month) {
                            echo $month['tithes'] . ', ';
                        }
                        ?>
                    ]
                },
                {
                    name: 'Offerings',
                    data: [
                        <?php 
                        foreach($monthly_data as $month) {
                            echo $month['offerings'] . ', ';
                        }
                        ?>
                    ]
                }
            ],
            chart: {
                type: 'area',
                height: '100%',
                fontFamily: '"Poppins", sans-serif',
                toolbar: {
                    show: true
                },
                zoom: {
                    enabled: false
                },
                animations: {
                    enabled: true,
                    easing: 'easeinout',
                    speed: 800
                }
            },
            colors: ['#28a745', '#17a2b8'],
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth',
                width: 2
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.7,
                    opacityTo: 0.3,
                }
            },
            xaxis: {
                categories: [
                    <?php 
                    foreach($monthly_data as $month) {
                        echo '"' . $month['month'] . '", ';
                    }
                    ?>
                ],
                labels: {
                    style: {
                        colors: '#6c757d',
                        fontSize: '12px',
                        fontFamily: '"Poppins", sans-serif'
                    }
                },
                axisBorder: {
                    show: false
                },
                axisTicks: {
                    show: false
                }
            },
            yaxis: {
                labels: {
                    formatter: function(value) {
                        return '$' + value.toLocaleString();
                    },
                    style: {
                        colors: '#6c757d',
                        fontSize: '12px',
                        fontFamily: '"Poppins", sans-serif'
                    }
                }
            },
            tooltip: {
                y: {
                    formatter: function(value) {
                        return '$' + value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    }
                },
                style: {
                    fontSize: '14px',
                    fontFamily: '"Poppins", sans-serif'
                }
            },
            legend: {
                position: 'top',
                horizontalAlign: 'right',
                fontSize: '14px',
                fontFamily: '"Poppins", sans-serif',
                markers: {
                    width: 10,
                    height: 10,
                    radius: 0
                },
                itemMargin: {
                    horizontal: 15,
                    vertical: 5
                }
            },
            grid: {
                borderColor: '#f0f0f0',
                strokeDashArray: 3,
                xaxis: {
                    lines: {
                        show: true
                    }
                },
                yaxis: {
                    lines: {
                        show: true
                    }
                },
                padding: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#financialChart"), options);
        chart.render();

        // Update chart on window resize
        window.addEventListener('resize', function() {
            chart.updateOptions({
                chart: {
                    width: '100%'
                }
            });
        });

        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>
