<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['member']);
$user = get_user();

// Get member statistics using file-based database
$prayer_requests_count = 0; // Not implemented yet
$registered_events = 0; // Not implemented yet

// Initialize donations count and total
$donations_count = 0;
$total_donated = 0.00;

// Load donations from file
$donations_file = __DIR__ . '/../data/donations.json';
if (file_exists($donations_file)) {
    $all_donations = json_decode(file_get_contents($donations_file), true) ?: [];
    
    // Filter donations for the current user
    $user_donations = array_filter($all_donations, function($donation) use ($user) {
        return isset($donation['recorded_by']) && $donation['recorded_by'] == $user['id'];
    });
    
    // Calculate count and total
    $donations_count = count($user_donations);
    $total_donated = array_sum(array_column($user_donations, 'amount'));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Dashboard - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #74b9ff 0%, #0984e3 100%);
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            border-radius: 10px;
            margin: 5px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .main-content {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 px-0">
            <div class="sidebar p-3">
                <div class="text-center mb-4">
                    <i class="fas fa-church fa-2x text-white mb-2"></i>
                    <h5 class="text-white">Church Management</h5>
                </div>
                <div class="text-center mb-4">
                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                         class="rounded-circle" width="60" height="60" alt="Profile">
                    <p class="text-white mb-0 mt-2"><?php echo htmlspecialchars($user['name']); ?></p>
                    <small class="text-white-50">Member</small>
                </div>
                <nav class="nav flex-column">
                    <a class="nav-link active" href="#"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a class="nav-link" href="../profile/edit.php"><i class="fas fa-user me-2"></i>Manage Profile</a>
                    <a class="nav-link" href="../events/list.php"><i class="fas fa-calendar me-2"></i>View Events</a>
                    <a class="nav-link" href="../prayer/submit.php"><i class="fas fa-pray me-2"></i>Submit Prayer Request</a>
                    <a class="nav-link" href="../communication/"><i class="fas fa-comments me-2"></i>Communicate</a>
                    <a class="nav-link" href="../donations/manage.php"><i class="fas fa-hand-holding-usd me-2"></i>Manage Donations</a>
                    <a class="nav-link" href="../feedback/submit.php"><i class="fas fa-comment-dots me-2"></i>Send Feedback</a>
                    <a class="nav-link" href="../counseling/request.php"><i class="fas fa-hands-helping me-2"></i>Request Counseling</a>
                    <a class="nav-link" href="../community/"><i class="fas fa-users me-2"></i>Community</a>
                    <hr class="text-white">
                    <a class="nav-link" href="../profile.php"><i class="fas fa-user me-2"></i>Profile</a>
                    <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10">
            <div class="main-content p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-tachometer-alt me-2"></i>Member Dashboard</h2>
                    <div class="text-muted">Welcome back, <?php echo htmlspecialchars($user['name']); ?>!</div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-calendar-check fa-2x text-primary mb-2"></i>
                            <h3 class="mb-1"><?php echo $registered_events; ?></h3>
                            <p class="text-muted mb-0">Registered Events</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-pray fa-2x text-success mb-2"></i>
                            <h3 class="mb-1"><?php echo $prayer_requests_count; ?></h3>
                            <p class="text-muted mb-0">Prayer Requests</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-hand-holding-usd fa-2x text-warning mb-2"></i>
                            <h3 class="mb-1"><?php echo $donations_count; ?></h3>
                            <p class="text-muted mb-0">Donations Made</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-money-bill-wave fa-2x text-info mb-2"></i>
                            <h3 class="mb-1">₵<?php echo number_format($total_donated, 2); ?></h3>
                            <p class="text-muted mb-0">Total Donated</p>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <a href="../events/list.php" class="btn btn-primary w-100">
                                            <i class="fas fa-calendar me-2"></i>Register for Events
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="../prayer/submit.php" class="btn btn-success w-100">
                                            <i class="fas fa-pray me-2"></i>Submit Prayer Request
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="../donations/manage.php" class="btn btn-warning w-100">
                                            <i class="fas fa-hand-holding-usd me-2"></i>Make Donation
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="../community/" class="btn btn-info w-100">
                                            <i class="fas fa-users me-2"></i>Join Community
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Personal Overview -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Personal Overview</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>My Activities</h6>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Events Attended</span>
                                            <span class="fw-bold"><?php echo $registered_events; ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Prayer Requests</span>
                                            <span class="fw-bold"><?php echo $prayer_requests_count; ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Total Donations</span>
                                            <span class="fw-bold">₵<?php echo number_format($total_donated, 2); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Engagement Level</h6>
                                        <div class="progress mb-3">
                                            <div class="progress-bar bg-success" style="width: 75%"></div>
                                        </div>
                                        <small class="text-muted">Event Participation: 75%</small>
                                        <br>
                                        <div class="progress mb-3 mt-2">
                                            <div class="progress-bar bg-primary" style="width: 60%"></div>
                                        </div>
                                        <small class="text-muted">Community Engagement: 60%</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Recent Activities</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <strong>Feedback Submitted</strong>
                                    <br><small class="text-muted">Recent Activity</small>
                                    <br><small class="text-muted">Aug 14</small>
                                </div>
                                <div class="mb-3">
                                    <strong>Counseling Requested</strong>
                                    <br><small class="text-muted">Recent Activity</small>
                                    <br><small class="text-muted">Aug 13</small>
                                </div>
                                <div class="mb-3">
                                    <strong>Profile Updated</strong>
                                    <br><small class="text-muted">Recent Activity</small>
                                    <br><small class="text-muted">Aug 12</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Upcoming Events -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-calendar me-2"></i>Upcoming Events</h5>
                            </div>
                            <div class="card-body">
                                <?php
                                $upcoming_events = $conn->query("SELECT name, date, description FROM events WHERE date >= '" . date('Y-m-d') . "' ORDER BY date ASC LIMIT 5");
                                if ($upcoming_events && $upcoming_events->num_rows > 0):
                                    while($event = $upcoming_events->fetch_assoc()):
                                ?>
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <strong><?php echo htmlspecialchars($event['name']); ?></strong>
                                        <br><small class="text-muted"><?php echo htmlspecialchars(substr($event['description'], 0, 50)) . '...'; ?></small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-primary"><?php echo date('M j, Y', strtotime($event['date'])); ?></span>
                                        <br><a href="../events/list.php" class="btn btn-sm btn-outline-primary mt-1">Register</a>
                                    </div>
                                </div>
                                <?php 
                                    endwhile;
                                else:
                                ?>
                                <p class="text-muted">No upcoming events.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>