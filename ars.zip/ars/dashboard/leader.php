<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['leader']);
$user = get_user();

// Get ministry statistics
$ministry_members = $conn->query("SELECT COUNT(*) as count FROM users WHERE ministry_id = (SELECT id FROM ministries WHERE leader_id = {$user['id']})")->fetch_assoc()['count'] ?? 0;
$ministry_events = $conn->query("SELECT COUNT(*) as count FROM events WHERE created_by = {$user['id']}")->fetch_assoc()['count'] ?? 0;
$volunteers_count = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'member' AND ministry_id IS NOT NULL")->fetch_assoc()['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ministry Leader Dashboard - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #fd79a8 0%, #e84393 100%);
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            border-radius: 10px;
            margin: 5px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .main-content {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 px-0">
            <div class="sidebar p-3">
                <div class="text-center mb-4">
                    <i class="fas fa-church fa-2x text-white mb-2"></i>
                    <h5 class="text-white">Church Management</h5>
                </div>
                <div class="text-center mb-4">
                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                         class="rounded-circle" width="60" height="60" alt="Profile">
                    <p class="text-white mb-0 mt-2"><?php echo htmlspecialchars($user['name']); ?></p>
                    <small class="text-white-50">Ministry Leader</small>
                </div>
                <nav class="nav flex-column">
                    <a class="nav-link active" href="#"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a class="nav-link" href="../ministry/members.php"><i class="fas fa-users me-2"></i>Ministry Members</a>
                    <a class="nav-link" href="../volunteers/"><i class="fas fa-hands-helping me-2"></i>Volunteers</a>
                    <a class="nav-link" href="../events/create.php"><i class="fas fa-calendar me-2"></i>Plan Events</a>
                    <a class="nav-link" href="../attendance/ministry.php"><i class="fas fa-clipboard-list me-2"></i>Ministry Attendance</a>
                    <a class="nav-link" href="../reports/ministry.php"><i class="fas fa-chart-bar me-2"></i>Ministry Reports</a>
                    <hr class="text-white">
                    <a class="nav-link" href="../profile.php"><i class="fas fa-user me-2"></i>Profile</a>
                    <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10">
            <div class="main-content p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-tachometer-alt me-2"></i>Ministry Leader Dashboard</h2>
                    <div class="text-muted">Welcome back, <?php echo htmlspecialchars($user['name']); ?>!</div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-users fa-2x text-primary mb-2"></i>
                            <h3 class="mb-1"><?php echo $ministry_members; ?></h3>
                            <p class="text-muted mb-0">Ministry Members</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-calendar fa-2x text-success mb-2"></i>
                            <h3 class="mb-1"><?php echo $ministry_events; ?></h3>
                            <p class="text-muted mb-0">Ministry Events</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-hands-helping fa-2x text-warning mb-2"></i>
                            <h3 class="mb-1"><?php echo $volunteers_count; ?></h3>
                            <p class="text-muted mb-0">Active Volunteers</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card p-3 text-center">
                            <i class="fas fa-chart-line fa-2x text-info mb-2"></i>
                            <h3 class="mb-1">85%</h3>
                            <p class="text-muted mb-0">Attendance Rate</p>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <a href="../ministry/members.php" class="btn btn-primary w-100">
                                            <i class="fas fa-user-plus me-2"></i>Add Member
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="../volunteers/assign.php" class="btn btn-success w-100">
                                            <i class="fas fa-hands-helping me-2"></i>Assign Volunteer
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="../events/create.php" class="btn btn-warning w-100">
                                            <i class="fas fa-calendar-plus me-2"></i>Plan Event
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="../reports/ministry.php" class="btn btn-info w-100">
                                            <i class="fas fa-chart-bar me-2"></i>View Report
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Ministry Overview -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Ministry Overview</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>Member Distribution</h6>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Active Members</span>
                                            <span class="fw-bold"><?php echo $ministry_members; ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Volunteers</span>
                                            <span class="fw-bold"><?php echo $volunteers_count; ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Events This Month</span>
                                            <span class="fw-bold"><?php echo $ministry_events; ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Performance Metrics</h6>
                                        <div class="progress mb-3">
                                            <div class="progress-bar bg-success" style="width: 85%"></div>
                                        </div>
                                        <small class="text-muted">Attendance Rate: 85%</small>
                                        <br>
                                        <div class="progress mb-3 mt-2">
                                            <div class="progress-bar bg-primary" style="width: 70%"></div>
                                        </div>
                                        <small class="text-muted">Volunteer Engagement: 70%</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Recent Activities</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <strong>New Member Added</strong>
                                    <br><small class="text-muted">John Doe joined the ministry</small>
                                    <br><small class="text-muted">2 hours ago</small>
                                </div>
                                <div class="mb-3">
                                    <strong>Event Created</strong>
                                    <br><small class="text-muted">Prayer Meeting scheduled</small>
                                    <br><small class="text-muted">1 day ago</small>
                                </div>
                                <div class="mb-3">
                                    <strong>Volunteer Assigned</strong>
                                    <br><small class="text-muted">Sarah assigned to ushering</small>
                                    <br><small class="text-muted">3 days ago</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 