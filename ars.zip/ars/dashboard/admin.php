<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin']);
$user = get_user();

// Get statistics
$total_members = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'member'")->fetch_assoc()['count'];
$total_events = $conn->query("SELECT COUNT(*) as count FROM events")->fetch_assoc()['count'];
$total_attendance = $conn->query("SELECT COUNT(*) as count FROM attendance")->fetch_assoc()['count'];
$total_donations = $conn->query("SELECT SUM(amount) as total FROM donations")->fetch_assoc()['total'] ?? 0;

// Get recent activities
$recent_members = $conn->query("SELECT u.name, u.email, u.created_at FROM users u WHERE u.role = 'member' ORDER BY u.created_at DESC LIMIT 5");
$recent_events = $conn->query("SELECT name, date, time FROM events ORDER BY date DESC LIMIT 5");
$recent_announcements = $conn->query("SELECT title, created_at FROM announcements ORDER BY created_at DESC LIMIT 5");

$page_title = "Admin Dashboard";
$base_path = "../";
include '../includes/header.php';

// Add export button to the donations card header
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="donations.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Date', 'Amount', 'Donor', 'Description']);
    $filter_donor = $_GET['donor'] ?? '';
    $filter_date = $_GET['date'] ?? '';
    $where = [];
    if ($filter_donor) $where[] = "donor_name LIKE '%" . $conn->real_escape_string($filter_donor) . "%'";
    if ($filter_date) $where[] = "date = '" . $conn->real_escape_string($filter_date) . "'";
    $where_sql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
    $donations = $conn->query("SELECT * FROM donations $where_sql ORDER BY date DESC");
    if ($donations && $donations->num_rows > 0) {
        while($don = $donations->fetch_assoc()) {
            fputcsv($out, [
                $don['date'],
                $don['amount'],
                $don['donor_name'],
                $don['description']
            ]);
        }
    }
    exit;
}
?>

<!-- Dashboard Header -->
<div class="container p-0 mt-4">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <div class="dashboard-title-wrapper" style="position: relative; display: inline-block; padding: 20px 25px; width: 100%; margin-top: 1.5rem; border-radius: 0 0 15px 15px; background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15); border: 1px solid rgba(255, 255, 255, 0.18); transform-style: preserve-3d; transform: perspective(500px) rotateX(0deg); transition: all 0.3s ease; overflow: hidden;">
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(45deg, rgba(44, 62, 80, 0.1), rgba(52, 152, 219, 0.1)); z-index: 0;"></div>
                <h1 class="mb-0" style="font-size: 2.2rem; font-weight: 800; letter-spacing: -0.5px; margin: 0; position: relative; z-index: 1; text-transform: uppercase; color: #007bff;">
                    <i class="fas fa-tachometer-alt me-2" style="font-size: 1.1em; vertical-align: middle; color: #0056b3;"></i>
                    Admin Dashboard
                </h1>
                <div class="title-ornament" style="position: absolute; top: -10px; right: -10px; width: 30px; height: 30px; border-top: 3px solid #3498db; border-right: 3px solid #9b59b6; border-radius: 0 15px 0 0; transition: all 0.3s ease;"></div>
                <div class="title-ornament" style="position: absolute; bottom: -10px; left: -10px; width: 30px; height: 30px; border-bottom: 3px solid #9b59b6; border-left: 3px solid #3498db; border-radius: 0 0 0 15px; transition: all 0.3s ease;"></div>
                <style>
                    .dashboard-title-wrapper:hover {
                        transform: perspective(500px) rotateX(2deg) translateY(-3px);
                        box-shadow: 0 12px 40px 0 rgba(31, 38, 135, 0.25);
                    }
                    .dashboard-title-wrapper:hover .title-highlight {
                        transform: scaleX(1) translateY(2px);
                        opacity: 0.5;
                    }
                    .dashboard-title-wrapper:hover .title-ornament {
                        width: 40px;
                        height: 40px;
                    }
                </style>
            </div>
            <p class="text-primary">Welcome back, <?php echo htmlspecialchars($user['name']); ?>!</p>
        </div>
        <div class="d-flex gap-2">
            <a href="../reports/generate.php" class="btn btn-success">
                <i class="fas fa-chart-bar me-2"></i>Generate Reports
            </a>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-1"><?php echo $total_members; ?></h4>
                            <p class="mb-0">Total Members</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-1"><?php echo $total_events; ?></h4>
                            <p class="mb-0">Total Events</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-calendar fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-1"><?php echo $total_attendance; ?></h4>
                            <p class="mb-0">Attendance Records</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-clipboard-check fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-1">$<?php echo number_format($total_donations, 2); ?></h4>
                            <p class="mb-0">Total Donations</p>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-dollar-sign fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <a href="../members/register.php" class="btn btn-outline-primary w-100">
                                <i class="fas fa-user-plus me-2"></i>Register Member
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="../events/create.php" class="btn btn-outline-success w-100">
                                <i class="fas fa-calendar-plus me-2"></i>Create Event
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="../announcements/post.php" class="btn btn-outline-warning w-100">
                                <i class="fas fa-bullhorn me-2"></i>Post Announcement
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="../attendance/mark.php" class="btn btn-outline-info w-100">
                                <i class="fas fa-clipboard-check me-2"></i>Mark Attendance
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <a href="../feedback/submit.php" class="btn btn-outline-primary w-100">
                                <i class="fas fa-comment me-2"></i>Submit Feedback
                            </a>
                        </div>
                        <div class="col-md-6 mb-3">
                            <a href="../donations/verify.php" class="btn btn-outline-success w-100">
                                <i class="fas fa-check-circle me-2"></i>Verify Donations
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="row">
        <!-- Recent Members -->
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-users me-2"></i>Recent Members</h5>
                </div>
                <div class="card-body">
                    <?php if ($recent_members && $recent_members->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($member = $recent_members->fetch_assoc()): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($member['name']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($member['email']); ?></small>
                                </div>
                                <small class="text-muted"><?php echo date('M j', strtotime($member['created_at'])); ?></small>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No members registered yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Events -->
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-calendar me-2"></i>Recent Events</h5>
                </div>
                <div class="card-body">
                    <?php if ($recent_events && $recent_events->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($event = $recent_events->fetch_assoc()): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($event['name']); ?></h6>
                                    <small class="text-muted"><?php echo date('g:i A', strtotime($event['time'])); ?></small>
                                </div>
                                <small class="text-muted"><?php echo date('M j', strtotime($event['date'])); ?></small>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No events scheduled.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Announcements -->
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bullhorn me-2"></i>Recent Announcements</h5>
                </div>
                <div class="card-body">
                    <?php if ($recent_announcements && $recent_announcements->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($announcement = $recent_announcements->fetch_assoc()): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($announcement['title']); ?></h6>
                                </div>
                                <small class="text-muted"><?php echo date('M j', strtotime($announcement['created_at'])); ?></small>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No announcements posted.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Management Links -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-cog me-2"></i>System Management</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="text-center">
                                <i class="fas fa-users fa-2x text-primary mb-2"></i>
                                <h6>Member Management</h6>
                                <a href="../members/register.php" class="btn btn-sm btn-outline-primary">Register Member</a>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="text-center">
                                <i class="fas fa-chart-bar fa-2x text-success mb-2"></i>
                                <h6>Reports</h6>
                                <a href="../reports/generate.php" class="btn btn-sm btn-outline-success">Generate Reports</a>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="text-center">
                                <i class="fas fa-clipboard-check fa-2x text-info mb-2"></i>
                                <h6>Attendance</h6>
                                <a href="../attendance/mark.php" class="btn btn-sm btn-outline-info">Mark Attendance</a>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="text-center">
                                <i class="fas fa-dollar-sign fa-2x text-warning mb-2"></i>
                                <h6>Financial</h6>
                                <a href="../financial/records.php" class="btn btn-sm btn-outline-warning">View Records</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?> 