<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['pastor']);
$user = get_user();

/**
 * Adjust the brightness of a hex color
 * @param string $hex Hex color code
 * @param int $steps Steps to adjust brightness (-255 to 255)
 * @return string Adjusted hex color
 */
function adjustBrightness($hex, $steps) {
    $steps = max(-255, min(255, $steps));
    $hex = str_replace('#', '', $hex);
    
    if (strlen($hex) == 3) {
        $hex = str_repeat(substr($hex, 0, 1), 2) . str_repeat(substr($hex, 1, 1), 2) . str_repeat(substr($hex, 2, 1), 2);
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    
    return '#' . $r_hex . $g_hex . $b_hex;
}

// Get statistics
$sermons_count = $conn->query("SELECT COUNT(*) as count FROM sermons WHERE uploaded_by = {$user['id']}")->fetch_assoc()['count'];
$announcements_count = $conn->query("SELECT COUNT(*) as count FROM announcements WHERE posted_by = {$user['id']}")->fetch_assoc()['count'];
$events_count = $conn->query("SELECT COUNT(*) as count FROM events WHERE created_by = {$user['id']}")->fetch_assoc()['count'];
$members_count = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'member'")->fetch_assoc()['count'];

// Get unread feedback count
$unread_feedback_count = $conn->getUnreadFeedbackCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pastor Dashboard - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333;
            --text-light: #7f8c8d;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--text);
        }
        
        /* Sidebar Styles */
        .sidebar {
            background: linear-gradient(180deg, var(--secondary) 0%, #1a252f 100%);
            min-height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: relative;
            z-index: 10;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 0.7rem 1.5rem;
            margin: 0.2rem 0;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-weight: 400;
        }
        
        .sidebar .nav-link:hover, 
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
            transform: translateX(5px);
        }
        
        .sidebar .nav-link i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
        }
        
        .sidebar .badge {
            font-size: 0.6rem;
            padding: 0.35em 0.65em;
        }
        
        /* Main Content Styles */
        .main-content {
            padding: 2rem !important;
            background-color: #f5f7fa;
        }
        
        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border: 1px solid rgba(0,0,0,0.05);
            height: 100%;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .stat-card i {
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            margin: 0 auto 1rem;
            font-size: 1.5rem;
        }
        
        .stat-card h3 {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }
        
        .stat-card p {
            color: var(--text-light);
            margin-bottom: 0;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        /* Card Styles */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
            border: 1px solid rgba(0,0,0,0.05);
        }
        
        .card:hover {
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 1.25rem 1.5rem;
            border-radius: 12px 12px 0 0 !important;
        }
        
        .card-header h5 {
            font-weight: 600;
            color: var(--dark);
            margin: 0;
            display: flex;
            align-items: center;
        }
        
        .card-header h5 i {
            margin-right: 10px;
            color: var(--primary);
        }
        
        /* Button Styles */
        .btn {
            padding: 0.6rem 1.25rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%);
            border: none;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
            border: none;
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            border: none;
            color: white;
        }
        
        /* Welcome Section */
        .welcome-card {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%);
            color: white;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .welcome-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            transform: rotate(30deg);
        }
        
        .welcome-card h2 {
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .welcome-card p {
            opacity: 0.9;
            margin-bottom: 0;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .sidebar {
                min-height: auto;
                padding: 1rem;
            }
            
            .main-content {
                padding: 1.5rem !important;
            }
            
            .stat-card {
                margin-bottom: 1rem;
            }
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 px-0">
            <div class="sidebar p-4">
                <div class="text-center mb-5">
                    <div class="logo-container position-relative d-inline-block mb-3">
                        <div class="logo-icon-wrapper">
                            <i class="fas fa-church"></i>
                        </div>
                        <h4 class="logo-text">ChurchMS</h4>
                    </div>
                    <p class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-normal">Pastor's Portal</p>
                </div>
                <style>
                .logo-container {
                    --logo-size: 80px;
                    --icon-size: 2rem;
                    --accent-color: #ffc107;
                    --text-color: #fff;
                }

                .logo-icon-wrapper {
                    width: var(--logo-size);
                    height: var(--logo-size);
                    background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
                    border-radius: 20px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 1rem;
                    position: relative;
                    overflow: hidden;
                    transform: rotate(-5deg);
                    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
                    border: 1px solid rgba(255,255,255,0.1);
                }

                .logo-icon-wrapper::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: 
                        linear-gradient(45deg, 
                            transparent 45%, 
                            rgba(255,255,255,0.1) 48%, 
                            rgba(255,255,255,0.1) 52%, 
                            transparent 55%
                        );
                    transform: translateX(-100%);
                    animation: shine 3s infinite;
                }

                @keyframes shine {
                    100% {
                        transform: translateX(100%);
                    }
                }

                .logo-icon-wrapper i {
                    font-size: var(--icon-size);
                    color: var(--accent-color);
                    position: relative;
                    z-index: 1;
                    text-shadow: 0 2px 10px rgba(255, 193, 7, 0.3);
                }

                .logo-text {
                    font-family: 'Poppins', sans-serif;
                    font-weight: 700;
                    letter-spacing: 1px;
                    margin: 1rem 0 0;
                    background: linear-gradient(90deg, #fff, #f8f9fa);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    text-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    position: relative;
                    display: inline-block;
                }

                .logo-text::after {
                    content: '';
                    position: absolute;
                    bottom: -8px;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 40px;
                    height: 3px;
                    background: var(--accent-color);
                    border-radius: 3px;
                }
                </style>
                
                <div class="text-center mb-5">
                    <div class="d-flex flex-column align-items-center">
                        <?php 
                        // Get user initials for avatar
                        $name_parts = explode(' ', $user['name']);
                        $initials = '';
                        foreach ($name_parts as $part) {
                            $initials .= strtoupper(substr($part, 0, 1));
                            if (strlen($initials) >= 2) break; // Limit to 2 characters
                        }
                        $colors = ['#e67e22', '#2c3e50', '#e74c3c', '#3498db', '#9b59b6', '#1abc9c', '#f1c40f'];
                        $color = $colors[ord($initials[0]) % count($colors)];
                        ?>
                        <div class="position-relative d-inline-block">
                            <div class="avatar-container" style="width: 80px; height: 80px; background: linear-gradient(135deg, <?php echo $color; ?> 0%, <?php echo adjustBrightness($color, -20); ?> 100%); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: 600; border: 3px solid #ffc107;">
                                <?php echo $initials; ?>
                            </div>
                            <span class="position-absolute" style="bottom: 0; right: 0; background: #28a745; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; border: 2px solid white; transform: translate(5px, 5px);">
                                <i class="fas fa-check" style="font-size: 0.7rem;"></i>
                            </span>
                        </div>
                        <h5 class="text-white mt-2 mb-0"><?php echo htmlspecialchars($user['name']); ?></h5>
                        <span class="badge bg-warning text-dark">Pastor</span>
                    </div>
                </div>
                <nav class="nav flex-column mb-4">
                    <a class="nav-link active" href="#">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                        <i class="fas fa-chevron-right float-end mt-1 small"></i>
                    </a>
                    <a class="nav-link" href="../sermons/upload.php">
                        <i class="fas fa-bible"></i> Sermons
                    </a>
                    <a class="nav-link" href="../announcements/post.php">
                        <i class="fas fa-bullhorn"></i> Announcements
                    </a>
                    <a class="nav-link" href="../events/create.php">
                        <i class="fas fa-calendar"></i> Events
                    </a>
                    <a class="nav-link" href="../attendance/summary.php">
                        <i class="fas fa-chart-line"></i> Attendance
                    </a>
                    <a class="nav-link position-relative" href="../feedback/view.php">
                        <i class="fas fa-comments"></i> Feedback
                        <?php if ($unread_feedback_count > 0): ?>
                            <span class="position-absolute top-50 end-0 translate-middle badge rounded-pill bg-danger">
                                <?php echo $unread_feedback_count; ?>
                                <span class="visually-hidden">unread messages</span>
                            </span>
                        <?php endif; ?>
                    </a>
                    <a class="nav-link" href="../donations/verify.php">
                        <i class="fas fa-check-circle"></i> Donations
                    </a>
                    <a class="nav-link" href="../counseling/">
                        <i class="fas fa-hands-helping"></i> Counseling
                    </a>
                </nav>
                
                <div class="position-absolute bottom-0 start-0 w-100 p-3 bg-dark">
                    <a class="nav-link text-white" href="../profile.php">
                        <i class="fas fa-user-circle me-2"></i> My Profile
                    </a>
                    <a class="nav-link text-white" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10">
            <div class="main-content">
                <!-- Welcome Section -->
                <div class="welcome-card mb-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2>Welcome back, <?php echo htmlspecialchars(explode(' ', $user['name'])[0]); ?>! 👋</h2>
                            <p>Here's what's happening with your ministry today.</p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <a href="../index.php" class="btn btn-primary text-uppercase fw-bold px-4 py-2" style="font-family: 'Montserrat', sans-serif; letter-spacing: 0.5px; background-color: #e67e22; border: none; transition: all 0.3s ease; text-decoration: none;" id="homeButton">
                                <i class="fas fa-home me-2"></i>Back to Home
                            </a>
                            <script>
                                // Debug: Log the current path and button click
                                console.log('Current path:', window.location.pathname);
                                document.getElementById('homeButton').addEventListener('click', function(e) {
                                    console.log('Button clicked, navigating to:', this.href);
                                });
                            </script>
                            <style>
                                .btn-primary:hover {
                                    background-color: #d35400 !important;
                                    transform: translateY(-2px);
                                    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                                }
                            </style>
                        </div>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row g-4 mb-4">
                    <!-- Sermons Card -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card position-relative p-4 text-center overflow-hidden" 
                             style="background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%); 
                                    border-radius: 15px; 
                                    box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
                                    transition: all 0.3s ease; 
                                    border: 1px solid rgba(230,126,34,0.1);">
                            <!-- Decorative elements -->
                            <div class="position-absolute top-0 end-0 w-100 h-100" style="background: radial-gradient(circle at 90% 10%, rgba(230,126,34,0.03) 0%, transparent 40%);"></div>
                            
                            <!-- Icon with gradient background -->
                            <div class="icon-wrapper d-inline-flex align-items-center justify-content-center mb-3" 
                                 style="width: 70px; height: 70px; 
                                        background: linear-gradient(135deg, rgba(230,126,34,0.1) 0%, rgba(255,215,0,0.1) 100%); 
                                        border-radius: 20px; position: relative; overflow: hidden;">
                                <i class="fas fa-bible text-primary" style="font-size: 1.75rem; position: relative; z-index: 2;"></i>
                                <div class="position-absolute top-0 start-0 w-100 h-100" style="background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSgzMCkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyMzAsMTI2LDM0LDAuMDUpIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI3BhdHRlcm4pIi8+PC9zdmc+');"></div>
                            </div>
                            
                            <!-- Counter with animation -->
                            <div class="mb-2">
                                <h3 class="display-5 fw-bold mb-0 counter" data-target="<?php echo $sermons_count; ?>" style="background: linear-gradient(135deg, #e67e22 0%, #d35400 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; position: relative; display: inline-block;">0</h3>
                            </div>
                            
                            <!-- Title with decorative underline -->
                            <h5 class="mb-4 position-relative d-inline-block" style="color: #2c3e50;">
                                Sermons
                                <span style="position: absolute; bottom: -8px; left: 0; width: 40%; height: 3px; background: linear-gradient(90deg, #e67e22, #ffd700); border-radius: 3px;"></span>
                            </h5>
                            
                            <!-- Action button -->
                            <div class="mt-3">
                                <a href="../sermons/upload.php" class="btn btn-primary btn-sm px-3 py-2" 
                                   style="background: linear-gradient(135deg, #e67e22 0%, #d35400 100%); border: none; 
                                          border-radius: 50px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;
                                          position: relative; overflow: hidden; transition: all 0.3s ease;
                                          box-shadow: 0 4px 15px rgba(230,126,34,0.3);">
                                    <i class="fas fa-plus me-2"></i> Add New
                                    <span style="position: absolute; top: 50%; left: 50%; width: 0; height: 0; background: rgba(255,255,255,0.2); border-radius: 50%; transform: translate(-50%, -50%); transition: width 0.6s ease 0s, height 0.6s ease 0s, opacity 0.6s ease 0s; opacity: 0;"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Announcements Card -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card position-relative p-4 text-center overflow-hidden" 
                             style="background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%); 
                                    border-radius: 15px; 
                                    box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
                                    transition: all 0.3s ease; 
                                    border: 1px solid rgba(46, 204, 113, 0.1);">
                            <!-- Decorative elements -->
                            <div class="position-absolute top-0 end-0 w-100 h-100" style="background: radial-gradient(circle at 90% 10%, rgba(46, 204, 113, 0.03) 0%, transparent 40%);"></div>
                            
                            <!-- Icon with gradient background -->
                            <div class="icon-wrapper d-inline-flex align-items-center justify-content-center mb-3" 
                                 style="width: 70px; height: 70px; 
                                        background: linear-gradient(135deg, rgba(46, 204, 113, 0.1) 0%, rgba(52, 152, 219, 0.1) 100%); 
                                        border-radius: 20px; position: relative; overflow: hidden;">
                                <i class="fas fa-bullhorn text-success" style="font-size: 1.75rem; position: relative; z-index: 2;"></i>
                                <div class="position-absolute top-0 start-0 w-100 h-100" style="background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSgzMCkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSg0NiwgMjA0LCAxMTMsIDAuMDUpIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI3BhdHRlcm4pIi8+PC9zdmc+');"></div>
                            </div>
                            
                            <!-- Counter with animation -->
                            <div class="mb-2">
                                <h3 class="display-5 fw-bold mb-0 counter" data-target="<?php echo $announcements_count; ?>" style="background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; position: relative; display: inline-block;">0</h3>
                            </div>
                            
                            <!-- Title with decorative underline -->
                            <h5 class="mb-4 position-relative d-inline-block" style="color: #2c3e50;">
                                Announcements
                                <span style="position: absolute; bottom: -8px; left: 0; width: 40%; height: 3px; background: linear-gradient(90deg, #2ecc71, #3498db); border-radius: 3px;"></span>
                            </h5>
                            
                            <!-- Action button -->
                            <div class="mt-3">
                                <a href="../announcements/post.php" class="btn btn-success btn-sm px-3 py-2" 
                                   style="background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%); border: none; 
                                          border-radius: 50px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;
                                          position: relative; overflow: hidden; transition: all 0.3s ease;
                                          box-shadow: 0 4px 15px rgba(46, 204, 113, 0.3);">
                                    <i class="fas fa-plus me-2"></i> Create New
                                    <span style="position: absolute; top: 50%; left: 50%; width: 0; height: 0; background: rgba(255,255,255,0.2); border-radius: 50%; transform: translate(-50%, -50%); transition: width 0.6s ease 0s, height 0.6s ease 0s, opacity 0.6s ease 0s; opacity: 0;"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Events Card -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card position-relative p-4 text-center overflow-hidden" 
                             style="background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%); 
                                    border-radius: 15px; 
                                    box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
                                    transition: all 0.3s ease; 
                                    border: 1px solid rgba(241, 196, 15, 0.1);">
                            <!-- Decorative elements -->
                            <div class="position-absolute top-0 end-0 w-100 h-100" style="background: radial-gradient(circle at 90% 10%, rgba(241, 196, 15, 0.03) 0%, transparent 40%);"></div>
                            
                            <!-- Icon with gradient background -->
                            <div class="icon-wrapper d-inline-flex align-items-center justify-content-center mb-3" 
                                 style="width: 70px; height: 70px; 
                                        background: linear-gradient(135deg, rgba(241, 196, 15, 0.1) 0%, rgba(230, 126, 34, 0.1) 100%); 
                                        border-radius: 20px; position: relative; overflow: hidden;">
                                <i class="fas fa-calendar text-warning" style="font-size: 1.75rem; position: relative; z-index: 2;"></i>
                                <div class="position-absolute top-0 start-0 w-100 h-100" style="background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSgzMCkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNDEsIDE5NiwgMTUsIDAuMDUpIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI3BhdHRlcm4pIi8+PC9zdmc+');"></div>
                            </div>
                            
                            <!-- Counter with animation -->
                            <div class="mb-2">
                                <h3 class="display-5 fw-bold mb-0 counter" data-target="<?php echo $events_count; ?>" style="background: linear-gradient(135deg, #f1c40f 0%, #e67e22 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; position: relative; display: inline-block;">0</h3>
                            </div>
                            
                            <!-- Title with decorative underline -->
                            <h5 class="mb-4 position-relative d-inline-block" style="color: #2c3e50;">
                                Upcoming Events
                                <span style="position: absolute; bottom: -8px; left: 0; width: 40%; height: 3px; background: linear-gradient(90deg, #f1c40f, #e67e22); border-radius: 3px;"></span>
                            </h5>
                            
                            <!-- Action button -->
                            <div class="mt-3">
                                <a href="../events/create.php" class="btn btn-warning btn-sm px-3 py-2 text-white" 
                                   style="background: linear-gradient(135deg, #f1c40f 0%, #e67e22 100%); border: none; 
                                          border-radius: 50px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;
                                          position: relative; overflow: hidden; transition: all 0.3s ease;
                                          box-shadow: 0 4px 15px rgba(241, 196, 15, 0.3);">
                                    <i class="fas fa-plus me-2"></i> Schedule Event
                                    <span style="position: absolute; top: 50%; left: 50%; width: 0; height: 0; background: rgba(255,255,255,0.2); border-radius: 50%; transform: translate(-50%, -50%); transition: width 0.6s ease 0s, height 0.6s ease 0s, opacity 0.6s ease 0s; opacity: 0;"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Members Card -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card position-relative p-4 text-center overflow-hidden" 
                             style="background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%); 
                                    border-radius: 15px; 
                                    box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
                                    transition: all 0.3s ease; 
                                    border: 1px solid rgba(52, 152, 219, 0.1);">
                            <!-- Decorative elements -->
                            <div class="position-absolute top-0 end-0 w-100 h-100" style="background: radial-gradient(circle at 90% 10%, rgba(52, 152, 219, 0.03) 0%, transparent 40%);"></div>
                            
                            <!-- Icon with gradient background -->
                            <div class="icon-wrapper d-inline-flex align-items-center justify-content-center mb-3" 
                                 style="width: 70px; height: 70px; 
                                        background: linear-gradient(135deg, rgba(52, 152, 219, 0.1) 0%, rgba(155, 89, 182, 0.1) 100%); 
                                        border-radius: 20px; position: relative; overflow: hidden;">
                                <i class="fas fa-users text-info" style="font-size: 1.75rem; position: relative; z-index: 2;"></i>
                                <div class="position-absolute top-0 start-0 w-100 h-100" style="background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSgzMCkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSg1MiwgMTUyLCAyMTksIDAuMDUpIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI3BhdHRlcm4pIi8+PC9zdmc+');"></div>
                            </div>
                            
                            <!-- Counter with animation -->
                            <div class="mb-2">
                                <h3 class="display-5 fw-bold mb-0 counter" data-target="<?php echo $members_count; ?>" style="background: linear-gradient(135deg, #3498db 0%, #9b59b6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; position: relative; display: inline-block;">0</h3>
                            </div>
                            
                            <!-- Title with decorative underline -->
                            <h5 class="mb-4 position-relative d-inline-block" style="color: #2c3e50;">
                                Church Members
                                <span style="position: absolute; bottom: -8px; left: 0; width: 40%; height: 3px; background: linear-gradient(90deg, #3498db, #9b59b6); border-radius: 3px;"></span>
                            </h5>
                            
                            <!-- Action button -->
                            <div class="mt-3">
                                <a href="../members.php" class="btn btn-info btn-sm px-3 py-2 text-white" 
                                   style="background: linear-gradient(135deg, #3498db 0%, #9b59b6 100%); border: none; 
                                          border-radius: 50px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;
                                          position: relative; overflow: hidden; transition: all 0.3s ease;
                                          box-shadow: 0 4px 15px rgba(52, 152, 219, 0.3);">
                                    <i class="fas fa-search me-2"></i> View All
                                    <span style="position: absolute; top: 50%; left: 50%; width: 0; height: 0; background: rgba(255,255,255,0.2); border-radius: 50%; transform: translate(-50%, -50%); transition: width 0.6s ease 0s, height 0.6s ease 0s, opacity 0.6s ease 0s; opacity: 0;"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Add animation script -->
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Animate counters
                        const counters = document.querySelectorAll('.counter');
                        const speed = 2000; // The lower the faster
                        
                        counters.forEach(counter => {
                            const target = parseInt(counter.getAttribute('data-target'));
                            const count = 0;
                            const increment = target / (speed / 16); // 60fps
                            
                            const updateCount = () => {
                                const count = parseInt(counter.innerText);
                                if (count < target) {
                                    counter.innerText = Math.ceil(count + increment);
                                    setTimeout(updateCount, 1);
                                } else {
                                    counter.innerText = target;
                                }
                            };
                            
                            // Start counter when element is in viewport
                            const observer = new IntersectionObserver((entries) => {
                                if (entries[0].isIntersecting) {
                                    updateCount();
                                    observer.disconnect();
                                }
                            });
                            
                            observer.observe(counter);
                        });
                        
                        // Add hover effects to cards
                        const statCards = document.querySelectorAll('.stat-card');
                        statCards.forEach(card => {
                            card.addEventListener('mouseenter', function() {
                                this.style.transform = 'translateY(-5px)';
                                this.style.boxShadow = '0 15px 35px rgba(0,0,0,0.1)';
                            });
                            
                            card.addEventListener('mouseleave', function() {
                                this.style.transform = 'translateY(0)';
                                this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.05)';
                            });
                            
                            // Add ripple effect to buttons
                            const buttons = card.querySelectorAll('a.btn');
                            buttons.forEach(button => {
                                button.addEventListener('mouseenter', function(e) {
                                    const rect = this.getBoundingClientRect();
                                    const x = e.clientX - rect.left;
                                    const y = e.clientY - rect.top;
                                    
                                    const ripple = this.querySelector('span');
                                    ripple.style.left = x + 'px';
                                    ripple.style.top = y + 'px';
                                    ripple.style.width = '300%';
                                    ripple.style.height = '300%';
                                    ripple.style.opacity = '1';
                                    
                                    setTimeout(() => {
                                        ripple.style.width = '0';
                                        ripple.style.height = '0';
                                        ripple.style.opacity = '0';
                                    }, 600);
                                });
                            });
                        });
                    });
                </script>

                <!-- Quick Actions & Calendar -->
                <div class="row g-4 mb-4">
                    <div class="col-lg-8">
                        <div class="card h-100">
                            <div class="card-header">
                                <h5><i class="fas fa-calendar-alt me-2"></i>Upcoming Events</h5>
                            </div>
                            <div class="card-body p-0">
                                <?php
                                $upcoming_events_result = $conn->query("
                                    SELECT title, description, event_date, start_time 
                                    FROM events 
                                    WHERE event_date >= CURDATE() 
                                    ORDER BY event_date ASC, start_time ASC 
                                    LIMIT 5
                                ");
                                $upcoming_events = [];
                                if ($upcoming_events_result) {
                                    while($row = $upcoming_events_result->fetch_assoc()) {
                                        $upcoming_events[] = $row;
                                    }
                                }
                                ?>
                                
                                <?php if (!empty($upcoming_events)): ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($upcoming_events as $event): ?>
                                            <div class="list-group-item border-0 py-3">
                                                <div class="d-flex align-items-center">
                                                    <div class="me-3 text-center">
                                                        <div class="text-uppercase text-muted small"><?php echo date('M', strtotime($event['event_date'])); ?></div>
                                                        <div class="h4 mb-0 fw-bold text-primary"><?php echo date('d', strtotime($event['event_date'])); ?></div>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="mb-1"><?php echo htmlspecialchars($event['title']); ?></h6>
                                                        <p class="text-muted small mb-0">
                                                            <i class="far fa-clock me-1"></i> 
                                                            <?php echo date('g:i A', strtotime($event['start_time'])); ?>
                                                        </p>
                                                    </div>
                                                    <div class="ms-3">
                                                        <span class="badge bg-light text-dark"><?php echo date('D', strtotime($event['event_date'])); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center p-5">
                                        <div class="mb-3">
                                            <i class="fas fa-calendar-day fa-3x text-muted"></i>
                                        </div>
                                        <h5>No Upcoming Events</h5>
                                        <p class="text-muted">You don't have any events scheduled yet.</p>
                                        <a href="../events/create.php" class="btn btn-primary">
                                            <i class="fas fa-plus me-2"></i>Create Event
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-transparent border-top">
                                <a href="../events/" class="btn btn-sm btn-outline-primary">
                                    View All Events <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card h-100">
                            <div class="card-header">
                                <h5><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body p-0">
                                <div class="d-grid gap-2 p-3">
                                    <a href="../sermons/upload.php" class="btn btn-outline-primary text-start py-3">
                                        <i class="fas fa-bible me-2"></i> Upload New Sermon
                                    </a>
                                    <a href="../announcements/post.php" class="btn btn-outline-success text-start py-3">
                                        <i class="fas fa-bullhorn me-2"></i> Send Announcement
                                    </a>
                                    <a href="../events/create.php" class="btn btn-outline-warning text-start py-3">
                                        <i class="fas fa-calendar-plus me-2"></i> Schedule Event
                                    </a>
                                    <a href="../counseling/" class="btn btn-outline-info text-start py-3">
                                        <i class="fas fa-hands-helping me-2"></i> Counseling Session
                                    </a>
                                    <a href="../attendance/summary.php" class="btn btn-outline-secondary text-start py-3">
                                        <i class="fas fa-chart-pie me-2"></i> View Attendance
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><i class="fas fa-history me-2"></i>Recent Activities</h5>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary active">All</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary">Sermons</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary">Announcements</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="list-group list-group-flush">
                                    <?php
                                    // Get recent sermons
                                    $recent_sermons = [];
                                    $sermons_result = $conn->query("
                                        SELECT 'sermon' as type, title, created_at as date, CONCAT('/sermons/view.php?id=', id) as link 
                                        FROM sermons 
                                        WHERE uploaded_by = {$user['id']} 
                                        ORDER BY created_at DESC 
                                        LIMIT 3
                                    ");
                                    if ($sermons_result) {
                                        while($row = $sermons_result->fetch_assoc()) {
                                            $recent_sermons[] = $row;
                                        }
                                    }
                                    
                                    // Get recent announcements
                                    $recent_announcements = [];
                                    $announcements_result = $conn->query("
                                        SELECT 'announcement' as type, title, created_at as date, CONCAT('/announcements/view.php?id=', id) as link 
                                        FROM announcements 
                                        WHERE posted_by = {$user['id']} 
                                        ORDER BY created_at DESC 
                                        LIMIT 2
                                    ");
                                    if ($announcements_result) {
                                        while($row = $announcements_result->fetch_assoc()) {
                                            $recent_announcements[] = $row;
                                        }
                                    }
                                    
                                    // Combine and sort by date
                                    $recent_activities = array_merge($recent_sermons, $recent_announcements);
                                    usort($recent_activities, function($a, $b) {
                                        return strtotime($b['date']) - strtotime($a['date']);
                                    });
                                    
                                    if (!empty($recent_activities)):
                                        foreach ($recent_activities as $activity):
                                            $icon = $activity['type'] === 'sermon' ? 'bible' : 'bullhorn';
                                            $color = $activity['type'] === 'sermon' ? 'primary' : 'success';
                                            $type = ucfirst($activity['type']);
                                    ?>
                                    <a href="<?php echo $activity['link']; ?>" class="list-group-item list-group-item-action border-0 py-3">
                                        <div class="d-flex align-items-center">
                                            <div class="icon-wrapper bg-<?php echo $color; ?>-subtle text-<?php echo $color; ?> me-3">
                                                <i class="fas fa-<?php echo $icon; ?>"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($activity['title']); ?></h6>
                                                    <small class="text-muted"><?php echo date('M d, Y', strtotime($activity['date'])); ?></small>
                                                </div>
                                                <p class="mb-0 small text-muted">
                                                    <span class="badge bg-<?php echo $color; ?>-subtle text-<?php echo $color; ?> me-2"><?php echo $type; ?></span>
                                                    <?php echo date('g:i A', strtotime($activity['date'])); ?>
                                                </p>
                                            </div>
                                        </div>
                                    </a>
                                    <?php 
                                        endforeach;
                                    else:
                                    ?>
                                    <div class="text-center p-5">
                                        <div class="mb-3">
                                            <i class="fas fa-inbox fa-3x text-muted"></i>
                                        </div>
                                        <h5>No Recent Activities</h5>
                                        <p class="text-muted">Your recent activities will appear here.</p>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent border-top">
                                <a href="#" class="btn btn-sm btn-outline-primary">
                                    View All Activities <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <!-- Feedback Summary -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-comment-dots me-2"></i>Recent Feedback</h5>
                            </div>
                            <div class="card-body p-0">
                                <?php
                                $recent_feedback = [];
                                $feedback_result = $conn->query(
                                    "SELECT f.message, f.created_at, u.name as user_name 
                                    FROM feedback f 
                                    JOIN users u ON f.user_id = u.id 
                                    ORDER BY f.created_at DESC 
                                    LIMIT 3"
                                );
                                
                                if ($feedback_result) {
                                    while($row = $feedback_result->fetch_assoc()) {
                                        $recent_feedback[] = $row;
                                    }
                                }
                                ?>
                                
                                <?php if (!empty($recent_feedback)): ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($recent_feedback as $feedback): ?>
                                            <div class="list-group-item border-0 py-3">
                                                <div class="d-flex">
                                                    <div class="flex-shrink-0 me-3">
                                                        <div class="avatar bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                            <?php echo strtoupper(substr($feedback['user_name'], 0, 1)); ?>
                                                        </div>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="mb-1"><?php echo htmlspecialchars($feedback['user_name']); ?></h6>
                                                        <p class="small text-muted mb-1"><?php echo substr(htmlspecialchars($feedback['message']), 0, 60) . '...'; ?></p>
                                                        <small class="text-muted"><?php echo date('M d, Y', strtotime($feedback['created_at'])); ?></small>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center p-4">
                                        <div class="mb-3">
                                            <i class="fas fa-comment-slash fa-3x text-muted"></i>
                                        </div>
                                        <h6>No Feedback Yet</h6>
                                        <p class="small text-muted mb-0">Your congregation's feedback will appear here.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-transparent border-top">
                                <a href="../feedback/view.php?user_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-outline-primary w-100">
                                    View All Feedback
                                    <span class="badge bg-danger ms-2"><?php echo $unread_feedback_count > 0 ? $unread_feedback_count . ' New' : 'View All'; ?></span>
                                </a>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Quick Stats</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="small text-muted">Sermon Views</span>
                                        <span class="small fw-bold">1,254</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="small text-muted">Event Attendance</span>
                                        <span class="small fw-bold">85%</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div>
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="small text-muted">Member Engagement</span>
                                        <span class="small fw-bold">92%</span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 92%" aria-valuenow="92" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add AOS Animation Library -->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="../assets/js/main.js"></script>

<script>
    // Initialize AOS animation
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true
    });
    
    // Update current time
    function updateCurrentTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        const dateString = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        
        const timeElement = document.getElementById('current-time');
        const dateElement = document.getElementById('current-date');
        
        if (timeElement) timeElement.textContent = timeString;
        if (dateElement) dateElement.textContent = dateString;
    }
    
    // Update time every minute
    updateCurrentTime();
    setInterval(updateCurrentTime, 60000);
    
    // Add active class to current nav item
    document.addEventListener('DOMContentLoaded', function() {
        const currentPage = window.location.pathname.split('/').pop() || 'index.php';
        document.querySelectorAll('.nav-link').forEach(link => {
            const linkHref = link.getAttribute('href');
            if (linkHref && linkHref.includes(currentPage)) {
                link.classList.add('active');
            }
        });
    });
</script>

</body>
</html> 