<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin']);
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
    $service_date = $_POST['service_date'];
    $service_type = $_POST['service_type'];
    $member_ids = $_POST['member_ids'] ?? [];
    $notes = trim($_POST['notes']);

    if ($service_date && $service_type) {
        // Save attendance record using file-based system
        $attendance_data = [
            'id' => time(), // Use timestamp as ID
            'service_date' => $service_date,
            'service_type' => $service_type,
            'marked_by' => $user['id'],
            'notes' => $notes,
            'created_at' => date('Y-m-d H:i:s'),
            'members' => $member_ids
        ];
        
        if ($conn->saveAttendance($attendance_data)) {
            // Clear the form by redirecting to prevent resubmission
            $_SESSION['success_message'] = 'Attendance marked successfully!';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit();
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error marking attendance: ' . $conn->error . '</div>';
        }
    } else {
        $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
    }
}
}

// Get all members and store in array
$members_result = $conn->getMembersWithMinistry();
$members = [];
if ($members_result) {
    $members = $members_result->fetchAll();
    // Ensure all members have the required fields
    foreach ($members as &$member) {
        $member['name'] = $member['name'] ?? 'Unknown Member';
        $member['email'] = $member['email'] ?? '';
        $member['ministry'] = $member['ministry'] ?? 'Not Specified';
    }
    unset($member); // Break the reference
}

// Debug: Output members to check if they're being fetched
// echo "<pre>" . print_r($members, true) . "</pre>";

// Start output buffering to handle redirects
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance - Apostolic Church Louisville</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333;
            --text-light: #7f8c8d;
        }
        body {
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text);
            background-color: #f5f7fa;
        }
        .navbar {
            background-color: var(--secondary) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            color: white !important;
        }
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .card-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-hover));
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }
        .card-header h3 {
            margin: 0;
            font-weight: 700;
            font-family: 'Montserrat', sans-serif;
        }
        .form-control, .form-select {
            border-radius: 8px;
            padding: 0.75rem 1rem;
            border: 1px solid #e1e5ee;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border: none;
            border-radius: 8px;
            padding: 0.75rem 1.5rem;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .table thead th {
            background-color: var(--light);
            border-bottom: 2px solid #e1e5ee;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            color: var(--text-light);
        }
        .table-hover tbody tr:hover {
            background-color: rgba(230, 126, 34, 0.05);
        }
        .badge-ministry {
            background-color: rgba(44, 62, 80, 0.1);
            color: var(--secondary);
            font-weight: 500;
            padding: 0.35em 0.65em;
            border-radius: 6px;
            font-size: 0.8rem;
        }
        .form-check-input:checked {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        .attendance-stats {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .stat-card {
            text-align: center;
            padding: 1rem;
            border-radius: 10px;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0.5rem 0;
            font-family: 'Montserrat', sans-serif;
        }
        .stat-label {
            color: var(--text-light);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .member-photo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            border: 2px solid #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .member-name {
            font-weight: 500;
            color: var(--dark);
        }
        .member-ministry {
            font-size: 0.8rem;
            color: var(--text-light);
        }
        .search-box {
            position: relative;
            margin-bottom: 1.5rem;
        }
        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }
        .search-box input {
            padding-left: 45px;
            border-radius: 50px !important;
            border: 1px solid #e1e5ee;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Apostolic Church Louisville
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard/<?php echo $user['role']; ?>.php">
                            <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="mark.php">
                            <i class="fas fa-clipboard-check me-1"></i> Attendance
                        </a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="text-white me-3 d-none d-md-block">
                        <div class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></div>
                        <div class="small text-white-50"><?php echo ucfirst($user['role']); ?></div>
                    </div>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                                <div class="d-flex align-items-center">
                                    <div class="position-relative">
                                        <i class="fas fa-user-circle" style="font-size: 1.8rem;"></i>
                                    </div>
                                </div>
                            </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2"></i>My Profile</a></li>
                            <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1" style="font-family: 'Montserrat', sans-serif; font-weight: 700; color: var(--dark);">
                    <i class="fas fa-book me-2" style="color: var(--primary);"></i>Attendance Register
                </h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="../dashboard/<?php echo $user['role']; ?>.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Attendance Register</li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex">
                <button type="button" class="btn btn-outline-secondary me-2" onclick="window.print()">
                    <i class="fas fa-print me-2"></i>Print
                </button>
                <button type="submit" form="attendanceForm" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i>Save Register
                </button>
            </div>
        </div>

        <?php 
        // Show success message if set
        if (isset($_SESSION['success_message'])): 
        ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?php 
            echo htmlspecialchars($_SESSION['success_message']);
            unset($_SESSION['success_message']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($message)) echo $message; ?>

        <div class="register-book">
            <div class="register-header">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="register-title">
                        <h3 class="mb-0">
                            <i class="fas fa-calendar-alt me-2"></i>Service Details
                        </h3>
                        <p class="text-muted mb-0 small">Fill in the service information to begin</p>
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <span class="badge bg-light text-dark">
                                <i class="fas fa-users me-1"></i>
                                <span id="totalMembers"><?php echo count($members); ?></span> Total Members
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="register-details">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label fw-medium text-muted mb-1">SERVICE DATE</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-calendar-day text-primary"></i></span>
                                    <input type="date" name="service_date" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label fw-medium text-muted mb-1">SERVICE TYPE</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-church text-primary"></i></span>
                                    <select name="service_type" class="form-select" required>
                                        <option value="" disabled selected>Select service type</option>
                                        <option value="sunday_morning">Sunday Morning Service</option>
                                        <option value="sunday_evening">Sunday Evening Service</option>
                                        <option value="wednesday_prayer">Wednesday Prayer Meeting</option>
                                        <option value="bible_study">Bible Study</option>
                                        <option value="youth_service">Youth Service</option>
                                        <option value="prayer_meeting">Prayer Meeting</option>
                                        <option value="special_event">Special Event</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label fw-medium text-muted mb-1">PRESENT</label>
                                <div class="d-flex align-items-center">
                                    <div class="flex-grow-1 text-center">
                                        <h2 class="mb-0 text-primary" id="presentCount">0</h2>
                                        <small class="text-muted">Members Present</small>
                                    </div>
                                    <div class="vr mx-3"></div>
                                    <div class="text-center">
                                        <h2 class="mb-0" id="attendancePercentage">0%</h2>
                                        <small class="text-muted">Attendance</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label fw-medium text-muted mb-1">NOTES</label>
                                <textarea name="notes" class="form-control" rows="2" placeholder="Add any notes about this service..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="register-body">
                <div class="register-toolbar">
                    <div class="d-flex justify-content-between align-items-center py-2">
                        <div class="d-flex align-items-center">
                            <div class="input-group me-3" style="max-width: 300px;">
                                <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
                                <input type="text" id="memberSearch" class="form-control border-start-0 ps-0" placeholder="Search members...">
                                <button class="btn btn-outline-secondary" type="button" id="clearSearch">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                            
                            <div class="btn-group me-3" role="group">
                                <button type="button" class="btn btn-outline-secondary" id="selectAllMembers">
                                    <i class="fas fa-check-double me-1"></i> Select All
                                </button>
                                <button type="button" class="btn btn-outline-secondary" id="clearSelection">
                                    <i class="fas fa-undo me-1"></i> Clear
                                </button>
                            </div>
                            
                            <div class="dropdown
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-filter me-1"></i> Filter
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="filterDropdown">
                                <li><a class="dropdown-item" href="#" data-filter="all">All Members</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><h6 class="dropdown-header">By Ministry</h6></li>
                                <?php
                                $all_ministries = array_unique(array_column($members, 'ministry'));
                                sort($all_ministries);
                                foreach($all_ministries as $m): 
                                    if (!empty($m)): 
                                ?>
                                <li>
                                    <a class="dropdown-item" href="#" data-filter="ministry" data-value="<?php echo htmlspecialchars($m); ?>">
                                        <?php echo htmlspecialchars($m); ?>
                                    </a>
                                </li>
                                <?php 
                                    endif;
                                endforeach; 
                                ?>
                            </ul>
                        </div>
                        </div>
                        
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 me-3">
                                <i class="fas fa-user-check me-1"></i>
                                <span id="selectedCount">0</span> selected
                            </span>
                            
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-outline-secondary" id="viewList">
                                    <i class="fas fa-list"></i>
                                </button>
                                <button type="button" class="btn btn-outline-secondary active" id="viewGrid">
                                    <i class="fas fa-th-large"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="register-content" id="registerContent">
                    <div class="row g-3" id="memberGrid">
                        <?php 
                        // Sort members alphabetically by name
                        usort($members, function($a, $b) {
                            return strcmp($a['name'], $b['name']);
                        });
                        
                        foreach($members as $index => $member): 
                            $ministry = $member['ministry'] ?: 'Not Specified';
                            $first_letter = strtoupper(substr($member['name'], 0, 1));
                            $colors = ['#e67e22', '#2c3e50', '#3498db', '#9b59b6', '#e74c3c', '#1abc9c', '#f39c12'];
                            $color = $colors[ord($first_letter) % count($colors)];
                        ?>
                        <div class="col-xxl-2 col-lg-3 col-md-4 col-sm-6" data-name="<?php echo strtolower(htmlspecialchars($member['name'])); ?>" data-ministry="<?php echo htmlspecialchars($ministry); ?>">
                            <div class="member-card">
                                <div class="member-avatar" style="background-color: <?php echo $color; ?>20; color: <?php echo $color; ?>">
                                    <?php echo $first_letter; ?>
                                </div>
                                <div class="member-details">
                                    <h6 class="member-name"><?php echo htmlspecialchars($member['name']); ?></h6>
                                    <div class="member-ministry">
                                        <i class="fas fa-users me-1"></i>
                                        <?php echo htmlspecialchars($ministry); ?>
                                    </div>
                                </div>
                                <div class="member-actions">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input member-present" 
                                               type="checkbox" 
                                               role="switch" 
                                               id="present_<?php echo $member['id']; ?>"
                                               data-member-id="<?php echo $member['id']; ?>">
                                        <input type="hidden" name="member_ids[]" value="" class="member-checkbox" id="member_<?php echo $member['id']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="table-responsive d-none" id="memberTable">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th width="50">#</th>
                                    <th>MEMBER NAME</th>
                                    <th>MINISTRY</th>
                                    <th class="text-end">PRESENT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($members as $index => $member): 
                                    $ministry = $member['ministry'] ?: 'Not Specified';
                                ?>
                                <tr data-name="<?php echo strtolower(htmlspecialchars($member['name'])); ?>" data-ministry="<?php echo htmlspecialchars($ministry); ?>">
                                    <td class="text-muted"><?php echo $index + 1; ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="member-avatar-sm me-3" style="background-color: <?php echo $colors[ord(strtoupper(substr($member['name'], 0, 1))) % count($colors)]; ?>20; color: <?php echo $colors[ord(strtoupper(substr($member['name'], 0, 1))) % count($colors)]; ?>">
                                                <?php echo strtoupper(substr($member['name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="fw-medium"><?php echo htmlspecialchars($member['name']); ?></div>
                                                <small class="text-muted"><?php echo htmlspecialchars($member['email'] ?? ''); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark">
                                            <i class="fas fa-users me-1"></i>
                                            <?php echo htmlspecialchars($ministry); ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <div class="form-check form-switch d-inline-block">
                                            <input class="form-check-input member-present" 
                                                   type="checkbox" 
                                                   role="switch" 
                                                   id="present_<?php echo $member['id']; ?>_table"
                                                   data-member-id="<?php echo $member['id']; ?>">
                                            <input type="hidden" name="member_ids[]" value="" class="member-checkbox" id="member_<?php echo $member['id']; ?>_table">
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .member-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            font-weight: 600;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        .member-avatar-sm {
            width: 36px;
            height: 36px;
            font-size: 1rem;
        }
        
        .member-details {
            flex-grow: 1;
            min-width: 0;
        }
        
        .member-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .member-ministry {
            font-size: 0.75rem;
            color: #6c757d;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .member-actions {
            margin-left: 0.5rem;
            flex-shrink: 0;
        }
        
        .form-switch .form-check-input {
            width: 2.5em;
            margin-left: -2.5em;
        }
        
        .form-check-input:checked {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        @media print {
            .register-toolbar, .btn, .form-switch, .dropdown-menu {
                display: none !important;
            }
            
            .register-book {
                box-shadow: none;
                border: 1px solid #dee2e6;
            }
            
            .member-card {
                break-inside: avoid;
            }
        }
        </style>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="selectAllMembers">
                                    <label class="form-check-label fw-medium" for="selectAllMembers">
                                        Select All Visible
                                    </label>
                                </div>
                                <div>
                                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2">
                                        <i class="fas fa-user-check me-1"></i>
                                        <span id="selectedCount">0</span> selected
                                    </span>
                                </div>
                            </div>
                                
                                <div class="attendance-book">
                                    <!-- Search and Filter Bar -->
                                    <div class="row mb-3 g-2">
                                        <div class="col-md-6">
                                            <select class="form-select" id="ministryFilter">
                                                <option value="">All Ministries</option>
                                                <?php
                                                $all_ministries = array_unique(array_column($members, 'ministry'));
                                                sort($all_ministries);
                                                foreach($all_ministries as $m) {
                                                    if (!empty($m)) {
                                                        echo '<option value="' . htmlspecialchars($m) . '">' . htmlspecialchars($m) . '</option>';
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <!-- Attendance Table -->
                                    <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                                        <table class="table table-hover align-middle">
                                            <thead class="sticky-top bg-white">
                                                <tr>
                                                    <th width="50">
                                                        <div class="form-check
                                                            <input class="form-check-input" type="checkbox" id="selectAllMembers">
                                                        </div>
                                                    </th>
                                                    <th>Member Name</th>
                                                    <th>Ministry</th>
                                                    <th class="text-center">Present</th>
                                                </tr>
                                            </thead>
                                            <tbody class="member-list">
                                                <?php if (!empty($members)): ?>
                                                    <?php 
                                                    // Sort members alphabetically by name
                                                    usort($members, function($a, $b) {
                                                        return strcmp($a['name'], $b['name']);
                                                    });
                                                    
                                                    foreach($members as $member): 
                                                        $ministry = $member['ministry'] ?: 'Not Specified';
                                                    ?>
                                                    <tr class="member-row" data-name="<?php echo strtolower(htmlspecialchars($member['name'])); ?>" data-ministry="<?php echo htmlspecialchars($ministry); ?>">
                                                        <td>
                                                            <div class="form-check">
                                                                <input class="form-check-input member-checkbox" type="checkbox" name="member_ids[]" value="<?php echo $member['id']; ?>" id="member_<?php echo $member['id']; ?>">
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <label class="form-check-label fw-medium" for="member_<?php echo $member['id']; ?>">
                                                                <?php echo htmlspecialchars($member['name']); ?>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-secondary bg-opacity-10 text-secondary">
                                                                <?php echo htmlspecialchars($ministry); ?>
                                                            </span>
                                                        </td>
                                                        <td class="text-center">
                                                            <div class="form-check d-inline-block">
                                                                <input class="form-check-input member-present" type="checkbox" id="present_<?php echo $member['id']; ?>">
                                                                <label class="form-check-label" for="present_<?php echo $member['id']; ?>"></label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="4" class="text-center py-4">
                                                            <i class="fas fa-users-slash fa-3x text-muted mb-3 d-block"></i>
                                                            <p class="text-muted mb-0">No members registered yet.</p>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <div class="text-muted small">
                                            <span id="selectedCount">0</span> of <span id="totalMembers"><?php echo count($members); ?></span> members selected
                                        </div>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" id="clearSelection">
                                            <i class="fas fa-times me-1"></i> Clear Selection
                                        </button>
                                    </div>
                                </div>
                                
                                <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    const searchInput = document.getElementById('memberSearch');
                                    const ministryFilter = document.getElementById('ministryFilter');
                                    const memberRows = document.querySelectorAll('.member-row');
                                    const selectAllCheckbox = document.getElementById('selectAllMembers');
                                    const memberCheckboxes = document.querySelectorAll('.member-checkbox');
                                    const clearSelectionBtn = document.getElementById('clearSelection');
                                    const selectedCountEl = document.getElementById('selectedCount');
                                    
                                    // Update selected count
                                    function updateSelectedCount() {
                                        const selected = document.querySelectorAll('.member-checkbox:checked').length;
                                        selectedCountEl.textContent = selected;
                                    }
                                    
                                    // Search functionality
                                    function filterMembers() {
                                        const searchTerm = searchInput.value.toLowerCase();
                                        const selectedMinistry = ministryFilter.value;
                                        
                                        memberRows.forEach(row => {
                                            const name = row.getAttribute('data-name');
                                            const ministry = row.getAttribute('data-ministry');
                                            const matchesSearch = name.includes(searchTerm);
                                            const matchesMinistry = !selectedMinistry || ministry === selectedMinistry;
                                            
                                            if (matchesSearch && matchesMinistry) {
                                                row.style.display = '';
                                            } else {
                                                row.style.display = 'none';
                                            }
                                        });
                                        
                                        // Update select all state
                                        updateSelectAllState();
                                    }
                                    
                                    // Update select all checkbox state
                                    function updateSelectAllState() {
                                        const visibleCheckboxes = Array.from(document.querySelectorAll('.member-row:not([style*="display: none"]) .member-checkbox'));
                                        if (visibleCheckboxes.length === 0) {
                                            selectAllCheckbox.checked = false;
                                            selectAllCheckbox.indeterminate = false;
                                            return;
                                        }
                                        
                                        const checkedCount = visibleCheckboxes.filter(cb => cb.checked).length;
                                        selectAllCheckbox.checked = checkedCount === visibleCheckboxes.length;
                                        selectAllCheckbox.indeterminate = checkedCount > 0 && checkedCount < visibleCheckboxes.length;
                                    }
                                    
                                    // Event listeners
                                    searchInput.addEventListener('input', filterMembers);
                                    ministryFilter.addEventListener('change', filterMembers);
                                    
                                    selectAllCheckbox.addEventListener('change', function(e) {
                                        const visibleCheckboxes = document.querySelectorAll('.member-row:not([style*="display: none"]) .member-checkbox');
                                        visibleCheckboxes.forEach(checkbox => {
                                            checkbox.checked = e.target.checked;
                                        });
                                        updateSelectedCount();
                                    });
                                    
                                    memberCheckboxes.forEach(checkbox => {
                                        checkbox.addEventListener('change', function() {
                                            updateSelectedCount();
                                            updateSelectAllState();
                                        });
                                    });
                                    
                                    clearSelectionBtn.addEventListener('click', function() {
                                        memberCheckboxes.forEach(checkbox => {
                                            checkbox.checked = false;
                                        });
                                        updateSelectedCount();
                                        updateSelectAllState();
                                    });
                                    
                                    // Initialize
                                    updateSelectedCount();
                                    updateSelectAllState();
                                    
                                    // Sync present checkboxes with the main checkboxes
                                    document.querySelectorAll('.member-present').forEach((presentCheckbox, index) => {
                                        presentCheckbox.addEventListener('change', function() {
                                            const memberCheckbox = document.getElementById('member_' + this.id.split('_')[1]);
                                            if (memberCheckbox) {
                                                memberCheckbox.checked = this.checked;
                                                memberCheckbox.dispatchEvent(new Event('change'));
                                            }
                                        });
                                        
                                        // Also sync the state from the main checkbox to the present checkbox
                                        const memberCheckbox = document.getElementById('member_' + presentCheckbox.id.split('_')[1]);
                                        if (memberCheckbox) {
                                            memberCheckbox.addEventListener('change', function() {
                                                presentCheckbox.checked = this.checked;
                                            });
                                        }
                                    });
                                });
                                </script>
                            </div>
                            
                            <script>
                            // Search functionality
                            document.getElementById('memberSearch').addEventListener('input', function(e) {
                                const searchTerm = e.target.value.toLowerCase();
                                const memberItems = document.querySelectorAll('.member-item');
                                
                                memberItems.forEach(item => {
                                    const memberName = item.getAttribute('data-name');
                                    if (memberName.includes(searchTerm)) {
                                        item.style.display = 'block';
                                    } else {
                                        item.style.display = 'none';
                                    }
                                });
                            });
                            
                            // Select all functionality
                            document.getElementById('selectAllMembers').addEventListener('change', function(e) {
                                const checkboxes = document.querySelectorAll('.member-checkbox');
                                checkboxes.forEach(checkbox => {
                                    checkbox.checked = e.target.checked;
                                });
                            });
                            </script>
                            
                            <div class="d-flex justify-content-between">
                                <a href="../dashboard/<?php echo $user['role']; ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                                </a>
                                <div>
                                    <button type="button" class="btn btn-outline-secondary me-2" onclick="document.getElementById('attendanceForm').reset()">
                                        <i class="fas fa-undo me-2"></i>Reset Form
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Mark Attendance
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // DOM Elements
        const searchInput = document.getElementById('memberSearch');
        const clearSearchBtn = document.getElementById('clearSearch');
        const selectAllBtn = document.getElementById('selectAllMembers');
        const clearSelectionBtn = document.getElementById('clearSelection');
        const viewListBtn = document.getElementById('viewList');
        const viewGridBtn = document.getElementById('viewGrid');
        const memberGrid = document.getElementById('memberGrid');
        const memberTable = document.getElementById('memberTable');
        const registerContent = document.getElementById('registerContent');
        const filterLinks = document.querySelectorAll('[data-filter]');
        
        // Toggle between grid and list view
        viewListBtn.addEventListener('click', function() {
            viewListBtn.classList.add('active');
            viewGridBtn.classList.remove('active');
            memberGrid.classList.add('d-none');
            memberTable.classList.remove('d-none');
            localStorage.setItem('attendanceView', 'list');
        });
        
        viewGridBtn.addEventListener('click', function() {
            viewGridBtn.classList.add('active');
            viewListBtn.classList.remove('active');
            memberGrid.classList.remove('d-none');
            memberTable.classList.add('d-none');
            localStorage.setItem('attendanceView', 'grid');
        });
        
        // Load saved view preference
        const savedView = localStorage.getItem('attendanceView') || 'grid';
        if (savedView === 'list') {
            viewListBtn.click();
        } else {
            viewGridBtn.click();
        }
        
        // Filter members by ministry
        filterLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const filterType = this.getAttribute('data-filter');
                const filterValue = this.getAttribute('data-value');
                
                // Update active state
                document.querySelectorAll('.dropdown-item').forEach(item => item.classList.remove('active'));
                this.classList.add('active');
                
                if (filterType === 'all') {
                    // Show all members
                    document.querySelectorAll('.member-card, .member-row').forEach(el => {
                        el.style.display = '';
                    });
                } else if (filterType === 'ministry') {
                    // Filter by ministry
                    document.querySelectorAll('.member-card, .member-row').forEach(el => {
                        if (el.getAttribute('data-ministry') === filterValue) {
                            el.style.display = '';
                        } else {
                            el.style.display = 'none';
                        }
                    });
                }
                
                // Update counts
                updateSelectedCount();
            });
        });
        
        // Search functionality
        function filterMembers() {
            const searchTerm = searchInput.value.toLowerCase();
            const activeFilter = document.querySelector('.dropdown-item.active');
            const currentFilter = activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
            const currentValue = activeFilter ? activeFilter.getAttribute('data-value') : '';
            
            document.querySelectorAll('.member-card, .member-row').forEach(card => {
                const name = card.getAttribute('data-name');
                const ministry = card.getAttribute('data-ministry');
                const matchesSearch = name.includes(searchTerm);
                const matchesFilter = currentFilter === 'all' || ministry === currentValue;
                
                if (matchesSearch && matchesFilter) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
            
            updateSelectedCount();
        }
        
        // Clear search
        if (clearSearchBtn) {
            clearSearchBtn.addEventListener('click', function() {
                searchInput.value = '';
                filterMembers();
                searchInput.focus();
            });
        }
        
        // Search as you type
        if (searchInput) {
            searchInput.addEventListener('input', filterMembers);
        }
        
        // Select all members
        if (selectAllBtn) {
            selectAllBtn.addEventListener('click', function() {
                const visibleCheckboxes = document.querySelectorAll('.member-card:not([style*="display: none"]) .member-present, .member-row:not([style*="display: none"]) .member-present');
                const allChecked = Array.from(visibleCheckboxes).every(checkbox => checkbox.checked);
                
                visibleCheckboxes.forEach(checkbox => {
                    if (!checkbox.checked || allChecked) {
                        checkbox.checked = !allChecked;
                        const event = new Event('change');
                        checkbox.dispatchEvent(event);
                    }
                });
            });
        }
        
        // Clear selection
        if (clearSelectionBtn) {
            clearSelectionBtn.addEventListener('click', function() {
                document.querySelectorAll('.member-present').forEach(checkbox => {
                    if (checkbox.checked) {
                        checkbox.checked = false;
                        const event = new Event('change');
                        checkbox.dispatchEvent(event);
                    }
                });
            });
        }
        
        // Handle member present/absent toggle
        function handlePresentToggle(e) {
            const memberId = this.getAttribute('data-member-id');
            const isChecked = this.checked;
            
            // Update the hidden checkbox
            const hiddenCheckbox = document.getElementById('member_' + memberId) || 
                                  document.getElementById('member_' + memberId + '_table');
            if (hiddenCheckbox) {
                hiddenCheckbox.value = isChecked ? memberId : '';
            }
            
            // Update the other view's checkbox if it exists
            const otherCheckbox = this.id.includes('_table') ? 
                document.getElementById(this.id.replace('_table', '')) :
                document.getElementById(this.id + '_table');
                
            if (otherCheckbox) {
                otherCheckbox.checked = isChecked;
                // Update the hidden checkbox for the other view
                const otherHiddenCheckbox = document.getElementById('member_' + memberId) || 
                                          document.getElementById('member_' + memberId + '_table');
                if (otherHiddenCheckbox) {
                    otherHiddenCheckbox.value = isChecked ? memberId : '';
                }
            }
            
            // Update the UI
            updateSelectedCount();
        }
        
        // Add event listeners to all present/absent toggles
        document.querySelectorAll('.member-present').forEach(checkbox => {
            checkbox.addEventListener('change', handlePresentToggle);
        });
        
        // Update the selected count and statistics
        function updateSelectedCount() {
            const selectedCount = document.querySelectorAll('.member-present:checked').length;
            const totalCount = <?php echo count($members); ?>;
            const percentage = totalCount > 0 ? Math.round((selectedCount / totalCount) * 100) : 0;
            
            // Update the UI
            document.getElementById('selectedCount').textContent = selectedCount;
            document.getElementById('presentCount').textContent = selectedCount;
            document.getElementById('attendancePercentage').textContent = percentage + '%';
            
            // Update progress bar
            const progressBar = document.querySelector('.progress-bar');
            if (progressBar) {
                progressBar.style.width = percentage + '%';
                progressBar.setAttribute('aria-valuenow', percentage);
                
                // Update color based on percentage
                if (percentage < 30) {
                    progressBar.className = 'progress-bar bg-danger';
                } else if (percentage < 70) {
                    progressBar.className = 'progress-bar bg-warning';
                } else {
                    progressBar.className = 'progress-bar bg-success';
                }
            }
        }
        
        // Initialize
        updateSelectedCount();
        
        // Make member cards clickable
        document.querySelectorAll('.member-card').forEach(card => {
            card.addEventListener('click', function(e) {
                // Don't toggle if clicking on the switch or a link
                if (e.target.closest('.form-check-input, a')) {
                    return;
                }
                
                const checkbox = this.querySelector('.member-present');
                if (checkbox) {
                    checkbox.checked = !checkbox.checked;
                    const event = new Event('change');
                    checkbox.dispatchEvent(event);
                }
            });
        });
        
        // Make table rows clickable
        document.querySelectorAll('.member-row').forEach(row => {
            row.addEventListener('click', function(e) {
                // Don't toggle if clicking on the switch or a link
                if (e.target.closest('.form-check-input, a')) {
                    return;
                }
                
                const checkbox = this.querySelector('.member-present');
                if (checkbox) {
                    checkbox.checked = !checkbox.checked;
                    const event = new Event('change');
                    checkbox.dispatchEvent(event);
                }
            });
        });
        
        // Handle print
        window.addEventListener('beforeprint', function() {
            // Show all members when printing
            document.querySelectorAll('.member-card, .member-row').forEach(el => {
                el.style.display = '';
            });
        });
    });
    </script>
</body>
</html> 