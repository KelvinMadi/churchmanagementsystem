<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin', 'pastor']);
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $priority = $_POST['priority'] ?? 'normal';
        $is_public = isset($_POST['is_public']) ? 1 : 0;

        if (empty($title) || empty($content)) {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
        } else {
            $saved = $conn->saveAnnouncement([
                'title' => $title,
                'content' => $content,
                'priority' => $priority,
                'is_public' => $is_public,
                'author_id' => $user['id'],
                'author_name' => $user['name'] ?? 'Admin',
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            if ($saved) {
                // Redirect to the announcements list after successful post
                header('Location: list.php?success=1');
                exit();
            } else {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error saving announcement. Please try again.</div>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Announcement - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            min-height: 100vh;
            color: var(--dark);
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%) !important;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }
        
        .announcement-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border: none;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 2rem;
        }
        
        .announcement-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
        }
        
        .announcement-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%);
            color: white;
            padding: 3rem 2rem;
            position: relative;
            overflow: hidden;
            text-align: center;
        }
        
        .announcement-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSIvPjwvc3ZnPg==');
            opacity: 0.3;
        }
        
        .announcement-header i {
            font-size: 2.5rem;
            background: rgba(255, 255, 255, 0.2);
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1.5rem;
            border: 3px solid rgba(255, 255, 255, 0.3);
        }
        
        .announcement-header h3 {
            font-weight: 700;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }
        
        .announcement-header p {
            font-size: 1.1rem;
            opacity: 0.9;
            position: relative;
            z-index: 1;
            margin-bottom: 0;
        }
        
        .form-label {
            font-weight: 500;
            color: var(--secondary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }
        
        .form-label i {
            margin-right: 0.5rem;
            color: var(--primary);
        }
        
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
            font-size: 1rem;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.15);
        }
        
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        
        .btn {
            font-weight: 600;
            padding: 0.75rem 1.75rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn i {
            margin-right: 0.5rem;
        }
        
        .btn-primary {
            background: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-primary:hover {
            background: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-2px);
        }
        
        .btn-outline-primary {
            color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-outline-primary:hover {
            background: var(--primary);
            color: white;
        }
        
        .btn-danger {
            background: #e74c3c;
            border-color: #e74c3c;
            padding: 0.75rem 2rem;
        }
        
        .btn-danger:hover {
            background: #c0392b;
            border-color: #c0392b;
            transform: translateY(-2px);
        }
        
        .form-check-input:checked {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .form-check-label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        
        .form-check-input {
            width: 1.25em;
            height: 1.25em;
            margin-top: 0;
        }
        
        .priority-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .card-body {
            padding: 2.5rem;
        }
        
        @media (max-width: 768px) {
            .card-body {
                padding: 1.5rem;
            }
            
            .announcement-header {
                padding: 2rem 1rem;
            }
            
            .btn {
                width: 100%;
                margin-bottom: 0.5rem;
            }
            
            .btn-group .btn {
                width: auto;
            }
        }
        
        /* Animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in-up {
            animation: fadeInUp 0.6s ease-out forwards;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
            opacity: 0;
            animation: fadeInUp 0.6s ease-out forwards;
        }
        
        .form-group:nth-child(1) { animation-delay: 0.1s; }
        .form-group:nth-child(2) { animation-delay: 0.2s; }
        .form-group:nth-child(3) { animation-delay: 0.3s; }
        .form-group:nth-child(4) { animation-delay: 0.4s; }
        
        /* Custom checkbox */
        .form-switch .form-check-input {
            width: 2.5em;
            margin-left: -2.5em;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%23fff'/%3e%3c/svg%3e");
            background-position: left center;
            border-radius: 2em;
            transition: background-position 0.15s ease-in-out;
        }
        
        .form-switch .form-check-input:checked {
            background-position: right center;
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .form-switch .form-check-label {
            padding-left: 0.5em;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand fw-bold" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="announcement-card">
                    <!-- Header with Gradient Background -->
                    <div class="announcement-header">
                        <i class="fas fa-bullhorn"></i>
                        <h3 class="animate-fade-in-up">Create New Announcement</h3>
                        <p class="animate-fade-in-up" style="animation-delay: 0.2s">Share important updates with the church community</p>
                    </div>
                    
                    <!-- Form Section -->
                    <div class="card-body">
                        <?php if (!empty($message)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo strip_tags($message, '<i>'); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" class="needs-validation" novalidate>
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            
                            <!-- Title Input -->
                            <div class="form-group">
                                <label for="title" class="form-label">
                                    <i class="fas fa-heading"></i>Announcement Title *
                                </label>
                                <input type="text" 
                                       class="form-control form-control-lg" 
                                       id="title" 
                                       name="title" 
                                       value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>"
                                       placeholder="Enter announcement title" 
                                       required>
                                <div class="invalid-feedback">
                                    Please provide a title for your announcement.
                                </div>
                            </div>
                            
                            <!-- Content Textarea -->
                            <div class="form-group">
                                <label for="content" class="form-label">
                                    <i class="fas fa-align-left"></i>Announcement Content *
                                </label>
                                <textarea class="form-control" 
                                          id="content" 
                                          name="content" 
                                          rows="6" 
                                          placeholder="Type your announcement details here..." 
                                          required><?php echo htmlspecialchars($_POST['content'] ?? ''); ?></textarea>
                                <div class="invalid-feedback">
                                    Please provide the announcement content.
                                </div>
                            </div>
                            
                            <div class="row">
                                <!-- Priority Select -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="priority" class="form-label">
                                            <i class="fas fa-exclamation-triangle"></i>Priority Level
                                        </label>
                                        <select class="form-select" id="priority" name="priority">
                                            <option value="normal" <?php echo ($_POST['priority'] ?? '') === 'normal' ? 'selected' : ''; ?>>Normal Priority</option>
                                            <option value="important" <?php echo ($_POST['priority'] ?? '') === 'important' ? 'selected' : ''; ?>>Important</option>
                                            <option value="urgent" <?php echo ($_POST['priority'] ?? '') === 'urgent' ? 'selected' : ''; ?>>Urgent</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <!-- Public Toggle -->
                                <div class="col-md-6">
                                    <div class="form-group d-flex align-items-end h-100">
                                        <div class="form-check form-switch mb-0">
                                            <input class="form-check-input" 
                                                   type="checkbox" 
                                                   role="switch" 
                                                   id="is_public" 
                                                   name="is_public" 
                                                   <?php echo !isset($_POST['is_public']) || $_POST['is_public'] ? 'checked' : ''; ?>>
                                            <label class="form-check-label ms-3" for="is_public">
                                                <i class="fas fa-globe"></i> Make this announcement public
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Form Actions -->
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center pt-4 mt-4 border-top">
                                <a href="list.php" class="btn btn-outline-primary mb-3 mb-md-0">
                                    <i class="fas fa-arrow-left"></i> Back to Announcements
                                </a>
                                <button type="submit" class="btn btn-danger px-4">
                                    <i class="fas fa-paper-plane"></i> Publish Announcement
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function () {
            'use strict'
            
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation')
            
            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
        
        // Add animation to form elements on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Animate form elements
            const formGroups = document.querySelectorAll('.form-group');
            formGroups.forEach((group, index) => {
                group.style.animationDelay = `${index * 0.1}s`;
                group.classList.add('animate-fade-in-up');
            });
            
            // Add character counter for textarea
            const textarea = document.getElementById('content');
            if (textarea) {
                const charCount = document.createElement('small');
                charCount.className = 'text-muted d-block text-end mt-1';
                charCount.id = 'charCount';
                textarea.parentNode.insertBefore(charCount, textarea.nextSibling);
                
                function updateCharCount() {
                    const currentLength = textarea.value.length;
                    charCount.textContent = `${currentLength} characters`;
                    
                    // Change color based on length
                    if (currentLength > 500) {
                        charCount.classList.remove('text-muted');
                        charCount.classList.add('text-danger');
                    } else {
                        charCount.classList.remove('text-danger');
                        charCount.classList.add('text-muted');
                    }
                }
                
                textarea.addEventListener('input', updateCharCount);
                updateCharCount(); // Initial count
            }
            
            // Add focus styles
            const formControls = document.querySelectorAll('.form-control, .form-select, .form-check-input');
            formControls.forEach(control => {
                control.addEventListener('focus', function() {
                    this.parentNode.classList.add('focused');
                });
                
                control.addEventListener('blur', function() {
                    this.parentNode.classList.remove('focused');
                });
                
                // Add animation to form controls
                control.style.opacity = '0';
                control.style.transform = 'translateY(10px)';
                control.style.transition = 'all 0.3s ease';
                
                setTimeout(() => {
                    control.style.opacity = '1';
                    control.style.transform = 'translateY(0)';
                }, 100);
            });
        });
    </script>
</body>
</html> 