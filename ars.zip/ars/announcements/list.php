<?php
require_once '../includes/db.php';
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

// Check for success message
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $message = '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i>Announcement posted successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
} else {
    $message = '';
}

// Search functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$announcements = [];
$result = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");

// Filter announcements based on search
if ($result && $result->num_rows > 0) {
    $announcements = [];
    while ($row = $result->fetch_assoc()) {
        if ($search) {
            if (stripos($row['title'], $search) !== false || 
                stripos($row['content'], $search) !== false) {
                $announcements[] = $row;
            }
        } else {
            $announcements[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../sermons/list.php">Sermons</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../events/list.php">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="list.php">Announcements</a>
                    </li>
                    <?php if ($user_id): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../dashboard/<?php echo $user_role; ?>.php">Dashboard</a></li>
                                <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../login.php">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-4">Church Announcements</h1>
            <p class="lead mb-4">Stay updated with the latest news and important information from our church</p>
            
            <!-- Search Box -->
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form method="GET" class="search-box p-3">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control border-0" placeholder="Search announcements..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Announcements List -->
    <div class="container mt-5">
        <?php if (in_array($user_role, ['admin', 'pastor'])): ?>
        <div class="text-end mb-4">
            <a href="post.php" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Post New Announcement
            </a>
        </div>
        <?php endif; ?>

        <?php if (!empty($announcements)): ?>
            <?php echo $message; ?>
            <div class="row">
                <?php foreach ($announcements as $announcement): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card announcement-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title"><?php echo htmlspecialchars($announcement['title']); ?></h5>
                                <span class="badge bg-<?php 
                                    echo $announcement['priority'] === 'urgent' ? 'danger' : 
                                         ($announcement['priority'] === 'important' ? 'warning' : 'primary'); 
                                ?>">
                                    <?php echo date('M j, Y', strtotime($announcement['created_at'])); ?>
                                </span>
                            </div>
                            <p class="card-text">
                                <?php echo htmlspecialchars(substr($announcement['content'], 0, 150)); ?>
                                <?php if (strlen($announcement['content']) > 150) echo '...'; ?>
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($announcement['author_name'] ?? 'Admin'); ?>
                                </small>
                                <a href="view.php?id=<?php echo $announcement['id']; ?>" class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-eye me-1"></i>Read More
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-bullhorn fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">No announcements found</h4>
                <p class="text-muted"><?php echo $search ? 'Try a different search term.' : 'No announcements posted yet.'; ?></p>
                <?php if (in_array($user_role, ['admin', 'pastor'])): ?>
                <a href="post.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Post First Announcement
                </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php include '../includes/footer.php'; ?>