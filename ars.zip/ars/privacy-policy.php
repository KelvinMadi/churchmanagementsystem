<?php
require_once 'includes/db.php';
$page_title = 'Privacy Policy';
$show_page_header = true;
include 'includes/header.php';
?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h2 class="h4 mb-3">Our Commitment to Your Privacy</h2>
                    <p>We value your privacy and are committed to protecting your personal information. This policy explains how we collect, use, and safeguard your data within our church management system.</p>
                    <h3 class="h5 mt-4">Information We Collect</h3>
                    <ul>
                        <li>Account details you provide (name, email)</li>
                        <li>Ministry participation and attendance records</li>
                        <li>Donations you choose to record</li>
                    </ul>
                    <h3 class="h5 mt-4">How We Use Information</h3>
                    <ul>
                        <li>To manage church membership and ministries</li>
                        <li>To communicate important updates</li>
                        <li>For financial records where applicable</li>
                    </ul>
                    <p class="mt-3">For questions, contact us at <a href="mailto:info@arschurch.org">info@arschurch.org</a>.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>

