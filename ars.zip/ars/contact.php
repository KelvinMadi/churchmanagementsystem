<?php
$page_title = "Contact Us";
$show_page_header = true;
$base_path = '';

// Include necessary files
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Initialize variables
$error_message = '';
$submission_success = false;
$name = $email = $message = '';
$subject = 'General Inquiry';

// Generate CSRF token
$csrf_token = generate_csrf_token();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid session token. Please refresh and try again.';
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $subject = trim($_POST['subject'] ?? 'General Inquiry');
        $message = trim($_POST['message'] ?? '');
    
        // Validation
        if (empty($name) || empty($email) || empty($message)) {
            $error_message = 'Please fill in all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = 'Please provide a valid email address.';
        } else {
            // Email sending logic
            $to = 'info@arschurch.org';
            $email_subject = 'Contact Form: ' . $subject;
            $body = "Name: $name\nEmail: $email\nSubject: $subject\n\n$message";
            $headers = "From: $email\r\n";
            $headers .= "Reply-To: $email\r\n";
            
            if (mail($to, $email_subject, $body, $headers)) {
                $submission_success = true;
                // Clear form data on success
                $name = $email = $message = '';
                $subject = 'General Inquiry';
            } else {
                $error_message = 'There was an error sending your message. Please try again later.';
            }
        }
    }
}

include 'includes/header.php';
?>

<!-- Hero Section with Gradient Background -->
<section class="position-relative bg-gradient-primary text-white py-7 py-lg-9 overflow-hidden">
    <!-- Decorative Elements -->
    <div class="position-absolute top-0 start-0 w-100 h-100" style="
        background: 
            radial-gradient(circle at 10% 20%, rgba(230, 126, 34, 0.1) 0%, transparent 15%),
            radial-gradient(circle at 90% 80%, rgba(44, 62, 80, 0.1) 0%, transparent 15%),
            linear-gradient(135deg, rgba(255, 215, 0, 0.03) 0%, transparent 50%);
        z-index: 0;
        pointer-events: none;
        opacity: 0.8;
    "></div>
    
    <div class="container position-relative">
        <div class="row justify-content-center text-center">
            <div class="col-lg-10 col-xl-8">
                <!-- Animated badge with pulse effect -->
                <div class="position-relative d-inline-block mb-4">
                    <div class="position-absolute top-50 start-50 translate-middle" style="width: 80px; height: 80px; background: rgba(255,255,255,0.2); border-radius: 50%; animation: pulse 2s infinite;"></div>
                    <span class="badge bg-warning bg-opacity-20 text-warning border-0 rounded-pill px-4 py-2 d-inline-flex align-items-center position-relative" style="--bs-bg-opacity: 0.2;">
                        <i class="fas fa-paper-plane me-2"></i> We're Here For You
                    </span>
                </div>
                
                <!-- Main heading with decorative elements -->
                <div class="position-relative mb-4">
                    <h1 class="display-3 fw-bold mb-4 text-warning position-relative" style="text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">
                        Connect With <span class="text-white">Us</span>
                        <div class="position-absolute bottom-0 start-50 translate-middle-x" style="width: 80px; height: 4px; background: var(--bs-warning); border-radius: 2px;"></div>
                    </h1>
                    <div class="position-absolute top-0 start-0 translate-middle" style="width: 30px; height: 30px; border: 3px solid rgba(255,255,255,0.3); border-radius: 50%;"></div>
                    <div class="position-absolute bottom-0 end-0 translate-middle" style="width: 20px; height: 20px; border: 2px solid rgba(255,255,255,0.2); border-radius: 50%;"></div>
                </div>
                
                <!-- Description with animated underline -->
                <p class="lead mb-5 px-lg-5 mx-lg-5 position-relative d-inline-block" style="color: #FFD700;">
                    Whether you have questions, prayer requests, or just want to say hello, our team is ready to assist you on your spiritual journey.
                    <span class="position-absolute bottom-0 start-0 w-100" style="height: 2px; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);"></span>
                </p>
                
                <!-- Action buttons with hover effects -->
                <div class="d-flex flex-column flex-sm-row justify-content-center gap-3 mt-5">
                    <a href="#contact-form" class="btn btn-light btn-lg px-5 py-3 fw-medium rounded-pill shadow-sm position-relative overflow-hidden border-0" 
                       style="transition: all 0.3s ease; z-index: 1;">
                        <span class="position-relative d-flex align-items-center justify-content-center">
                            <i class="fas fa-envelope me-2"></i> Send a Message
                        </span>
                        <div class="position-absolute top-0 start-0 w-100 h-100 bg-warning" style="opacity: 0; z-index: -1; transition: all 0.3s ease; transform: translateY(100%);"></div>
                    </a>
                    
                    <a href="#contact-info" class="btn btn-outline-warning btn-lg px-5 py-3 fw-medium rounded-pill border-2 position-relative overflow-hidden"
                       style="transition: all 0.3s ease; z-index: 1; --bs-btn-hover-bg: rgba(255, 215, 0, 0.2); --bs-btn-hover-border-color: #FFD700;">
                        <span class="position-relative d-flex align-items-center justify-content-center">
                            <i class="fas fa-phone-alt me-2"></i> Call Us Now
                        </span>
                        <div class="position-absolute top-0 start-0 w-100 h-100 bg-white" style="opacity: 0; z-index: -1; transition: all 0.3s ease; transform: translateY(-100%);"></div>
                    </a>
                </div>
                
                <!-- Decorative elements -->
                <div class="position-absolute" style="top: 20%; left: 10%; width: 20px; height: 20px; border: 2px solid rgba(255,255,255,0.2); transform: rotate(45deg);"></div>
                <div class="position-absolute" style="bottom: 20%; right: 10%; width: 15px; height: 15px; border: 2px solid rgba(255, 215, 0, 0.4); border-radius: 50%;"></div>
                
                <!-- CSS Animation -->
                <style>
                    @keyframes pulse {
                        0% { transform: translate(-50%, -50%) scale(1); opacity: 0.8; }
                        50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.4; }
                        100% { transform: translate(-50%, -50%) scale(1); opacity: 0.8; }
                    }
                    .btn-light:hover {
                        transform: translateY(-3px);
                        box-shadow: 0 10px 20px rgba(0,0,0,0.2) !important;
                    }
                    .btn-outline-warning:hover {
                        transform: translateY(-3px);
                        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
                    }
                    .btn:hover .position-absolute {
                        opacity: 0.1 !important;
                        transform: none !important;
                    }
                </style>
            </div>
        </div>
    </div>
    
    <!-- Wave Divider -->
    <div class="position-absolute bottom-0 start-0 w-100 overflow-hidden" style="color: #ffffff;">
        <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" fill="currentColor"></path>
            <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" fill="currentColor"></path>
            <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,86c57.79-8.17,113.3-32.91,168.54-57.07,48.05-20.8,99.85-42.8,80.26-68.92Z" fill="currentColor"></path>
        </svg>
    </div>
</section>

<!-- Main Content -->
<div class="container py-5">
    <?php if (isset($error_message) && $error_message): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <?php echo htmlspecialchars($error_message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="row g-5">
        <!-- Contact Form -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4 p-lg-5">
                    <div class="section-header mb-5">
                        <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill mb-3">Send a Message</span>
                        <h2 class="h1 fw-bold mb-3">Get In Touch</h2>
                        <p class="text-muted mb-0">Have questions or need more information? Fill out the form below and we'll get back to you as soon as possible.</p>
                        <div class="divider bg-primary" style="width: 80px; height: 3px; margin: 1.5rem 0;"></div>
                    </div>
                    
                    <?php if ($submission_success): ?>
                        <div class="alert alert-success border-0 shadow-sm" role="alert">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-check-circle me-3 fs-4"></i>
                                <div>
                                    <h5 class="alert-heading mb-1">Message Sent Successfully!</h5>
                                    <p class="mb-0">Thank you for contacting us. We'll get back to you within 24-48 hours.</p>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <form action="contact.php" method="POST" class="needs-validation" novalidate>
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <div class="form-floating mb-4">
                                        <input type="text" class="form-control" id="name" name="name" 
                                               value="<?php echo htmlspecialchars($name); ?>" 
                                               placeholder="John Doe" required>
                                        <label for="name">Your Name *</label>
                                        <div class="invalid-feedback">Please enter your name</div>
                                        <div class="form-icon">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-floating mb-4">
                                        <input type="email" class="form-control" id="email" name="email" 
                                               value="<?php echo htmlspecialchars($email); ?>" 
                                               placeholder="name@example.com" required>
                                        <label for="email">Email Address *</label>
                                        <div class="invalid-feedback">Please enter a valid email address</div>
                                        <div class="form-icon">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="form-floating mb-4">
                                        <select class="form-select" id="subject" name="subject" required>
                                            <option value="" disabled>Select a subject</option>
                                            <option value="General Inquiry" <?php echo ($subject === 'General Inquiry') ? 'selected' : ''; ?>>General Inquiry</option>
                                            <option value="Prayer Request" <?php echo ($subject === 'Prayer Request') ? 'selected' : ''; ?>>Prayer Request</option>
                                            <option value="Ministry Question" <?php echo ($subject === 'Ministry Question') ? 'selected' : ''; ?>>Ministry Question</option>
                                            <option value="Event Information" <?php echo ($subject === 'Event Information') ? 'selected' : ''; ?>>Event Information</option>
                                            <option value="Volunteer" <?php echo ($subject === 'Volunteer') ? 'selected' : ''; ?>>Volunteer Opportunities</option>
                                            <option value="Other" <?php echo ($subject === 'Other') ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                        <label for="subject">How can we help you? *</label>
                                        <div class="form-icon">
                                            <i class="fas fa-tag"></i>
                                        </div>
                                        <div class="invalid-feedback">Please select a subject</div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="form-floating mb-4">
                                        <textarea class="form-control" id="message" name="message" 
                                                  placeholder="Your message" style="height: 150px;" required><?php echo htmlspecialchars($message); ?></textarea>
                                        <label for="message">Your Message *</label>
                                        <div class="form-icon">
                                            <i class="fas fa-comment-alt"></i>
                                        </div>
                                        <div class="invalid-feedback">Please enter your message</div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary btn-lg py-3 fw-bold">
                                            <i class="fas fa-paper-plane me-2"></i> Send Message
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Contact Information -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4 p-lg-5">
                    <div class="section-header mb-5 text-center">
                        <span class="badge bg-primary bg-opacity-10 text-primary px-4 py-2 rounded-pill mb-3 d-inline-flex align-items-center">
                            <i class="fas fa-info-circle me-2"></i> Our Information
                        </span>
                        <h2 class="h1 fw-bold mb-3 text-gradient-primary">Contact Details</h2>
                        <p class="lead text-muted mb-4">Find us at our location or reach out through any of these channels.</p>
                        <div class="divider bg-primary mx-auto" style="width: 80px; height: 3px; margin: 1.5rem auto; opacity: 0.2;"></div>
                    </div>
                    
                    <div class="contact-info">
                        <!-- Location Card -->
                        <div class="contact-card mb-4 p-4 rounded-4 bg-light border-0 position-relative overflow-hidden shadow-sm">
                            <div class="position-absolute top-0 end-0 w-100 h-100 bg-primary bg-opacity-5" style="z-index: 0; clip-path: circle(50% at 100% 0);"></div>
                            <div class="d-flex align-items-center position-relative" style="z-index: 1;">
                                <div class="flex-shrink-0 me-4">
                                    <div class="icon-box bg-primary text-white" style="width: 50px; height: 50px; line-height: 50px; text-align: center; border-radius: 12px;">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                </div>
                                <div>
                                    <h5 class="h6 fw-bold mb-1">Our Location</h5>
                                    <p class="mb-2 text-dark">123 Church Street<br>Louisville, KY 40202</p>
                                    <a href="https://maps.google.com" target="_blank" class="btn btn-sm btn-outline-primary mt-1 px-3 py-1 rounded-pill">
                                        <i class="fas fa-directions me-1"></i> Get Directions
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Phone Card -->
                        <div class="contact-card mb-4 p-4 rounded-4 bg-light border-0 position-relative overflow-hidden shadow-sm">
                            <div class="position-absolute top-0 end-0 w-100 h-100 bg-primary bg-opacity-5" style="z-index: 0; clip-path: circle(50% at 100% 0);"></div>
                            <div class="d-flex align-items-center position-relative" style="z-index: 1;">
                                <div class="flex-shrink-0 me-4">
                                    <div class="icon-box bg-primary text-white" style="width: 50px; height: 50px; line-height: 50px; text-align: center; border-radius: 12px;">
                                        <i class="fas fa-phone-alt"></i>
                                    </div>
                                </div>
                                <div>
                                    <h5 class="h6 fw-bold mb-1">Phone Numbers</h5>
                                    <p class="mb-1">
                                        <a href="tel:+15025551234" class="text-decoration-none text-dark">(502) 555-1234</a>
                                    </p>
                                    <p class="mb-0">
                                        <a href="tel:+15025555678" class="text-decoration-none text-dark">(502) 555-5678</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex mb-4">
                            <div class="flex-shrink-0 me-4">
                                <div class="icon-box bg-primary bg-opacity-10 text-primary">
                                    <i class="fas fa-phone-alt"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="h6 mb-1">Phone Number</h5>
                                <p class="mb-0 text-dark">
                                    <a href="tel:+15025551234" class="text-decoration-none text-dark">(502) 555-1234</a>
                                </p>
                            </div>
                        </div>
                        
                        <div class="d-flex mb-4">
                            <div class="flex-shrink-0 me-4">
                                <div class="icon-box bg-primary bg-opacity-10 text-primary">
                                    <i class="fas fa-envelope"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="h6 mb-1">Email Address</h5>
                                <p class="mb-0 text-dark">
                                    <a href="mailto:info@arschurch.org" class="text-decoration-none text-dark">info@arschurch.org</a>
                                </p>
                            </div>
                        </div>
                        
                        <div class="d-flex">
                            <div class="flex-shrink-0 me-4">
                                <div class="icon-box bg-primary bg-opacity-10 text-primary">
                                    <i class="far fa-clock"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="h6 mb-1">Service Times</h5>
                                <ul class="list-unstyled text-dark mb-0">
                                    <li>Sunday: 9:00 AM - 12:00 PM</li>
                                    <li>Wednesday: 7:00 PM - 8:30 PM</li>
                                    <li>Friday: 7:00 PM - 9:00 PM</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-5">
                        <h5 class="h6 mb-3">Follow Us</h5>
                        <div class="social-links d-flex gap-3">
                            <a href="#" class="text-primary" title="Facebook">
                                <i class="fab fa-facebook-f fa-lg"></i>
                            </a>
                            <a href="#" class="text-primary" title="Twitter">
                                <i class="fab fa-twitter fa-lg"></i>
                            </a>
                            <a href="#" class="text-primary" title="Instagram">
                                <i class="fab fa-instagram fa-lg"></i>
                            </a>
                            <a href="#" class="text-primary" title="YouTube">
                                <i class="fab fa-youtube fa-lg"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Map Section -->
<div class="map-container">
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3132.967794245685!2d-85.75895032494396!3d38.25659697185921!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88690b1ab35bd511%3A0xd4d3b9f8c3a8e2f2!2sLouisville%2C%20KY!5e0!3m2!1sen!2sus!4v1234567890123!5m2!1sen!2sus" 
        width="100%" 
        height="450" 
        style="border:0;" 
        allowfullscreen="" 
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>

<style>
    /* General Styles */
    :root {
        --primary: #e67e22;
        --primary-hover: #d35400;
        --secondary: #2c3e50;
        --light: #f8f9fa;
        --dark: #2c3e50;
        --text: #333;
        --text-light: #7f8c8d;
    }
    
    body {
        font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: var(--text);
        line-height: 1.6;
    }
    
    h1, h2, h3, h4, h5, h6 {
        font-family: 'Montserrat', sans-serif;
        font-weight: 700;
    }
    
    /* Form Styles */
    .form-floating {
        position: relative;
    }
    
    .form-control, .form-select {
        padding-left: 3rem;
        border: 1px solid #e9ecef;
        border-radius: 10px;
        transition: all 0.3s ease;
        background-color: #f8f9fa;
        height: calc(3.5rem + 2px);
    }
    
    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
        background-color: #fff;
    }
    
    textarea.form-control {
        height: auto;
        min-height: 150px;
        padding-top: 1.625rem;
    }
    
    .form-icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--primary);
        font-size: 1.1rem;
        z-index: 5;
    }
    
    .form-floating > label {
        padding-left: 3rem;
    }
    
    .form-floating > .form-control:focus ~ label,
    .form-floating > .form-control:not(:placeholder-shown) ~ label,
    .form-floating > .form-select ~ label {
        transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
        opacity: 0.8;
    }
    
    /* Contact Info */
    .icon-box {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
    }
    
    /* Social Links */
    .social-links a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: rgba(230, 126, 34, 0.1);
        transition: all 0.3s ease;
    }
    
    .social-links a:hover {
        background-color: var(--primary);
        color: white !important;
        transform: translateY(-3px);
    }
    
    /* Map */
    .map-container {
        width: 100%;
        height: 450px;
        margin-top: 5rem;
    }
    
    /* Responsive Adjustments */
    @media (max-width: 991.98px) {
        .map-container {
            margin-top: 3rem;
        }
    }
    
    @media (max-width: 767.98px) {
        .section-header h2 {
            font-size: 1.75rem;
        }
        
        .map-container {
            height: 350px;
        }
    }
</style>

<?php
// Include footer
include 'includes/footer.php';
?>
