<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_login();
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

// Get user details and member information
$user_details = $user;

// Get member details if available
$members_result = $conn->query("SELECT * FROM members WHERE user_id = " . intval($user['id']));
if ($members_result) {
    $member = $members_result->fetch_assoc();
    if ($member) {
        $user_details = array_merge($user_details, $member);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        
        if ($name && $email) {
            // Update user data
            $user_details = $conn->getUserById($user['id']);
            if ($user_details) {
                $user_details['name'] = $name;
                $user_details['email'] = $email;
                
                // Update the user in the database
                $result = $conn->query("UPDATE users SET name = '$name', email = '$email' WHERE id = " . $user['id']);
                
                if ($result) {
                    // Update session data
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_email'] = $email;
                    
                    // Update member data if exists
                    if (isset($member)) {
                        $member['phone'] = $phone;
                        $member['address'] = $address;
                        
                        // Update member in the database
                        $conn->query("UPDATE members SET phone = '$phone', address = '$address' WHERE user_id = " . $user['id']);
                    }
                    
                    $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Profile updated successfully!</div>';
                } else {
                    $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i>Failed to update profile. Please try again.</div>';
                }
                
                // Get all members
                $members = [];
                $members_result = $conn->query("SELECT * FROM members");
                if ($members_result) {
                    while ($row = $members_result->fetch_assoc()) {
                        $members[] = $row;
                    }
                }
                
                $member_found = false;
                
                // Update existing member or add new one
                foreach ($members as &$member) {
                    if (isset($member['user_id']) && $member['user_id'] == $user['id']) {
                        $member['phone'] = $phone;
                        $member['address'] = $address;
                        $member_found = true;
                        break;
                    }
                }
                
                if (!$member_found) {
                    // Insert new member record if not found
                    $conn->query("INSERT INTO members (user_id, name, email, phone, address, join_date) 
                             VALUES ('{$user['id']}', '$name', '$email', '$phone', '$address', NOW())");
                }
                
                $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Profile updated successfully!</div>';
                
                // Update session
                $_SESSION['user_name'] = $name;
            } else {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error updating profile.</div>';
            }
        } else {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
        }
    } elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Get stored user to verify existing password hash
        $storedUser = $conn->getUserById($user['id']);
        if ($storedUser && isset($storedUser['password']) && password_verify($current_password, $storedUser['password'])) {
            if ($new_password === $confirm_password) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                // Update password in the database
                $result = $conn->query("UPDATE users SET password = '$hashed_password' WHERE id = " . $user['id']);
                
                if ($result) {
                    $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Password changed successfully!</div>';
                } else {
                    $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error updating password.</div>';
                }
            } else {
                $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>New passwords do not match.</div>';
            }
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Current password is incorrect.</div>';
        }
    }
    
    // Refresh user details
    $user_details = $conn->getUserById($user['id']);
    
    // Get member details if available
    $members_result = $conn->query("SELECT * FROM members WHERE user_id = " . intval($user['id']));
    if ($members_result && $members_result->num_rows > 0) {
        $member = $members_result->fetch_assoc();
        if ($member) {
            $user_details = array_merge($user_details, $member);
        }
    }
    // Note: using file-based storage, no statement here
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            min-height: 100vh;
            color: var(--dark);
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%);
            padding: 2rem 0;
            margin-bottom: 2rem;
            color: white;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .profile-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background: white;
        }
        
        .profile-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        
        .profile-img {
            width: 150px;
            height: 150px;
            border: 5px solid white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .profile-img:hover {
            transform: scale(1.05);
        }
        
        .profile-role {
            background: var(--accent);
            color: var(--dark);
            display: inline-block;
            padding: 0.25rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
            margin: 0.5rem 0;
        }
        
        .info-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        
        .info-card:hover {
            transform: translateY(-3px);
        }
        
        .info-card h5 {
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 1rem;
            border-bottom: 2px solid var(--light);
            padding-bottom: 0.5rem;
        }
        
        .info-item {
            display: flex;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px dashed #eee;
        }
        
        .info-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        
        .info-icon {
            width: 40px;
            height: 40px;
            background: rgba(230, 126, 34, 0.1);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            color: var(--primary);
            font-size: 1.1rem;
        }
        
        .btn-edit {
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 0.5rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-edit:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            color: white;
            box-shadow: 0 5px 15px rgba(230, 126, 34, 0.3);
        }
        
        .btn-submit {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        
        .btn-submit:hover {
            background-color: #bb2d3b;
            border-color: #b02a37;
            box-shadow: 0 5px 15px rgba(220, 53, 69, 0.3);
        }
        
        .nav-pills .nav-link.active {
            background: var(--primary);
        }
        
        .nav-pills .nav-link {
            color: var(--dark);
            font-weight: 500;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sermons/list.php">Sermons</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="events/list.php">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="announcements/list.php">Announcements</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user['name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="dashboard/<?php echo $user['role']; ?>.php">Dashboard</a></li>
                            <li><a class="dropdown-item active" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Back to Home Button -->
        <div class="mb-4">
            <a href="index.php" class="btn btn-outline-primary">
                <i class="fas fa-home me-2"></i> Back to Home
            </a>
        </div>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="avatar-xxl mb-3">
                            <?php 
                                $name_parts = explode(' ', $user_details['name'] ?? 'U');
                                $initials = '';
                                foreach ($name_parts as $part) {
                                    $initials .= strtoupper(substr($part, 0, 1));
                                    if (strlen($initials) >= 2) break;
                                }
                            ?>
                            <div class="avatar-text" style="width: 100px; height: 100px; font-size: 36px; background-color: #e67e22; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto; border: 3px solid #ffd700;">
                                <?php echo $initials; ?>
                            </div>
                        </div>
                        <h5 class="card-title"><?php echo htmlspecialchars($user_details['name']); ?></h5>
                        <p class="text-muted"><?php echo ucfirst($user_details['role']); ?></p>
                        <p class="text-muted">
                            <i class="fas fa-envelope me-1"></i><?php echo htmlspecialchars($user_details['email']); ?>
                        </p>
                        <?php if (!empty($user_details['phone'])): ?>
                        <p class="text-muted">
                            <i class="fas fa-phone me-1"></i><?php echo htmlspecialchars($user_details['phone']); ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <?php echo $message; ?>
                
                <!-- Profile Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-user me-2"></i>Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <input type="hidden" name="action" value="update_profile">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user_details['name']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email *</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user_details['email']); ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($user_details['phone'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Role</label>
                                    <input type="text" class="form-control" value="<?php echo ucfirst($user_details['role']); ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <textarea name="address" class="form-control" rows="2"><?php echo htmlspecialchars($user_details['address'] ?? ''); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-submit">
                                <i class="fas fa-save me-2"></i>Update Profile
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Change Password -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-lock me-2"></i>Change Password</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <input type="hidden" name="action" value="change_password">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Current Password *</label>
                                    <input type="password" name="current_password" class="form-control" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">New Password *</label>
                                    <input type="password" name="new_password" class="form-control" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Confirm Password *</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-key me-2"></i>Change Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom Scripts -->
    <script>
        // Enable tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
        
        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const input = this.previousElementSibling;
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
        
        // Form validation
        (function () {
            'use strict'
            
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation')
            
            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
        
        // Simulate profile completion calculation
        function calculateProfileCompletion() {
            // This is a simplified example - in a real app, you would check actual field completion
            const progress = document.querySelector('.progress-bar');
            let completion = 85; // Base completion percentage
            
            // Update progress bar
            progress.style.width = completion + '%';
            progress.setAttribute('aria-valuenow', completion);
            progress.previousElementSibling.textContent = completion + '%';
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            calculateProfileCompletion();
        });
    </script>
</body>
</html> 