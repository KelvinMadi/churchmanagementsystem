<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
$csrf_token = generate_csrf_token();
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger">Invalid session token. Please refresh and try again.</div>';
    } else {
    $email = trim($_POST['email']);
    if ($email) {
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id);
            $stmt->fetch();
            // Generate a secure token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            // Store token in password_resets table (create if not exists)
            $conn->query('CREATE TABLE IF NOT EXISTS password_resets (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, email VARCHAR(255), token VARCHAR(64), expires_at DATETIME, used TINYINT(1) DEFAULT 0)');
            $stmt2 = $conn->prepare('INSERT INTO password_resets (user_id, email, token, expires_at) VALUES (?, ?, ?, ?)');
            $stmt2->bind_param('isss', $user_id, $email, $token, $expires);
            $stmt2->execute();
            $stmt2->close();
            // Send reset email
            $reset_link = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/reset_password.php?token=' . $token;
            $subject = 'Password Reset Request';
            $body = "Hello,\n\nTo reset your password, click the link below or copy and paste it into your browser:\n$reset_link\n\nThis link will expire in 1 hour. If you did not request a password reset, please ignore this email.";
            $headers = 'From: no-reply@yourchurch.com';
            @mail($email, $subject, $body, $headers);
            $message = '<div class="alert alert-success">If the email exists, a password reset link has been sent.</div>';
        } else {
            $message = '<div class="alert alert-info">If the email exists, a password reset link has been sent.</div>';
        }
        $stmt->close();
    } else {
        $message = '<div class="alert alert-warning">Please enter your email address.</div>';
    }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card">
                <div class="card-header bg-primary text-white text-center">
                    <h4 class="mb-0"><i class="fas fa-unlock-alt me-2"></i>Forgot Password</h4>
                </div>
                <div class="card-body p-4">
                    <?php echo $message; ?>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <div class="mb-3">
                            <label class="form-label">Enter your email address</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Send Reset Link</button>
                    </form>
                    <div class="text-center mt-3">
                        <a href="login.php" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i>Back to Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html> 