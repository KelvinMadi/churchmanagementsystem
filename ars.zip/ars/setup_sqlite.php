<?php
// SQLite database setup script
$database_file = __DIR__ . '/church_management.db';

try {
    // Create SQLite connection
    $pdo = new PDO("sqlite:$database_file", null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    
    echo "SQLite database created successfully.\n";
    
    // Create tables (SQLite compatible version)
    $sql = "
    -- Users table
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'member',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    
    -- Members table
    CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        phone TEXT,
        address TEXT,
        birth_date DATE,
        baptism_date DATE,
        ministry TEXT DEFAULT 'none',
        emergency_contact TEXT,
        emergency_phone TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    
    -- Insert default admin user
    INSERT OR IGNORE INTO users (name, email, password, role) VALUES 
    ('Administrator', 'admin@church.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
    ";
    
    $pdo->exec($sql);
    echo "Database tables created successfully!\n";
    echo "Default admin user created: admin@church.com (password: admin123)\n";
    
} catch (PDOException $e) {
    die("Setup failed: " . $e->getMessage() . "\n");
}
?>
