<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Please log in to comment']);
    exit();
}

$user_id = $_SESSION['user_id'];
$post_id = $_POST['post_id'] ?? 0;
$content = trim($_POST['content'] ?? '');

if (empty($post_id) || empty($content)) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit();
}

// Insert comment
$content_escaped = $conn->real_escape_string($content);
$sql = "INSERT INTO community_comments (post_id, user_id, content) 
        VALUES ($post_id, $user_id, '$content_escaped')";

if ($conn->query($sql)) {
    // Get user info for the response
    $user = $conn->query("SELECT name, profile_pic FROM users WHERE id = $user_id")->fetch_assoc();
    
    echo json_encode([
        'success' => true,
        'comment' => [
            'content' => $content,
            'created_at' => date('Y-m-d H:i:s')
        ],
        'user_name' => $user['name'],
        'user_avatar' => $user['profile_pic']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add comment']);
}
?>
