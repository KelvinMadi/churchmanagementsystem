<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

$user_id = $_SESSION['user_id'];
$post_id = $_POST['post_id'] ?? 0;
$action = $_POST['action'] ?? 'like';

if (empty($post_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid post ID']);
    exit();
}

if ($action === 'like') {
    // Check if already liked
    $check = $conn->query("SELECT id FROM community_likes WHERE post_id = $post_id AND user_id = $user_id");
    
    if ($check && $check->num_rows === 0) {
        // Add like
        $conn->query("INSERT INTO community_likes (post_id, user_id) VALUES ($post_id, $user_id)");
    }
} else {
    // Remove like
    $conn->query("DELETE FROM community_likes WHERE post_id = $post_id AND user_id = $user_id");
}

// Get updated like count
$like_count = $conn->query("SELECT COUNT(*) as count FROM community_likes WHERE post_id = $post_id")->fetch_assoc()['count'];

echo json_encode([
    'success' => true,
    'like_count' => $like_count
]);
?>
