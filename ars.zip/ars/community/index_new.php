<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check database connection
if (!isset($conn) || !$conn) {
    die('Database connection failed');
}

// Initialize community data files
$data_dir = __DIR__ . '/../data/';
$posts_file = $data_dir . 'community_posts.json';
$comments_file = $data_dir . 'community_comments.json';
$likes_file = $data_dir . 'community_likes.json';

// Create files if they don't exist
foreach ([$posts_file, $comments_file, $likes_file] as $file) {
    if (!file_exists($file)) {
        file_put_contents($file, json_encode([]));
    }
}

// Check if user is logged in
if (!is_logged_in()) {
    header('Location: ../login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_role = $_SESSION['user_role'] ?? 'member';
$message = '';

// Handle new post submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_post'])) {
    $content = trim($_POST['content'] ?? '');
    $title = trim($_POST['title'] ?? '');
    
    if (!empty($content) && !empty($title)) {
        $posts = json_decode(file_get_contents($posts_file), true) ?: [];
        $newPost = [
            'id' => uniqid(),
            'user_id' => $user_id,
            'user_name' => $user_name,
            'title' => $title,
            'content' => $content,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        $posts[] = $newPost;
        if (file_put_contents($posts_file, json_encode($posts, JSON_PRETTY_PRINT))) {
            $message = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>Post created successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
            // Redirect to prevent form resubmission
            header('Location: index.php');
            exit();
        } else {
            $message = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>Error creating post. Please try again.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
    } else {
        $message = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i class="fas fa-info-circle me-2"></i>Please fill in both title and content.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
}

// Handle comment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_comment') {
    $comment = trim($_POST['comment'] ?? '');
    $post_id = $_POST['post_id'] ?? '';
    
    if (!empty($comment) && !empty($post_id)) {
        $comments = file_exists($comments_file) ? json_decode(file_get_contents($comments_file), true) : [];
        
        $newComment = [
            'id' => uniqid(),
            'post_id' => $post_id,
            'user_id' => $user_id,
            'user_name' => $user_name,
            'content' => $comment,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $comments[] = $newComment;
        if (file_put_contents($comments_file, json_encode($comments, JSON_PRETTY_PRINT))) {
            // Redirect to prevent form resubmission
            header('Location: ' . $_SERVER['REQUEST_URI'] . '#post-' . $post_id);
            exit();
        } else {
            $message = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>Error adding comment. Please try again.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
    } else {
        $message = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i class="fas fa-info-circle me-2"></i>Please enter a comment.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
}

// Get all posts with comments and likes
$posts = [];
if (file_exists($posts_file)) {
    $posts = json_decode(file_get_contents($posts_file), true) ?: [];
    
    // Get all comments
    $all_comments = [];
    if (file_exists($comments_file)) {
        $all_comments = json_decode(file_get_contents($comments_file), true) ?: [];
    }
    
    // Get all likes
    $all_likes = [];
    if (file_exists($likes_file)) {
        $all_likes = json_decode(file_get_contents($likes_file), true) ?: [];
    }
    
    // Process posts to include comments and like counts
    foreach ($posts as &$post) {
        $post['comments'] = array_filter($all_comments, function($comment) use ($post) {
            return $comment['post_id'] === $post['id'];
        });
        
        $post['like_count'] = count(array_filter($all_likes, function($like) use ($post) {
            return $like['post_id'] === $post['id'];
        }));
        
        $post['is_liked'] = in_array($user_id, array_column(array_filter($all_likes, function($like) use ($post) {
            return $like['post_id'] === $post['id'];
        }), 'user_id'));
    }
    
    // Sort posts by creation date (newest first)
    usort($posts, function($a, $b) {
        return strtotime($b['created_at']) - strtotime($a['created_at']);
    });
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root {
            --primary-color: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --gray: #6c757d;
            --light-gray: #f1f3f5;
            --border-radius: 8px;
            --box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s ease;
        }
        
        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            color: #333;
        }
        
        .community-header {
            background: linear-gradient(135deg, var(--secondary), #34495e);
            color: white;
            padding: 4rem 0 3rem;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .community-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('../images/pattern.png') center/cover;
            opacity: 0.05;
            pointer-events: none;
        }
        
        .community-header h1 {
            font-weight: 700;
            margin-bottom: 0.5rem;
            position: relative;
        }
        
        .community-header p {
            opacity: 0.9;
            font-size: 1.1rem;
            max-width: 700px;
            margin: 0 auto;
            position: relative;
        }
        
        .post-card {
            background: white;
            border: none;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            margin-bottom: 1.5rem;
            transition: var(--transition);
            overflow: hidden;
        }
        
        .post-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        
        .post-header {
            display: flex;
            align-items: center;
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .user-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--light);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: var(--transition);
        }
        
        .user-avatar:hover {
            transform: scale(1.05);
        }
        
        .user-info {
            margin-left: 12px;
        }
        
        .user-name {
            font-weight: 600;
            margin: 0;
            color: var(--dark);
            font-size: 1rem;
        }
        
        .post-time {
            font-size: 0.8rem;
            color: var(--gray);
            margin: 0;
        }
        
        .post-content {
            padding: 1.5rem;
        }
        
        .post-title {
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 0.75rem;
            font-size: 1.4rem;
        }
        
        .post-text {
            color: #4a5568;
            line-height: 1.7;
            margin-bottom: 0;
            font-size: 1.05rem;
        }
        
        .post-actions {
            display: flex;
            padding: 0.75rem 1.5rem;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            background-color: #fcfcfc;
        }
        
        .action-btn {
            display: inline-flex;
            align-items: center;
            background: none;
            border: none;
            color: var(--gray);
            padding: 0.5rem 1rem;
            margin-right: 0.5rem;
            border-radius: 20px;
            transition: var(--transition);
            font-weight: 500;
            font-size: 0.9rem;
            cursor: pointer;
            text-decoration: none;
        }
        
        .action-btn:hover {
            background-color: rgba(0, 0, 0, 0.03);
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .action-btn i {
            margin-right: 6px;
            font-size: 1.1em;
        }
        
        .action-btn.liked {
            color: #e74c3c;
        }
        
        .action-btn.liked i {
            font-weight: 900;
        }
        
        .comments-section {
            background-color: #f8f9fa;
            padding: 1rem 1.5rem;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            display: none;
        }
        
        .comment {
            display: flex;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .comment:last-child {
            margin-bottom: 0.5rem;
            padding-bottom: 0;
            border-bottom: none;
        }
        
        .comment-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            border: 2px solid white;
            flex-shrink: 0;
        }
        
        .comment-content {
            flex: 1;
        }
        
        .comment-header {
            display: flex;
            align-items: center;
            margin-bottom: 4px;
        }
        
        .comment-author {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--dark);
            margin: 0 8px 0 0;
        }
        
        .comment-time {
            font-size: 0.75rem;
            color: var(--gray);
        }
        
        .comment-text {
            font-size: 0.95rem;
            color: #4a5568;
            margin: 0;
            line-height: 1.6;
        }
        
        .comment-form {
            margin-top: 1rem;
            display: flex;
        }
        
        .comment-input {
            flex: 1;
            border: 1px solid #dee2e6;
            border-radius: 20px;
            padding: 0.5rem 1rem;
            font-size: 0.95rem;
            transition: var(--transition);
        }
        
        .comment-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
            outline: none;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-weight: 500;
            padding: 0.5rem 1.5rem;
            border-radius: 20px;
            transition: var(--transition);
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-1px);
        }
        
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .no-posts {
            text-align: center;
            padding: 3rem 2rem;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }
        
        .no-posts i {
            font-size: 3.5rem;
            color: #bdc3c7;
            margin-bottom: 1.5rem;
            opacity: 0.7;
        }
        
        .no-posts h4 {
            color: var(--dark);
            margin-bottom: 0.75rem;
            font-weight: 600;
        }
        
        .no-posts p {
            color: var(--gray);
            margin-bottom: 1.5rem;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }
        
        .like-count, .comment-count {
            font-weight: 500;
            margin-left: 4px;
        }
        
        /* Create Post Modal */
        .modal-content {
            border: none;
            border-radius: var(--border-radius);
            overflow: hidden;
        }
        
        .modal-header {
            background-color: var(--secondary);
            color: white;
            padding: 1.25rem 1.5rem;
            border-bottom: none;
        }
        
        .modal-title {
            font-weight: 600;
        }
        
        .btn-close {
            filter: invert(1) brightness(2);
            opacity: 0.8;
        }
        
        .form-label {
            font-weight: 500;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-select {
            border-radius: var(--border-radius);
            padding: 0.6rem 1rem;
            border-color: #dee2e6;
            transition: var(--transition);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .community-header {
                padding: 3rem 1rem 2rem;
                text-align: center;
            }
            
            .post-header {
                padding: 1rem;
            }
            
            .post-content {
                padding: 1.25rem 1rem;
            }
            
            .post-actions {
                padding: 0.75rem 1rem;
                justify-content: space-around;
            }
            
            .action-btn {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
                margin: 0;
            }
            
            .comments-section {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <?php include '../includes/navbar.php'; ?>

    <!-- Community Header -->
    <header class="community-header">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8">
                    <h1><i class="fas fa-users me-2"></i>Community Hub</h1>
                    <p class="mb-4">Connect, share, and grow together with your church community. Share your thoughts, prayer requests, and encouragement.</p>
                    <button class="btn btn-light btn-lg" data-bs-toggle="modal" data-bs-target="#createPostModal">
                        <i class="fas fa-plus me-2"></i>Create Post
                    </button>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container mb-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php echo $message; ?>
                
                <!-- Posts Feed -->
                <div class="posts-feed">
                    <?php if (!empty($posts)): ?>
                        <?php foreach ($posts as $post): ?>
                            <div class="post-card" id="post-<?php echo $post['id']; ?>">
                                <!-- Post Header -->
                                <div class="post-header">
                                    <img src="<?php echo !empty($post['profile_pic']) ? htmlspecialchars($post['profile_pic']) : '../images/default-avatar.png'; ?>" 
                                         alt="Profile" class="user-avatar">
                                    <div class="user-info">
                                        <div class="user-name"><?php echo htmlspecialchars($post['user_name'] ?? 'User'); ?></div>
                                        <div class="post-time">
                                            <i class="far fa-clock me-1"></i>
                                            <?php 
                                            $postTime = new DateTime($post['created_at']);
                                            $now = new DateTime();
                                            $interval = $postTime->diff($now);
                                            
                                            if ($interval->y > 0) {
                                                echo $interval->y . ' year' . ($interval->y > 1 ? 's' : '') . ' ago';
                                            } elseif ($interval->m > 0) {
                                                echo $interval->m . ' month' . ($interval->m > 1 ? 's' : '') . ' ago';
                                            } elseif ($interval->d > 0) {
                                                echo $interval->d . ' day' . ($interval->d > 1 ? 's' : '') . ' ago';
                                            } elseif ($interval->h > 0) {
                                                echo $interval->h . ' hour' . ($interval->h > 1 ? 's' : '') . ' ago';
                                            } elseif ($interval->i > 0) {
                                                echo $interval->i . ' minute' . ($interval->i > 1 ? 's' : '') . ' ago';
                                            } else {
                                                echo 'Just now';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Post Content -->
                                <div class="post-content">
                                    <h3 class="post-title"><?php echo htmlspecialchars($post['title']); ?></h3>
                                    <p class="post-text"><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                                </div>
                                
                                <!-- Post Actions -->
                                <div class="post-actions">
                                    <button class="action-btn like-btn <?php echo !empty($post['is_liked']) ? 'liked' : ''; ?>" 
                                            data-post-id="<?php echo $post['id']; ?>">
                                        <i class="<?php echo !empty($post['is_liked']) ? 'fas' : 'far'; ?> fa-heart"></i>
                                        <span class="like-count"><?php echo $post['like_count']; ?></span>
                                    </button>
                                    
                                    <button class="action-btn comment-toggle" 
                                            data-post-id="<?php echo $post['id']; ?>">
                                        <i class="far fa-comment"></i>
                                        <span class="comment-count"><?php echo count($post['comments'] ?? []); ?></span>
                                    </button>
                                    
                                    <div class="ms-auto">
                                        <?php if ($post['user_id'] === $user_id || $user_role === 'admin'): ?>
                                            <button class="action-btn text-danger delete-post" data-post-id="<?php echo $post['id']; ?>">
                                                <i class="far fa-trash-alt"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Comments Section -->
                                <div class="comments-section" id="comments-<?php echo $post['id']; ?>">
                                    <h6 class="mb-3">Comments</h6>
                                    
                                    <!-- Comments List -->
                                    <div class="comments-list mb-3">
                                        <?php if (!empty($post['comments'])): ?>
                                            <?php foreach ($post['comments'] as $comment): ?>
                                                <div class="comment">
                                                    <img src="<?php echo !empty($comment['profile_pic']) ? htmlspecialchars($comment['profile_pic']) : '../images/default-avatar.png'; ?>" 
                                                         alt="Profile" class="comment-avatar">
                                                    <div class="comment-content">
                                                        <div class="comment-header">
                                                            <div class="comment-author"><?php echo htmlspecialchars($comment['user_name'] ?? 'User'); ?></div>
                                                            <div class="comment-time">
                                                                <?php 
                                                                $commentTime = new DateTime($comment['created_at']);
                                                                $interval = $commentTime->diff($now);
                                                                
                                                                if ($interval->y > 0) {
                                                                    echo $interval->y . 'y';
                                                                } elseif ($interval->m > 0) {
                                                                    echo $interval->m . 'mo';
                                                                } elseif ($interval->d > 0) {
                                                                    echo $interval->d . 'd';
                                                                } elseif ($interval->h > 0) {
                                                                    echo $interval->h . 'h';
                                                                } elseif ($interval->i > 0) {
                                                                    echo $interval->i . 'm';
                                                                } else {
                                                                    echo 'Just now';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <p class="comment-text"><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <p class="text-muted text-center py-3">No comments yet. Be the first to comment!</p>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Comment Form -->
                                    <form class="comment-form" data-post-id="<?php echo $post['id']; ?>">
                                        <input type="hidden" name="action" value="add_comment">
                                        <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                        <input type="text" name="comment" class="form-control comment-input" 
                                               placeholder="Write a comment..." required>
                                        <button type="submit" class="btn btn-primary ms-2">
                                            <i class="fas fa-paper-plane"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-posts">
                            <i class="fas fa-comments"></i>
                            <h4>No Posts Yet</h4>
                            <p>Be the first to share something with the community. Your post could inspire or help someone in need.</p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createPostModal">
                                <i class="fas fa-plus me-2"></i>Create Your First Post
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Post Modal -->
    <div class="modal fade" id="createPostModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Post</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="postTitle" class="form-label">Title</label>
                            <input type="text" class="form-control" id="postTitle" name="title" required 
                                   placeholder="What's on your mind?">
                        </div>
                        <div class="mb-3">
                            <label for="postContent" class="form-label">Content</label>
                            <textarea class="form-control" id="postContent" name="content" rows="4" required
                                      placeholder="Share your thoughts, prayer requests, or encouragement..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="create_post" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-1"></i> Post
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle comments section
            $('.comment-toggle').on('click', function() {
                const postId = $(this).data('post-id');
                $(`#comments-${postId}`).slideToggle('fast');
            });
            
            // Handle like button click
            $('.like-btn').on('click', function() {
                const $btn = $(this);
                const postId = $btn.data('post-id');
                const isLiked = $btn.hasClass('liked');
                const $icon = $btn.find('i');
                const $likeCount = $btn.find('.like-count');
                
                // Optimistic UI update
                const currentLikes = parseInt($likeCount.text());
                $likeCount.text(isLiked ? currentLikes - 1 : currentLikes + 1);
                $btn.toggleClass('liked', !isLiked);
                $icon.toggleClass('far fas');
                
                // Send AJAX request
                $.ajax({
                    url: 'api/like.php',
                    method: 'POST',
                    data: {
                        post_id: postId,
                        action: isLiked ? 'unlike' : 'like'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (!response.success) {
                            // Revert UI if there was an error
                            $likeCount.text(isLiked ? currentLikes : currentLikes - 1);
                            $btn.toggleClass('liked', isLiked);
                            $icon.toggleClass('far fas');
                            alert('Error: ' + (response.message || 'Failed to update like'));
                        }
                    },
                    error: function() {
                        // Revert UI on error
                        $likeCount.text(isLiked ? currentLikes : currentLikes - 1);
                        $btn.toggleClass('liked', isLiked);
                        $icon.toggleClass('far fas');
                        alert('An error occurred. Please try again.');
                    }
                });
            });
            
            // Handle comment form submission
            $('.comment-form').on('submit', function(e) {
                e.preventDefault();
                const $form = $(this);
                const postId = $form.data('post-id');
                const $input = $form.find('input[name="comment"]');
                const comment = $input.val().trim();
                
                if (!comment) return;
                
                // Disable form while submitting
                $form.find('button[type="submit"]').prop('disabled', true);
                
                // Add loading state
                const $submitBtn = $form.find('button[type="submit"]');
                const originalBtnText = $submitBtn.html();
                $submitBtn.html('<i class="fas fa-spinner fa-spin"></i>');
                
                // Send AJAX request
                $.ajax({
                    url: 'index.php',
                    method: 'POST',
                    data: {
                        action: 'add_comment',
                        post_id: postId,
                        comment: comment
                    },
                    success: function() {
                        // The page will reload on success due to PHP redirect
                    },
                    error: function() {
                        alert('An error occurred while posting your comment');
                        $submitBtn.html(originalBtnText);
                        $form.find('button[type="submit"]').prop('disabled', false);
                    }
                });
            });
            
            // Handle delete post
            $('.delete-post').on('click', function() {
                if (confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
                    const postId = $(this).data('post-id');
                    // Add AJAX call to delete post
                    $.ajax({
                        url: 'api/delete_post.php',
                        method: 'POST',
                        data: { post_id: postId },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                $(`#post-${postId}`).fadeOut(300, function() {
                                    $(this).remove();
                                    // Show no posts message if this was the last post
                                    if ($('.post-card').length === 0) {
                                        $('.posts-feed').html(`
                                            <div class="no-posts">
                                                <i class="fas fa-comments"></i>
                                                <h4>No Posts Yet</h4>
                                                <p>Be the first to share something with the community. Your post could inspire or help someone in need.</p>
                                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createPostModal">
                                                    <i class="fas fa-plus me-2"></i>Create Your First Post
                                                </button>
                                            </div>
                                        `);
                                    }
                                });
                            } else {
                                alert('Error: ' + (response.message || 'Failed to delete post'));
                            }
                        },
                        error: function() {
                            alert('An error occurred. Please try again.');
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
