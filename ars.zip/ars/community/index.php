<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/community_errors.log');

// Debug: Log start of script
error_log("Community page accessed: " . date('Y-m-d H:i:s'));

// Initialize variables
$error_message = '';
$message = '';
$posts = [];

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    require_once '../includes/db.php';
    require_once '../includes/auth.php';
    
    // Debug: Check if required files exist
    if (!file_exists('../includes/db.php')) {
        throw new Exception("db.php not found");
    }
    if (!file_exists('../includes/auth.php')) {
        throw new Exception("auth.php not found");
    }

    // Debug: Check database connection
    if (!isset($conn) || !$conn) {
        throw new Exception('Database connection failed');
    }

    // Initialize community data files if they don't exist
    $data_dir = __DIR__ . '/../data/';
    
    // Debug: Check data directory
    if (!is_dir($data_dir) && !mkdir($data_dir, 0755, true)) {
        throw new Exception("Failed to create data directory: $data_dir");
    }
    
    $posts_file = $data_dir . 'community_posts.json';
    $comments_file = $data_dir . 'community_comments.json';
    $likes_file = $data_dir . 'community_likes.json';
    
    // Debug: Log file paths
    error_log("Posts file: $posts_file");
    error_log("Comments file: $comments_file");
    error_log("Likes file: $likes_file");
    
    // Create files if they don't exist
    $files = [
        $posts_file => [],
        $comments_file => [],
        $likes_file => []
    ];
    
    foreach ($files as $file => $default_data) {
        if (!file_exists($file)) {
            $result = file_put_contents($file, json_encode($default_data, JSON_PRETTY_PRINT));
            if ($result === false) {
                error_log("Failed to create file: $file");
                throw new Exception("Failed to initialize data file: $file");
            }
            error_log("Created file: $file");
        } elseif (!is_writable($file)) {
            error_log("File not writable: $file");
            throw new Exception("Data file not writable: $file");
        }
    }

    // Check if user is logged in
    if (!is_logged_in()) {
        header('Location: ../login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit();
    }

    // Debug: Check session
    error_log("Session data: " . print_r($_SESSION, true));
    
    if (!isset($_SESSION['user_id'])) {
        error_log("User not logged in, redirecting to login");
        header('Location: ../login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['user_role'] ?? 'member';
    $message = '';
    
    // Debug: Log user info
    error_log("User ID: $user_id, Role: $user_role");

// Handle new post submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_post'])) {
    $content = trim($_POST['content'] ?? '');
    $title = trim($_POST['title'] ?? '');
    
    if (!empty($content) && !empty($title)) {
        $posts = json_decode(file_get_contents($posts_file), true) ?: [];
        $newPost = [
            'id' => uniqid(),
            'user_id' => $user_id,
            'title' => $title,
            'content' => $content,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        $posts[] = $newPost;
        if (file_put_contents($posts_file, json_encode($posts, JSON_PRETTY_PRINT))) {
            $message = '<div class="alert alert-success">Post created successfully!</div>';
        } else {
            $message = '<div class="alert alert-danger">Error creating post. Please try again.</div>';
        }
    } else {
        $message = '<div class="alert alert-warning">Please fill in both title and content.</div>';
    }
}

// Handle comment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_comment') {
    $comment = trim($_POST['comment'] ?? '');
    $post_id = $_POST['post_id'] ?? '';
    
    if (!empty($comment) && !empty($post_id)) {
        $comments = file_exists($comments_file) ? json_decode(file_get_contents($comments_file), true) : [];
        
        $newComment = [
            'id' => uniqid(),
            'post_id' => $post_id,
            'user_id' => $user_id,
            'content' => $comment,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $comments[] = $newComment;
        if (file_put_contents($comments_file, json_encode($comments, JSON_PRETTY_PRINT))) {
            // Redirect to prevent form resubmission
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit();
        } else {
            $message = '<div class="alert alert-danger">Error adding comment. Please try again.</div>';
        }
    } else {
        $message = '<div class="alert alert-warning">Please enter a comment.</div>';
    }
}

    // Get all community posts with user info and like count
    $posts = [];
    
    // Debug: Check if posts file exists and is readable
    if (!file_exists($posts_file)) {
        error_log("Posts file does not exist: $posts_file");
    } elseif (!is_readable($posts_file)) {
        error_log("Posts file not readable: $posts_file");
    } else {
        $posts_content = file_get_contents($posts_file);
        if ($posts_content === false) {
            error_log("Failed to read posts file: $posts_file");
        } else {
            $posts = json_decode($posts_content, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                error_log("JSON decode error in posts file: " . json_last_error_msg());
                $posts = [];
            } else {
                $posts = is_array($posts) ? $posts : [];
                error_log("Loaded " . count($posts) . " posts from file");
            }
        }
    }
    
    // Get user info for each post
    $users = [];
    $users_file = $data_dir . 'users.json';
    if (file_exists($users_file) && is_readable($users_file)) {
        $users_content = file_get_contents($users_file);
        if ($users_content !== false) {
            $users = json_decode($users_content, true) ?: [];
            error_log("Loaded " . count($users) . " users from file");
        }
    } else {
        error_log("Users file not found or not readable: $users_file");
    }
    
    // Get likes and comments count
    $likes = [];
    if (file_exists($likes_file) && is_readable($likes_file)) {
        $likes_content = file_get_contents($likes_file);
        if ($likes_content !== false) {
            $likes = json_decode($likes_content, true) ?: [];
        }
    }
    
    $comments = [];
    if (file_exists($comments_file) && is_readable($comments_file)) {
        $comments_content = file_get_contents($comments_file);
        if ($comments_content !== false) {
            $comments = json_decode($comments_content, true) ?: [];
        }
    }
    
    // Debug: Log counts
    error_log("Processing " . count($posts) . " posts, " . count($users) . " users, " . 
              count($likes) . " likes, " . count($comments) . " comments");
    
    // Add additional info to each post
    foreach ($posts as &$post) {
        if (!is_array($post)) {
            error_log("Invalid post data: " . print_r($post, true));
            continue;
        }
        
        $post['author'] = isset($post['user_id'], $users[$post['user_id']]['name']) 
            ? $users[$post['user_id']]['name'] 
            : 'Unknown User';
            
        $post['profile_pic'] = isset($post['user_id'], $users[$post['user_id']]['profile_pic']) 
            ? $users[$post['user_id']]['profile_pic'] 
            : '../images/default-avatar.png';
            
        $post['like_count'] = count(array_filter($likes, function($like) use ($post) {
            return isset($like['post_id']) && $like['post_id'] == $post['id'];
        }));
        
        $post['comment_count'] = count(array_filter($comments, function($comment) use ($post) {
            return isset($comment['post_id']) && $comment['post_id'] == $post['id'];
        }));
    }
    
    // Sort posts by creation date (newest first)
    usort($posts, function($a, $b) {
        $timeA = isset($a['created_at']) ? strtotime($a['created_at']) : 0;
        $timeB = isset($b['created_at']) ? strtotime($b['created_at']) : 0;
        return $timeB - $timeA;
    });
    
    // Debug: Log first post for verification
    if (!empty($posts)) {
        error_log("First post: " . print_r(reset($posts), true));
    }
} catch (Exception $e) {
    // Log the error and show a user-friendly message
    error_log("Error in community page: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $error_message = "An error occurred while loading the community page. Please try again later.";
    if (ini_get('display_errors')) {
        $error_message .= "\n\nError: " . $e->getMessage();
    }
}
?>
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/community.css">
</head>
<body>
    <!-- Navigation -->
    <?php include '../includes/navbar.php'; ?>

    <!-- Community Header -->
    <div class="community-header">
        <div class="container">
            <h1><i class="fas fa-users me-3"></i>Church Community</h1>
            <p class="lead">Connect, share, and grow together as a church family. Share your thoughts, prayer requests, and encourage one another.</p>
            <button class="btn btn-primary btn-lg" data-bs-toggle="modal" data-bs-target="#createPostModal">
                <i class="fas fa-plus me-2"></i>Create Post
            </button>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">

                <?php 
                // Display error message if there was an exception
                if (isset($error_message)): ?>
                    <div class="alert alert-danger">
                        <?php echo nl2br(htmlspecialchars($error_message)); ?>
                        <div class="mt-2">
                            <small>For administrators: Check the error log at <?php echo htmlspecialchars(__DIR__ . '/community_errors.log'); ?></small>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($message) && !empty($message)): ?>
                    <div class="alert alert-info">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <!-- Posts Feed -->
                <div class="posts-feed">
                    <?php if (!empty($posts)): ?>
                        <?php foreach ($posts as $post): ?>
                            <div class="card post-card">
                                <div class="post-header">
                                    <img src="<?php echo !empty($post['profile_pic']) ? htmlspecialchars($post['profile_pic']) : '../images/default-avatar.png'; ?>" 
                                         alt="Profile" class="profile-pic">
                                    <div class="post-meta">
                                        <h5 class="post-author"><?php echo htmlspecialchars($post['author']); ?></h5>
                                        <p class="post-time"><?php echo date('M j, Y \a\t g:i A', strtotime($post['created_at'])); ?></p>
                                    </div>
                                </div>
                                
                                <div class="post-content">
                                    <h3 class="post-title"><?php echo htmlspecialchars($post['title']); ?></h3>
                                    <p class="post-text"><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                                </div>
                                
                                <div class="post-actions">
                                    <button class="action-btn like-btn" data-post-id="<?php echo $post['id']; ?>">
                                        <i class="far fa-heart"></i>
                                        <span class="like-count"><?php echo $post['like_count']; ?></span>
                                    </button>
                                    <button class="action-btn comment-btn" data-bs-toggle="collapse" data-bs-target="#comments-<?php echo $post['id']; ?>">
                                        <i class="far fa-comment"></i>
                                        <span class="comment-count"><?php echo $post['comment_count']; ?></span>
                                    </button>
                                </div>
                                    
                                <!-- Comments Section -->
                                <div class="collapse" id="comments-<?php echo $post['id']; ?>">
                                    <div class="comments-section">
                                        <div class="comments-list">
                                            <?php 
                                            $post_comments = [];
                                            if (file_exists($comments_file)) {
                                                $all_comments = json_decode(file_get_contents($comments_file), true) ?: [];
                                                $post_comments = array_filter($all_comments, function($comment) use ($post) {
                                                    return $comment['post_id'] == $post['id'];
                                                });
                                            }
                                            
                                            if (!empty($post_comments)): 
                                                foreach ($post_comments as $comment): 
                                                    $user = [];
                                                    if (file_exists($data_dir . 'users.json')) {
                                                        $users = json_decode(file_get_contents($data_dir . 'users.json'), true) ?: [];
                                                        $user = $users[$comment['user_id']] ?? [];
                                                    }
                                            ?>
                                                <div class="comment">
                                                    <img src="<?php echo !empty($user['profile_pic']) ? htmlspecialchars($user['profile_pic']) : '../images/default-avatar.png'; ?>" 
                                                         alt="Profile" class="comment-avatar">
                                                    <div class="comment-content">
                                                        <div class="comment-header">
                                                            <h6 class="comment-author"><?php echo htmlspecialchars($user['name'] ?? 'Unknown User'); ?></h6>
                                                            <span class="comment-time"><?php echo date('M j, g:i A', strtotime($comment['created_at'])); ?></span>
                                                        </div>
                                                        <p class="comment-text"><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>
                                                    </div>
                                                </div>
                                            <?php 
                                                endforeach; 
                                            else: 
                                            ?>
                                                <p class="text-center text-muted py-3">No comments yet. Be the first to comment!</p>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <!-- Comment Form -->
                                        <form class="comment-form" data-post-id="<?php echo $post['id']; ?>" method="POST">
                                            <input type="hidden" name="action" value="add_comment">
                                            <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                            <div class="position-relative">
                                                <input type="text" name="comment" class="form-control" placeholder="Write a comment..." required>
                                                <button class="btn btn-primary" type="submit">Post</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-comments"></i>
                            <h4>No Posts Yet</h4>
                            <p>Be the first to share something with the community! Your post could inspire or help someone in our church family.</p>
{{ ... }}
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createPostModal">
                                <i class="fas fa-plus me-2"></i>Create Your First Post
                            </button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Post Modal -->
    <div class="modal fade" id="createPostModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Create New Post</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-4">
                            <label for="postTitle" class="form-label">Title</label>
                            <input type="text" class="form-control form-control-lg" id="postTitle" name="title" placeholder="What's the title of your post?" required>
                        </div>
                        <div class="mb-3">
                            <label for="postContent" class="form-label">Share your thoughts</label>
                            <textarea class="form-control" id="postContent" name="content" rows="6" 
                                      placeholder="Share what's on your heart with the community..." required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="create_post" class="btn btn-primary px-4">
                            <i class="fas fa-paper-plane me-2"></i>Post to Community
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/community.js"></script>
</body>
</html>
