<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_login();

$errors = [];
$member = [
    'name' => '',
    'email' => '',
    'phone' => '',
    'address' => '',
    'city' => '',
    'state' => '',
    'zip' => '',
    'status' => 'active',
    'ministry' => '',
    'join_date' => date('Y-m-d'),
    'birth_date' => '',
    'baptism_date' => '',
    'membership_date' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $member['name'] = trim($_POST['name'] ?? '');
    $member['email'] = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $member['phone'] = preg_replace('/[^0-9+]/', '', $_POST['phone'] ?? '');
    $member['address'] = trim($_POST['address'] ?? '');
    $member['city'] = trim($_POST['city'] ?? '');
    $member['state'] = trim($_POST['state'] ?? '');
    $member['zip'] = trim($_POST['zip'] ?? '');
    $member['status'] = in_array($_POST['status'], ['active', 'inactive', 'visitor']) ? $_POST['status'] : 'active';
    $member['ministry'] = trim($_POST['ministry'] ?? '');
    $member['join_date'] = !empty($_POST['join_date']) ? $_POST['join_date'] : date('Y-m-d');
    $member['birth_date'] = !empty($_POST['birth_date']) ? $_POST['birth_date'] : null;
    $member['baptism_date'] = !empty($_POST['baptism_date']) ? $_POST['baptism_date'] : null;
    $member['membership_date'] = !empty($_POST['membership_date']) ? $_POST['membership_date'] : null;

    // Validate required fields
    if (empty($member['name'])) {
        $errors[] = 'Name is required';
    }
    if (empty($member['email'])) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($member['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address';
    }

    if (empty($errors)) {
        // Save to JSON file
        $members_file = __DIR__ . '/data/members.json';
        $members = [];
        
        if (file_exists($members_file)) {
            $members = json_decode(file_get_contents($members_file), true) ?: [];
        }
        
        // Generate a new ID
        $new_id = 1;
        if (!empty($members)) {
            $ids = array_column($members, 'id');
            $new_id = max($ids) + 1;
        }
        
        // Add new member
        $member['id'] = $new_id;
        $member['created_at'] = date('Y-m-d H:i:s');
        $member['updated_at'] = date('Y-m-d H:i:s');
        
        $members[] = $member;
        
        // Save back to file
        if (file_put_contents($members_file, json_encode($members, JSON_PRETTY_PRINT))) {
            $_SESSION['success_message'] = 'Member added successfully';
            header('Location: members.php');
            exit();
        } else {
            $errors[] = 'Failed to save member. Please try again.';
        }
    }
}

$page_title = 'Add New Member';
include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Add New Member</h1>
        <div>
            <a href="members.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i> Back to Members
            </a>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST" id="memberForm">
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="mb-3">Personal Information</h5>
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($member['name']); ?>" required>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($member['email']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($member['phone']); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($member['address']); ?>">
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="city" class="form-label">City</label>
                                    <input type="text" class="form-control" id="city" name="city" value="<?php echo htmlspecialchars($member['city']); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="state" class="form-label">State</label>
                                    <input type="text" class="form-control" id="state" name="state" value="<?php echo htmlspecialchars($member['state']); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="zip" class="form-label">ZIP</label>
                                    <input type="text" class="form-control" id="zip" name="zip" value="<?php echo htmlspecialchars($member['zip']); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h5 class="mb-3">Church Information</h5>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status">
                                        <option value="active" <?php echo $member['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo $member['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                        <option value="visitor" <?php echo $member['status'] === 'visitor' ? 'selected' : ''; ?>>Visitor</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="ministry" class="form-label">Ministry</label>
                                    <input type="text" class="form-control" id="ministry" name="ministry" value="<?php echo htmlspecialchars($member['ministry']); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="join_date" class="form-label">Join Date</label>
                                    <input type="date" class="form-control" id="join_date" name="join_date" value="<?php echo htmlspecialchars($member['join_date']); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="birth_date" class="form-label">Birth Date</label>
                                    <input type="date" class="form-control" id="birth_date" name="birth_date" value="<?php echo htmlspecialchars($member['birth_date']); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="baptism_date" class="form-label">Baptism Date</label>
                                    <input type="date" class="form-control" id="baptism_date" name="baptism_date" value="<?php echo htmlspecialchars($member['baptism_date']); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="membership_date" class="form-label">Membership Date</label>
                                    <input type="date" class="form-control" id="membership_date" name="membership_date" value="<?php echo htmlspecialchars($member['membership_date']); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-end mt-4">
                    <button type="reset" class="btn btn-outline-secondary me-2">Reset</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Save Member
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
