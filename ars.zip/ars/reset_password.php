<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
$csrf_token = generate_csrf_token();
$message = '';
$show_form = false;
$token = $_GET['token'] ?? '';
if ($token) {
    $stmt = $conn->prepare('SELECT id, user_id, email, expires_at, used FROM password_resets WHERE token = ?');
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        if ($row['used']) {
            $message = '<div class="alert alert-danger">This reset link has already been used.</div>';
        } elseif (strtotime($row['expires_at']) < time()) {
            $message = '<div class="alert alert-danger">This reset link has expired.</div>';
        } else {
            $show_form = true;
            $user_id = $row['user_id'];
        }
    } else {
        $message = '<div class="alert alert-danger">Invalid reset link.</div>';
    }
    $stmt->close();
} else {
    $message = '<div class="alert alert-danger">No reset token provided.</div>';
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['token'], $_POST['password'], $_POST['confirm_password'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger">Invalid session token. Please refresh and try again.</div>';
        $show_form = true;
    } else {
    $token = $_POST['token'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    if ($password === $confirm_password && strlen($password) >= 6) {
        $stmt = $conn->prepare('SELECT id, user_id, used, expires_at FROM password_resets WHERE token = ?');
        $stmt->bind_param('s', $token);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            if ($row['used']) {
                $message = '<div class="alert alert-danger">This reset link has already been used.</div>';
            } elseif (strtotime($row['expires_at']) < time()) {
                $message = '<div class="alert alert-danger">This reset link has expired.</div>';
            } else {
                $user_id = $row['user_id'];
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt2 = $conn->prepare('UPDATE users SET password = ? WHERE id = ?');
                $stmt2->bind_param('si', $hashed, $user_id);
                if ($stmt2->execute()) {
                    $conn->query('UPDATE password_resets SET used = 1 WHERE id = ' . intval($row['id']));
                    $message = '<div class="alert alert-success">Your password has been reset. <a href="login.php">Login</a></div>';
                    $show_form = false;
                } else {
                    $message = '<div class="alert alert-danger">Error resetting password. Please try again.</div>';
                }
                $stmt2->close();
            }
        } else {
            $message = '<div class="alert alert-danger">Invalid reset link.</div>';
        }
        $stmt->close();
    } else {
        $message = '<div class="alert alert-warning">Passwords do not match or are too short (min 6 characters).</div>';
        $show_form = true;
    }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card">
                <div class="card-header bg-primary text-white text-center">
                    <h4 class="mb-0"><i class="fas fa-key me-2"></i>Reset Password</h4>
                </div>
                <div class="card-body p-4">
                    <?php echo $message; ?>
                    <?php if ($show_form): ?>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" name="password" class="form-control" required minlength="6">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required minlength="6">
                        </div>
                        <button type="submit" class="btn btn-success w-100">Reset Password</button>
                    </form>
                    <?php endif; ?>
                    <div class="text-center mt-3">
                        <a href="login.php" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i>Back to Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html> 