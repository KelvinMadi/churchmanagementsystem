-- Add sample sermons to the database
INSERT INTO sermons (title, content, scripture, date, uploaded_by) VALUES
('The Power of Prayer', 'Exploring the depths of prayer and how it transforms our spiritual lives.', 'James 5:13-16', '2024-10-01', 1),
('Walking in Faith', 'Understanding what it means to live a life of faith in everyday circumstances.', '2 Corinthians 5:7', '2024-09-28', 1),
('The Love of God', 'Discovering the depth and breadth of God\'s unconditional love for us.', 'Romans 8:38-39', '2024-09-21', 1),
('Spiritual Growth', 'Keys to growing in your relationship with God and maturing in faith.', '2 Peter 3:18', '2024-09-14', 1),
('Overcoming Temptation', 'Biblical strategies for resisting temptation and living victoriously.', '1 Corinthians 10:13', '2024-09-07', 1),
('The Holy Spirit\'s Guidance', 'Learning to recognize and follow the Holy Spirit\'s leading in your life.', 'John 16:13', '2024-08-31', 1),
('The Power of Forgiveness', 'How forgiveness sets us free and heals relationships.', 'Colossians 3:13', '2024-08-24', 1),
('Living with Purpose', 'Discovering and fulfilling God\'s unique purpose for your life.', 'Ephesians 2:10', '2024-08-17', 1),
('The Armor of God', 'Understanding and applying the spiritual armor in daily life.', 'Ephesians 6:10-18', '2024-08-10', 1),
('The Fruit of the Spirit', 'Cultivating the character of Christ through the Holy Spirit.', 'Galatians 5:22-23', '2024-08-03', 1);
