<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

// Sample data for generating members
$firstNames = ['James', 'Mary', 'John', 'Patricia', 'Robert', 'Jennifer', 'Michael', 'Linda', 'William', 'Elizabeth', 
              'David', 'Susan', 'Richard', 'Jessica', 'Joseph', 'Sarah', 'Thomas', 'Karen', 'Charles', 'Nancy',
              'Christopher', 'Lisa', 'Daniel', 'Margaret', 'Matthew', 'Betty', 'Anthony', 'Sandra', 'Donald', 'Ashley'];

$lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
             'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin',
             'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson'];

$streets = ['Main St', 'Oak Ave', 'Pine St', 'Cedar Ln', 'Elm St', 'Maple Ave', 'Washington St', 'Lake St', 'Park Ave', 'Church St'];
$cities = ['Louisville', 'Jeffersonville', 'New Albany', 'Clarksville', 'Sellersburg', 'Floyds Knobs', 'Charlestown', 'Georgetown'];
$states = ['KY', 'IN'];
$ministries = ['worship', 'youth', 'children', 'outreach', 'prayer', 'ushering', 'technical', 'none'];

// Function to generate a random date between two dates
function randomDate($start_date, $end_date) {
    $min = strtotime($start_date);
    $max = strtotime($end_date);
    $val = rand($min, $max);
    return date('Y-m-d', $val);
}

// Function to generate a random phone number
function randomPhone() {
    return sprintf('(%03d) %03d-%04d', rand(200, 999), rand(100, 999), rand(1000, 9999));
}

// Generate 50 members
$members = [];
for ($i = 0; $i < 50; $i++) {
    $firstName = $firstNames[array_rand($firstNames)];
    $lastName = $lastNames[array_rand($lastNames)];
    $email = strtolower($firstName[0] . $lastName . rand(1, 99) . '@example.com');
    $phone = randomPhone();
    $address = rand(100, 9999) . ' ' . $streets[array_rand($streets)] . ', ' . $cities[array_rand($cities)] . ', ' . $states[array_rand($states)] . ' ' . rand(10000, 99999);
    $birthDate = randomDate('1950-01-01', '2010-12-31');
    $baptismDate = randomDate($birthDate, date('Y-m-d'));
    $ministry = $ministries[array_rand($ministries)];
    $emergencyContact = $firstNames[array_rand($firstNames)] . ' ' . $lastNames[array_rand($lastNames)];
    $emergencyPhone = randomPhone();
    
    $members[] = [
        'name' => "$firstName $lastName",
        'email' => $email,
        'phone' => $phone,
        'address' => $address,
        'birth_date' => $birthDate,
        'baptism_date' => $baptismDate,
        'ministry' => $ministry,
        'emergency_contact' => $emergencyContact,
        'emergency_phone' => $emergencyPhone
    ];
}

// Save members to the database
$conn = new FileDB();
$added = 0;
$errors = [];

foreach ($members as $member) {
    try {
        // Generate a random password
        $password = bin2hex(random_bytes(8));
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert into users table
        $userSql = "INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, 'member', NOW())";
        $stmt = $conn->prepare($userSql);
        $stmt->bind_param('sss', $member['name'], $member['email'], $hashed);
        
        if ($stmt->execute()) {
            $user_id = $conn->insert_id;
            
            // Insert into members table
            $memberSql = "INSERT INTO members (user_id, phone, address, birth_date, baptism_date, ministry, emergency_contact, emergency_phone) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $mStmt = $conn->prepare($memberSql);
            $mStmt->bind_param('isssssss', 
                $user_id, 
                $member['phone'], 
                $member['address'],
                $member['birth_date'],
                $member['baptism_date'],
                $member['ministry'],
                $member['emergency_contact'],
                $member['emergency_phone']
            );
            
            if ($mStmt->execute()) {
                $added++;
            } else {
                $errors[] = "Error adding member details for {$member['name']}: " . $mStmt->error;
                // Delete the user to maintain consistency
                $conn->query("DELETE FROM users WHERE id = $user_id");
            }
            $mStmt->close();
        } else {
            $errors[] = "Error creating user account for {$member['name']}: " . $stmt->error;
        }
        $stmt->close();
    } catch (Exception $e) {
        $errors[] = "Error processing {$member['name']}: " . $e->getMessage();
    }
}

// Output results
echo "<h2>Sample Members Generation Complete</h2>";
echo "<p>Successfully added $added new members.</p>";

if (!empty($errors)) {
    echo "<h3>Errors:</h3>";
    echo "<ul>";
    foreach ($errors as $error) {
        echo "<li>$error</li>";
    }
    echo "</ul>";
}

echo "<p><a href='../members/register.php'>Back to Member Registration</a> | <a href='../dashboard/admin.php'>Go to Dashboard</a></p>";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Sample Members</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4"><i class="fas fa-users me-2"></i>Generate Sample Members</h1>
        <div class="card">
            <div class="card-body">
                <p>Click the button below to generate 50 sample members.</p>
                <form method="post">
                    <input type="hidden" name="generate" value="1">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-user-plus me-2"></i>Generate 50 Sample Members
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
