<?php
require_once __DIR__ . '/../includes/db.php';

// Sample sermons data
$sample_sermons = [
    [
        'title' => 'The Power of Prayer',
        'content' => 'Exploring the depths of prayer and how it transforms our spiritual lives.',
        'scripture' => 'James 5:13-16',
        'date' => '2024-10-01',
        'category' => 'Bible Study'
    ],
    [
        'title' => 'Walking in Faith',
        'content' => 'Understanding what it means to live a life of faith in everyday circumstances.',
        'scripture' => '2 Corinthians 5:7',
        'date' => '2024-09-28',
        'category' => 'Sunday Service'
    ],
    [
        'title' => 'The Love of God',
        'content' => 'Discovering the depth and breadth of God\'s unconditional love for us.',
        'scripture' => 'Romans 8:38-39',
        'date' => '2024-09-21',
        'category' => 'Sunday Service'
    ],
    [
        'title' => 'Spiritual Growth',
        'content' => 'Keys to growing in your relationship with God and maturing in faith.',
        'scripture' => '2 Peter 3:18',
        'date' => '2024-09-14',
        'category' => 'Bible Study'
    ],
    [
        'title' => 'Overcoming Temptation',
        'content' => 'Biblical strategies for resisting temptation and living victoriously.',
        'scripture' => '1 Corinthians 10:13',
        'date' => '2024-09-07',
        'category' => 'Sunday Service'
    ],
    [
        'title' => 'The Holy Spirit\'s Guidance',
        'content' => 'Learning to recognize and follow the Holy Spirit\'s leading in your life.',
        'scripture' => 'John 16:13',
        'date' => '2024-08-31',
        'category' => 'Prayer Meeting'
    ]
];

// Add each sermon to the database
$added = 0;
$stmt = $conn->prepare("INSERT INTO sermons (title, content, scripture, date, category, uploaded_by) VALUES (?, ?, ?, ?, ?, 1)");

foreach ($sample_sermons as $sermon) {
    $stmt->bind_param("sssss", 
        $sermon['title'],
        $sermon['content'],
        $sermon['scripture'],
        $sermon['date'],
        $sermon['category']
    );
    
    if ($stmt->execute()) {
        $added++;
    }
}

echo "Successfully added $added sermons to the database.\n";

// Close the database connection
$stmt->close();
$conn->close();
?>
