<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role(['admin', 'accountant']);
$user = get_user();

// Load budgets data
$budgets_file = __DIR__ . '/../data/budgets.json';
$budgets = [];

if (file_exists($budgets_file)) {
    $budgets = json_decode(file_get_contents($budgets_file), true) ?: [];
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_budget':
                $new_budget = [
                    'id' => uniqid(),
                    'name' => trim($_POST['name']),
                    'description' => trim($_POST['description']),
                    'amount' => floatval($_POST['amount']),
                    'start_date' => $_POST['start_date'],
                    'end_date' => $_POST['end_date'],
                    'categories' => [],
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => $user['id']
                ];
                $budgets[] = $new_budget;
                file_put_contents($budgets_file, json_encode($budgets, JSON_PRETTY_PRINT));
                $_SESSION['success'] = 'Budget created successfully';
                break;
                
            case 'add_category':
                $budget_id = $_POST['budget_id'];
                foreach ($budgets as &$budget) {
                    if ($budget['id'] === $budget_id) {
                        $budget['categories'][] = [
                            'id' => uniqid(),
                            'name' => trim($_POST['category_name']),
                            'allocated' => floatval($_POST['allocated']),
                            'spent' => 0,
                            'transactions' => []
                        ];
                        file_put_contents($budgets_file, json_encode($budgets, JSON_PRETTY_PRINT));
                        $_SESSION['success'] = 'Category added successfully';
                        break;
                    }
                }
                break;
                
            case 'add_transaction':
                $budget_id = $_POST['budget_id'];
                $category_id = $_POST['category_id'];
                foreach ($budgets as &$budget) {
                    if ($budget['id'] === $budget_id) {
                        foreach ($budget['categories'] as &$category) {
                            if ($category['id'] === $category_id) {
                                $transaction = [
                                    'id' => uniqid(),
                                    'date' => $_POST['date'],
                                    'amount' => floatval($_POST['amount']),
                                    'description' => trim($_POST['description']),
                                    'type' => $_POST['type'],
                                    'created_at' => date('Y-m-d H:i:s'),
                                    'created_by' => $user['id']
                                ];
                                $category['transactions'][] = $transaction;
                                // Update spent amount
                                if ($_POST['type'] === 'expense') {
                                    $category['spent'] += $transaction['amount'];
                                } else {
                                    $category['spent'] -= $transaction['amount'];
                                }
                                file_put_contents($budgets_file, json_encode($budgets, JSON_PRETTY_PRINT));
                                $_SESSION['success'] = 'Transaction added successfully';
                                break 2;
                            }
                        }
                    }
                }
                break;
        }
    }
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Get active budgets (end date in future or not set)
$active_budgets = array_filter($budgets, function($budget) {
    return empty($budget['end_date']) || strtotime($budget['end_date']) >= time();
});
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Management - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333;
            --text-light: #7f8c8d;
            --success: #28a745;
            --danger: #dc3545;
        }
        
        body {
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text);
            background-color: #f5f5f5;
        }
        
        .navbar {
            background-color: var(--secondary) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            font-weight: 600;
            padding: 1.25rem 1.5rem;
        }
        
        .stat-card {
            text-align: center;
            padding: 1.5rem;
        }
        
        .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0.5rem 0;
        }
        
        .stat-label {
            color: var(--text-light);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-2px);
        }
        
        .progress {
            height: 10px;
            border-radius: 5px;
            background-color: #e9ecef;
            margin: 0.5rem 0;
        }
        
        .progress-bar {
            background-color: var(--primary);
        }
        
        .budget-category {
            border-left: 4px solid var(--primary);
            padding-left: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .transaction-income {
            border-left: 4px solid var(--success);
        }
        
        .transaction-expense {
            border-left: 4px solid var(--danger);
        }
        
        .amount-income {
            color: var(--success);
            font-weight: 600;
        }
        
        .amount-expense {
            color: var(--danger);
            font-weight: 600;
        }
        
        .nav-tabs .nav-link {
            border: none;
            color: var(--text-light);
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            border-radius: 0;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--primary);
            border-bottom: 3px solid var(--primary);
            background: none;
        }
        
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
            border-radius: 50px;
        }
        
        .badge-primary {
            background-color: var(--primary);
        }
        
        .badge-success {
            background-color: var(--success);
        }
        
        .badge-danger {
            background-color: var(--danger);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="../index.php">
                <i class="fas fa-church me-2"></i>
                <span>Apostolic Church</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="donations.php">Donations</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Reports</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="budgets.php">Budgets</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="text-white me-3 d-none d-md-block">
                        <div class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></div>
                        <div class="small"><?php echo ucfirst($user['role']); ?></div>
                    </div>
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle fa-lg me-1"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Budget Management</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active">Budgets</li>
                    </ol>
                </nav>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBudgetModal">
                <i class="fas fa-plus me-1"></i> Create Budget
            </button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <!-- Budgets Tabs -->
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" id="budgetTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="active-tab" data-bs-toggle="tab" data-bs-target="#active" type="button" role="tab">
                            Active Budgets
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab">
                            All Budgets
                        </button>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="budgetTabsContent">
                    <!-- Active Budgets Tab -->
                    <div class="tab-pane fade show active" id="active" role="tabpanel" aria-labelledby="active-tab">
                        <?php if (!empty($active_budgets)): ?>
                            <div class="row">
                                <?php foreach ($active_budgets as $budget): 
                                    $total_allocated = array_sum(array_column($budget['categories'], 'allocated'));
                                    $total_spent = array_sum(array_column($budget['categories'], 'spent'));
                                    $remaining = $total_allocated - $total_spent;
                                    $percentage_used = $total_allocated > 0 ? ($total_spent / $total_allocated) * 100 : 0;
                                ?>
                                    <div class="col-md-6 mb-4">
                                        <div class="card h-100">
                                            <div class="card-header d-flex justify-content-between align-items-center">
                                                <h5 class="mb-0"><?php echo htmlspecialchars($budget['name']); ?></h5>
                                                <div>
                                                    <span class="badge bg-primary">
                                                        <?php echo date('M d, Y', strtotime($budget['start_date'])); ?> - 
                                                        <?php echo !empty($budget['end_date']) ? date('M d, Y', strtotime($budget['end_date'])) : 'No End Date'; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <?php if (!empty($budget['description'])): ?>
                                                    <p class="text-muted"><?php echo htmlspecialchars($budget['description']); ?></p>
                                                <?php endif; ?>
                                                
                                                <div class="mb-3">
                                                    <div class="d-flex justify-content-between mb-1">
                                                        <span>Budget Utilization</span>
                                                        <span><?php echo number_format($percentage_used, 1); ?>%</span>
                                                    </div>
                                                    <div class="progress">
                                                        <div class="progress-bar" role="progressbar" style="width: <?php echo $percentage_used; ?>%" 
                                                             aria-valuenow="<?php echo $percentage_used; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                                
                                                <div class="row text-center mb-3">
                                                    <div class="col-4">
                                                        <div class="stat-label">Allocated</div>
                                                        <div class="stat-value">₵<?php echo number_format($total_allocated, 2); ?></div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="stat-label">Spent</div>
                                                        <div class="stat-value">₵<?php echo number_format($total_spent, 2); ?></div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="stat-label">Remaining</div>
                                                        <div class="stat-value">₵<?php echo number_format($remaining, 2); ?></div>
                                                    </div>
                                                </div>
                                                
                                                <h6 class="mt-4 mb-3">Categories</h6>
                                                <?php foreach ($budget['categories'] as $category): 
                                                    $category_percentage = $category['allocated'] > 0 ? ($category['spent'] / $category['allocated']) * 100 : 0;
                                                    $is_over_budget = $category['spent'] > $category['allocated'];
                                                ?>
                                                    <div class="budget-category mb-3">
                                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                                            <h6 class="mb-0"><?php echo htmlspecialchars($category['name']); ?></h6>
                                                            <div>
                                                                <span class="badge <?php echo $is_over_budget ? 'bg-danger' : 'bg-primary'; ?>">
                                                                    ₵<?php echo number_format($category['spent'], 2); ?> / ₵<?php echo number_format($category['allocated'], 2); ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="progress" style="height: 5px;">
                                                            <div class="progress-bar <?php echo $is_over_budget ? 'bg-danger' : ''; ?>" 
                                                                 role="progressbar" style="width: <?php echo min($category_percentage, 100); ?>%" 
                                                                 aria-valuenow="<?php echo $category_percentage; ?>" 
                                                                 aria-valuemin="0" aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                        <div class="d-flex justify-content-between mt-2">
                                                            <small class="text-muted">
                                                                <?php echo number_format($category_percentage, 1); ?>% used
                                                                <?php if ($is_over_budget): ?>
                                                                    <span class="text-danger">(Over budget)</span>
                                                                <?php endif; ?>
                                                            </small>
                                                            <div>
                                                                <button class="btn btn-sm btn-outline-primary" 
                                                                        data-bs-toggle="modal" 
                                                                        data-bs-target="#addTransactionModal"
                                                                        data-budget-id="<?php echo $budget['id']; ?>"
                                                                        data-category-id="<?php echo $category['id']; ?>"
                                                                        data-category-name="<?php echo htmlspecialchars($category['name']); ?>">
                                                                    <i class="fas fa-plus"></i> Transaction
                                                                </button>
                                                                <button class="btn btn-sm btn-outline-secondary" 
                                                                        data-bs-toggle="collapse" 
                                                                        data-bs-target="#transactions-<?php echo $category['id']; ?>">
                                                                    <i class="fas fa-list"></i> Details
                                                                </button>
                                                            </div>
                                                        </div>
                                                        
                                                        <!-- Transactions -->
                                                        <div class="collapse mt-2" id="transactions-<?php echo $category['id']; ?>">
                                                            <?php if (!empty($category['transactions'])): ?>
                                                                <div class="list-group list-group-flush">
                                                                    <?php foreach ($category['transactions'] as $transaction): ?>
                                                                        <div class="list-group-item px-0 <?php echo 'transaction-' . $transaction['type']; ?>">
                                                                            <div class="d-flex justify-content-between align-items-center">
                                                                                <div>
                                                                                    <div class="fw-bold"><?php echo htmlspecialchars($transaction['description']); ?></div>
                                                                                    <small class="text-muted">
                                                                                        <?php echo date('M d, Y', strtotime($transaction['date'])); ?>
                                                                                    </small>
                                                                                </div>
                                                                                <span class="amount-<?php echo $transaction['type']; ?>">
                                                                                    <?php echo $transaction['type'] === 'expense' ? '-' : '+'; ?>₵<?php echo number_format($transaction['amount'], 2); ?>
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    <?php endforeach; ?>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="alert alert-light mb-0 mt-2">
                                                                    No transactions recorded for this category.
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                                
                                                <button class="btn btn-sm btn-outline-primary w-100 mt-2" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#addCategoryModal"
                                                        data-budget-id="<?php echo $budget['id']; ?>">
                                                    <i class="fas fa-plus"></i> Add Category
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                                <h5>No active budgets found</h5>
                                <p class="text-muted">Create a new budget to get started with your financial planning.</p>
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBudgetModal">
                                    <i class="fas fa-plus me-1"></i> Create Budget
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- All Budgets Tab -->
                    <div class="tab-pane fade" id="all" role="tabpanel" aria-labelledby="all-tab">
                        <?php if (!empty($budgets)): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Budget Name</th>
                                            <th>Period</th>
                                            <th class="text-end">Allocated</th>
                                            <th class="text-end">Spent</th>
                                            <th class="text-end">Remaining</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($budgets as $budget): 
                                            $total_allocated = array_sum(array_column($budget['categories'], 'allocated'));
                                            $total_spent = array_sum(array_column($budget['categories'], 'spent'));
                                            $remaining = $total_allocated - $total_spent;
                                            $percentage_used = $total_allocated > 0 ? ($total_spent / $total_allocated) * 100 : 0;
                                            $is_active = empty($budget['end_date']) || strtotime($budget['end_date']) >= time();
                                        ?>
                                            <tr style="cursor: pointer;" onclick="window.location='budget_details.php?id=<?php echo $budget['id']; ?>';">
                                                <td>
                                                    <div class="fw-bold"><?php echo htmlspecialchars($budget['name']); ?></div>
                                                    <?php if (!empty($budget['description'])): ?>
                                                        <small class="text-muted"><?php echo htmlspecialchars($budget['description']); ?></small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php echo date('M d, Y', strtotime($budget['start_date'])); ?>
                                                    <?php if (!empty($budget['end_date'])): ?>
                                                        <br><small>to <?php echo date('M d, Y', strtotime($budget['end_date'])); ?></small>
                                                    <?php else: ?>
                                                        <br><small>Ongoing</small>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-end">₵<?php echo number_format($total_allocated, 2); ?></td>
                                                <td class="text-end">₵<?php echo number_format($total_spent, 2); ?></td>
                                                <td class="text-end fw-bold">₵<?php echo number_format($remaining, 2); ?></td>
                                                <td class="text-center">
                                                    <?php if ($is_active): ?>
                                                        <span class="badge bg-success">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary">Completed</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                                <h5>No budgets found</h5>
                                <p class="text-muted">Create your first budget to start managing your church's finances.</p>
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBudgetModal">
                                    <i class="fas fa-plus me-1"></i> Create Budget
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Budget Modal -->
    <div class="modal fade" id="addBudgetModal" tabindex="-1" aria-labelledby="addBudgetModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="action" value="add_budget">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addBudgetModalLabel">Create New Budget</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="name" class="form-label">Budget Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="start_date" class="form-label">Start Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="start_date" name="start_date" required 
                                       value="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="end_date" class="form-label">End Date (Optional)</label>
                                <input type="date" class="form-control" id="end_date" name="end_date">
                                <div class="form-text">Leave blank for ongoing budgets</div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="amount" class="form-label">Initial Budget Amount <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">₵</span>
                                <input type="number" step="0.01" min="0" class="form-control" id="amount" name="amount" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create Budget</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="action" value="add_category">
                    <input type="hidden" name="budget_id" id="category_budget_id">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addCategoryModalLabel">Add Budget Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="category_name" class="form-label">Category Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="category_name" name="category_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="allocated" class="form-label">Allocated Amount <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">₵</span>
                                <input type="number" step="0.01" min="0" class="form-control" id="allocated" name="allocated" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Transaction Modal -->
    <div class="modal fade" id="addTransactionModal" tabindex="-1" aria-labelledby="addTransactionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="action" value="add_transaction">
                    <input type="hidden" name="budget_id" id="transaction_budget_id">
                    <input type="hidden" name="category_id" id="transaction_category_id">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addTransactionModalLabel">Add Transaction</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div id="transactionCategoryInfo" class="alert alert-info mb-3"></div>
                        <div class="mb-3">
                            <label for="transaction_type" class="form-label">Transaction Type <span class="text-danger">*</span></label>
                            <select class="form-select" id="transaction_type" name="type" required>
                                <option value="expense">Expense</option>
                                <option value="income">Income (Refund/Adjustment)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="transaction_date" class="form-label">Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="transaction_date" name="date" required 
                                   value="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="transaction_amount" class="form-label">Amount <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">₵</span>
                                <input type="number" step="0.01" min="0.01" class="form-control" id="transaction_amount" name="amount" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="transaction_description" class="form-label">Description <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="transaction_description" name="description" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Transaction</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle Add Category Modal
        document.getElementById('addCategoryModal').addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const budgetId = button.getAttribute('data-budget-id');
            document.getElementById('category_budget_id').value = budgetId;
        });
        
        // Handle Add Transaction Modal
        document.getElementById('addTransactionModal').addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const budgetId = button.getAttribute('data-budget-id');
            const categoryId = button.getAttribute('data-category-id');
            const categoryName = button.getAttribute('data-category-name');
            
            document.getElementById('transaction_budget_id').value = budgetId;
            document.getElementById('transaction_category_id').value = categoryId;
            document.getElementById('transactionCategoryInfo').textContent = 'Category: ' + categoryName;
        });
        
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>
