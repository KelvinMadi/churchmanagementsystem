<?php
// Set headers first to ensure proper content type
header('Content-Type: application/json');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to users

// Function to send JSON response
function sendJsonResponse($success, $message = '', $data = []) {
    http_response_code($success ? 200 : 400);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

try {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    require_once __DIR__ . '/../includes/auth.php';
    require_once __DIR__ . '/../includes/db.php';
    
    // Check if user is logged in and has required role
    if (!isset($_SESSION['user_id'])) {
        sendJsonResponse(false, 'Authentication required');
    }
    
    // Get user data including role
    $user = get_user();
    if (!$user) {
        sendJsonResponse(false, 'User not found. Please log in again.');
    }
    
    // Check if user has required role
    $allowed_roles = ['admin', 'accountant'];
    if (!in_array($user['role'], $allowed_roles)) {
        error_log('Access denied for user ' . ($user['email'] ?? 'unknown') . ' with role ' . ($user['role'] ?? 'none'));
        sendJsonResponse(false, 'Insufficient permissions. Please contact an administrator.');
    }
    
    // Check if request is POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendJsonResponse(false, 'Invalid request method');
    }

    // Log the incoming POST data for debugging
    error_log('Incoming POST data: ' . print_r($_POST, true));

    // Get and validate form data
    $donorName = isset($_POST['donor_name']) ? trim($_POST['donor_name']) : '';
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
    $donationType = isset($_POST['donation_type']) ? trim($_POST['donation_type']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $date = isset($_POST['date']) ? trim($_POST['date']) : '';

    // Validate required fields with specific error messages
    $errors = [];
    if (empty($donorName)) {
        $errors[] = 'Donor name is required';
    }
    if ($email === false || empty($email)) {
        $errors[] = 'A valid email address is required';
    }
    if ($amount === false || $amount <= 0) {
        $errors[] = 'A valid amount greater than zero is required';
    }
    if (empty($donationType)) {
        $errors[] = 'Donation type is required';
    }
    if (empty($date)) {
        $errors[] = 'Date is required';
    }

    if (!empty($errors)) {
        sendJsonResponse(false, 'Validation failed: ' . implode(', ', $errors));
    }
    
    // Ensure amount is positive
    if ($amount <= 0) {
        sendJsonResponse(false, 'Amount must be greater than zero');
    }

    // Generate a unique reference
    $reference = 'DON_' . uniqid();

    // Initialize Paystack transaction
    $paystackPublicKey = 'pk_test_aa065488fa44094a421ea163f52e06c1b33aa7be';
    $paystackSecretKey = 'sk_test_2c6272e2885761d185ea3b6c3d2b2b54b3e9fde9';
    
    // Ensure we have the required keys
    if (empty($paystackPublicKey) || empty($paystackSecretKey)) {
        error_log('Paystack API keys are not configured');
        sendJsonResponse(false, 'Payment processing is not available at the moment');
    }

    $url = 'https://api.paystack.co/transaction/initialize';
    $fields = [
        'email' => $email,
        'amount' => $amount * 100, // Convert to kobo
        'reference' => $reference,
        'callback_url' => 'http://' . $_SERVER['HTTP_HOST'] . '/financial/donations.php?verify_payment=1',
        'metadata' => [
            'donor_name' => $donorName,
            'type' => $donationType,
            'description' => $description,
            'date' => $date
        ]
    ];

    $headers = [
        'Authorization: Bearer ' . $paystackSecretKey,
        'Content-Type: application/json',
        'Cache-Control: no-cache'
    ];

    // Check if we can make HTTP requests
    $canUseCurl = function_exists('curl_version');
    $canUseFileGetContents = function_exists('file_get_contents') && 
                           (bool)ini_get('allow_url_fopen');
    
    $response = false;
    $httpCode = 0;
    
    // Try cURL first if available
    if ($canUseCurl) {
        $ch = curl_init();
        if ($ch !== false) {
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($fields),
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_SSL_VERIFYPEER => false, // Only for testing
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HEADER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($response === false) {
                error_log('cURL Error: ' . $error);
                $response = false;
            } else {
                // Extract the body from the response
                $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $response = substr($response, $headerSize);
            }
        }
    }
    
    // If cURL failed or not available, try file_get_contents
    if ($response === false && $canUseFileGetContents) {
        $options = [
            'http' => [
                'header'  => $headers,
                'method'  => 'POST',
                'content' => json_encode($fields),
                'ignore_errors' => true,
                'timeout' => 30,
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                ]
            ]
        ];
        
        $context = stream_context_create($options);
        $response = @file_get_contents($url, false, $context);
        
        if (isset($http_response_header[0])) {
            preg_match('{HTTP\/\S*\s(\d{3})}', $http_response_header[0], $match);
            $httpCode = isset($match[1]) ? (int)$match[1] : 0;
        }
        
        if ($response === false) {
            $error = error_get_last();
            error_log('file_get_contents Error: ' . ($error['message'] ?? 'Unknown error'));
        }
    }
    
    // If both methods failed
    if ($response === false) {
        $errorMsg = 'Unable to process payment. ';
        if (!$canUseCurl && !$canUseFileGetContents) {
            $errorMsg .= 'Server configuration error: cURL is not available and allow_url_fopen is disabled. Please contact your system administrator to enable either cURL or allow_url_fopen in PHP configuration.';
        } else {
            $errorMsg .= 'Please try again later or contact support if the problem persists.';
        }
        error_log('Payment processing failed: ' . $errorMsg);
        sendJsonResponse(false, $errorMsg);
    }
    
    // Log the full request and response for debugging
    error_log('Paystack API Request: ' . json_encode([
        'url' => $url,
        'headers' => $headers,
        'fields' => $fields
    ]));

    error_log('Paystack API Response (HTTP ' . $httpCode . '): ' . $response);

    if ($httpCode < 200 || $httpCode >= 300) {
        $errorMessage = 'Payment processor returned an error (HTTP ' . $httpCode . ')';
        
        // Try to get more specific error from Paystack response
        if (!empty($response)) {
            $responseData = json_decode($response, true);
            if (json_last_error() === JSON_ERROR_NONE && isset($responseData['message'])) {
                $errorMessage = $responseData['message'];
            }
        }
        
        error_log('HTTP Error: ' . $httpCode . ' - ' . $errorMessage . ' - Response: ' . $response);
        sendJsonResponse(false, $errorMessage);
    }

    $responseData = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('Invalid JSON response from Paystack: ' . $response);
        sendJsonResponse(false, 'Invalid response format from payment processor');
    }

    if (!$responseData || !isset($responseData['status'])) {
        error_log('Invalid Paystack response: ' . print_r($responseData, true));
        sendJsonResponse(false, 'Invalid response from payment processor');
    }

    if (!$responseData['status']) {
        error_log('Paystack API error: ' . ($responseData['message'] ?? 'Unknown error'));
        sendJsonResponse(false, $responseData['message'] ?? 'Payment initialization failed');
    }

    // Return the authorization URL
    if (isset($responseData['data']['authorization_url'])) {
        sendJsonResponse(true, 'Payment initialized', [
            'authorization_url' => $responseData['data']['authorization_url']
        ]);
    } else {
        error_log('Paystack response missing authorization_url: ' . print_r($responseData, true));
        sendJsonResponse(false, 'Failed to initialize payment. Please try again.');
    }

} catch (Exception $e) {
    // Log the error
    error_log('Payment processing error: ' . $e->getMessage() . ' in ' . $e->getFile() . ' on line ' . $e->getLine());
    
    // Send a generic error message to the client
    sendJsonResponse(false, 'An error occurred while processing your payment. Please try again.');
}
