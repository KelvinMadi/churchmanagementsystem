<?php
// Test script to check cURL and SSL configuration

echo "<h1>PHP cURL Test</h1>";

// Check if cURL is enabled
if (!function_exists('curl_version')) {
    die("<p style='color: red;'>cURL is not enabled in your PHP installation.</p>");
}

// Get cURL version info
$curl_info = curl_version();
echo "<h2>cURL Information</h2>";
echo "<pre>" . print_r($curl_info, true) . "</pre>";

// Test SSL certificate verification
$ch = curl_init('https://api.paystack.co/transaction/verify/1234');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer sk_test_2c6272e2885761d185ea3b6c3d2b2b54b3e9fde9'
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo "<h2 style='color: red;'>cURL Error</h2>";
    echo "<p>Error: " . curl_error($ch) . "</p>";
    
    // Try with SSL verification disabled (for testing only)
    echo "<h3>Trying with SSL verification disabled (for testing only)</h3>";
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "<p>Error with SSL verification disabled: " . curl_error($ch) . "</p>";
    } else {
        echo "<h3>Success with SSL verification disabled</h3>";
        echo "<pre>" . htmlspecialchars($response) . "</pre>";
    }
} else {
    echo "<h2 style='color: green;'>cURL Request Successful</h2>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
}

curl_close($ch);

// Check if allow_url_fopen is enabled
echo "<h2>PHP Configuration</h2>";
echo "<p>allow_url_fopen: " . (ini_get('allow_url_fopen') ? 'Enabled' : 'Disabled') . "</p>";

// Check if we can make HTTP requests
echo "<h2>HTTP Request Test</h2>";
$http_response = @file_get_contents('https://api.paystack.co/transaction/verify/1234', false, stream_context_create([
    'http' => [
        'method' => 'GET',
        'header' => 'Authorization: Bearer sk_test_2c6272e2885761d185ea3b6c3d2b2b54b3e9fde9'
    ]
]));

if ($http_response === false) {
    echo "<p style='color: red;'>HTTP request failed: " . print_r(error_get_last(), true) . "</p>";
} else {
    echo "<p style='color: green;'>HTTP request successful</p>";
    echo "<pre>" . htmlspecialchars($http_response) . "</pre>";
}

// Check if we can write to the log file
$log_file = __DIR__ . '/paystack_debug.log';
if (@file_put_contents($log_file, 'Test log entry\n', FILE_APPEND) === false) {
    echo "<p style='color: red;'>Cannot write to log file: $log_file</p>";
    echo "<p>Check directory permissions for: " . dirname($log_file) . "</p>";
} else {
    echo "<p style='color: green;'>Can write to log file: $log_file</p>";
}

// Show PHP info
if (isset($_GET['phpinfo'])) {
    phpinfo();
} else {
    echo "<p><a href='?phpinfo=1'>Show PHP Info</a></p>";
}
?>
