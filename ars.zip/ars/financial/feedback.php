<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$user = get_user();
$feedback_file = __DIR__ . '/../data/feedback.json';
$feedback = [];

if (file_exists($feedback_file)) {
    $feedback = json_decode(file_get_contents($feedback_file), true) ?: [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_feedback = [
        'id' => uniqid(),
        'user_id' => $user['id'],
        'user_name' => $user['name'],
        'type' => $_POST['type'],
        'subject' => trim($_POST['subject']),
        'message' => trim($_POST['message']),
        'status' => 'open',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $feedback[] = $new_feedback;
    file_put_contents($feedback_file, json_encode($feedback, JSON_PRETTY_PRINT));
    
    $_SESSION['success'] = 'Thank you for your feedback!';
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback - Financial System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
        }
        
        body { background-color: #f5f5f5; }
        .navbar { background-color: var(--secondary) !important; }
        .card { border: none; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .btn-primary { background-color: var(--primary); border-color: var(--primary); }
        .btn-primary:hover { background-color: var(--primary-hover); border-color: var(--primary-hover); }
        .feedback-item { border-left: 4px solid #17a2b8; padding: 1rem; margin-bottom: 1rem; background: white; }
        .feedback-type { font-weight: 600; color: var(--primary); }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>
                Apostolic Church
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Submit Feedback</h4>
                        <a href="/dashboard/accountant.php" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_SESSION['success'])): ?>
                            <div class="alert alert-success">
                                <?php 
                                echo $_SESSION['success'];
                                unset($_SESSION['success']);
                                ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="submit_feedback">
                            <div class="mb-3">
                                <label class="form-label">Feedback Type <span class="text-danger">*</span></label>
                                <select name="type" class="form-select" required>
                                    <option value="suggestion">Suggestion</option>
                                    <option value="bug">Bug Report</option>
                                    <option value="question">Question</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Subject <span class="text-danger">*</span></label>
                                <input type="text" name="subject" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Message <span class="text-danger">*</span></label>
                                <textarea name="message" rows="4" class="form-control" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-1"></i> Submit Feedback
                            </button>
                        </form>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">My Feedback</h4>
                        <a href="/dashboard/accountant.php" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                        </a>
                    </div>
                    <div class="card-body">
                        <?php 
                        $user_feedback = array_filter($feedback, function($item) use ($user) {
                            return isset($item['user_id']) && isset($user['id']) && $item['user_id'] === $user['id'];
                        });
                        
                        if (empty($user_feedback)): 
                        ?>
                            <div class="text-center py-4">
                                <i class="fas fa-comment-alt fa-3x text-muted mb-3"></i>
                                <p class="text-muted">You haven't submitted any feedback yet.</p>
                            </div>
                        <?php else: ?>
<?php foreach (array_reverse($user_feedback) as $item): ?>
                                <?php if (!isset($item['type'])) continue; ?>
                                <div class="feedback-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <span class="badge bg-primary">
                                                <?php echo isset($item['type']) ? ucfirst($item['type']) : 'General'; ?>
                                            </span>
                                            <span class="ms-2 text-muted">
                                                <?php echo isset($item['created_at']) ? date('M d, Y', strtotime($item['created_at'])) : 'N/A'; ?>
                                            </span>
                                        </div>
                                        <span class="badge bg-<?php 
                                            echo $item['status'] === 'open' ? 'info' : 
                                                 ($item['status'] === 'in_progress' ? 'warning' : 'success'); 
                                        ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $item['status'])); ?>
                                        </span>
                                    </div>
                                    <h5 class="mt-2"><?php echo isset($item['subject']) ? htmlspecialchars($item['subject']) : 'No Subject'; ?></h5>
                                    <p class="mb-0"><?php echo isset($item['message']) ? nl2br(htmlspecialchars($item['message'])) : 'No message provided.'; ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
