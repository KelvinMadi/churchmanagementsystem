<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role(['admin', 'accountant']);
$user = get_user();

// Load donations data
$donations_file = __DIR__ . '/../data/donations.json';
$donations = [];

if (file_exists($donations_file)) {
    $donations = json_decode(file_get_contents($donations_file), true) ?: [];
}

// Date range for reports (default: current month)
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$report_type = $_GET['type'] ?? 'summary';

// Filter donations by date range
$filtered_donations = array_filter($donations, function($donation) use ($start_date, $end_date) {
    $donation_date = $donation['date'];
    return ($donation_date >= $start_date) && ($donation_date <= $end_date);
});

// Calculate report data
$report_data = [
    'total_amount' => 0,
    'by_type' => [
        'tithe' => 0,
        'offering' => 0,
        'donation' => 0,
        'other' => 0
    ],
    'by_month' => [],
    'by_donor' => []
];

// Process donations data
foreach ($filtered_donations as $donation) {
    $amount = floatval($donation['amount'] ?? 0);
    $type = $donation['type'] ?? 'other';
    $month = date('Y-m', strtotime($donation['date']));
    $donor = $donation['donor_name'] ?? 'Anonymous';
    
    // Update totals
    $report_data['total_amount'] += $amount;
    
    // Update by type
    if (isset($report_data['by_type'][$type])) {
        $report_data['by_type'][$type] += $amount;
    } else {
        $report_data['by_type']['other'] += $amount;
    }
    
    // Update by month
    if (!isset($report_data['by_month'][$month])) {
        $report_data['by_month'][$month] = 0;
    }
    $report_data['by_month'][$month] += $amount;
    
    // Update by donor
    if (!isset($report_data['by_donor'][$donor])) {
        $report_data['by_donor'][$donor] = 0;
    }
    $report_data['by_donor'][$donor] += $amount;
}

// Sort data
arsort($report_data['by_donor']);
ksort($report_data['by_month']);
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Reports - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333;
            --text-light: #7f8c8d;
        }
        
        body {
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text);
            background-color: #f5f5f5;
        }
        
        .navbar {
            background-color: var(--secondary) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            font-weight: 600;
            padding: 1.25rem 1.5rem;
        }
        
        .stat-card {
            text-align: center;
            padding: 1.5rem;
        }
        
        .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0.5rem 0;
        }
        
        .stat-label {
            color: var(--text-light);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
        }
        
        .nav-pills .nav-link.active {
            background-color: var(--primary);
        }
        
        .table th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
            color: var(--text-light);
            border-top: none;
        }
        
        .badge-tithe {
            background-color: #28a745;
            color: white;
        }
        
        .badge-offering {
            background-color: #17a2b8;
            color: white;
        }
        
        .badge-donation {
            background-color: #6f42c1;
            color: white;
        }
        
        .badge-other {
            background-color: #6c757d;
            color: white;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            margin: 1.5rem 0;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="../index.php">
                <i class="fas fa-church me-2"></i>
                <span>Apostolic Church</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="donations.php">Donations</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reports.php">Reports</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="text-white me-3 d-none d-md-block">
                        <div class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></div>
                        <div class="small"><?php echo ucfirst($user['role']); ?></div>
                    </div>
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle fa-lg me-1"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Financial Reports</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active">Financial Reports</li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex">
                <button class="btn btn-primary" id="printReport">
                    <i class="fas fa-print me-1"></i> Print Report
                </button>
            </div>
        </div>
        
        <!-- Report Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label for="start_date" class="form-label">From Date</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="end_date" class="form-label">To Date</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="type" class="form-label">Report Type</label>
                        <select class="form-select" id="type" name="type">
                            <option value="summary" <?php echo $report_type === 'summary' ? 'selected' : ''; ?>>Summary Report</option>
                            <option value="detailed" <?php echo $report_type === 'detailed' ? 'selected' : ''; ?>>Detailed Report</option>
                            <option value="donor" <?php echo $report_type === 'donor' ? 'selected' : ''; ?>>Donor Report</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-1"></i> Apply Filters
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3 mb-md-0">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Total Donations</h6>
                        <h3 class="stat-value">₵<?php echo number_format($report_data['total_amount'], 2); ?></h3>
                        <div class="text-muted"><?php echo count($filtered_donations); ?> records</div>
                        <i class="fas fa-money-bill-wave stat-icon"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3 mb-md-0">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Tithes</h6>
                        <h3 class="stat-value">₵<?php echo number_format($report_data['by_type']['tithe'], 2); ?></h3>
                        <div class="text-muted">
                            <?php 
                            $percentage = $report_data['total_amount'] > 0 ? ($report_data['by_type']['tithe'] / $report_data['total_amount'] * 100) : 0;
                            echo number_format($percentage, 1); 
                            ?>% of total
                        </div>
                        <i class="fas fa-church stat-icon"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3 mb-md-0">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Offerings</h6>
                        <h3 class="stat-value">₵<?php echo number_format($report_data['by_type']['offering'], 2); ?></h3>
                        <div class="text-muted">
                            <?php 
                            $percentage = $report_data['total_amount'] > 0 ? ($report_data['by_type']['offering'] / $report_data['total_amount'] * 100) : 0;
                            echo number_format($percentage, 1); 
                            ?>% of total
                        </div>
                        <i class="fas fa-gift stat-icon"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Other Donations</h6>
                        <h3 class="stat-value">₵<?php echo number_format(($report_data['by_type']['donation'] + $report_data['by_type']['other']), 2); ?></h3>
                        <div class="text-muted">
                            <?php 
                            $other_total = $report_data['by_type']['donation'] + $report_data['by_type']['other'];
                            $percentage = $report_data['total_amount'] > 0 ? ($other_total / $report_data['total_amount'] * 100) : 0;
                            echo number_format($percentage, 1); 
                            ?>% of total
                        </div>
                        <i class="fas fa-donate stat-icon"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Charts Row -->
        <div class="row mb-4">
            <div class="col-md-6 mb-4 mb-md-0">
                <div class="card h-100">
                    <div class="card-header">
                        <h6 class="mb-0">Donations by Type</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="typeChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <h6 class="mb-0">Monthly Donations</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="monthlyChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Donations Table -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Donation Records</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Donor</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th class="text-end">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($filtered_donations)): ?>
                                <?php foreach($filtered_donations as $donation): ?>
                                    <tr>
                                        <td><?php echo date('M d, Y', strtotime($donation['date'])); ?></td>
                                        <td><?php echo htmlspecialchars($donation['donor_name']); ?></td>
                                        <td>
                                            <?php 
                                            $type = $donation['type'] ?? 'other';
                                            $type_class = 'badge-other';
                                            $type_label = ucfirst($type);
                                            
                                            switch ($type) {
                                                case 'tithe':
                                                    $type_class = 'badge-tithe';
                                                    break;
                                                case 'offering':
                                                    $type_class = 'badge-offering';
                                                    break;
                                                case 'donation':
                                                    $type_class = 'badge-donation';
                                                    break;
                                                default:
                                                    $type_class = 'badge-other';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $type_class; ?>"><?php echo htmlspecialchars($type_label); ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($donation['description'] ?? 'N/A'); ?></td>
                                        <td class="text-end fw-bold">₵<?php echo number_format($donation['amount'], 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                        <p class="mb-0">No donation records found for the selected period</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="bg-light">
                                <td colspan="4" class="text-end fw-bold">Total:</td>
                                <td class="text-end fw-bold">₵<?php echo number_format($report_data['total_amount'], 2); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Print Report
        document.getElementById('printReport').addEventListener('click', function() {
            window.print();
        });
        
        // Donations by Type Chart
        const typeCtx = document.getElementById('typeChart').getContext('2d');
        const typeChart = new Chart(typeCtx, {
            type: 'doughnut',
            data: {
                labels: ['Tithes', 'Offerings', 'Donations', 'Other'],
                datasets: [{
                    data: [
                        <?php echo $report_data['by_type']['tithe']; ?>,
                        <?php echo $report_data['by_type']['offering']; ?>,
                        <?php echo $report_data['by_type']['donation']; ?>,
                        <?php echo $report_data['by_type']['other']; ?>
                    ],
                    backgroundColor: [
                        '#28a745',
                        '#17a2b8',
                        '#6f42c1',
                        '#6c757d'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ₵${value.toFixed(2)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Monthly Donations Chart
        const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
        const monthlyChart = new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($report_data['by_month'])); ?>,
                datasets: [{
                    label: 'Monthly Donations',
                    data: <?php echo json_encode(array_values($report_data['by_month'])); ?>,
                    backgroundColor: 'rgba(230, 126, 34, 0.7)',
                    borderColor: 'rgba(230, 126, 34, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₵' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₵' + context.raw.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
