<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role(['admin', 'accountant']);
$user = get_user();

// Initialize database connection
$db = $conn;

$paystackPublicKey = 'pk_test_aa065488fa44094a421ea163f52e06c1b33aa7be'; // Test public key - replace with your actual key
$paystackSecretKey = 'sk_test_2c6272e2885761d185ea3b6c3d2b2b54b3e9fde9'; // Test secret key - replace with your actual key

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1); // Show errors for debugging
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Set a custom error handler to log all errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $error = sprintf(
        '[%s] %s in %s on line %s',
        date('Y-m-d H:i:s'),
        $errstr,
        $errfile,
        $errline
    );
    error_log($error);
    return false; // Let the default error handler run as well
});

// Log function for debugging
function log_message($message, $data = null) {
    $log = '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n";
    if ($data !== null) {
        $log .= 'Data: ' . print_r($data, true) . "\n";
    }
    // Also log to PHP's error log
    error_log($message . (is_array($data) ? ': ' . json_encode($data) : ''));
    // And to our custom log file
    file_put_contents(__DIR__ . '/paystack_debug.log', $log, FILE_APPEND);
}

log_message('Script accessed', ['GET' => $_GET, 'POST' => $_POST]);
// Initialize Paystack service (cURL only)
function initializePaystackTransaction($data) {
    global $paystackSecretKey;

    $url = 'https://api.paystack.co/transaction/initialize';
    $payload = [
        'email' => $data['email'],
        'amount' => $data['amount'] * 100, // Convert to kobo
        'reference' => $data['reference'],
        'callback_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/financial/donations.php?verify_payment=1',
        'metadata' => [
            'donor_name' => $data['donor_name'],
            'type' => $data['donation_type'],
            'description' => $data['description'] ?? ''
        ]
    ];

    $headers = [
        'Authorization: Bearer ' . $paystackSecretKey,
        'Content-Type: application/json',
        'Cache-Control: no-cache'
    ];

    // Try cURL first if available
    if (function_exists('curl_version')) {
        $ch = curl_init($url);
        
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HEADER => true
        ]);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            log_message("cURL Error", [
                'error' => $error,
                'http_code' => $httpCode
            ]);
            // Fall through to file_get_contents
        } else {
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $headers = substr($response, 0, $headerSize);
            $body = substr($response, $headerSize);
            curl_close($ch);
            
            log_message("cURL Response", [
                'headers' => $headers,
                'body' => $body
            ]);
            
            $result = json_decode($body, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $result;
            }
        }
    }
    
    // Fallback to file_get_contents if cURL fails or not available
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headers),
            'content' => json_encode($payload),
            'ignore_errors' => true,
            'timeout' => 30
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    
    if ($response === false) {
        $error = error_get_last();
        log_message("file_get_contents Error", [
            'error' => $error['message'] ?? 'Unknown error',
            'http_response_header' => $http_response_header ?? []
        ]);
        return ['status' => false, 'message' => 'Failed to initialize payment. Please try again later.'];
    }
    
    log_message("file_get_contents Response", [
        'headers' => $http_response_header ?? [],
        'body' => $response
    ]);
    
    $result = json_decode($response, true);
    
    // If JSON decode failed, log the raw response for debugging
    if (json_last_error() !== JSON_ERROR_NONE) {
        log_message("JSON Decode Error: " . json_last_error_msg(), [
            'raw_response' => $response,
            'http_code' => curl_getinfo($ch, CURLINFO_HTTP_CODE),
            'content_type' => curl_getinfo($ch, CURLINFO_CONTENT_TYPE)
        ]);
        return ['status' => false, 'message' => 'Invalid JSON response from Paystack: ' . substr($response, 0, 100)];
    }
    
    return $result;
}

// Verify Paystack transaction (cURL only)
function verifyPaystackTransaction($reference) {
    global $paystackSecretKey;

    $url = 'https://api.paystack.co/transaction/verify/' . rawurlencode($reference);

    $headers = [
        'Authorization: Bearer ' . $paystackSecretKey,
        'Cache-Control: no-cache'
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return ['status' => false, 'message' => $error];
    }
    curl_close($ch);

    log_message("Verify response", $response);
    return json_decode($response, true);
}

// Load donations from file
$donations_file = __DIR__ . '/../data/donations.json';
$donations = [];

if (file_exists($donations_file)) {
    $donations = json_decode(file_get_contents($donations_file), true) ?: [];
}

// Helper function to save donations to file
function saveDonations($donations) {
    global $donations_file;
    $dir = dirname($donations_file);
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
    file_put_contents($donations_file, json_encode($donations, JSON_PRETTY_PRINT));
}

// Handle search and filters
$search = $_GET['search'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$type = $_GET['type'] ?? 'all';

// Handle form submission for new donation with Paystack
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type']) && $_POST['type'] === 'donation') {
    // Log the raw POST data
    log_message('Raw POST data', file_get_contents('php://input'));
    log_message('POST array', $_POST);
    log_message('Form submitted', $_POST);

    // Basic validation
    $required = ['donor_name', 'email', 'amount', 'donation_type'];
    $missing = array_filter($required, function($field) { return empty($_POST[$field]); });

    if (!empty($missing)) {
        $error = 'Missing required fields: ' . implode(', ', $missing);
        log_message('Validation error', $error);
        header('Location: donations.php?error=' . urlencode($error));
        exit;
    }

    // Validate email
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address';
        log_message('Validation error', $error);
        header('Location: donations.php?error=' . urlencode($error));
        exit;
    }

    // Validate amount
    if (!is_numeric($_POST['amount']) || $_POST['amount'] <= 0) {
        $error = 'Invalid amount';
        log_message('Validation error', $error);
        header('Location: donations.php?error=' . urlencode($error));
        exit;
    }

    // Generate a unique reference
    $reference = 'DON-' . time() . '-' . uniqid();

    // Prepare payment data
    $paymentData = [
        'email' => $_POST['email'] ?? '',
        'amount' => floatval($_POST['amount'] ?? 0),
        'reference' => $reference,
        'donor_name' => $_POST['donor_name'] ?? '',
        'donation_type' => $_POST['donation_type'] ?? 'donation',
        'description' => $_POST['description'] ?? ''
    ];

    // Initialize Paystack transaction
    $payment = initializePaystackTransaction($paymentData);

    if ($payment['status'] && isset($payment['data']['authorization_url'])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'authorization_url' => $payment['data']['authorization_url']
        ]);
        exit;
    } else {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $payment['message'] ?? 'Failed to initialize payment'
        ]);
        exit;
    }
    
}

// Verify payment callback from Paystack
if (isset($_GET['verify_payment']) && isset($_GET['trxref'])) {
    $reference = $_GET['trxref'];
    $verification = verifyPaystackTransaction($reference);

    if ($verification['status'] && $verification['data']['status'] === 'success') {
        $data = $verification['data'];
        $metadata = $data['metadata'];

        $new_donation = [
            'id' => uniqid(),
            'date' => date('Y-m-d'),
            'donor_name' => $metadata['donor_name'] ?? 'Anonymous',
            'email' => $data['customer']['email'] ?? '',
            'type' => $metadata['type'] ?? 'donation',
            'amount' => $data['amount'] / 100, // Convert back from kobo/pesewas
            'description' => $metadata['description'] ?? '',
            'payment_reference' => $reference,
            'payment_status' => 'completed',
            'created_at' => date('Y-m-d H:i:s'),
            'recorded_by' => $user['name']
        ];

        // Add to donations array
        $donations[] = $new_donation;

        // Save to file
        saveDonations($donations);

        // Redirect to success page
        header('Location: donations.php?success=1&ref=' . $reference);
        exit;
    } else {
        $error = $verification['message'] ?? 'Payment verification failed';
        header('Location: donations.php?error=' . urlencode($error));
        exit;
    }

// Filtering, pagination, stats (unchanged from your version)
// ...

}
$where = [];
$params = [];
$types = [];

if ($search) {
    $where[] = "(donor_name LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types[] = 'ss';
}

if ($start_date) {
    $where[] = "date >= ?";
    $params[] = $start_date;
    $types[] = 's';
}

if ($end_date) {
    $where[] = "date <= ?";
    $params[] = $end_date;
    $types[] = 's';
}

if ($type !== 'all') {
    $where[] = "type = ?";
    $params[] = $type;
    $types[] = 's';
}

$where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Apply filters
$filtered_donations = $donations;

if ($search) {
    $search = strtolower($search);
    $filtered_donations = array_filter($filtered_donations, function($donation) use ($search) {
        return (stripos($donation['donor_name'], $search) !== false) || 
               (stripos($donation['description'], $search) !== false);
    });
}

if ($type !== 'all') {
    $filtered_donations = array_filter($filtered_donations, function($donation) use ($type) {
        return $donation['type'] === $type;
    });
}

if ($start_date) {
    $filtered_donations = array_filter($filtered_donations, function($donation) use ($start_date) {
        return strtotime($donation['date']) >= strtotime($start_date);
    });
}

if ($end_date) {
    $filtered_donations = array_filter($filtered_donations, function($donation) use ($end_date) {
        return strtotime($donation['date']) <= strtotime($end_date . ' 23:59:59');
    });
}

// Reset array keys after filtering
$filtered_donations = array_values($filtered_donations);

// Get total count for pagination
$total_records = count($filtered_donations);

// Pagination
$per_page = 10;
$total_pages = ceil($total_records / $per_page);
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $per_page;

// Sort donations by date (newest first)
usort($filtered_donations, function($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

// Apply pagination
$paginated_donations = array_slice($filtered_donations, $offset, $per_page);

// Get donation types for filter
$donation_types = [
    'all' => 'All Types',
    'tithe' => 'Tithes',
    'offering' => 'Offerings',
    'donation' => 'Donations',
    'other' => 'Other'
];

// Calculate summary statistics
$stats = [
    'total_count' => 0,
    'total_amount' => 0.00,
    'tithes' => 0.00,
    'offerings' => 0.00,
    'donations' => 0.00,
    'others' => 0.00
];

foreach ($donations as $donation) {
    if (empty($donation) || !is_array($donation)) {
        continue; // Skip invalid entries
    }
    
    // Ensure amount is a valid number
    $amount = isset($donation['amount']) ? floatval($donation['amount']) : 0.00;
    $donation_type = $donation['type'] ?? 'other';
    
    // Update statistics
    $stats['total_count']++;
    $stats['total_amount'] += $amount;
    
    // Update type-specific totals
    switch (strtolower($donation_type)) {
        case 'tithe':
            $stats['tithes'] += $amount;
            break;
        case 'offering':
            $stats['offerings'] += $amount;
            break;
        case 'donation':
            $stats['donations'] += $amount;
            break;
        default:
            $stats['others'] += $amount;
            $donation_type = 'other'; // Ensure type is set to a valid value
            break;
    }
}

// Ensure all values are properly formatted
$stats['total_amount'] = number_format($stats['total_amount'], 2, '.', '');
$stats['tithes'] = number_format($stats['tithes'], 2, '.', '');
$stats['offerings'] = number_format($stats['offerings'], 2, '.', '');
$stats['donations'] = number_format($stats['donations'], 2, '.', '');
$stats['others'] = number_format($stats['others'], 2, '.', '');
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donations - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Cross-browser user-select for Paystack button */
        .paystack-trigger-btn {
            -webkit-user-select: none; /* Safari 3+ */
            -moz-user-select: none;    /* Firefox */
            -ms-user-select: none;     /* IE 10+ */
            user-select: none;         /* Standard syntax */
        }

        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
        }
        
        body {
            background-color: #f8fafc;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            line-height: 1.6;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
        }
        
        .navbar {
            background-color: var(--secondary) !important;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 0.75rem 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 0.5px;
            color: white !important;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.5rem rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            transition: transform 0.2s, box-shadow 0.2s;
            border: 1px solid rgba(0,0,0,0.05);
        }
        
        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 0.5rem 1.5rem rgba(0, 0, 0, 0.08);
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            font-weight: 600;
            padding: 1.25rem 1.5rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .stat-card {
            position: relative;
            overflow: hidden;
            border-left: 4px solid var(--primary);
            background: white;
        }
        
        .stat-card .card-body {
            padding: 1.5rem;
        }
        
        .stat-card .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0.5rem 0;
            font-family: 'Montserrat', sans-serif;
        }
        
        .stat-card .stat-label {
            color: #6c757d;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 500;
        }
        
        .stat-card .stat-icon {
            font-size: 2rem;
            opacity: 0.1;
            position: absolute;
            right: 1.25rem;
            top: 1.25rem;
            color: var(--primary);
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table th {
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #6c757d;
            border-top: none;
            padding: 1rem 1.5rem;
            background-color: #f8f9fa;
        }
        
        .table td {
            padding: 1rem 1.5rem;
            vertical-align: middle;
            border-color: #f0f0f0;
        }
        
        .badge {
            padding: 0.35em 0.65em;
            font-weight: 500;
            border-radius: 0.25rem;
            font-size: 0.75rem;
        }
        
        .badge-tithe {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .badge-offering {
            background-color: rgba(23, 162, 184, 0.1);
            color: #17a2b8;
        }
        
        .badge-donation {
            background-color: rgba(13, 110, 253, 0.1);
            color: #0d6efd;
        }
        
        .badge-other {
            background-color: rgba(108, 117, 125, 0.1);
            color: #6c757d;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.5rem 1.25rem;
            border-radius: 20px;
            transition: all 0.2s;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-1px);
        }
        
        .btn-outline-primary {
            color: var(--primary);
            border-color: var(--primary);
            font-weight: 500;
        }
        
        .btn-outline-primary:hover {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .form-control, .form-select {
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            border: 1px solid #e1e5ee;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
        }
        
        .pagination .page-link {
            color: var(--primary);
            border: 1px solid #dee2e6;
            margin: 0 0.25rem;
            border-radius: 0.5rem !important;
            min-width: 2.5rem;
            text-align: center;
        }
        
        .pagination .page-item.active .page-link {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .pagination .page-item.disabled .page-link {
            color: #6c757d;
        }
        
        .export-buttons .btn {
            margin-left: 0.5rem;
        }
        
        @media (max-width: 768px) {
            .stat-card .stat-value {
                font-size: 1.25rem;
            }
            
            .btn {
                padding: 0.5rem 1rem;
                font-size: 0.9rem;
            }
            
            .table-responsive {
                border-radius: 0.5rem;
                border: 1px solid #e1e5ee;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: rgba(44, 62, 80, 0.95); backdrop-filter: blur(10px); box-shadow: 0 2px 15px rgba(0,0,0,0.1);">
        <div class="container">
            <!-- Logo and Church Name -->
            <a class="navbar-brand d-flex align-items-center fw-bold" href="../index.php" style="font-family: 'Montserrat', sans-serif; letter-spacing: 0.5px;">
                <i class="fas fa-church me-2" style="color: #e67e22;"></i>
                <span>Apostolic Church</span>
            </a>
            
            <!-- Mobile Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Navigation Links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="../index.php">
                            <i class="fas fa-home d-lg-none me-2"></i>Home
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="records.php">
                            <i class="fas fa-file-invoice-dollar d-lg-none me-2"></i>Financial Records
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3 active" href="donations.php">
                            <i class="fas fa-donate d-lg-none me-2"></i>Donations
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="expenses.php">
                            <i class="fas fa-receipt d-lg-none me-2"></i>Expenses
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="../contact/">
                            <i class="fas fa-envelope d-lg-none me-2"></i>Contact
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                </ul>
                
                <!-- User Dropdown -->
                <div class="d-flex align-items-center">
                    <div class="text-white me-3 d-none d-md-block text-end">
                        <div class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></div>
                        <div class="small text-white-50"><?php echo ucfirst($user['role']); ?></div>
                    </div>
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle fa-lg"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="userDropdown" style="border: none; min-width: 200px;">
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2 text-muted"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2 text-muted"></i>Settings</a></li>
                            <li><hr class="dropdown-divider my-2"></li>
                            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Add padding to body to account for fixed navbar -->
    <div style="padding-top: 70px;"></div>
    
    <style>
        .navbar {
            padding: 0.8rem 0;
            transition: all 0.3s ease;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            font-weight: 500;
            margin: 0 0.2rem;
            transition: color 0.3s ease;
        }
        
        .nav-link:hover, .nav-link.active {
            color: #e67e22 !important;
        }
        
        .nav-link-underline {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background-color: #e67e22;
            transition: width 0.3s ease;
        }
        
        .nav-link:hover .nav-link-underline,
        .nav-link.active .nav-link-underline {
            width: 60%;
        }
        
        .navbar-brand {
            font-size: 1.4rem;
            transition: all 0.3s ease;
        }
        
        .navbar-brand:hover {
            transform: translateY(-1px);
        }
        
        .dropdown-menu {
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 0.5rem 0;
        }
        
        .dropdown-item {
            padding: 0.5rem 1.25rem;
            font-weight: 400;
            transition: all 0.2s ease;
        }
        
        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #e67e22 !important;
            padding-left: 1.5rem;
        }
        
        .dropdown-divider {
            margin: 0.3rem 0;
        }
    </style>

    <!-- Main Content -->
    <div class="container py-4">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Donations</h2>
                <p class="text-muted mb-0">Manage and track all donations</p>
            </div>
            <div>
                <a href="records.php?type=donation" class="btn btn-outline-primary me-2">
                    <i class="fas fa-arrow-left me-2"></i>Back to Records
                </a>
                <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDonationModal">
                    <i class="fas fa-plus me-2"></i>Add Donation
                </a>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3 mb-md-0">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Total Donations</h6>
                        <h3 class="stat-value">₵<?php echo number_format($stats['total_amount'] ?? 0, 2); ?></h3>
                        <div class="text-muted"><?php echo number_format($stats['total_count'] ?? 0); ?> records</div>
                        <i class="fas fa-hand-holding-usd stat-icon"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3 mb-md-0">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Tithes</h6>
                        <h3 class="stat-value">₵<?php echo number_format($stats['tithes'] ?? 0, 2); ?></h3>
                        <div class="text-muted">
                            <?php 
                            $percentage = $stats['total_amount'] > 0 ? ($stats['tithes'] / $stats['total_amount'] * 100) : 0;
                            echo number_format($percentage, 1); 
                            ?>% of total
                        </div>
                        <i class="fas fa-church stat-icon"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3 mb-md-0">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Offerings</h6>
                        <h3 class="stat-value">₵<?php echo number_format($stats['offerings'] ?? 0, 2); ?></h3>
                        <div class="text-muted">
                            <?php 
                            $percentage = $stats['total_amount'] > 0 ? ($stats['offerings'] / $stats['total_amount'] * 100) : 0;
                            echo number_format($percentage, 1); 
                            ?>% of total
                        </div>
                        <i class="fas fa-gift stat-icon"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <h6 class="stat-label">Other Donations</h6>
                        <h3 class="stat-value">₵<?php echo number_format(($stats['donations'] ?? 0) + ($stats['others'] ?? 0), 2); ?></h3>
                        <div class="text-muted">
                            <?php 
                            $other_total = ($stats['donations'] ?? 0) + ($stats['others'] ?? 0);
                            $percentage = $stats['total_amount'] > 0 ? ($other_total / $stats['total_amount'] * 100) : 0;
                            echo number_format($percentage, 1); 
                            ?>% of total
                        </div>
                        <i class="fas fa-donate stat-icon"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label for="search" class="form-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by donor or description...">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="type" class="form-label">Type</label>
                        <select class="form-select" id="type" name="type">
                            <?php foreach($donation_types as $value => $label): ?>
                                <option value="<?php echo $value; ?>" <?php echo $type === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="start_date" class="form-label">From</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="end_date" class="form-label">To</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                    <div class="col-md-1 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-1"></i> Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Donations Table -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Donation Records</h5>
                <div class="export-buttons">
                    <a href="#" class="btn btn-sm btn-outline-secondary" id="printBtn">
                        <i class="fas fa-print me-1"></i>Print
                    </a>
                    <a href="#" class="btn btn-sm btn-outline-secondary" id="exportPdfBtn">
                        <i class="fas fa-file-pdf me-1"></i>PDF
                    </a>
                    <a href="#" class="btn btn-sm btn-outline-secondary" id="exportExcelBtn">
                        <i class="fas fa-file-excel me-1"></i>Excel
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Donor</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th class="text-end">Amount</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($paginated_donations)): ?>
                                <?php foreach($paginated_donations as $donation): ?>
                                    <tr>
                                        <td><?php echo date('M d, Y', strtotime($donation['date'])); ?></td>
                                        <td><?php echo htmlspecialchars($donation['donor_name']); ?></td>
                                        <td>
                                            <?php 
                                            $donation_type = $donation['type'] ?? 'other';
                                            $type_class = 'badge-other';
                                            $type_label = ucfirst($donation_type);
                                            
                                            switch ($donation_type) {
                                                case 'tithe':
                                                    $type_class = 'badge-tithe';
                                                    break;
                                                case 'offering':
                                                    $type_class = 'badge-offering';
                                                    break;
                                                case 'donation':
                                                    $type_class = 'badge-donation';
                                                    break;
                                                default:
                                                    $type_class = 'badge-other';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $type_class; ?>"><?php echo htmlspecialchars($type_label); ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($donation['description']); ?></td>
                                        <td class="text-end fw-bold">₵<?php echo number_format($donation['amount'], 2); ?></td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <button class="btn btn-sm btn-outline-primary" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#viewDonationModal" 
                                                    data-id="<?php echo $donation['id'] ?? ''; ?>"
                                                    data-date="<?php echo isset($donation['date']) ? date('Y-m-d', strtotime($donation['date'])) : ''; ?>"
                                                    data-donor="<?php echo htmlspecialchars($donation['donor_name'] ?? ''); ?>"
                                                    data-type="<?php echo $donation['type'] ?? 'other'; ?>"
                                                    data-amount="<?php echo $donation['amount'] ?? 0; ?>"
                                                    data-description="<?php echo htmlspecialchars($donation['description'] ?? ''); ?>"
                                                    data-recorded="<?php echo isset($donation['created_at']) ? date('M d, Y h:i A', strtotime($donation['created_at'])) : ''; ?>"
                                                    data-recorded-by="<?php echo htmlspecialchars($donation['recorded_by'] ?? 'System'); ?>"
                                                    aria-label="View donation details"
                                                    title="View">
                                                    <i class="fas fa-eye" aria-hidden="true"></i>
                                                    <span class="visually-hidden">View donation details</span>
                                                </button>
                                                <a href="edit_donation.php?id=<?php echo $donation['id']; ?>" 
                                                   class="btn btn-sm btn-outline-secondary"
                                                   aria-label="Edit donation"
                                                   title="Edit">
                                                    <i class="fas fa-edit" aria-hidden="true"></i>
                                                    <span class="visually-hidden">Edit donation</span>
                                                </a>
                                                <button class="btn btn-sm btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteModal" 
                                                    data-id="<?php echo $donation['id']; ?>"
                                                    aria-label="Delete donation"
                                                    title="Delete">
                                                    <i class="fas fa-trash" aria-hidden="true"></i>
                                                    <span class="visually-hidden">Delete donation</span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                        <p class="mb-0">No donation records found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="bg-light">
                                <td colspan="4" class="text-end fw-bold">Total:</td>
                                <td class="text-end fw-bold">
                                    ₵<?php 
                                    $total = 0;
                                    if (isset($stats['total_amount']) && is_numeric($stats['total_amount'])) {
                                        $total = $stats['total_amount'];
                                    } else {
                                        // Calculate total from individual categories if total_amount is not set
                                        $total = ($stats['tithes'] ?? 0) + ($stats['offerings'] ?? 0) + 
                                                ($stats['donations'] ?? 0) + ($stats['others'] ?? 0);
                                    }
                                    echo number_format($total, 2); 
                                    ?>
                                </td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="card-footer bg-white">
                        <nav aria-label="Donation pagination">
                            <ul class="pagination justify-content-center mb-0">
                                <li class="page-item <?php echo $current_page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?<?php 
                                        $params = $_GET;
                                        $params['page'] = $current_page - 1;
                                        echo http_build_query($params);
                                    ?>">Previous</a>
                                </li>
                                
                                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?<?php 
                                            $params = $_GET;
                                            $params['page'] = $i;
                                            echo http_build_query($params);
                                        ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <li class="page-item <?php echo $current_page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?<?php 
                                        $params = $_GET;
                                        $params['page'] = $current_page + 1;
                                        echo http_build_query($params);
                                    ?>">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Success Alert -->
    <?php if (isset($_GET['success'])): ?>
    <div class="position-fixed top-0 end-0 p-3" style="z-index: 11">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?php 
            $message = 'Donation recorded successfully';
            if (isset($_GET['ref'])) {
                $message .= ' (Ref: ' . htmlspecialchars($_GET['ref']) . ')';
            }
            echo $message;
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Error Alert -->
    <?php if (isset($_GET['error'])): ?>
    <div class="position-fixed top-0 end-0 p-3" style="z-index: 11">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?php echo htmlspecialchars(urldecode($_GET['error'])); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Add Donation Modal -->
    <div class="modal fade" id="addDonationModal" tabindex="-1" aria-labelledby="addDonationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addDonationModalLabel">Add New Donation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="donationForm" method="POST" action="process_donation.php">
                    <input type="hidden" name="type" value="donation">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="donor_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="donor_name" name="donor_name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="donation_type" class="form-label">Type <span class="text-danger">*</span></label>
                                    <select class="form-select" id="donation_type" name="donation_type" required>
                                        <option value="tithe">Tithe</option>
                                        <option value="offering" selected>Offering</option>
                                        <option value="donation">Donation</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="amount" class="form-label">Amount <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">₵</span>
                                        <input type="number" step="0.01" min="0.01" class="form-control" id="amount" name="amount" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="date" class="form-label">Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="date" name="date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="donateButton">
                            <i class="fas fa-credit-card me-2"></i>Proceed to Payment
                        </button>
                        <div class="mt-2 small text-muted">
                            <i class="fas fa-lock me-1"></i> Secure payment powered by Paystack
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- View Donation Modal -->
    <div class="modal fade" id="viewDonationModal" tabindex="-1" aria-labelledby="viewDonationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewDonationModalLabel">Donation Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-6">
                            <h6 class="text-muted mb-1">Date</h6>
                            <p id="view-date" class="mb-0">-</p>
                        </div>
                        <div class="col-6">
                            <h6 class="text-muted mb-1">Donor</h6>
                            <p id="view-donor" class="mb-0">-</p>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <h6 class="text-muted mb-1">Type</h6>
                            <p id="view-type" class="mb-0">-</p>
                        </div>
                        <div class="col-6">
                            <h6 class="text-muted mb-1">Amount</h6>
                            <p id="view-amount" class="fw-bold mb-0">-</p>
                        </div>
                    </div>
                    <div class="mb-3">
                        <h6 class="text-muted mb-1">Description</h6>
                        <p id="view-description" class="mb-0">-</p>
                    </div>
                    <hr>
                    <div class="text-muted small">
                        <div>Recorded: <span id="view-recorded">-</span></div>
                        <div>Recorded by: <span id="view-recorded-by">-</span></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <a href="#" id="edit-donation-btn" class="btn btn-primary">
                        <i class="fas fa-edit me-2"></i>Edit
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this donation record? This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form id="delete-form" method="POST" action="delete_donation.php" class="d-inline">
                        <input type="hidden" name="id" id="delete-id" value="">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash-alt me-2"></i>Delete
                        </button>
                    </form>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/print-this/printThis.min.js"></script>
    <script src="https://js.paystack.co/v1/inline.js"></script>
    <script>
        // Handle form submission with Paystack
        document.addEventListener('DOMContentLoaded', function() {
            const donationForm = document.getElementById('donationForm');
            
            if (donationForm) {
                donationForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const submitBtn = this.querySelector('button[type="submit"]');
                    const originalBtnText = submitBtn.innerHTML;
                    
                    // Show loading state
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
                    
                    // Show debug info
                    console.log('Form data:', Object.fromEntries(formData));
                    
                    // Submit form via AJAX
                    fetch('donations.php', {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            return response.text().then(text => { 
                                throw new Error(text);
                            });
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data && data.data.authorization_url) {
                            // Redirect to Paystack payment page
                            window.location.href = data.data.authorization_url;
                        } else {
                            throw new Error(data.message || 'Failed to initialize payment');
                        }
                    })
                    .catch(error => {
                        console.error('Payment Error:', error);
                        let errorMessage = 'An error occurred while processing your payment';
                        let showContactSupport = true;
                        
                        // Try to parse the error message as JSON
                            if (error.message) {
                                try {
                                    const errorData = JSON.parse(error.message);
                                    if (errorData.message) {
                                        errorMessage = errorData.message;
                                        // If we got a specific error from our server, don't show contact support
                                        showContactSupport = false;
                                    }
                            } catch (e) {
                                // If it's not JSON, check for specific error messages
                                if (error.message && (error.message.includes('cURL is not available') || 
                                    error.message.includes('allow_url_fopen'))) {
                                    errorMessage = 'Server configuration issue: ' + error.message + 
                                                 '\n\nPlease contact your system administrator to enable cURL or allow_url_fopen in PHP configuration.';
                                } else if (error.message) {
                                    errorMessage = error.message;
                                }
                                    }
                                }
                            }
                        } catch (e) {
                            console.error('Error processing error message:', e);
                        }
                        
                        // Show detailed error message
                        const fullErrorMessage = 'Payment Error: ' + errorMessage + 
                            (showContactSupport ? '\n\nPlease try again later or contact support if the problem persists.' : '');
                            
                        alert(fullErrorMessage);
                        
                        // Log the full error for debugging
                        console.error('Full error details:', {
                            error: error,
                            message: error.message,
                            stack: error.stack
                        });
                        
                        // Reset button state
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalBtnText;
                        
                        // Don't close the modal on error so user can try again
                        // const modal = bootstrap.Modal.getInstance(document.getElementById('addDonationModal'));
                        // if (modal) {
                        //     modal.hide();
                        // }
                    });
                });
            }
        });
        
        // View Donation Modal
        const viewDonationModal = document.getElementById('viewDonationModal');
        if (viewDonationModal) {
            viewDonationModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                
                // Extract info from data-* attributes
                const id = button.getAttribute('data-id');
                const date = button.getAttribute('data-date');
                const donor = button.getAttribute('data-donor');
                const type = button.getAttribute('data-type');
                const amount = button.getAttribute('data-amount');
                const description = button.getAttribute('data-description');
                const recorded = button.getAttribute('data-recorded');
                const recordedBy = button.getAttribute('data-recorded-by');
                
                // Format date
                const formattedDate = new Date(date).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                });
                
                // Format type
                let typeBadge = '';
                let typeClass = 'badge-other';
                let typeLabel = type.charAt(0).toUpperCase() + type.slice(1);
                
                if (type === 'tithe') {
                    typeClass = 'badge-tithe';
                } else if (type === 'offering') {
                    typeClass = 'badge-offering';
                } else if (type === 'donation') {
                    typeClass = 'badge-donation';
                }
                
                typeBadge = `<span class="badge ${typeClass}">${typeLabel}</span>`;
                
                // Update the modal's content
                document.getElementById('view-date').textContent = formattedDate;
                document.getElementById('view-donor').textContent = donor || 'N/A';
                document.getElementById('view-type').innerHTML = typeBadge;
                document.getElementById('view-amount').textContent = `$${parseFloat(amount).toFixed(2)}`;
                document.getElementById('view-description').textContent = description || 'No description provided';
                document.getElementById('view-recorded').textContent = recorded || 'N/A';
                document.getElementById('view-recorded-by').textContent = recordedBy || 'N/A';
                
                // Update edit button href
                document.getElementById('edit-donation-btn').href = `edit_donation.php?id=${id}`;
            });
        }
        
        // Delete Confirmation Modal
        const deleteModal = document.getElementById('deleteModal');
        if (deleteModal) {
            deleteModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                const id = button.getAttribute('data-id');
                document.getElementById('delete-id').value = id;
            });
        }
        
        // Print functionality
        document.getElementById('printBtn')?.addEventListener('click', function(e) {
            e.preventDefault();
            window.print();
        });
        
        // Export to PDF (placeholder - would need a library like jsPDF or server-side generation)
        document.getElementById('exportPdfBtn')?.addEventListener('click', function(e) {
            e.preventDefault();
            alert('Export to PDF functionality would be implemented here');
        });
        
        // Export to Excel (placeholder - would need a library like SheetJS or server-side generation)
        document.getElementById('exportExcelBtn')?.addEventListener('click', function(e) {
            e.preventDefault();
            alert('Export to Excel functionality would be implemented here');
        });
        
        // Set default date to today for the add donation form
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('date').value = today;
        });
    </script>
</body>
</html>
