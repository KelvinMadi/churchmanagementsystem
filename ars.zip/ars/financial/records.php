<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin', 'accountant']);
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    } else {
        $type = $_POST['type'];
        $amount = (float)$_POST['amount'];
        $description = trim($_POST['description']);
        $date = $_POST['date'];
        $category = $_POST['category'];
        $donor_name = trim($_POST['donor_name'] ?? '');

        if ($type && $amount > 0 && $description && $date) {
            if ($type === 'donation') {
                $stmt = $conn->prepare('INSERT INTO donations (amount, description, donor_name, date, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
                $stmt->bind_param('dssss', $amount, $description, $donor_name, $date, $user['id']);
            } else {
                $stmt = $conn->prepare('INSERT INTO expenses (amount, description, category, date, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
                $stmt->bind_param('dssss', $amount, $description, $category, $date, $user['id']);
            }
            
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>Financial record added successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
            } else {
                $message = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>Error adding record: ' . htmlspecialchars($stmt->error) . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
            }
            $stmt->close();
        } else {
            $message = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                <i class="fas fa-info-circle me-2"></i>Please fill all required fields.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
    }
}

// Get financial statistics
$total_donations = $conn->query("SELECT SUM(amount) as total FROM donations")->fetch_assoc()['total'] ?? 0;
$total_expenses = $conn->query("SELECT SUM(amount) as total FROM expenses")->fetch_assoc()['total'] ?? 0;
$balance = $total_donations - $total_expenses;

// Get recent transactions
$recent_donations = $conn->query("SELECT * FROM donations ORDER BY date DESC LIMIT 5");
$recent_expenses = $conn->query("SELECT * FROM expenses ORDER BY date DESC LIMIT 5");

// Get monthly data for charts
$monthly_donations = $conn->query("
    SELECT 
        DATE_FORMAT(date, '%b %Y') as month,
        SUM(amount) as total
    FROM donations 
    WHERE date >= DATE_SUB(NOW(), INTERVAL 5 MONTH)
    GROUP BY DATE_FORMAT(date, '%Y-%m')
    ORDER BY date ASC
");

$monthly_expenses = $conn->query("
    SELECT 
        DATE_FORMAT(date, '%b %Y') as month,
        SUM(amount) as total
    FROM expenses 
    WHERE date >= DATE_SUB(NOW(), INTERVAL 5 MONTH)
    GROUP BY DATE_FORMAT(date, '%Y-%m')
    ORDER BY date ASC
");

// Get expense categories
$expense_categories = [
    'ministry' => 'Ministry Expenses',
    'facilities' => 'Facilities',
    'salaries' => 'Salaries',
    'outreach' => 'Outreach',
    'other' => 'Other'
];
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Records - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/apexcharts@3.35.0/dist/apexcharts.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2c3e50;
            --primary-hover: #1a252f;
            --secondary: #e67e22;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
        }
        
        body {
            background-color: #f8fafc;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            line-height: 1.6;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
        }
        
        .navbar {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 0.75rem 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.125rem 0.5rem rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            transition: transform 0.2s, box-shadow 0.2s;
            border: 1px solid rgba(0,0,0,0.05);
        }
        
        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 0.5rem 1.5rem rgba(0, 0, 0, 0.08);
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            font-weight: 600;
            padding: 1.25rem 1.5rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .stat-card {
            position: relative;
            overflow: hidden;
            border-left: 4px solid var(--primary);
            background: white;
        }
        
        .stat-card.income {
            border-left-color: var(--success);
        }
        
        .stat-card.expense {
            border-left-color: var(--danger);
        }
        
        .stat-card.balance {
            border-left-color: var(--info);
        }
        
        .stat-card .card-body {
            padding: 1.5rem;
        }
        
        .stat-card .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0.5rem 0;
            font-family: 'Montserrat', sans-serif;
        }
        
        .stat-card.income .stat-value {
            color: var(--success);
        }
        
        .stat-card.expense .stat-value {
            color: var(--danger);
        }
        
        .stat-card.balance .stat-value {
            color: var(--info);
        }
        
        .stat-card .stat-label {
            color: #6c757d;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 500;
        }
        
        .stat-card .stat-icon {
            font-size: 2.5rem;
            opacity: 0.1;
            position: absolute;
            right: 1.25rem;
            top: 1.25rem;
            color: var(--primary);
        }
        
        .stat-card.income .stat-icon {
            color: var(--success);
        }
        
        .stat-card.expense .stat-icon {
            color: var(--danger);
        }
        
        .stat-card.balance .stat-icon {
            color: var(--info);
        }
        
        .transaction-item {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.2s;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .transaction-item:last-child {
            border-bottom: none;
        }
        
        .transaction-item:hover {
            background-color: #f8f9fa;
        }
        
        .transaction-amount {
            font-weight: 600;
            font-family: 'Montserrat', sans-serif;
        }
        
        .transaction-date {
            font-size: 0.8rem;
            color: #6c757d;
        }
        
        .badge {
            padding: 0.35em 0.65em;
            font-weight: 500;
            border-radius: 0.25rem;
            font-size: 0.75rem;
        }
        
        .badge-income {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .badge-expense {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .chart-container {
            height: 300px;
            position: relative;
            margin: 1rem 0;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            font-weight: 500;
            padding: 0.5rem 1.25rem;
            border-radius: 20px;
            transition: all 0.2s;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-1px);
        }
        
        .btn-outline-primary {
            color: var(--primary);
            border-color: var(--primary);
            font-weight: 500;
        }
        
        .btn-outline-primary:hover {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table th {
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #6c757d;
            border-top: none;
            padding: 1rem 1.5rem;
            background-color: #f8f9fa;
        }
        
        .table td {
            padding: 1rem 1.5rem;
            vertical-align: middle;
            border-color: #f0f0f0;
        }
        
        .table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .nav-pills .nav-link {
            border-radius: 20px;
            padding: 0.5rem 1.25rem;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            color: #6c757d;
            font-weight: 500;
        }
        
        .nav-pills .nav-link.active {
            background-color: var(--primary);
            color: white;
        }
        
        .form-control, .form-select {
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            border: 1px solid #e1e5ee;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(44, 62, 80, 0.1);
        }
        
        .modal-header {
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 1.25rem 1.5rem;
        }
        
        .modal-footer {
            border-top: 1px solid rgba(0,0,0,0.05);
            padding: 1.25rem 1.5rem;
        }
        
        @media (max-width: 768px) {
            .stat-card .stat-value {
                font-size: 1.5rem;
            }
            
            .btn {
                padding: 0.5rem 1rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="../index.php">
                <i class="fas fa-church me-2"></i>
                <span>Church MS</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="records.php">Financial Records</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Reports</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="text-white me-3 d-none d-md-block">
                        <div class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></div>
                        <div class="small"><?php echo ucfirst($user['role']); ?></div>
                    </div>
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle fa-lg"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container py-4">
        <?php echo $message; ?>
        
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Financial Records</h2>
                <p class="text-muted mb-0">Manage and track all financial transactions</p>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRecordModal">
                <i class="fas fa-plus me-2"></i>Add Record
            </button>
        </div>
        
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card stat-card income">
                    <div class="card-body">
                        <h6 class="stat-label">Total Income</h6>
                        <h2 class="stat-value">$<?php echo number_format($total_donations, 2); ?></h2>
                        <div class="d-flex align-items-center mt-2">
                            <span class="text-success me-2"><i class="fas fa-arrow-up"></i> 12%</span>
                            <span class="text-muted">vs last month</span>
                        </div>
                        <i class="fas fa-hand-holding-usd stat-icon"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card stat-card expense">
                    <div class="card-body">
                        <h6 class="stat-label">Total Expenses</h6>
                        <h2 class="stat-value">$<?php echo number_format($total_expenses, 2); ?></h2>
                        <div class="d-flex align-items-center mt-2">
                            <span class="text-success me-2"><i class="fas fa-arrow-down"></i> 5%</span>
                            <span class="text-muted">vs last month</span>
                        </div>
                        <i class="fas fa-receipt stat-icon"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card stat-card balance">
                    <div class="card-body">
                        <h6 class="stat-label">Current Balance</h6>
                        <h2 class="stat-value">$<?php echo number_format($balance, 2); ?></h2>
                        <div class="d-flex align-items-center mt-2">
                            <span class="text-<?php echo $balance >= 0 ? 'success' : 'danger'; ?> me-2">
                                <i class="fas fa-<?php echo $balance >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i> 
                                <?php echo $balance >= 0 ? 'Good' : 'Low'; ?>
                            </span>
                            <span class="text-muted">Financial Health</span>
                        </div>
                        <i class="fas fa-wallet stat-icon"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Charts Row -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Financial Overview</h5>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-secondary active">6 Months</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary">1 Year</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary">All Time</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="financialChart" class="chart-container"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Transactions -->
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Recent Donations</h5>
                        <a href="donations.php" class="btn btn-sm btn-link">View All</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if ($recent_donations && $recent_donations->num_rows > 0): ?>
                            <?php while($donation = $recent_donations->fetch_assoc()): ?>
                                <div class="transaction-item">
                                    <div>
                                        <div class="d-flex align-items-center">
                                            <span class="badge badge-income me-2">
                                                Donation
                                            </span>
                                            <span class="text-truncate" style="max-width: 150px;" title="<?php echo htmlspecialchars($donation['donor_name']); ?>">
                                                <?php echo htmlspecialchars($donation['donor_name']); ?>
                                            </span>
                                        </div>
                                        <div class="transaction-date">
                                            <?php echo date('M d, Y', strtotime($donation['date'])); ?>
                                        </div>
                                    </div>
                                    <div class="transaction-amount text-success">
                                        +$<?php echo number_format($donation['amount'], 2); ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center p-4 text-muted">
                                <i class="fas fa-inbox fa-2x mb-2"></i>
                                <p class="mb-0">No donation records found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Recent Expenses</h5>
                        <a href="expenses.php" class="btn btn-sm btn-link">View All</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if ($recent_expenses && $recent_expenses->num_rows > 0): ?>
                            <?php while($expense = $recent_expenses->fetch_assoc()): ?>
                                <div class="transaction-item">
                                    <div>
                                        <div class="d-flex align-items-center">
                                            <span class="badge badge-expense me-2">
                                                <?php echo $expense_categories[$expense['category']] ?? 'Expense'; ?>
                                            </span>
                                            <span class="text-truncate" style="max-width: 150px;" title="<?php echo htmlspecialchars($expense['description']); ?>">
                                                <?php echo htmlspecialchars($expense['description']); ?>
                                            </span>
                                        </div>
                                        <div class="transaction-date">
                                            <?php echo date('M d, Y', strtotime($expense['date'])); ?>
                                        </div>
                                    </div>
                                    <div class="transaction-amount text-danger">
                                        -$<?php echo number_format($expense['amount'], 2); ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center p-4 text-muted">
                                <i class="fas fa-inbox fa-2x mb-2"></i>
                                <p class="mb-0">No expense records found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Record Modal -->
    <div class="modal fade" id="addRecordModal" tabindex="-1" aria-labelledby="addRecordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addRecordModalLabel">Add New Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Record Type</label>
                            <div class="btn-group w-100" role="group">
                                <input type="radio" class="btn-check" name="type" id="type_donation" value="donation" autocomplete="off" checked>
                                <label class="btn btn-outline-success" for="type_donation">
                                    <i class="fas fa-hand-holding-usd me-2"></i>Donation
                                </label>
                                
                                <input type="radio" class="btn-check" name="type" id="type_expense" value="expense" autocomplete="off">
                                <label class="btn btn-outline-danger" for="type_expense">
                                    <i class="fas fa-receipt me-2"></i>Expense
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" step="0.01" min="0.01" class="form-control" id="amount" name="amount" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <input type="text" class="form-control" id="description" name="description" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="date" class="form-label">Date</label>
                            <input type="date" class="form-control" id="date" name="date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="mb-3" id="donorField">
                            <label for="donor_name" class="form-label">Donor Name</label>
                            <input type="text" class="form-control" id="donor_name" name="donor_name">
                        </div>
                        
                        <div class="mb-3 d-none" id="categoryField">
                            <label for="category" class="form-label">Expense Category</label>
                            <select class="form-select" id="category" name="category">
                                <?php foreach($expense_categories as $value => $label): ?>
                                    <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Save Record
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.35.0/dist/apexcharts.min.js"></script>
    <script>
        // Toggle between donation and expense fields
        document.querySelectorAll('input[name="type"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const isExpense = this.value === 'expense';
                document.getElementById('donorField').classList.toggle('d-none', isExpense);
                document.getElementById('categoryField').classList.toggle('d-none', !isExpense);
            });
        });
        
        // Initialize chart
        document.addEventListener('DOMContentLoaded', function() {
            // Sample data - replace with your actual data
            const monthlyData = {
                months: [
                    <?php 
                    $months = [];
                    while($row = $monthly_donations->fetch_assoc()) {
                        $months[] = '"' . $row['month'] . '"';
                    }
                    echo implode(',', $months);
                    ?>
                ],
                donations: [
                    <?php 
                    $monthly_donations->data_seek(0); // Reset pointer
                    $amounts = [];
                    while($row = $monthly_donations->fetch_assoc()) {
                        $amounts[] = $row['total'];
                    }
                    echo implode(',', $amounts);
                    ?>
                ],
                expenses: [
                    <?php 
                    $amounts = [];
                    while($row = $monthly_expenses->fetch_assoc()) {
                        $amounts[] = $row['total'];
                    }
                    echo implode(',', $amounts);
                    ?>
                ]
            };
            
            const options = {
                series: [
                    {
                        name: 'Donations',
                        data: monthlyData.donations,
                        color: '#28a745'
                    },
                    {
                        name: 'Expenses',
                        data: monthlyData.expenses,
                        color: '#dc3545'
                    }
                ],
                chart: {
                    type: 'bar',
                    height: '100%',
                    stacked: false,
                    toolbar: {
                        show: true
                    },
                    zoom: {
                        enabled: false
                    }
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '70%',
                        endingShape: 'rounded',
                        borderRadius: 4
                    },
                },
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    show: true,
                    width: 2,
                    colors: ['transparent']
                },
                xaxis: {
                    categories: monthlyData.months,
                    labels: {
                        style: {
                            colors: '#6c757d',
                            fontSize: '12px',
                            fontFamily: '"Poppins", sans-serif'
                        }
                    },
                    axisBorder: {
                        show: false
                    },
                    axisTicks: {
                        show: false
                    }
                },
                yaxis: {
                    labels: {
                        formatter: function(value) {
                            return '$' + value.toLocaleString();
                        },
                        style: {
                            colors: '#6c757d',
                            fontSize: '12px',
                            fontFamily: '"Poppins", sans-serif'
                        }
                    }
                },
                fill: {
                    opacity: 1
                },
                tooltip: {
                    y: {
                        formatter: function(value) {
                            return '$' + value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
                        }
                    },
                    style: {
                        fontSize: '14px',
                        fontFamily: '"Poppins", sans-serif'
                    }
                },
                legend: {
                    position: 'top',
                    horizontalAlign: 'right',
                    fontSize: '14px',
                    fontFamily: '"Poppins", sans-serif',
                    markers: {
                        width: 10,
                        height: 10,
                        radius: 0
                    },
                    itemMargin: {
                        horizontal: 15,
                        vertical: 5
                    }
                },
                grid: {
                    borderColor: '#f0f0f0',
                    strokeDashArray: 3,
                    xaxis: {
                        lines: {
                            show: true
                        }
                    },
                    yaxis: {
                        lines: {
                            show: true
                        }
                    },
                    padding: {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0
                    }
                }
            };

            const chart = new ApexCharts(document.querySelector("#financialChart"), options);
            chart.render();
            
            // Update chart on window resize
            window.addEventListener('resize', function() {
                chart.updateOptions({
                    chart: {
                        width: '100%'
                    }
                });
            });
        });
    </script>
</body>
</html>
