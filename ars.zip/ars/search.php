<?php
require_once 'includes/db.php';
$page_title = 'Search';
$show_page_header = true;
include 'includes/header.php';

$query = isset($_GET['q']) ? trim($_GET['q']) : '';
?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <form method="get" class="mb-4">
                <div class="input-group">
                    <input type="text" class="form-control" name="q" value="<?php echo htmlspecialchars($query); ?>" placeholder="Search sermons, events, and announcements...">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </form>
            <?php if ($query !== ''): ?>
            <div class="card shadow-sm">
                <div class="card-body">
                    <h2 class="h5 mb-3">Results for "<?php echo htmlspecialchars($query); ?>"</h2>
                    <p>No full-text index yet. Please refine your search.</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>

