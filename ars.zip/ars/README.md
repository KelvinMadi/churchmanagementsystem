# Church Management System

A comprehensive web-based church management system built with PHP, MySQL, and Bootstrap. This system provides tools for managing church activities, members, events, finances, and more.

## Features

### 🔐 Authentication & User Management
- **Multi-role System**: Admin, Pastor, Accountant, Ministry Leader, Member
- **Secure Login/Registration**: Password hashing and session management
- **Profile Management**: Users can update their information and change passwords

### 📚 Sermons & Devotionals
- **Upload Sermons**: Pastors can upload and manage sermons
- **Search Functionality**: Search through sermons by title, content, or scripture
- **Public Access**: Anyone can view sermons without logging in

### 📅 Events Management
- **Create Events**: Admins, pastors, and leaders can create church events
- **Event Registration**: Members can register for events
- **Event Details**: Date, time, location, and participant limits

### 📢 Announcements
- **Post Announcements**: Admins and pastors can post announcements
- **Priority Levels**: Normal, Important, Urgent
- **Public/Private**: Control visibility of announcements

### 👥 Member Management
- **Member Registration**: Admins can register new members
- **Detailed Profiles**: Contact info, ministry involvement, emergency contacts
- **Ministry Tracking**: Track member involvement in different ministries

### 📊 Attendance Tracking
- **Service Attendance**: Mark attendance for different service types
- **Attendance Reports**: Generate attendance statistics
- **Member Tracking**: Track individual member attendance

### 💰 Financial Management
- **Donations Tracking**: Record and track church donations
- **Expense Management**: Track church expenses by category
- **Financial Reports**: Generate financial summaries and reports

### 📈 Reporting System
- **Attendance Reports**: Service attendance statistics
- **Financial Reports**: Donations and expenses summaries
- **Member Reports**: Member information and statistics
- **Printable Reports**: Export reports for printing

## Installation

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)

### Setup Instructions

1. **Clone or Download the Project**
   ```bash
   git clone <repository-url>
   cd church-management-system
   ```

2. **Database Setup**
   - Create a MySQL database named `church_management`
   - Import the `database_schema.sql` file to create all tables
   - Update database credentials in `includes/db.php`

3. **Configure Database Connection**
   Edit `includes/db.php` with your database credentials:
   ```php
   $host = 'localhost';
   $db   = 'church_management';
   $user = 'your_username';
   $pass = 'your_password';
   ```

4. **Web Server Configuration**
   - Place the project in your web server directory
   - Ensure PHP has write permissions for file uploads
   - Configure your web server to serve the application

5. **Default Login Credentials**
   - **Admin**: admin@church.com / admin123
   - **Pastor**: pastor@church.com / admin123
   - **Accountant**: accountant@church.com / admin123
   - **Leader**: leader@church.com / admin123
   - **Member**: member@church.com / admin123

## User Roles & Permissions

### 👑 Administrator
- Full system access
- Member registration
- Attendance management
- Financial oversight
- Report generation
- System administration

### 🙏 Pastor
- Sermon upload and management
- Event creation and coordination
- Announcement posting
- Attendance tracking
- Member pastoral care

### 💰 Accountant
- Financial record management
- Donations and expenses tracking
- Financial reporting
- Budget management

### 👥 Ministry Leader
- Event planning and coordination
- Ministry-specific attendance tracking
- Member engagement
- Ministry reporting

### 👤 Member
- View sermons and announcements
- Register for events
- Update personal profile
- View personal attendance

## File Structure

```
church-management-system/
├── index.php                 # Home page
├── login.php                 # Login page
├── register.php              # Registration page
├── logout.php                # Logout script
├── profile.php               # User profile management
├── database_schema.sql       # Database schema
├── README.md                 # This file
├── includes/
│   ├── auth.php             # Authentication functions
│   └── db.php               # Database connection
├── assets/
│   ├── css/
│   │   └── style.css        # Custom styles
│   └── js/
│       └── main.js          # JavaScript functions
├── dashboard/
│   ├── admin.php            # Admin dashboard
│   ├── pastor.php           # Pastor dashboard
│   ├── accountant.php       # Accountant dashboard
│   ├── leader.php           # Leader dashboard
│   └── member.php           # Member dashboard
├── sermons/
│   ├── list.php             # Sermons listing
│   └── upload.php           # Sermon upload
├── events/
│   ├── list.php             # Events listing
│   └── create.php           # Event creation
├── announcements/
│   ├── list.php             # Announcements listing
│   └── post.php             # Announcement posting
├── members/
│   └── register.php         # Member registration
├── attendance/
│   └── mark.php             # Attendance marking
├── financial/
│   └── records.php          # Financial records
└── reports/
    └── generate.php         # Report generation
```

## Database Schema

The system uses the following main tables:

- **users**: User authentication and basic info
- **members**: Extended member information
- **sermons**: Sermon content and metadata
- **events**: Church events and activities
- **announcements**: Church announcements
- **attendance**: Service attendance records
- **attendance_members**: Individual attendance tracking
- **donations**: Financial donations
- **expenses**: Church expenses

## Security Features

- **Password Hashing**: All passwords are hashed using PHP's `password_hash()`
- **SQL Injection Prevention**: Prepared statements for all database queries
- **XSS Prevention**: Output escaping with `htmlspecialchars()`
- **Session Management**: Secure session handling
- **Role-based Access Control**: Permission-based feature access

## Customization

### Styling
- Modify `assets/css/style.css` for custom styling
- Update color schemes and branding
- Customize dashboard themes for different roles

### Features
- Add new modules by creating new directories and files
- Extend database schema for additional features
- Modify role permissions in authentication system

### Localization
- Update text strings for different languages
- Modify date/time formats
- Customize currency formatting

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify database credentials in `includes/db.php`
   - Ensure MySQL service is running
   - Check database exists and tables are created

2. **Permission Errors**
   - Ensure web server has read/write permissions
   - Check file upload directory permissions

3. **Login Issues**
   - Verify default passwords are working
   - Check session configuration
   - Ensure cookies are enabled

### Support

For technical support or feature requests, please contact the development team.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Version History

- **v1.0.0**: Initial release with core features
- Complete church management functionality
- Multi-role user system
- Comprehensive reporting
- Modern responsive design

---

**Developed with ❤️ for church communities** 