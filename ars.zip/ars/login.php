<?php
// Set session configuration before starting the session
@ini_set('session.cookie_lifetime', 60 * 60 * 24 * 30); // 30 days
@ini_set('session.gc_maxlifetime', 60 * 60 * 24 * 30); // 30 days

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'includes/db.php';
require_once 'includes/auth.php';

// Ensure CSRF token
$csrf_token = generate_csrf_token();

$email = $password = '';
$message = '';
$remember = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) && $_POST['remember'] === '1';

    if ($email && $password) {
        // Use our file-based database directly
        $user = $conn->findUserByEmail($email);
        if ($user) {
            if (password_verify($password, $user['password'])) {
                $id = $user['id'];
                $name = $user['name'];
                $role = $user['role'];
                
                // Regenerate session ID to prevent session fixation
                session_regenerate_id(true);
                
                // Set session variables
                $_SESSION['user_id'] = $id;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_role'] = $role;
                $_SESSION['user_email'] = $email;
                
                // If "Remember Me" is checked, set a cookie that expires in 30 days
                if ($remember) {
                    $token = bin2hex(random_bytes(32));
                    $expires = time() + (60 * 60 * 24 * 30); // 30 days
                    setcookie('remember_me', $token, $expires, '/', '', true, true);
                    
                    // Store the token in the database
                    $conn->query("UPDATE users SET remember_token = '$token' WHERE id = $id");
                }
                // Redirect based on role
                switch ($role) {
                    case 'pastor': header('Location: dashboard/pastor.php'); break;
                    case 'admin': header('Location: dashboard/admin.php'); break;
                    case 'accountant': header('Location: dashboard/accountant.php'); break;
                    case 'leader': header('Location: dashboard-leader.php'); break;
                    case 'member': header('Location: dashboard/member.php'); break;
                    default: header('Location: index.php'); break;
                }
                exit();
            } else {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid credentials.</div>';
            }
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>User not found.</div>';
        }
    }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
<div class="container min-vh-100 d-flex align-items-center">
    <div class="row justify-content-center w-100">
        <div class="col-md-6 col-lg-4">
            <div class="login-card">
                <div class="login-header text-center p-4">
                    <i class="fas fa-church fa-3x mb-3"></i>
                    <h3>Welcome Back</h3>
                    <p class="mb-0">Sign in to your account</p>
                </div>
                <div class="card-body p-4">
                    <?php echo $message; ?>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-envelope me-2"></i>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-lock me-2"></i>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="remember" name="remember" value="1">
                            <label class="form-check-label" for="remember">Remember me</label>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 mb-3">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </button>
                    </form>
                    <div class="text-center">
                        <a href="forgot_password.php" class="text-decoration-none">Forgot Password?</a>
                        <p class="mb-0">Don't have an account? <a href="register.php" class="text-decoration-none">Register</a></p>
                        <a href="index.php" class="text-decoration-none"><i class="fas fa-arrow-left me-1"></i>Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html> 