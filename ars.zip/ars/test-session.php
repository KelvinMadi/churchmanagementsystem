<?php
// Start session if not already started
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Include required files
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Get user info from session
$user_id = $_SESSION['user_id'] ?? null;
$user_name = $_SESSION['user_name'] ?? null;
$user_role = $_SESSION['user_role'] ?? null;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Session Test Page</h1>
        
        <div class="card mt-4">
            <div class="card-header">
                <h3>Session Information</h3>
            </div>
            <div class="card-body">
                <pre><?php print_r([
                    'session_id' => session_id(),
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                    'user_role' => $user_role,
                    'all_session' => $_SESSION
                ]); ?></pre>
            </div>
        </div>
        
        <div class="mt-4">
            <a href="index.php" class="btn btn-primary">Go to Home</a>
            <a href="sermons/list.php" class="btn btn-secondary">Go to Sermons</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
