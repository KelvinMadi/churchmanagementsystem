<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/header.php';

// Check if user is logged in
if (!is_logged_in()) {
    header('Location: ../login.php');
    exit();
}

$page_title = 'Groups';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get groups with pagination
$groups = [];
$total_groups = 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query
$query = "SELECT g.*, 
          (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count,
          u.name as leader_name
          FROM groups g 
          LEFT JOIN users u ON g.leader_id = u.id 
          WHERE g.is_active = 1";

$count_query = "SELECT COUNT(*) as count FROM groups WHERE is_active = 1";

if (!empty($search)) {
    $search_term = "%$search%";
    $query .= " AND (g.name LIKE ? OR g.description LIKE ?)";
    $count_query .= " AND (name LIKE '$search_term' OR description LIKE '$search_term')";
}

$query .= " ORDER BY g.name LIMIT $offset, $per_page";

// Get total count
$result = $conn->query($count_query);
$total_groups = $result->fetch_assoc()['count'];
$total_pages = ceil($total_groups / $per_page);

// Get groups
if (!empty($search)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $groups[] = $row;
    }
}
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Groups</h1>
        <a href="create.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> New Group
        </a>
    </div>

    <div class="card">
        <div class="card-header bg-white">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h5 class="mb-0">All Groups</h5>
                </div>
                <div class="col-md-6">
                    <form method="get" action="" class="d-flex">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search groups..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-outline-secondary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                            <?php if (!empty($search)): ?>
                                <a href="index.php" class="btn btn-outline-danger" type="button">
                                    <i class="fas fa-times"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <?php if (!empty($groups)): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Group Name</th>
                            <th>Description</th>
                            <th>Leader</th>
                            <th>Members</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($groups as $group): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-sm bg-primary bg-opacity-10 rounded-circle me-2">
                                            <i class="fas fa-users text-primary"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0"><?php echo htmlspecialchars($group['name']); ?></h6>
                                            <small class="text-muted"><?php echo $group['meeting_day'] ?? 'No meeting day set'; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php 
                                        $desc = $group['description'] ?? 'No description';
                                        echo strlen($desc) > 50 ? substr($desc, 0, 50) . '...' : $desc;
                                        ?>
                                    </small>
                                </td>
                                <td><?php echo htmlspecialchars($group['leader_name'] ?? 'Not assigned'); ?></td>
                                <td>
                                    <span class="badge bg-primary">
                                        <?php echo (int)$group['member_count']; ?> members
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $group['is_active'] ? 'success' : 'secondary'; ?>">
                                        <?php echo $group['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="groupActions" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="groupActions">
                                            <li>
                                                <a class="dropdown-item" href="view.php?id=<?php echo $group['id']; ?>">
                                                    <i class="fas fa-eye me-2"></i>View
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="edit.php?id=<?php echo $group['id']; ?>">
                                                    <i class="fas fa-edit me-2"></i>Edit
                                                </a>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#deleteGroup<?php echo $group['id']; ?>">
                                                    <i class="fas fa-trash-alt me-2"></i>Delete
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    
                                    <!-- Delete Confirmation Modal -->
                                    <div class="modal fade" id="deleteGroup<?php echo $group['id']; ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Confirm Delete</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete the group "<?php echo htmlspecialchars($group['name']); ?>"? This action cannot be undone.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <a href="delete.php?id=<?php echo $group['id']; ?>" class="btn btn-danger">
                                                        <i class="fas fa-trash-alt me-2"></i>Delete Group
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($total_pages > 1): ?>
                <div class="card-footer bg-white">
                    <nav aria-label="Groups pagination">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo; Previous</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" aria-label="Next">
                                        <span aria-hidden="true">Next &raquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="card-body">
                <div class="text-center py-5">
                    <i class="fas fa-users fa-4x text-muted mb-3"></i>
                    <h5>No groups found</h5>
                    <p class="text-muted">Get started by creating your first group.</p>
                    <a href="create.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i> Create Group
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
