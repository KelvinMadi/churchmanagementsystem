<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/header.php';

// Check if user is logged in
if (!is_logged_in()) {
    header('Location: ../login.php');
    exit();
}

$page_title = 'View Group';
$group_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$group_id) {
    header('Location: index.php');
    exit();
}

// Get group details
$group = [];
$stmt = $conn->prepare("
    SELECT g.*, u.name as leader_name, u.email as leader_email, u.phone as leader_phone,
           uc.name as created_by_name
    FROM groups g
    LEFT JOIN users u ON g.leader_id = u.id
    LEFT JOIN users uc ON g.created_by = uc.id
    WHERE g.id = ?
");
$stmt->bind_param('i', $group_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = 'Group not found';
    header('Location: index.php');
    exit();
}

$group = $result->fetch_assoc();

// Get group members
$members = [];
$stmt = $conn->prepare("
    SELECT u.id, u.name, u.email, u.phone, u.photo,
           gm.join_date, gm.is_leader, gm.status
    FROM group_members gm
    JOIN users u ON gm.user_id = u.id
    WHERE gm.group_id = ?
    ORDER BY gm.is_leader DESC, u.name
");
$stmt->bind_param('i', $group_id);
$stmt->execute();
$members_result = $stmt->get_result();

if ($members_result) {
    while ($row = $members_result->fetch_assoc()) {
        $members[] = $row;
    }
}

// Get upcoming meetings
$upcoming_meetings = [];
$stmt = $conn->prepare("
    SELECT * FROM group_meetings 
    WHERE group_id = ? AND meeting_date >= CURDATE()
    ORDER BY meeting_date ASC, start_time ASC
    LIMIT 3
");
$stmt->bind_param('i', $group_id);
$stmt->execute();
$meetings_result = $stmt->get_result();

if ($meetings_result) {
    while ($row = $meetings_result->fetch_assoc()) {
        $upcoming_meetings[] = $row;
    }
}

// Get recent activities
$recent_activities = [];
$stmt = $conn->prepare("
    SELECT * FROM activity_log 
    WHERE entity_type = 'group' AND entity_id = ?
    ORDER BY created_at DESC
    LIMIT 5
");
$stmt->bind_param('i', $group_id);
$stmt->execute();
$activities_result = $stmt->get_result();

if ($activities_result) {
    while ($row = $activities_result->fetch_assoc()) {
        $recent_activities[] = $row;
    }
}
?>

<div class="container-fluid py-4">
    <?php if (isset($_GET['created'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            Group created successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="../dashboard-pastor.php">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="index.php">Groups</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($group['name']); ?></li>
                </ol>
            </nav>
            <h1 class="h3 mb-0"><?php echo htmlspecialchars($group['name']); ?></h1>
        </div>
        <div>
            <div class="dropdown">
                <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="groupActions" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-ellipsis-v"></i> Actions
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="groupActions">
                    <li>
                        <a class="dropdown-item" href="edit.php?id=<?php echo $group['id']; ?>">
                            <i class="fas fa-edit me-2"></i>Edit Group
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="meeting.php?action=create&group_id=<?php echo $group['id']; ?>">
                            <i class="fas fa-plus-circle me-2"></i>Add Meeting
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="members.php?group_id=<?php echo $group['id']; ?>&action=add">
                            <i class="fas fa-user-plus me-2"></i>Add Member
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#deleteGroup">
                            <i class="fas fa-trash-alt me-2"></i>Delete Group
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Left Column -->
        <div class="col-lg-8">
            <!-- Group Details Card -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <ul class="nav nav-tabs card-header-tabs" id="groupTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="details-tab" data-bs-toggle="tab" data-bs-target="#details" type="button" role="tab" aria-controls="details" aria-selected="true">
                                <i class="fas fa-info-circle me-2"></i>Details
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="members-tab" data-bs-toggle="tab" data-bs-target="#members" type="button" role="tab" aria-controls="members" aria-selected="false">
                                <i class="fas fa-users me-2"></i>Members (<?php echo count($members); ?>)
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="meetings-tab" data-bs-toggle="tab" data-bs-target="#meetings" type="button" role="tab" aria-controls="meetings" aria-selected="false">
                                <i class="far fa-calendar-alt me-2"></i>Meetings
                            </button>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="groupTabsContent">
                        <!-- Details Tab -->
                        <div class="tab-pane fade show active" id="details" role="tabpanel" aria-labelledby="details-tab">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 class="mb-3">Group Information</h5>
                                    <table class="table table-borderless">
                                        <tr>
                                            <th width="40%">Status:</th>
                                            <td>
                                                <span class="badge bg-<?php echo $group['is_active'] ? 'success' : 'secondary'; ?>">
                                                    <?php echo $group['is_active'] ? 'Active' : 'Inactive'; ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php if ($group['meeting_day']): ?>
                                        <tr>
                                            <th>Meeting Time:</th>
                                            <td>
                                                <?php 
                                                    echo htmlspecialchars($group['meeting_day']); 
                                                    if ($group['meeting_time']) {
                                                        echo ' at ' . date('g:i A', strtotime($group['meeting_time']));
                                                    }
                                                    if ($group['location']) {
                                                        echo ' in ' . htmlspecialchars($group['location']);
                                                    }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <th>Created On:</th>
                                            <td><?php echo date('F j, Y', strtotime($group['created_at'])); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Created By:</th>
                                            <td><?php echo htmlspecialchars($group['created_by_name']); ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-md-6">
                                    <h5 class="mb-3">Group Leader</h5>
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="avatar avatar-xl bg-light rounded-circle text-primary me-3">
                                            <?php 
                                                $initials = '';
                                                $name_parts = explode(' ', $group['leader_name']);
                                                foreach ($name_parts as $part) {
                                                    $initials .= strtoupper(substr($part, 0, 1));
                                                    if (strlen($initials) >= 2) break;
                                                }
                                                echo $initials;
                                            ?>
                                        </div>
                                        <div>
                                            <h6 class="mb-1"><?php echo htmlspecialchars($group['leader_name']); ?></h6>
                                            <?php if ($group['leader_email']): ?>
                                                <a href="mailto:<?php echo htmlspecialchars($group['leader_email']); ?>" class="text-muted small">
                                                    <i class="fas fa-envelope me-1"></i> <?php echo htmlspecialchars($group['leader_email']); ?>
                                                </a><br>
                                            <?php endif; ?>
                                            <?php if ($group['leader_phone']): ?>
                                                <a href="tel:<?php echo preg_replace('/[^0-9+]/', '', $group['leader_phone']); ?>" class="text-muted small">
                                                    <i class="fas fa-phone me-1"></i> <?php echo htmlspecialchars($group['leader_phone']); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <a href="mailto:<?php echo htmlspecialchars($group['leader_email']); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-envelope me-1"></i> Send Message
                                    </a>
                                </div>
                            </div>
                            
                            <?php if (!empty($group['description'])): ?>
                                <div class="mt-4">
                                    <h5>Description</h5>
                                    <div class="p-3 bg-light rounded">
                                        <?php echo nl2br(htmlspecialchars($group['description'])); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Members Tab -->
                        <div class="tab-pane fade" id="members" role="tabpanel" aria-labelledby="members-tab">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0">Group Members</h5>
                                <a href="members.php?group_id=<?php echo $group['id']; ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-user-plus me-1"></i> Add Members
                                </a>
                            </div>
                            
                            <?php if (!empty($members)): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Contact</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($members as $member): ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar avatar-sm bg-light rounded-circle me-2">
                                                                <?php 
                                                                    $initials = '';
                                                                    $name_parts = explode(' ', $member['name']);
                                                                    foreach ($name_parts as $part) {
                                                                        $initials .= strtoupper(substr($part, 0, 1));
                                                                        if (strlen($initials) >= 2) break;
                                                                    }
                                                                    echo $initials;
                                                                ?>
                                                            </div>
                                                            <div>
                                                                <div class="fw-bold"><?php echo htmlspecialchars($member['name']); ?></div>
                                                                <small class="text-muted">
                                                                    <?php echo $member['is_leader'] ? 'Leader' : 'Member'; ?>
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php if ($member['email']): ?>
                                                            <div class="small text-muted">
                                                                <i class="fas fa-envelope me-1"></i> <?php echo htmlspecialchars($member['email']); ?>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if ($member['phone']): ?>
                                                            <div class="small text-muted">
                                                                <i class="fas fa-phone me-1"></i> <?php echo htmlspecialchars($member['phone']); ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?php 
                                                            echo $member['status'] === 'active' ? 'success' : 
                                                                ($member['status'] === 'pending' ? 'warning' : 'secondary'); 
                                                        ?>">
                                                            <?php echo ucfirst($member['status']); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="memberActions" data-bs-toggle="dropdown" aria-expanded="false">
                                                                <i class="fas fa-ellipsis-v"></i>
                                                            </button>
                                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="memberActions">
                                                                <li>
                                                                    <a class="dropdown-item" href="../members/view.php?id=<?php echo $member['id']; ?>">
                                                                        <i class="fas fa-eye me-2"></i>View Profile
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#removeMember<?php echo $member['id']; ?>">
                                                                        <i class="fas fa-user-minus me-2"></i>Remove from Group
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        
                                                        <!-- Remove Member Modal -->
                                                        <div class="modal fade" id="removeMember<?php echo $member['id']; ?>" tabindex="-1" aria-hidden="true">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title">Remove Member</h5>
                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <p>Are you sure you want to remove <strong><?php echo htmlspecialchars($member['name']); ?></strong> from this group?</p>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                                        <a href="members.php?action=remove&group_id=<?php echo $group_id; ?>&user_id=<?php echo $member['id']; ?>" class="btn btn-danger">
                                                                            <i class="fas fa-user-minus me-1"></i> Remove Member
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-5">
                                    <i class="fas fa-users fa-4x text-muted mb-3"></i>
                                    <h5>No Members Found</h5>
                                    <p class="text-muted">This group doesn't have any members yet.</p>
                                    <a href="members.php?group_id=<?php echo $group['id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-user-plus me-2"></i> Add Members
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Meetings Tab -->
                        <div class="tab-pane fade" id="meetings" role="tabpanel" aria-labelledby="meetings-tab">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0">Group Meetings</h5>
                                <a href="meeting.php?action=create&group_id=<?php echo $group['id']; ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-plus me-1"></i> Schedule Meeting
                                </a>
                            </div>
                            
                            <?php if (!empty($upcoming_meetings)): ?>
                                <div class="list-group">
                                    <?php foreach ($upcoming_meetings as $meeting): ?>
                                        <a href="meeting.php?id=<?php echo $meeting['id']; ?>" class="list-group-item list-group-item-action">
                                            <div class="d-flex w-100 justify-content-between">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($meeting['title']); ?></h6>
                                                <small class="text-muted">
                                                    <?php 
                                                        echo date('M j, Y', strtotime($meeting['meeting_date']));
                                                        if (!empty($meeting['start_time'])) {
                                                            echo ' at ' . date('g:i A', strtotime($meeting['start_time']));
                                                        }
                                                    ?>
                                                </small>
                                            </div>
                                            <?php if (!empty($meeting['location'])): ?>
                                                <div class="text-muted small">
                                                    <i class="fas fa-map-marker-alt me-1"></i> <?php echo htmlspecialchars($meeting['location']); ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($meeting['description'])): ?>
                                                <p class="mb-0 mt-2">
                                                    <?php 
                                                        $desc = $meeting['description'];
                                                        echo strlen($desc) > 150 ? substr($desc, 0, 150) . '...' : $desc;
                                                    ?>
                                                </p>
                                            <?php endif; ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div class="mt-3 text-center">
                                    <a href="meetings.php?group_id=<?php echo $group['id']; ?>" class="btn btn-outline-primary btn-sm">
                                        View All Meetings <i class="fas fa-arrow-right ms-1"></i>
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-5">
                                    <i class="far fa-calendar-alt fa-4x text-muted mb-3"></i>
                                    <h5>No Upcoming Meetings</h5>
                                    <p class="text-muted">This group doesn't have any scheduled meetings yet.</p>
                                    <a href="meeting.php?action=create&group_id=<?php echo $group['id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i> Schedule Meeting
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activities -->
            <div class="card">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Activities</h5>
                    <a href="activities.php?group_id=<?php echo $group['id']; ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <?php if (!empty($recent_activities)): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($recent_activities as $activity): ?>
                                <div class="list-group-item border-0">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <div class="avatar avatar-sm bg-light rounded-circle text-primary d-flex align-items-center justify-content-center">
                                                <i class="fas <?php echo $activity['icon'] ?? 'fa-bell'; ?>"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <div class="d-flex justify-content-between">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($activity['title'] ?? 'Activity'); ?></h6>
                                                <small class="text-muted">
                                                    <?php echo date('M j, Y g:i A', strtotime($activity['created_at'] ?? 'now')); ?>
                                                </small>
                                            </div>
                                            <p class="mb-0 text-muted">
                                                <?php echo htmlspecialchars($activity['description'] ?? ''); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-history fa-3x text-muted mb-3"></i>
                            <p class="text-muted">No recent activities found</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Right Column -->
        <div class="col-lg-4">
            <!-- Group Leader -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Group Leader</h5>
                </div>
                <div class="card-body text-center">
                    <div class="avatar avatar-xxl bg-light rounded-circle text-primary d-flex align-items-center justify-content-center mx-auto mb-3">
                        <?php 
                            $initials = '';
                            $name_parts = explode(' ', $group['leader_name']);
                            foreach ($name_parts as $part) {
                                $initials .= strtoupper(substr($part, 0, 1));
                                if (strlen($initials) >= 2) break;
                            }
                            echo $initials;
                        ?>
                    </div>
                    <h5 class="mb-1"><?php echo htmlspecialchars($group['leader_name']); ?></h5>
                    <p class="text-muted mb-3">Group Leader</p>
                    
                    <div class="d-flex justify-content-center gap-2 mb-3">
                        <?php if ($group['leader_email']): ?>
                            <a href="mailto:<?php echo htmlspecialchars($group['leader_email']); ?>" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-envelope"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($group['leader_phone']): ?>
                            <a href="tel:<?php echo preg_replace('/[^0-9+]/', '', $group['leader_phone']); ?>" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-phone"></i>
                            </a>
                        <?php endif; ?>
                        
                        <a href="#" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-comment-dots"></i>
                        </a>
                    </div>
                    
                    <div class="d-grid">
                        <a href="../members/view.php?id=<?php echo $group['leader_id']; ?>" class="btn btn-outline-primary">
                            <i class="fas fa-user me-2"></i> View Profile
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Group Stats -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Group Stats</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="mb-0">Total Members</h6>
                            <small class="text-muted">Active members in this group</small>
                        </div>
                        <div class="display-6 fw-bold"><?php echo count($members); ?></div>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="mb-0">Upcoming Events</h6>
                            <small class="text-muted">Scheduled meetings</small>
                        </div>
                        <div class="display-6 fw-bold"><?php echo count($upcoming_meetings); ?></div>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Active Since</h6>
                            <small class="text-muted">Group creation date</small>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold"><?php echo date('M j, Y', strtotime($group['created_at'])); ?></div>
                            <small class="text-muted"><?php echo floor((time() - strtotime($group['created_at'])) / (60 * 60 * 24)); ?> days ago</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="meeting.php?action=create&group_id=<?php echo $group['id']; ?>" class="btn btn-primary mb-2">
                            <i class="fas fa-plus-circle me-2"></i> Schedule Meeting
                        </a>
                        <a href="members.php?group_id=<?php echo $group['id']; ?>" class="btn btn-outline-primary mb-2">
                            <i class="fas fa-user-plus me-2"></i> Add Members
                        </a>
                        <a href="#" class="btn btn-outline-primary mb-2" data-bs-toggle="modal" data-bs-target="#sendMessageModal">
                            <i class="fas fa-paper-plane me-2"></i> Send Message
                        </a>
                        <a href="edit.php?id=<?php echo $group['id']; ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-cog me-2"></i> Group Settings
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Group Modal -->
<div class="modal fade" id="deleteGroup" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Group</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the group "<strong><?php echo htmlspecialchars($group['name']); ?></strong>"? This action cannot be undone.</p>
                <div class="alert alert-warning mb-0">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    This will permanently delete the group and all associated data including meetings and member records.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <a href="delete.php?id=<?php echo $group['id']; ?>" class="btn btn-danger">
                    <i class="fas fa-trash-alt me-2"></i> Delete Group
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Send Message Modal -->
<div class="modal fade" id="sendMessageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Send Message to Group</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="send_message.php" method="post">
                <input type="hidden" name="group_id" value="<?php echo $group['id']; ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="messageSubject" class="form-label">Subject</label>
                        <input type="text" class="form-control" id="messageSubject" name="subject" required>
                    </div>
                    <div class="mb-3">
                        <label for="messageContent" class="form-label">Message</label>
                        <textarea class="form-control" id="messageContent" name="message" rows="5" required></textarea>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="sendEmail" name="send_email" checked>
                        <label class="form-check-label" for="sendEmail">
                            Send as email to all members
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="sendSMS" name="send_sms">
                        <label class="form-check-label" for="sendSMS">
                            Send as SMS to members with phone numbers
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-2"></i> Send Message
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize tabs if they exist
    var tabElms = document.querySelectorAll('button[data-bs-toggle="tab"]');
    tabElms.forEach(function(tabEl) {
        tabEl.addEventListener('click', function (event) {
            event.preventDefault();
            var tab = new bootstrap.Tab(tabEl);
            tab.show();
        });
    });
    
    // Handle form submissions with confirmation
    var deleteForms = document.querySelectorAll('.delete-form');
    deleteForms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });
});
</script>

<?php include '../includes/footer.php'; ?>
