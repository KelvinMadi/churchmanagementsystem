<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/header.php';

// Check if user is logged in
if (!is_logged_in()) {
    header('Location: ../login.php');
    exit();
}

$page_title = 'Create New Group';
$errors = [];
$success = false;

// Get all users for group leader selection
$users = [];
$result = $conn->query("SELECT id, name, email FROM users WHERE is_active = 1 ORDER BY name");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $meeting_day = trim($_POST['meeting_day'] ?? '');
    $meeting_time = trim($_POST['meeting_time'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $leader_id = (int)($_POST['leader_id'] ?? 0);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    // Validate required fields
    if (empty($name)) {
        $errors[] = 'Group name is required';
    }
    
    if (empty($leader_id)) {
        $errors[] = 'Please select a group leader';
    }
    
    // If no errors, save to database
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO groups (name, description, meeting_day, meeting_time, location, leader_id, is_active, created_by) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $created_by = $_SESSION['user_id'];
        $stmt->bind_param('sssssiii', $name, $description, $meeting_day, $meeting_time, $location, $leader_id, $is_active, $created_by);
        
        if ($stmt->execute()) {
            $group_id = $stmt->insert_id;
            $success = true;
            
            // Log activity
            $activity = [
                'user_id' => $_SESSION['user_id'],
                'action' => 'created',
                'entity_type' => 'group',
                'entity_id' => $group_id,
                'description' => "Created group: $name"
            ];
            log_activity($activity);
            
            // Redirect to view page on success
            header("Location: view.php?id=$group_id&created=1");
            exit();
        } else {
            $errors[] = 'Error creating group: ' . $conn->error;
        }
    }
}
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Create New Group</h1>
        <a href="index.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i> Back to Groups
        </a>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <h6 class="alert-heading">Please fix the following errors:</h6>
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="post" action="" id="groupForm">
                <div class="row">
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label for="name" class="form-label">Group Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" required 
                                   value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?php 
                                echo htmlspecialchars($_POST['description'] ?? ''); 
                            ?></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="meeting_day" class="form-label">Meeting Day</label>
                                    <select class="form-select" id="meeting_day" name="meeting_day">
                                        <option value="">Select day...</option>
                                        <option value="Sunday" <?php echo (isset($_POST['meeting_day']) && $_POST['meeting_day'] === 'Sunday') ? 'selected' : ''; ?>>Sunday</option>
                                        <option value="Monday" <?php echo (isset($_POST['meeting_day']) && $_POST['meeting_day'] === 'Monday') ? 'selected' : ''; ?>>Monday</option>
                                        <option value="Tuesday" <?php echo (isset($_POST['meeting_day']) && $_POST['meeting_day'] === 'Tuesday') ? 'selected' : ''; ?>>Tuesday</option>
                                        <option value="Wednesday" <?php echo (isset($_POST['meeting_day']) && $_POST['meeting_day'] === 'Wednesday') ? 'selected' : ''; ?>>Wednesday</option>
                                        <option value="Thursday" <?php echo (isset($_POST['meeting_day']) && $_POST['meeting_day'] === 'Thursday') ? 'selected' : ''; ?>>Thursday</option>
                                        <option value="Friday" <?php echo (isset($_POST['meeting_day']) && $_POST['meeting_day'] === 'Friday') ? 'selected' : ''; ?>>Friday</option>
                                        <option value="Saturday" <?php echo (isset($_POST['meeting_day']) && $_POST['meeting_day'] === 'Saturday') ? 'selected' : ''; ?>>Saturday</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="meeting_time" class="form-label">Meeting Time</label>
                                    <input type="time" class="form-control" id="meeting_time" name="meeting_time" 
                                           value="<?php echo htmlspecialchars($_POST['meeting_time'] ?? ''); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="location" class="form-label">Location</label>
                            <input type="text" class="form-control" id="location" name="location" 
                                   value="<?php echo htmlspecialchars($_POST['location'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="card-title">Group Settings</h6>
                                
                                <div class="mb-3">
                                    <label for="leader_id" class="form-label">Group Leader <span class="text-danger">*</span></label>
                                    <select class="form-select" id="leader_id" name="leader_id" required>
                                        <option value="">Select leader...</option>
                                        <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user['id']; ?>" 
                                                <?php echo (isset($_POST['leader_id']) && $_POST['leader_id'] == $user['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($user['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" 
                                           <?php echo !isset($_POST['is_active']) || !empty($_POST['is_active']) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="is_active">Active Group</label>
                                </div>
                                
                                <hr>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i> Create Group
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize form validation
    const form = document.getElementById('groupForm');
    
    form.addEventListener('submit', function(event) {
        let valid = true;
        
        // Reset error states
        document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
        
        // Validate required fields
        const requiredFields = form.querySelectorAll('[required]');
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.classList.add('is-invalid');
                valid = false;
            }
        });
        
        if (!valid) {
            event.preventDefault();
            event.stopPropagation();
            
            // Scroll to first error
            const firstInvalid = form.querySelector('.is-invalid');
            if (firstInvalid) {
                firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>
