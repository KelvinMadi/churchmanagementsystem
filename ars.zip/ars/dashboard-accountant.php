<!-- Remove this section -->
<div class="profile-image-section">
    <img src="images/accountant-profile.jpg" alt="Accountant Profile" class="profile-image">
</div>