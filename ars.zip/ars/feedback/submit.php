<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['member', 'admin', 'accountant', 'leader']);
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
    $subject = trim($_POST['subject']);
    $feedback_content = trim($_POST['feedback_content']);
    $category = $_POST['category'];
    $is_anonymous = isset($_POST['is_anonymous']) ? 1 : 0;
    
    if ($subject && $feedback_content && $category) {
        // Sanitize input
        $subject = htmlspecialchars($subject);
        $feedback_content = htmlspecialchars($feedback_content);
        
        $feedback_data = [
            'id' => time() . rand(100, 999), // More unique ID
            'subject' => $subject,
            'content' => $feedback_content,
            'category' => $category,
            'from_user_id' => $user['id'],
            'from_user_name' => $is_anonymous ? 'Anonymous' : $user['name'],
            'from_user_role' => $user['role'],
            'is_anonymous' => $is_anonymous,
            'status' => 'unread',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        if ($conn->saveFeedback($feedback_data)) {
            $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Feedback submitted successfully! The pastor will review it soon.</div>';
            // Clear form data after successful submission
            $_POST = [];
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error submitting feedback. Please try again.</div>';
        }
    } else {
        $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
    }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Feedback - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user['name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../dashboard/<?php echo $user['role']; ?>.php">Dashboard</a></li>
                            <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="form-card">
                    <div class="upload-header text-center p-4">
                        <i class="fas fa-comments fa-3x mb-3"></i>
                        <h3>Submit Feedback</h3>
                        <p class="mb-0">Share your thoughts, suggestions, or concerns with the pastor</p>
                    </div>
                    <div class="card-body p-4">
                        <?php echo $message; ?>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-tag me-2"></i>Category *</label>
                                <select name="category" class="form-select" required>
                                    <option value="">Select Category</option>
                                    <option value="service">Church Service</option>
                                    <option value="ministry">Ministry Programs</option>
                                    <option value="leadership">Leadership</option>
                                    <option value="facility">Church Facility</option>
                                    <option value="community">Community Outreach</option>
                                    <option value="suggestion">General Suggestion</option>
                                    <option value="concern">Concern/Issue</option>
                                    <option value="appreciation">Appreciation</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-heading me-2"></i>Subject *</label>
                                <input type="text" name="subject" class="form-control" required placeholder="Brief subject line...">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-comment-alt me-2"></i>Feedback *</label>
                                <textarea name="feedback_content" class="form-control" rows="6" required placeholder="Please share your detailed feedback..."></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_anonymous" id="is_anonymous">
                                    <label class="form-check-label" for="is_anonymous">
                                        <i class="fas fa-user-secret me-1"></i>Submit anonymously
                                    </label>
                                    <small class="form-text text-muted d-block">Your identity will be hidden from the pastor</small>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="../dashboard/<?php echo $user['role']; ?>.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Feedback
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
