<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

$page_title = "";
$show_page_header = false;
$base_path = '';

include 'includes/header.php';
?>

<style>
    /* Ensure nav is white on about page */
    .navbar {
        background-color: #ffffff !important;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Ensure nav links are visible on white background */
    .navbar .nav-link {
        color: #2c3e50 !important;
    }
    
    .navbar .nav-link:hover {
        color: #e67e22 !important;
    }
    
    /* Active link styling */
    .navbar .nav-link.active {
        color: #e67e22 !important;
        font-weight: 600;
    }
</style>

<!-- Hero Section -->
<section class="about-hero text-white position-relative" style="padding-top: 100px;">
    <div class="container position-relative z-1 animate-fade-in">
        <div class="row justify-content-center text-center py-5">
            <div class="col-lg-9">
                <h1 class="display-4 fw-bold mb-3 animate-slide-up">Our Story &amp; Mission</h1>
                <p class="lead mb-4 animate-slide-up delay-100">Building a community of faith, hope, and love in the heart of our city.</p>
                <div class="divider about-divider mx-auto animate-scale-in delay-200"></div>
            </div>
        </div>
    </div>
    <!-- Decorative wave -->
    <div class="about-hero-wave"></div>
</section>

<!-- Our Story Section -->
<section class="py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0 animate-scale-in">
                <img src="images/founder.jpg" alt="Church Building" class="img-fluid rounded-3 shadow">
            </div>
            <div class="col-lg-6 ps-lg-5 animate-slide-up">
                <h2 class="h1 fw-bold mb-4">Our Humble Beginnings</h2>
                <p class="lead text-dark mb-0">Founded in 1985, our church began as a small gathering of believers in a local home. What started as a Bible study group of just 12 people has grown into a vibrant community of faith.</p>
                <p>Through the years, we've remained committed to spreading the Gospel and serving our community. Our journey has been marked by God's faithfulness and the dedication of our members who have worked tirelessly to create a welcoming place of worship.</p>
                <div class="d-flex align-items-center mt-4 animate-fade-in delay-200">
                    <div class="me-4">
                        <div class="display-4 fw-bold text-primary">35+</div>
                        <div>Years of Service</div>
                    </div>
                    <div class="vr mx-3"></div>
                    <div>
                        <div class="display-4 fw-bold text-primary">50+</div>
                        <div>Ministries</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-5">
            <div class="col-md-6 animate-slide-up">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 p-lg-5">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 70px; height: 70px;">
                            <i class="fas fa-cross fa-2x"></i>
                        </div>
                        <h3 class="h2 fw-bold mb-3">Our Mission</h3>
                        <p class="mb-0">To lead people into a growing relationship with Jesus Christ through authentic worship, biblical teaching, and compassionate service to our community and beyond.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 animate-slide-up delay-100">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 p-lg-5">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 70px; height: 70px;">
                            <i class="fas fa-eye fa-2x"></i>
                        </div>
                        <h3 class="h2 fw-bold mb-3">Our Vision</h3>
                        <p class="mb-0">To be a beacon of hope in our city, transforming lives through the power of the Gospel, and equipping believers to impact their world for Christ.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Core Values -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5 animate-fade-in">
            <h2 class="display-5 fw-bold">Our Core Values</h2>
            <div class="divider bg-primary mx-auto values-divider"></div>
            <p class="lead text-muted">Guiding principles that shape our community</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4 animate-slide-up">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 text-center">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-bible fa-lg"></i>
                        </div>
                        <h4 class="h5 fw-bold">Biblical Truth</h4>
                        <p class="mb-0">We are committed to the authority of Scripture as our foundation for faith and practice.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 animate-slide-up delay-100">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 text-center">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-hands-praying fa-lg"></i>
                        </div>
                        <h4 class="h5 fw-bold">Prayer</h4>
                        <p class="mb-0">We believe in the power of prayer and seek God's guidance in all we do.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 animate-slide-up delay-200">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 text-center">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-heart fa-lg"></i>
                        </div>
                        <h4 class="h5 fw-bold">Community</h4>
                        <p class="mb-0">We value authentic relationships and doing life together in Christ.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 animate-slide-up">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 text-center">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-hands-helping fa-lg"></i>
                        </div>
                        <h4 class="h5 fw-bold">Service</h4>
                        <p class="mb-0">We're called to serve others with the love of Christ, both locally and globally.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 animate-slide-up delay-100">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 text-center">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-gift fa-lg"></i>
                        </div>
                        <h4 class="h5 fw-bold">Generosity</h4>
                        <p class="mb-0">We give freely of our time, talents, and resources to advance God's kingdom.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 animate-slide-up delay-200">
                <div class="card border-0 h-100 shadow-sm hover-lift">
                    <div class="card-body p-4 text-center">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-people-group fa-lg"></i>
                        </div>
                        <h4 class="h5 fw-bold">Inclusivity</h4>
                        <p class="mb-0">All are welcome here, regardless of background, ethnicity, or past experiences.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Leadership Team -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5 animate-fade-in">
            <h2 class="display-5 fw-bold">Our Leadership</h2>
            <div class="divider bg-primary mx-auto"></div>
            <p class="lead text-muted">Meet our dedicated pastoral team</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4 animate-slide-up">
                <div class="card border-0 h-100 shadow-sm overflow-hidden hover-lift">
                    <img src="images/founder.jpg" class="card-img-top" alt="Senior Pastor">
                    <div class="card-body p-4 text-center">
                        <h4 class="h5 fw-bold mb-1">Rev. Michael Johnson</h4>
                        <p class="text-muted mb-3">Senior Pastor</p>
                        <p class="small">With over 25 years of ministry experience, Pastor Michael leads our congregation with wisdom and compassion.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 animate-slide-up delay-100">
                <div class="card border-0 h-100 shadow-sm overflow-hidden hover-lift">
                    <img src="images/image1.jpg" class="card-img-top" alt="Associate Pastor">
                    <div class="card-body p-4 text-center">
                        <h4 class="h5 fw-bold mb-1">Pastor Sarah Williams</h4>
                        <p class="text-muted mb-3">Associate Pastor</p>
                        <p class="small">Pastor Sarah oversees our community outreach programs and discipleship ministries.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 animate-slide-up delay-200">
                <div class="card border-0 h-100 shadow-sm overflow-hidden hover-lift">
                    <img src="images/team/worship.jpg" class="card-img-top" alt="Worship Pastor">
                    <div class="card-body p-4 text-center">
                        <h4 class="h5 fw-bold mb-1">David Thompson</h4>
                        <p class="text-muted mb-3">Worship Pastor</p>
                        <p class="small">David leads our worship ministry, creating an atmosphere where people can encounter God.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Events CTA Section -->
<section class="py-5 bg-light text-center">
    <div class="container">
        <h2 class="h1 fw-bold mb-4">Join Our Upcoming Events</h2>
        <p class="lead text-muted mb-4">Experience fellowship, worship, and spiritual growth with our church family</p>
        <a href="events/list.php" class="btn btn-primary btn-lg px-5">
            <i class="far fa-calendar-alt me-2"></i> View All Events
        </a>
    </div>
</section>
<!-- Call to Action -->
<section class="py-5 bg-primary text-white text-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 animate-fade-in">
                <h2 class="display-5 fw-bold mb-4">Join Us This Sunday</h2>
                <p class="lead mb-4">Experience the warmth of our community and the power of God's Word.</p>
                <a href="service-times.php" class="btn btn-light btn-lg px-4 me-2">Service Times</a>
                <a href="contact.php" class="btn btn-outline-light btn-lg px-4">Get Directions</a>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
