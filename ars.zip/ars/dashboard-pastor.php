<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/header.php';

// Check if user is logged in and is a pastor
if (!is_logged_in() || $_SESSION['user_role'] !== 'pastor') {
    header('Location: login.php');
    exit();
}

// Get user data
$user_id = $_SESSION['user_id'];
$user = $conn->getUserById($user_id);

// Get statistics
$all_members = $conn->getAllMembers();
$total_members = is_array($all_members) ? count($all_members) : 0;
$recent_members = is_array($all_members) ? array_slice($all_members, 0, 5) : [];

// Get upcoming events
$upcoming_events_result = $conn->getUpcomingSessions();
$upcoming_events = [];
if (is_object($upcoming_events_result) && method_exists($upcoming_events_result, 'fetch_assoc')) {
    while ($row = $upcoming_events_result->fetch_assoc()) {
        $upcoming_events[] = $row;
    }
} elseif (is_array($upcoming_events_result)) {
    $upcoming_events = $upcoming_events_result;
}

// Get recent activities
$recent_activities = [];
if (method_exists($conn, 'getRecentActivities')) {
    $activities = $conn->getRecentActivities(5);
    if (is_array($activities)) {
        $recent_activities = $activities;
    }
}
?>

<div class="container-fluid py-4">
    <!-- Welcome Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-primary text-white">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h2 class="h4 mb-1">Welcome back, <?php echo htmlspecialchars($user['name'] ?? 'Pastor'); ?>!</h2>
                            <p class="mb-0">Here's what's happening with your church today.</p>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <a href="profile.php" class="btn btn-light btn-sm me-2">
                                    <i class="fas fa-user-edit me-1"></i> Edit Profile
                                </a>
                                <a href="settings.php" class="btn btn-outline-light btn-sm">
                                    <i class="fas fa-cog me-1"></i> Settings
                                </a>
                            </div>
                            <div class="avatar avatar-lg">
                                <?php 
                                    $name_parts = explode(' ', $user['name'] ?? 'P');
                                    $initials = '';
                                    foreach ($name_parts as $part) {
                                        $initials .= strtoupper(substr($part, 0, 1));
                                        if (strlen($initials) >= 2) break;
                                    }
                                ?>
                                <div class="avatar-text" style="width: 80px; height: 80px; font-size: 32px; display: flex; align-items: center; justify-content: center;">
                                    <?php echo $initials; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-3">
                    <div class="d-flex flex-wrap gap-2">
                        <a href="sermons/create.php" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i> New Sermon
                        </a>
                        <a href="events/create.php" class="btn btn-success">
                            <i class="fas fa-calendar-plus me-2"></i> Schedule Event
                        </a>
                        <a href="members/add.php" class="btn btn-info text-white">
                            <i class="fas fa-user-plus me-2"></i> Add Member
                        </a>
                        <a href="counseling/schedule.php" class="btn btn-warning">
                            <i class="fas fa-hands-praying me-2"></i> Schedule Counseling
                        </a>
                        <a href="reports/attendance.php" class="btn btn-secondary">
                            <i class="fas fa-chart-bar me-2"></i> View Reports
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Total Members</h6>
                            <h3 class="mb-0"><?php echo $total_members; ?></h3>
                            <p class="text-muted small mb-0"><span class="text-success">+5%</span> this month</p>
                        </div>
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle">
                            <i class="fas fa-users text-primary"></i>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="members.php" class="btn btn-sm btn-outline-primary">View All</a>
                        <a href="members/add.php" class="btn btn-sm btn-primary ms-2">Add New</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Upcoming Events</h6>
                            <h3 class="mb-0"><?php echo is_array($upcoming_events) ? count($upcoming_events) : 0; ?></h3>
                            <p class="text-muted small mb-0">Next: 
                                <?php 
                                if (!empty($upcoming_events)) {
                                    $next_event = $upcoming_events[0];
                                    echo date('M j', strtotime($next_event['date'] ?? ''));
                                } else {
                                    echo 'No events';
                                }
                                ?>
                            </p>
                        </div>
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle">
                            <i class="fas fa-calendar-alt text-success"></i>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="events.php" class="btn btn-sm btn-outline-success">View Calendar</a>
                        <a href="events/create.php" class="btn btn-sm btn-success ms-2">New Event</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Active Groups</h6>
                            <h3 class="mb-0">12</h3>
                            <p class="text-muted small mb-0">5 meeting this week</p>
                        </div>
                        <div class="bg-info bg-opacity-10 p-3 rounded-circle">
                            <i class="fas fa-users text-info"></i>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="groups.php" class="btn btn-sm btn-outline-info">View Groups</a>
                        <a href="groups/create.php" class="btn btn-sm btn-info text-white ms-2">New Group</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Giving This Month</h6>
                            <h3 class="mb-0">$12,450</h3>
                            <p class="text-muted small mb-0"><span class="text-success">+8%</span> from last month</p>
                        </div>
                        <div class="bg-warning bg-opacity-10 p-3 rounded-circle">
                            <i class="fas fa-hand-holding-heart text-warning"></i>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="giving.php" class="btn btn-sm btn-outline-warning">View Report</a>
                        <a href="giving/add.php" class="btn btn-sm btn-warning ms-2">Record Gift</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="row">
        <!-- Left Column -->
        <div class="col-lg-8 mb-4">
            <!-- Quick Stats -->
            <div class="row mb-4">
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Attendance Overview</h5>
                        </div>
                        <div class="card-body">
                            <div id="attendanceChart" style="height: 200px;">
                                <!-- Chart will be rendered here by JavaScript -->
                                <div class="text-center py-4">
                                    <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Attendance chart will be displayed here</p>
                                </div>
                            </div>
                            <div class="mt-3 text-center">
                                <a href="reports/attendance.php" class="btn btn-sm btn-outline-primary">View Full Report</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Giving Summary</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-3">
                                <div>
                                    <h6 class="text-muted mb-1">This Month</h6>
                                    <h4 class="mb-0">$12,450</h4>
                                </div>
                                <div class="text-end">
                                    <h6 class="text-muted mb-1">Last Month</h6>
                                    <h4 class="mb-0">$11,520</h4>
                                </div>
                            </div>
                            <div class="progress mb-3" style="height: 8px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="d-flex justify-content-between mb-3">
                                <div>
                                    <h6 class="text-muted mb-1">Tithes</h6>
                                    <h5 class="mb-0">$8,150</h5>
                                </div>
                                <div class="text-end">
                                    <h6 class="text-muted mb-1">Offerings</h6>
                                    <h5 class="mb-0">$3,200</h5>
                                </div>
                                <div class="text-end">
                                    <h6 class="text-muted mb-1">Other</h6>
                                    <h5 class="mb-0">$1,100</h5>
                                </div>
                            </div>
                            <div class="mt-3 text-center">
                                <a href="reports/giving.php" class="btn btn-sm btn-outline-primary me-2">View Details</a>
                                <a href="giving/add.php" class="btn btn-sm btn-primary">Record Gift</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activities -->
            <div class="card mb-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Activities</h5>
                    <a href="activity-log.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php if (!empty($recent_activities)): ?>
                            <?php foreach ($recent_activities as $activity): ?>
                                <div class="list-group-item border-0">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <div class="avatar avatar-sm bg-light rounded-circle text-primary d-flex align-items-center justify-content-center">
                                                <i class="fas <?php echo $activity['icon'] ?? 'fa-bell'; ?>"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <div class="d-flex justify-content-between">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($activity['title'] ?? 'Activity'); ?></h6>
                                                <small class="text-muted"><?php echo $activity['time'] ?? ''; ?></small>
                                            </div>
                                            <p class="mb-0 text-muted small"><?php echo htmlspecialchars($activity['description'] ?? ''); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-history fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No recent activities found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column -->
        <div class="col-lg-4 mb-4">
            <!-- Upcoming Events -->
            <div class="card mb-4">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Upcoming Events</h5>
                    <div>
                        <a href="events.php" class="btn btn-sm btn-outline-primary">View All</a>
                        <a href="events/create.php" class="btn btn-sm btn-primary ms-1">+</a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php if (!empty($upcoming_events)): ?>
                            <?php foreach (array_slice($upcoming_events, 0, 5) as $event): ?>
                                <a href="events/view.php?id=<?php echo $event['id'] ?? ''; ?>" class="list-group-item list-group-item-action border-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0 bg-primary bg-opacity-10 p-2 rounded-3">
                                            <div class="text-center">
                                                <div class="text-uppercase text-primary fw-bold" style="font-size: 0.7rem;">
                                                    <?php echo date('M', strtotime($event['scheduled_date'] ?? '')); ?>
                                                </div>
                                                <div class="h5 mb-0">
                                                    <?php echo date('j', strtotime($event['scheduled_date'] ?? '')); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($event['title'] ?? 'Untitled Event'); ?></h6>
                                            <small class="text-muted">
                                                <i class="far fa-clock me-1"></i>
                                                <?php 
                                                    $time = $event['scheduled_time'] ?? '';
                                                    echo date('g:i A', strtotime($time));
                                                ?>
                                            </small>
                                        </div>
                                        <div class="text-end">
                                            <span class="badge bg-primary">
                                                <?php echo $event['type'] ?? 'Event'; ?>
                                            </span>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="far fa-calendar-alt fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No upcoming events</p>
                                <a href="events/create.php" class="btn btn-primary btn-sm">Create Event</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Members -->
            <div class="card">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Members</h5>
                    <div>
                        <a href="members.php" class="btn btn-sm btn-outline-primary">View All</a>
                        <a href="members/add.php" class="btn btn-sm btn-primary ms-1">+</a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php if (!empty($recent_members)): ?>
                            <?php foreach ($recent_members as $member): ?>
                                <a href="members/view.php?id=<?php echo $member['id'] ?? ''; ?>" class="list-group-item list-group-item-action border-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="avatar avatar-md bg-light rounded-circle text-primary d-flex align-items-center justify-content-center">
                                                <?php echo strtoupper(substr($member['name'] ?? 'U', 0, 1)); ?>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-0"><?php echo htmlspecialchars($member['name'] ?? 'Unknown'); ?></h6>
                                            <small class="text-muted">
                                                <?php 
                                                    $join_date = $member['join_date'] ?? '';
                                                    if ($join_date) {
                                                        echo 'Joined ' . date('M j, Y', strtotime($join_date));
                                                    } else {
                                                        echo 'Member';
                                                    }
                                                ?>
                                            </small>
                                        </div>
                                        <div class="text-end">
                                            <span class="badge bg-light text-dark">New</span>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No recent members</p>
                                <a href="members/add.php" class="btn btn-primary btn-sm">Add Member</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    :root {
        --primary: #4e73df;
        --secondary: #858796;
        --success: #1cc88a;
        --info: #36b9cc;
        --warning: #f6c23e;
        --danger: #e74a3b;
        --light: #f8f9fc;
        --dark: #5a5c69;
    }

    body {
        background-color: #f8f9fc;
    }

    .card {
        border: none;
        border-radius: 0.35rem;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        transition: all 0.2s ease-in-out;
        margin-bottom: 1.5rem;
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 0.5rem 1.5rem 0.5rem rgba(58, 59, 69, 0.15);
    }

    .card-header {
        background-color: #f8f9fc;
        border-bottom: 1px solid #e3e6f0;
        padding: 1rem 1.35rem;
        font-weight: 600;
    }

    .card-body {
        padding: 1.35rem;
    }
    
    .avatar {
        width: 2.5rem;
        height: 2.5rem;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        border-radius: 50%;
        color: #fff;
        background-color: var(--primary);
    }

    .avatar.avatar-sm {
        width: 2rem;
        height: 2rem;
        font-size: 0.8rem;
    }
    
    .profile-image-container {
        width: 5rem;
        height: 5rem;
        border-radius: 50%;
        overflow: hidden;
        border: 0.25rem solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.3);
    }
    
    .profile-image-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .list-group-item {
        padding: 1rem 1.35rem;
        border-left: none;
        border-right: none;
        border-color: #e3e6f0;
        transition: all 0.2s ease-in-out;
    }

    .list-group-item:hover {
        background-color: #f8f9fc;
    }
    
    .list-group-item:first-child {
        border-top: none;
    }
    
    .list-group-item:last-child {
        border-bottom: none;
    }

    .btn {
        border-radius: 0.35rem;
        font-weight: 500;
        padding: 0.5rem 1rem;
        font-size: 0.85rem;
        transition: all 0.2s ease-in-out;
    }

    .btn-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.75rem;
    }

    .btn-primary {
        background-color: var(--primary);
        border-color: var(--primary);
    }

    .btn-primary:hover {
        background-color: #2e59d9;
        border-color: #2653d4;
    }

    .badge {
        font-weight: 500;
        padding: 0.35em 0.65em;
        border-radius: 0.25rem;
    }

    .text-primary {
        color: var(--primary) !important;
    }

    .bg-primary {
        background-color: var(--primary) !important;
    }

    .border-left-primary {
        border-left: 0.25rem solid var(--primary) !important;
    }

    .progress {
        height: 1rem;
        border-radius: 0.35rem;
    }

    .progress-sm {
        height: 0.5rem;
    }

    .text-xs {
        font-size: 0.7rem;
    }

    /* Custom scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb {
        background: #c1c1c1;
        border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: #a8a8a8;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .card {
            margin-bottom: 1rem;
        }
        
        .profile-image-container {
            width: 4rem;
            height: 4rem;
        }
    }
</style>

<script>
    // Initialize tooltips
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Initialize charts (example with Chart.js)
        if (typeof Chart !== 'undefined') {
            // Attendance Chart
            var ctx = document.getElementById('attendanceChart');
            if (ctx) {
                new Chart(ctx.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                        datasets: [{
                            label: 'Weekly Average',
                            data: [65, 59, 80, 81, 56, 72],
                            borderColor: '#4e73df',
                            backgroundColor: 'rgba(78, 115, 223, 0.05)',
                            tension: 0.3,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    display: true,
                                    drawOnChartArea: true,
                                    drawTicks: false,
                                    color: 'rgba(0, 0, 0, 0.05)'
                                },
                                ticks: {
                                    maxTicksLimit: 5
                                }
                            },
                            x: {
                                grid: {
                                    display: false,
                                    drawOnChartArea: false,
                                    drawTicks: false
                                }
                            }
                        },
                        elements: {
                            point: {
                                radius: 3,
                                hoverRadius: 5,
                                hoverBackgroundColor: '#4e73df',
                                backgroundColor: '#4e73df',
                                borderWidth: 2
                            }
                        }
                    }
                });
            }
        }
    });
</script>

<?php include 'includes/footer.php'; ?>