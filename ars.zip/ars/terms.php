<?php
require_once 'includes/db.php';
$page_title = 'Terms of Use';
$show_page_header = true;
include 'includes/header.php';
?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h2 class="h4 mb-3">Terms of Use</h2>
                    <p>By accessing this site, you agree to use it in accordance with our church values and applicable laws. Do not misuse or attempt to disrupt the application.</p>
                    <ul>
                        <li>Respect the privacy of other members</li>
                        <li>Use your own account and keep it secure</li>
                        <li>Report issues to the administrators</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>

