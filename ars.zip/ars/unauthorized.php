<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$page_title = 'Unauthorized Access';
$is_logged_in = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> - Church Management System</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
        }
        
        .error-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 2rem;
            text-align: center;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .error-icon {
            font-size: 5rem;
            color: #dc3545;
            margin-bottom: 1.5rem;
        }
        
        .error-title {
            color: #dc3545;
            font-weight: 700;
            margin-bottom: 1rem;
        }
        
        .error-message {
            color: #6c757d;
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }
        
        .btn-home {
            background-color: #0d6efd;
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-home:hover {
            background-color: #0b5ed7;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .btn-login {
            background-color: #198754;
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            margin-left: 1rem;
        }
        
        .btn-login:hover {
            background-color: #157347;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .btn-container {
            display: flex;
            justify-content: center;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        @media (max-width: 576px) {
            .error-container {
                margin: 1rem;
                padding: 1.5rem;
            }
            
            .btn-container {
                flex-direction: column;
                gap: 0.75rem;
            }
            
            .btn-login {
                margin-left: 0;
                margin-top: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-container">
            <div class="error-icon">
                <i class="fas fa-ban"></i>
            </div>
            <h1 class="error-title">Access Denied</h1>
            <p class="error-message">
                <?php 
                if ($is_logged_in) {
                    echo "You don't have permission to access this page. Please contact the administrator if you believe this is an error.";
                } else {
                    echo 'You need to be logged in to access this page. Please log in with your credentials.';
                }
                ?>
            </p>
            <div class="btn-container">
                <a href="index.php" class="btn-home">
                    <i class="fas fa-home me-2"></i> Go to Homepage
                </a>
                <?php if (!$is_logged_in): ?>
                    <a href="login.php" class="btn-login">
                        <i class="fas fa-sign-in-alt me-2"></i> Log In
                    </a>
                <?php endif; ?>
            </div>
            
            <?php if ($is_logged_in): ?>
                <div class="mt-4">
                    <p class="text-muted small">
                        Logged in as: <strong><?php echo htmlspecialchars($_SESSION['email'] ?? 'User'); ?></strong> | 
                        <a href="logout.php" class="text-danger">Logout</a>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
