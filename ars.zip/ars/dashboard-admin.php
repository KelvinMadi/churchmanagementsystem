<!-- Remove this section -->
<div class="profile-image-section">
    <img src="images/admin-profile.jpg" alt="Admin Profile" class="profile-image">
</div>