<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_login();
$user = get_user();

// Debug: Check user role and session
// echo '<pre>User data: '; print_r($user); echo '</pre>';
// echo '<pre>Session: '; print_r($_SESSION); echo '</pre>';

// Check if user has permission to view members
if (!hasPermission('members', 'view')) {
    // Debug: Uncomment to see why permission is denied
    // die('Permission denied. User role: ' . ($user['role'] ?? 'not set'));
    header('Location: unauthorized.php');
    exit();
}

$page_title = "Church Members";
$csrf_token = generate_csrf_token();

// Get search parameters
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? 'all';
$order_by = $_GET['order_by'] ?? 'name';
$order_dir = $_GET['order_dir'] ?? 'asc';

// Build query
$query = "SELECT * FROM members WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param]);
}

if ($status !== 'all') {
    $query .= " AND status = ?";
    $params[] = $status;
}

// Add ordering
$valid_columns = ['name', 'join_date', 'status'];
$order_by = in_array($order_by, $valid_columns) ? $order_by : 'name';
$order_dir = strtoupper($order_dir) === 'DESC' ? 'DESC' : 'ASC';
$query .= " ORDER BY $order_by $order_dir";

// Initialize pagination
$items_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

// Get members
$members = [];
$status_counts = [
    'all' => 0,
    'active' => 0,
    'inactive' => 0,
    'visitor' => 0
];

// For file-based database, we'll use a simpler approach
$members_file = __DIR__ . '/data/members.json';
if (file_exists($members_file)) {
    $members = json_decode(file_get_contents($members_file), true) ?: [];
    
    // Apply search filter if any
    if (!empty($search)) {
        $search = strtolower($search);
        $members = array_filter($members, function($member) use ($search) {
            return strpos(strtolower($member['name']), $search) !== false ||
                   strpos(strtolower($member['email']), $search) !== false ||
                   strpos(strtolower($member['phone']), $search) !== false;
        });
    }
    
    // Apply status filter if any
    if (!empty($status) && $status !== 'all') {
        $members = array_filter($members, function($member) use ($status) {
            return $member['status'] === $status;
        });
    }
    
    // Count statuses
    foreach ($members as $member) {
        $status_counts[$member['status']]++;
    }
    $status_counts['all'] = count($members);
    
    // Apply sorting
    usort($members, function($a, $b) use ($order_by, $order_dir) {
        $result = strcmp($a[$order_by] ?? '', $b[$order_by] ?? '');
        return $order_dir === 'DESC' ? -$result : $result;
    });
}

// Apply pagination
$total_members = count($members);
$total_pages = ceil($total_members / $items_per_page);
$members = array_slice($members, max(0, $offset), $items_per_page);

include 'includes/header.php';
?>

<div class="container-fluid py-4 mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Church Members</h1>
        <div>
            <a href="member-add.php" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i> Add New Member
            </a>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card border-left-primary h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted small mb-1">Total Members</h6>
                            <h3 class="mb-0"><?php echo $status_counts['all']; ?></h3>
                        </div>
                        <div class="icon-circle bg-primary">
                            <i class="fas fa-users text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-left-success h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted small mb-1">Active</h6>
                            <h3 class="mb-0"><?php echo $status_counts['active']; ?></h3>
                        </div>
                        <div class="icon-circle bg-success">
                            <i class="fas fa-user-check text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-left-warning h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted small mb-1">Visitors</h6>
                            <h3 class="mb-0"><?php echo $status_counts['visitor'] ?? 0; ?></h3>
                        </div>
                        <div class="icon-circle bg-warning">
                            <i class="fas fa-user-clock text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-left-info h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted small mb-1">Inactive</h6>
                            <h3 class="mb-0"><?php echo $status_counts['inactive'] ?? 0; ?></h3>
                        </div>
                        <div class="icon-circle bg-info">
                            <i class="fas fa-user-slash text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search and Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Search members..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-4">
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All Members (<?php echo $status_counts['all']; ?>)</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active (<?php echo $status_counts['active']; ?>)</option>
                        <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive (<?php echo $status_counts['inactive'] ?? 0; ?>)</option>
                        <option value="visitor" <?php echo $status === 'visitor' ? 'selected' : ''; ?>>Visitors (<?php echo $status_counts['visitor'] ?? 0; ?>)</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <a href="members.php" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-sync-alt me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Members Table -->
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'name', 'order_dir' => $order_by === 'name' && $order_dir === 'ASC' ? 'desc' : 'asc'])); ?>" class="text-decoration-none text-dark">
                                    Name 
                                    <?php if ($order_by === 'name'): ?>
                                        <i class="fas fa-sort-<?php echo $order_dir === 'ASC' ? 'up' : 'down'; ?> ms-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort ms-1 text-muted"></i>
                                    <?php endif; ?>
                                </a>
                            </th>
                            <th>Contact</th>
                            <th>Ministry</th>
                            <th>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'join_date', 'order_dir' => $order_by === 'join_date' && $order_dir === 'ASC' ? 'desc' : 'asc'])); ?>" class="text-decoration-none text-dark">
                                    Member Since
                                    <?php if ($order_by === 'join_date'): ?>
                                        <i class="fas fa-sort-<?php echo $order_dir === 'ASC' ? 'up' : 'down'; ?> ms-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort ms-1 text-muted"></i>
                                    <?php endif; ?>
                                </a>
                            </th>
                            <th>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'status', 'order_dir' => $order_by === 'status' && $order_dir === 'ASC' ? 'desc' : 'asc'])); ?>" class="text-decoration-none text-dark">
                                    Status
                                    <?php if ($order_by === 'status'): ?>
                                        <i class="fas fa-sort-<?php echo $order_dir === 'ASC' ? 'up' : 'down'; ?> ms-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort ms-1 text-muted"></i>
                                    <?php endif; ?>
                                </a>
                            </th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($members)): ?>
                            <?php foreach ($members as $member): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar me-3">
                                                <?php 
                                                    $name_parts = explode(' ', $member['name']);
                                                    $initials = strtoupper(substr($name_parts[0], 0, 1) . (isset($name_parts[1]) ? substr($name_parts[1], 0, 1) : ''));
                                                ?>
                                                <div class="avatar-text" style="width: 40px; height: 40px; background-color: #e67e22; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600;">
                                                    <?php echo $initials; ?>
                                                </div>
                                            </div>
                                            <div>
                                                <h6 class="mb-0"><?php echo htmlspecialchars($member['name']); ?></h6>
                                                <small class="text-muted">ID: <?php echo htmlspecialchars($member['id']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($member['email'])): ?>
                                            <div><i class="fas fa-envelope me-2 text-muted"></i> <?php echo htmlspecialchars($member['email']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($member['phone'])): ?>
                                            <div><i class="fas fa-phone me-2 text-muted"></i> <?php echo htmlspecialchars($member['phone']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($member['ministry'])): ?>
                                            <span class="badge bg-light text-dark"><?php echo htmlspecialchars($member['ministry']); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">Not assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $join_date = !empty($member['join_date']) ? $member['join_date'] : date('Y-m-d');
                                            try {
                                                $date = new DateTime($join_date);
                                                echo $date->format('M j, Y');
                                            } catch (Exception $e) {
                                                echo date('M j, Y');
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $status_class = [
                                                'active' => 'success',
                                                'inactive' => 'secondary',
                                                'visitor' => 'warning'
                                            ][strtolower($member['status'])] ?? 'primary';
                                        ?>
                                        <span class="badge bg-<?php echo $status_class; ?> bg-opacity-10 text-<?php echo $status_class; ?>">
                                            <?php echo ucfirst($member['status']); ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="memberActions" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="memberActions">
                                                <li><a class="dropdown-item" href="member-view.php?id=<?php echo $member['id']; ?>"><i class="fas fa-eye me-2"></i>View Profile</a></li>
                                                <li><a class="dropdown-item" href="member-edit.php?id=<?php echo $member['id']; ?>"><i class="fas fa-edit me-2"></i>Edit</a></li>
                                                <li><hr class="dropdown-divider"></li>
                                                <li><a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#deleteMemberModal" data-member-id="<?php echo $member['id']; ?>" data-member-name="<?php echo htmlspecialchars($member['name']); ?>"><i class="fas fa-trash-alt me-2"></i>Delete</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-users-slash fa-3x mb-3"></i>
                                        <h5>No members found</h5>
                                        <p class="mb-0">Try adjusting your search or filter criteria</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if (!empty($members)): ?>
                <div class="card-footer bg-white border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="text-muted small">
                            Showing <span class="fw-bold"><?php echo $offset + 1; ?>-<?php echo min($offset + count($members), $total_members); ?></span> of <span class="fw-bold"><?php echo $total_members; ?></span> members
                        </div>
                        <nav>
                            <ul class="pagination pagination-sm mb-0">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" <?php echo $page <= 1 ? 'tabindex="-1" aria-disabled="true"' : ''; ?>>Previous</a>
                                </li>
                                <?php 
                                // Show page numbers with ellipsis
                                $start_page = max(1, $page - 2);
                                $end_page = min($total_pages, $page + 2);
                                
                                if ($start_page > 1) {
                                    echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, ['page' => 1])) . '">1</a></li>';
                                    if ($start_page > 2) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                }
                                
                                for ($i = $start_page; $i <= $end_page; $i++): 
                                ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php 
                                endfor; 
                                
                                if ($end_page < $total_pages) {
                                    if ($end_page < $total_pages - 1) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                    echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, ['page' => $total_pages])) . '">' . $total_pages . '</a></li>';
                                }
                                ?>
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">Next</a>
                                </li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteMemberModal" tabindex="-1" aria-labelledby="deleteMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteMemberModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong id="memberName"></strong>? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteMemberForm" method="post" action="member-delete.php">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="member_id" id="deleteMemberId">
                    <button type="submit" class="btn btn-danger">Delete Member</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Include JavaScript for interactive elements -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Delete member modal handler
    var deleteMemberModal = document.getElementById('deleteMemberModal');
    if (deleteMemberModal) {
        deleteMemberModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var memberId = button.getAttribute('data-member-id');
            var memberName = button.getAttribute('data-member-name');
            
            var modal = this;
            modal.querySelector('#memberName').textContent = memberName;
            modal.querySelector('#deleteMemberId').value = memberId;
        });
    }
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>

<style>
.avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    color: white;
    font-size: 16px;
}

.icon-circle {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
}

.table th {
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    color: #6c757d;
    border-top: none;
    padding-top: 1rem;
    padding-bottom: 1rem;
}

.table td {
    vertical-align: middle;
    padding: 1rem;
}

.border-left-primary {
    border-left: 4px solid #4e73df !important;
}

.border-left-success {
    border-left: 4px solid #1cc88a !important;
}

.border-left-warning {
    border-left: 4px solid #f6c23e !important;
}

.border-left-info {
    border-left: 4px solid #36b9cc !important;
}

.card {
    border: none;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
    border-radius: 0.5rem;
}

.card-header {
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
    padding: 1rem 1.25rem;
}

.badge {
    font-weight: 500;
    padding: 0.35em 0.65em;
}

.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
    line-height: 1.5;
    border-radius: 0.2rem;
}

.dropdown-menu {
    font-size: 0.85rem;
    border: none;
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    border-radius: 0.35rem;
}

.dropdown-item {
    padding: 0.5rem 1rem;
}

.dropdown-item i {
    width: 20px;
    text-align: center;
    margin-right: 0.5rem;
}

.pagination .page-link {
    color: #4e73df;
    border: none;
    margin: 0 0.25rem;
    border-radius: 0.25rem !important;
}

.pagination .page-item.active .page-link {
    background-color: #4e73df;
    border-color: #4e73df;
}

.pagination .page-item.disabled .page-link {
    color: #b7b9cc;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .table-responsive {
        border: none;
    }
    
    .card-body {
        padding: 1rem;
    }
    
    .d-flex {
        flex-direction: column;
    }
    
    .pagination {
        margin-top: 1rem;
    }
}
</style>

<?php include 'includes/footer.php'; ?>
