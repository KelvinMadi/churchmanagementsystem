<?php
require_once 'includes/db.php';
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

$page_title = "Gallery";
$base_path = "";
include 'includes/header.php';

// Sample album data (in a real app, this would come from a database)
$albums = [
    [
        'id' => 1,
        'title' => 'Sunday Service',
        'cover' => 'images/image1.jpg',
        'count' => 24,
        'date' => 'October 2023',
        'category' => 'worship'
    ],
    [
        'id' => 2,
        'title' => 'Bible Study',
        'cover' => 'images/image2.jpg',
        'count' => 18,
        'date' => 'September 2023',
        'category' => 'study'
    ],
    [
        'id' => 3,
        'title' => 'Community Outreach',
        'cover' => 'images/image3.jpg',
        'count' => 32,
        'date' => 'August 2023',
        'category' => 'outreach'
    ],
    [
        'id' => 4,
        'title' => 'Youth Camp',
        'cover' => 'images/image4.jpg',
        'count' => 45,
        'date' => 'July 2023',
        'category' => 'youth'
    ],
    [
        'id' => 5,
        'title' => 'Choir Performance',
        'cover' => 'images/image1.jpg',
        'count' => 15,
        'date' => 'June 2023',
        'category' => 'worship'
    ],
    [
        'id' => 6,
        'title' => 'Mission Trip',
        'cover' => 'images/image2.jpg',
        'count' => 62,
        'date' => 'May 2023',
        'category' => 'mission'
    ]
];

$categories = [
    'all' => 'All Albums',
    'worship' => 'Worship Services',
    'study' => 'Bible Study',
    'youth' => 'Youth Ministry',
    'mission' => 'Missions',
    'outreach' => 'Community Outreach'
];
?>

<!-- Hero Header with Parallax -->
<header class="gallery-hero position-relative d-flex align-items-center" style="background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.4)), url('images/founder.jpg') center/cover no-repeat; filter: brightness(1.1);">
    <div class="container position-relative z-index-2">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center text-white">
                <h1 class="display-4 fw-bold mb-3">Church Gallery</h1>
                <p class="lead mb-4">Capturing moments of faith, fellowship, and community in Christ</p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="#gallery" class="btn btn-primary btn-lg px-4">
                        <i class="fas fa-images me-2"></i>View Gallery
                    </a>
                    <?php if (isset($user_role) && in_array($user_role, ['admin', 'pastor'])): ?>
                    <button class="btn btn-outline-light btn-lg px-4" data-bs-toggle="modal" data-bs-target="#uploadModal">
                        <i class="fas fa-upload me-2"></i>Upload Photos
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="overlay"></div>
</header>

<!-- Gallery Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm" id="galleryNav">
    <div class="container">
        <div class="collapse navbar-collapse" id="galleryNavbar">
            <ul class="navbar-nav mx-auto gallery-categories">
                <?php foreach ($categories as $key => $category): ?>
                <li class="nav-item">
                    <a class="nav-link category-filter <?php echo $key === 'all' ? 'active' : ''; ?>" 
                       href="#" data-category="<?php echo $key; ?>">
                        <?php echo $category; ?>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Main Gallery Section -->
<section class="py-5 bg-white" id="gallery">
    <div class="container">
        <div class="row g-4" id="albumGrid">
            <?php foreach ($albums as $album): ?>
            <div class="col-md-6 col-lg-4 album-item" data-category="<?php echo $album['category']; ?>">
                <div class="card album-card h-100 border-0 shadow-sm overflow-hidden">
                    <div class="position-relative overflow-hidden album-cover">
                        <img src="<?php echo $album['cover']; ?>" class="img-fluid w-100" alt="<?php echo htmlspecialchars($album['title']); ?>" style="height: 250px; object-fit: cover;">
                        <div class="album-overlay d-flex align-items-center justify-content-center">
                            <div class="text-center text-white">
                                <span class="d-block mb-2"><i class="fas fa-images fa-2x"></i></span>
                                <span class="badge bg-primary rounded-pill px-3 py-2"><?php echo $album['count']; ?> Photos</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title mb-1"><?php echo htmlspecialchars($album['title']); ?></h5>
                        <p class="text-muted small mb-2"><?php echo $album['date']; ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-light text-dark"><?php echo $categories[$album['category']]; ?></span>
                            <a href="https://www.facebook.com/share/1Akt7TssmM/?mibextid=wwXIfr" class="btn btn-sm btn-outline-primary stretched-link" target="_blank">
                                View Album <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-5" id="noResults" style="display: none;">
            <i class="fas fa-images fa-4x text-muted mb-3"></i>
            <h4>No albums found</h4>
            <p class="text-muted">Try selecting a different category</p>
        </div>
        
        <div class="text-center mt-5">
            <button class="btn btn-outline-primary px-4" id="loadMore">
                <i class="fas fa-sync-alt me-2"></i>Load More
            </button>
        </div>
    </div>
</section>

<!-- Upload Modal (for admins) -->
<?php if (isset($user_role) && in_array($user_role, ['admin', 'pastor'])): ?>
<div class="modal fade" id="uploadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Upload New Album</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="albumForm">
                    <div class="mb-3">
                        <label for="albumTitle" class="form-label">Album Title</label>
                        <input type="text" class="form-control" id="albumTitle" required>
                    </div>
                    <div class="mb-3">
                        <label for="albumCategory" class="form-label">Category</label>
                        <select class="form-select" id="albumCategory" required>
                            <?php foreach ($categories as $key => $category): ?>
                                <?php if ($key !== 'all'): ?>
                                <option value="<?php echo $key; ?>"><?php echo $category; ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="albumDate" class="form-label">Date</label>
                        <input type="date" class="form-control" id="albumDate" required>
                    </div>
                    <div class="mb-3">
                        <label for="albumPhotos" class="form-label">Upload Photos</label>
                        <input class="form-control" type="file" id="albumPhotos" multiple accept="image/*" required>
                        <div class="form-text">Select multiple photos for this album</div>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-cloud-upload-alt me-2"></i>Upload Album
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Lightbox Modal -->
<div class="modal fade" id="imageLightbox" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-header border-0">
                <h5 class="modal-title text-white" id="lightboxTitle"></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-0">
                <div id="lightboxCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner" id="lightboxItems">
                        <!-- Carousel items will be added dynamically -->
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#lightboxCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#lightboxCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Gallery Hero */
.gallery-hero {
    background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('images/image1.jpg') center/cover no-repeat;
    min-height: 400px;
    position: relative;
}

/* Album Card Styles */
.album-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border-radius: 0.75rem;
    overflow: hidden;
}

.album-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1.5rem rgba(0, 0, 0, 0.15) !important;
}

.album-cover {
    position: relative;
    overflow: hidden;
    border-radius: 0.5rem 0.5rem 0 0;
}

.album-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.album-card:hover .album-overlay {
    opacity: 1;
}

/* Gallery Navigation */
.gallery-categories .nav-link {
    position: relative;
    padding: 0.5rem 1rem;
    color: #6c757d;
    font-weight: 500;
    transition: color 0.3s ease;
}

.gallery-categories .nav-link:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 0;
    height: 2px;
    background: #0d6efd;
    transition: all 0.3s ease;
    transform: translateX(-50%);
}

.gallery-categories .nav-link:hover,
.gallery-categories .nav-link.active {
    color: #0d6efd;
}

.gallery-categories .nav-link.active:after,
.gallery-categories .nav-link:hover:after {
    width: 60%;
}

/* Sticky Navigation */
#galleryNav {
    transition: all 0.3s ease;
    top: -100px;
}

#galleryNav.sticky {
    top: 0;
    z-index: 1020;
    background-color: rgba(255, 255, 255, 0.98) !important;
    backdrop-filter: blur(10px);
}

/* Lightbox Styles */
#imageLightbox .modal-content {
    background: transparent;
}

#imageLightbox .carousel-item img {
    max-height: 80vh;
    width: auto;
    margin: 0 auto;
    border-radius: 0.5rem;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .gallery-hero {
        min-height: 300px;
    }
    
    .gallery-categories {
        flex-wrap: nowrap;
        overflow-x: auto;
        padding-bottom: 0.5rem;
    }
    
    .gallery-categories .nav-item {
        white-space: nowrap;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Sticky Navigation
    const galleryNav = document.getElementById('galleryNav');
    const gallerySection = document.getElementById('gallery');
    
    if (galleryNav && gallerySection) {
        const observer = new IntersectionObserver(
            ([e]) => {
                galleryNav.classList.toggle('sticky', e.intersectionRatio < 1);
            },
            { threshold: [1] }
        );
        
        observer.observe(gallerySection);
    }
    
    // Category Filtering
    const categoryFilters = document.querySelectorAll('.category-filter');
    const albumItems = document.querySelectorAll('.album-item');
    const noResults = document.getElementById('noResults');
    
    categoryFilters.forEach(filter => {
        filter.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active state
            categoryFilters.forEach(f => f.classList.remove('active'));
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            let visibleItems = 0;
            
            // Filter albums
            albumItems.forEach(item => {
                if (category === 'all' || item.getAttribute('data-category') === category) {
                    item.style.display = 'block';
                    visibleItems++;
                } else {
                    item.style.display = 'none';
                }
            });
            
            // Show/hide no results message
            noResults.style.display = visibleItems > 0 ? 'none' : 'block';
        });
    });
    
    // Initialize lightbox
    const lightbox = new bootstrap.Modal(document.getElementById('imageLightbox'));
    
    // Redirect to Facebook when album is clicked
    document.querySelectorAll('.album-cover').forEach((cover) => {
        cover.style.cursor = 'pointer';
        cover.addEventListener('click', function() {
            window.location.href = 'https://www.facebook.com/share/1Akt7TssmM/?mibextid=wwXIfr';
        });
    });
    
    // Load more functionality
    const loadMoreBtn = document.getElementById('loadMore');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            // In a real app, this would load more albums from the server
            // For demo, we'll just show an alert
            alert('Loading more albums...');
        });
    }
    
    // Form submission for album upload (demo only)
    const albumForm = document.getElementById('albumForm');
    if (albumForm) {
        albumForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Album upload functionality would be implemented here');
            // In a real app, this would handle file uploads and create a new album
            const uploadModal = bootstrap.Modal.getInstance(document.getElementById('uploadModal'));
            uploadModal.hide();
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>
