<?php
// Start session if not already started
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Include required files
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

// Get user info from session
$user_id = $_SESSION['user_id'] ?? null;
$user_name = $_SESSION['user_name'] ?? null;
$user_role = $_SESSION['user_role'] ?? null;
$user_email = $_SESSION['user_email'] ?? null;
$search = trim($_GET['search'] ?? '');
$category = $_GET['category'] ?? '';
$sort = $_GET['sort'] ?? 'date_desc';
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 9; // Items per page

// Page metadata
$page_title = 'Sermons & Teachings';
$page_description = 'Browse our collection of inspiring sermons and biblical teachings';

// Get all sermons using the function from db.php

// Get sermons from the database
$result = $conn->query("SELECT * FROM sermons ORDER BY date DESC");
$all_sermons = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $all_sermons[] = $row;
    }
}

// If no sermons found in database, use sample data
if (empty($all_sermons)) {
    $all_sermons = $conn->getSermons()->fetchAll();
}

// Debug: Check if we have any sermons
echo '<!-- Debug: Number of sermons found: ' . count($all_sermons) . ' -->';
if (empty($all_sermons)) {
    error_log('No sermons found in $all_sermons array');
}

// Debug: Check database connection
if (!$conn) {
    echo '<!-- Debug: Database connection failed -->';
} else {
    echo '<!-- Debug: Database connection successful -->';
}

// Define category metadata with images
$categoryMetadata = [
    'Sunday Service' => [
        'icon' => 'fas fa-church',
        'description' => 'Weekly Sunday worship service',
        'image' => 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
        'color' => '#e67e22' // Primary orange
    ],
    'Bible Study' => [
        'icon' => 'fas fa-bible',
        'description' => 'In-depth Bible study sessions',
        'image' => 'https://images.unsplash.com/photo-14524218222460-df9b5a99dd9f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
        'color' => '#2c3e50' // Secondary dark blue
    ],
    'Prayer Meeting' => [
        'icon' => 'fas fa-pray',
        'description' => 'Corporate prayer gatherings',
        'image' => 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
        'color' => '#8e44ad' // Purple
    ],
    'Special Event' => [
        'icon' => 'fas fa-star',
        'description' => 'Special church events and conferences',
        'image' => 'https://images.unsplash.com/photo-1501281667305-0d4f86b7e2b9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
        'color' => '#e74c3c' // Red
    ],
    'Worship Night' => [
        'icon' => 'fas fa-music',
        'description' => 'Extended times of worship',
        'image' => 'https://images.unsplash.com/photo-1501612780327-45045538702b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
        'color' => '#3498db' // Blue
    ],
    'Missions Conference' => [
        'icon' => 'fas fa-globe',
        'description' => 'Missions-focused services',
        'image' => 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
        'color' => '#2ecc71' // Green
    ]
];

// Initialize categories and counts
$categories = [];
$categoryCounts = [];
$tags = [];

// Process all sermons to build categories and tags
foreach ($all_sermons as $sermon) {
    // Process categories
    if (!empty($sermon['category'])) {
        $cat = $sermon['category'];
        
        // Initialize category in categoryCounts if not exists
        if (!isset($categoryCounts[$cat])) {
            $categoryCounts[$cat] = 0;
            
            // Add to categories array if not exists
            if (!in_array($cat, $categories)) {
                $categories[] = $cat;
                // Ensure category has default metadata
                if (!isset($categoryMetadata[$cat])) {
                    $categoryMetadata[$cat] = [
                        'icon' => 'fas fa-folder',
                        'description' => $cat . ' messages',
                        'image' => 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
                        'color' => '#95a5a6' // Default gray
                    ];
                }
            }
        }
        $categoryCounts[$cat]++;
    }
    
    // Process tags
    if (!empty($sermon['tags'])) {
        $sermonTags = is_string($sermon['tags']) ? json_decode($sermon['tags'], true) : $sermon['tags'];
        if (is_array($sermonTags)) {
            foreach ($sermonTags as $tag) {
                if (!in_array($tag, $tags)) {
                    $tags[] = $tag;
                }
            }
        }
    }
}

// Debug: Check initial sermons data
echo '<!-- Debug: Initial sermon count: ' . count($all_sermons) . ' -->';

// Store the filtered sermons in $sermons for the template
$sermons = $all_sermons;

// Apply search filter
if (!empty($search)) {
    echo '<!-- Debug: Applying search filter for: ' . htmlspecialchars($search) . ' -->';
    $search = strtolower($search);
    $filtered = [];
    
    foreach ($sermons as $sermon) {
        if (!is_array($sermon)) continue;
        
        $title = strtolower($sermon['title'] ?? '');
        $content = strtolower($sermon['content'] ?? '');
        $author = strtolower($sermon['author'] ?? '');
        $scripture = strtolower($sermon['scripture'] ?? '');
        
        // Handle tags safely
        $sermonTags = [];
        if (isset($sermon['tags'])) {
            if (is_string($sermon['tags'])) {
                $decoded = json_decode($sermon['tags'], true);
                $sermonTags = is_array($decoded) ? $decoded : [];
            } elseif (is_array($sermon['tags'])) {
                $sermonTags = $sermon['tags'];
            }
        }
        
        $tagsStr = strtolower(implode(' ', $sermonTags));
        
        if (strpos($title, $search) !== false || 
            strpos($content, $search) !== false || 
            strpos($author, $search) !== false ||
            strpos($scripture, $search) !== false ||
            strpos($tagsStr, $search) !== false) {
            $filtered[] = $sermon;
        }
    }
    
    $sermons = $filtered;
    echo '<!-- Debug: After search filter: ' . count($sermons) . ' sermons remain -->';
}

// Apply category filter
if (!empty($category)) {
    echo '<!-- Debug: Applying category filter for: ' . htmlspecialchars($category) . ' -->';
    $filtered = [];
    $category = strtolower($category);
    
    foreach ($sermons as $sermon) {
        if (isset($sermon['category']) && strtolower($sermon['category']) === $category) {
            $filtered[] = $sermon;
        }
    }
    
    $sermons = $filtered;
    echo '<!-- Debug: After category filter: ' . count($sermons) . ' sermons remain -->';
}

// Reset array keys after filtering
$sermons = array_values($sermons);

// Apply sorting
usort($sermons, function($a, $b) use ($sort) {
    switch ($sort) {
        case 'title_asc':
            return strcmp($a['title'] ?? '', $b['title'] ?? '');
        case 'title_desc':
            return strcmp($b['title'] ?? '', $a['title'] ?? '');
        case 'date_asc':
            return strtotime($a['date'] ?? '') - strtotime($b['date'] ?? '');
        case 'date_desc':
        default:
            return strtotime($b['date'] ?? '') - strtotime($a['date'] ?? '');
    }
});

// Debug: Check sermon data
// echo '<pre>'; print_r($sermons); echo '</pre>';

// Pagination - Use the filtered sermons array
$total_sermons = count($sermons);
$total_pages = ceil($total_sermons / $per_page);
$offset = ($page - 1) * $per_page;
$sermons = array_slice($sermons, $offset, $per_page);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> - Apostolic Church</title>
    <meta name="description" content="<?php echo htmlspecialchars($page_description); ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/sermons.css">
</head>
<body>
    <style>
        /* Navigation Styles */
        .navbar {
            padding: 0.8rem 0;
            transition: all 0.3s ease;
        }
        
        .navbar-nav .nav-link,
        .navbar-nav .nav-link.active,
        .navbar-nav .nav-link:focus,
        .navbar-nav .nav-link:active,
        .navbar-nav .nav-link:visited {
            color: white !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            transition: all 0.3s ease;
        }
        
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #e67e22 !important;
            opacity: 1;
        }
        
        .navbar-brand {
            color: white !important;
            font-size: 1.4rem;
            transition: all 0.3s ease;
        }
        
        .navbar-brand:hover {
            color: #e67e22 !important;
        }
        
        .dropdown-menu {
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-radius: 8px;
            padding: 0.5rem 0;
        }
        
        .dropdown-item {
            padding: 0.5rem 1.25rem;
            font-weight: 400;
            transition: all 0.2s ease;
            color: #2c3e50 !important;
        }
        
        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #e67e22 !important;
            padding-left: 1.5rem;
        }
        
        .dropdown-divider {
            margin: 0.3rem 0;
        }
        
        .nav-link-underline {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background-color: #e67e22;
            transition: width 0.3s ease;
        }
        
        .nav-link:hover .nav-link-underline,
        .nav-link.active .nav-link-underline {
            width: 60%;
        }
    </style>
    
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: rgba(44, 62, 80, 0.95); backdrop-filter: blur(10px); box-shadow: 0 2px 15px rgba(0,0,0,0.1); color: white !important;">
        <div class="container">
            <!-- Logo and Church Name -->
            <a class="navbar-brand d-flex align-items-center fw-bold" href="../index.php" style="font-family: 'Montserrat', sans-serif; letter-spacing: 0.5px;">
                <i class="fas fa-church me-2" style="color: #e67e22;"></i>
                <span>Apostolic Church</span>
            </a>
            
            <!-- Mobile Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Navigation Links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="../index.php">
                            <i class="fas fa-home d-lg-none me-2"></i>Home
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3 active" href="list.php">
                            <i class="fas fa-bible d-lg-none me-2"></i>Sermons
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="../ministry/">
                            <i class="fas fa-hands-helping d-lg-none me-2"></i>Ministries
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="../events/list.php">
                            <i class="fas fa-calendar-alt d-lg-none me-2"></i>Events
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link position-relative px-3" href="../contact.php">
                            <i class="fas fa-envelope d-lg-none me-2"></i>Contact
                            <span class="nav-link-underline"></span>
                        </a>
                    </li>
                </ul>
                
                <!-- User Dropdown -->
                <div class="d-flex align-items-center">
                    <?php if ($user_id): ?>
                        <div class="text-white me-3 d-none d-md-block text-end">
                            <div class="fw-bold"><?php echo htmlspecialchars($_SESSION['name'] ?? 'User'); ?></div>
                            <div class="small text-white-50"><?php echo ucfirst($user_role ?? 'Member'); ?></div>
                        </div>
                        <div class="dropdown">
                            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle fa-lg"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="userDropdown" style="border: none; min-width: 200px;">
                                <?php 
                                $dashboard_link = 'dashboard-' . strtolower($_SESSION['user_role'] ?? 'member') . '.php';
                                ?>
                                <li><a class="dropdown-item" href="../<?php echo $dashboard_link; ?>"><i class="fas fa-tachometer-alt me-2 text-muted"></i>Dashboard</a></li>
                                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2 text-muted"></i>Profile</a></li>
                                <li><a class="dropdown-item" href="../settings.php"><i class="fas fa-cog me-2 text-muted"></i>Settings</a></li>
                                <li><hr class="dropdown-divider my-2"></li>
                                <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="../members/login.php" class="btn btn-outline-light me-2">Login</a>
                        <a href="../members/register.php" class="btn btn-light">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="hero-section">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="hero-title">Sermons & Teachings</h1>
                    <p class="hero-subtitle">Explore our collection of biblical messages and grow in your faith journey</p>
                    
                    <!-- Search Form -->
                    <form class="search-form mt-4" method="GET" action="">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search sermons..." value="<?php echo htmlspecialchars($search); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search me-2"></i> Search
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="py-5">
        <div class="container">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-lg-3 mb-4">
                    <!-- Categories -->
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Categories</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled">
                                <li class="mb-2">
                                    <a href="?" class="d-flex justify-content-between align-items-center text-decoration-none <?php echo empty($category) ? 'text-primary fw-bold' : 'text-dark' ?>">
                                        <span>All Sermons</span>
                                        <span class="badge bg-primary rounded-pill"><?php echo count($all_sermons); ?></span>
                                    </a>
                                </li>
                                <?php 
                                // Sort categories alphabetically
                                sort($categories);
                                foreach ($categories as $cat): 
                                    $isActive = strtolower($category) === strtolower($cat);
                                    $icon = $categoryMetadata[$cat]['icon'] ?? 'fas fa-folder';
                                    $description = $categoryMetadata[$cat]['description'] ?? $cat . ' messages';
                                ?>
                                    <li class="mb-2">
                                        <a href="?category=<?php echo urlencode($cat); ?>" 
                                           class="d-flex justify-content-between align-items-center text-decoration-none <?php echo $isActive ? 'text-primary fw-bold' : 'text-dark'; ?>"
                                           title="<?php echo htmlspecialchars($description); ?>">
                                            <span><i class="<?php echo $icon; ?> me-2"></i><?php echo htmlspecialchars($cat); ?></span>
                                            <span class="badge bg-light text-dark rounded-pill"><?php echo $categoryCounts[$cat] ?? 0; ?></span>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Main Content -->
                <div class="col-lg-9">
                    <!-- Page Header -->
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
                        <h2 class="mb-3 mb-md-0">
                            <?php if (!empty($category)): ?>
                                <?php echo htmlspecialchars($category); ?> Sermons
                            <?php elseif (!empty($search)): ?>
                                Search Results for "<?php echo htmlspecialchars($search); ?>"
                            <?php else: ?>
                                Latest Sermons
                            <?php endif; ?>
                        </h2>
                        
                        <!-- Sort Dropdown -->
                        <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-sort me-1"></i>
                                <?php
                                $sortLabels = [
                                    'date_desc' => 'Newest First',
                                    'date_asc' => 'Oldest First',
                                    'title_asc' => 'Title (A-Z)',
                                    'title_desc' => 'Title (Z-A)'
                                ];
                                echo $sortLabels[$sort] ?? 'Sort By';
                                ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="sortDropdown">
                                <li><a class="dropdown-item <?php echo $sort === 'date_desc' ? 'active' : ''; ?>" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'date_desc'])); ?>">Newest First</a></li>
                                <li><a class="dropdown-item <?php echo $sort === 'date_asc' ? 'active' : ''; ?>" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'date_asc'])); ?>">Oldest First</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item <?php echo $sort === 'title_asc' ? 'active' : ''; ?>" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'title_asc'])); ?>">Title (A-Z)</a></li>
                                <li><a class="dropdown-item <?php echo $sort === 'title_desc' ? 'active' : ''; ?>" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'title_desc'])); ?>">Title (Z-A)</a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- Sermons Grid -->
                    <?php if (!empty($sermons)): ?>
                        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                            <?php foreach ($sermons as $sermon): ?>
                                <div class="col" data-aos="fade-up" data-aos-duration="800">
                                    <div class="card h-100 sermon-card shadow-sm border-0">
                                        <?php 
// Set default values
$defaultCategory = 'Sermon';
$fallbackImage = 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';

// Safely get category with fallback
$category = !empty($sermon['category']) ? $sermon['category'] : $defaultCategory;

// Get image with fallbacks
$sermonImage = !empty($sermon['image']) ? 
    $sermon['image'] : 
    (isset($categoryMetadata[$category]['image']) ? 
        $categoryMetadata[$category]['image'] : 
        $fallbackImage);

// Get category styling
$bgColor = isset($categoryMetadata[$category]) ? 
    $categoryMetadata[$category]['color'] : '#95a5a6';
$icon = isset($categoryMetadata[$category]) ? 
    $categoryMetadata[$category]['icon'] : 'fas fa-folder';
    
// Format view count
$viewCount = isset($sermon['view_count']) ? number_format($sermon['view_count']) : '0';
?>
<div class="sermon-image position-relative" style="background-image: url('<?php echo htmlspecialchars($sermonImage); ?>');">
    <div class="position-absolute top-0 start-0 p-2">
        <span class="badge rounded-pill px-3 py-2" style="background-color: <?php echo $bgColor; ?>">
            <i class="<?php echo $icon; ?> me-1"></i>
            <?php echo htmlspecialchars($category); ?>
        </span>
    </div>
                                            <div class="sermon-play-overlay d-flex align-items-center justify-content-center" onclick="event.stopPropagation()">
                                                <a href="https://www.youtube.com/watch?v=INSPIRED_MUSIQ" target="_blank" rel="noopener noreferrer" class="sermon-play-btn btn btn-primary rounded-circle p-3 shadow" style="background-color: #e67e22; border-color: #e67e22;" onclick="event.stopPropagation()">
                                                    <i class="fas fa-play fa-lg"></i>
                                                </a>
                                            </div>
                                            <div class="sermon-views position-absolute bottom-0 end-0 m-2">
                                                <span class="badge bg-dark bg-opacity-75 px-2 py-1">
                                                    <i class="fas fa-eye me-1"></i> <?php echo $viewCount; ?>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="card-body d-flex flex-column">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <div class="sermon-date text-muted small">
                                                    <i class="far fa-calendar-alt me-1"></i>
                                                    <?php echo date('M j, Y', strtotime($sermon['date'])); ?>
                                                </div>
                                                <?php if (!empty($sermon['duration'])): ?>
                                                    <div class="sermon-duration small text-muted">
                                                        <i class="far fa-clock me-1"></i>
                                                        <?php echo htmlspecialchars($sermon['duration']); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <h3 class="h5 card-title mb-2 flex-grow-1">
                                                <a href="view.php?id=<?php echo urlencode($sermon['id']); ?>" class="text-dark text-decoration-none stretched-link">
                                                    <?php echo htmlspecialchars($sermon['title']); ?>
                                                </a>
                                            </h3>
                                            <?php if (!empty($sermon['scripture'])): ?>
                                                <div class="sermon-scripture text-muted small mb-3">
                                                    <i class="fas fa-book me-1"></i> <?php echo htmlspecialchars($sermon['scripture']); ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($sermon['scripture'])): ?>
                                                <div class="sermon-scripture text-primary small mb-2">
                                                    <i class="fas fa-book me-1"></i> <?php echo htmlspecialchars($sermon['scripture']); ?>
                                                </div>
                                            <?php endif; ?>
                                            <p class="card-text text-muted small mb-3 flex-grow-1">
                                                <?php 
                                                $excerpt = !empty($sermon['content']) ? strip_tags($sermon['content']) : 'No description available.';
                                                echo strlen($excerpt) > 120 ? substr($excerpt, 0, 120) . '...' : $excerpt;
                                                ?>
                                            </p>
                                            <div class="mt-auto pt-3 border-top">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="d-flex align-items-center">
                                                        <?php 
                                                        $authorName = !empty($sermon['author']) ? trim($sermon['author']) : 'Unknown Author';
                                                        $initials = 'UA';
                                                        if ($authorName !== 'Unknown Author') {
                                                            $nameParts = explode(' ', $authorName);
                                                            $initials = '';
                                                            foreach ($nameParts as $part) {
                                                                $initials .= strtoupper(substr($part, 0, 1));
                                                                if (strlen($initials) >= 2) break;
                                                            }
                                                        }
                                                        ?>
                                                        <div class="d-flex align-items-center">
                                                            <div class="rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 28px; height: 28px; font-size: 10px; background-color: rgba(0,0,0,0.05);">
                                                                <?php echo htmlspecialchars($initials); ?>
                                                            </div>
                                                            <span class="small text-muted"><?php echo htmlspecialchars($authorName); ?></span>
                                                        </div>
                                                    </div>
                                                    <a href="view.php?id=<?php echo urlencode($sermon['id']); ?>" class="btn btn-sm btn-link text-primary text-decoration-none p-0">
                                                        Watch Now <i class="fas fa-arrow-right ms-1 small"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <?php if (!empty($sermon['tags'])): ?>
                                                <div class="sermon-tags mt-3">
                                                    <?php 
                                                    $tags = is_string($sermon['tags']) ? json_decode($sermon['tags'], true) : $sermon['tags'];
                                                    if (is_array($tags)): 
                                                        foreach (array_slice($tags, 0, 3) as $tag): ?>
                                                            <a href="?search=<?php echo urlencode($tag); ?>" class="badge bg-light text-dark text-decoration-none me-1 mb-1">
                                                                #<?php echo htmlspecialchars($tag); ?>
                                                            </a>
                                                    <?php endforeach; endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <nav aria-label="Sermon pagination" class="mt-5">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" aria-label="Previous">
                                                <span aria-hidden="true">&laquo; Previous</span>
                                            </a>
                                        </li>
                                    <?php else: ?>
                                        <li class="page-item disabled">
                                            <span class="page-link" aria-hidden="true">&laquo; Previous</span>
                                        </li>
                                    <?php endif; ?>

                                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                            <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        </li>
                                    <?php endfor; ?>

                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" aria-label="Next">
                                                <span aria-hidden="true">Next &raquo;</span>
                                            </a>
                                        </li>
                                    <?php else: ?>
                                        <li class="page-item disabled">
                                            <span class="page-link" aria-hidden="true">Next &raquo;</span>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>

                    <?php else: ?>
                        <!-- Empty State -->
                        <div class="text-center py-5 my-5" data-aos="fade-up">
                            <div class="empty-state-icon mb-4">
                                <i class="fas fa-bible fa-3x text-muted"></i>
                            </div>
                            <h4 class="h5 mb-3">No sermons found</h4>
                            <p class="mb-4" style="color: blue;">
                                <?php if ($search || $category): ?>
                                    No sermons match your search criteria. Try adjusting your filters or search term.
                                <?php else: ?>
                                    There are no sermons available at the moment. Please check back later.
                                <?php endif; ?>
{{ ... }}
                            <a href="?" class="btn btn-primary">
                                <i class="fas fa-redo me-2"></i> Reset Filters
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5 class="text-uppercase mb-4">Apostolic Church</h5>
                    <p>Sharing the love of Christ and making disciples who make disciples in our community and around the world.</p>
                    <div class="social-links mt-4">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4">
                    <h6 class="text-uppercase mb-4">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="../index.php" class="text-white text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="list.php" class="text-white text-decoration-none">Sermons</a></li>
                        <li class="mb-2"><a href="../ministry/" class="text-white text-decoration-none">Ministries</a></li>
                        <li class="mb-2"><a href="../events/" class="text-white text-decoration-none">Events</a></li>
                        <li><a href="../contact/" class="text-white text-decoration-none">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-4">
                    <h6 class="text-uppercase mb-4">Service Times</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <div class="d-flex">
                                <span class="me-2">Sunday:</span>
                                <div>
                                    <div>Morning Worship: 10:00 AM</div>
                                    <div>Evening Service: 6:00 PM</div>
                                </div>
                            </div>
                        </li>
                        <li class="mb-2">
                            <div class="d-flex">
                                <span class="me-2">Wednesday:</span>
                                <div>Bible Study: 7:00 PM</div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-4">
                    <h6 class="text-uppercase mb-4">Contact Info</h6>
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            123 Church Street, City, State 12345
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-phone me-2"></i>
                            (123) 456-7890
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-envelope me-2"></i>
                            info@apostolicchurch.com
                        </li>
                    </ul>
                </div>
            </div>
            <hr class="my-4 bg-light">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> Apostolic Church. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-white text-decoration-none me-3">Privacy Policy</a>
                    <a href="#" class="text-white text-decoration-none">Terms of Use</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top" id="backToTop">
        <i class="fas fa-arrow-up"></i>
    </a>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- AOS Animation -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <!-- Custom JS -->
    <script src="assets/js/sermons.js"></script>
</body>
</html>
