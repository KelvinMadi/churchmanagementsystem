<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['pastor']);

$user = get_user();
$message = '';
$csrf_token = generate_csrf_token();

// Get all speakers for the dropdown
$speakers = [];
try {
    $speakers = $conn->query("SELECT id, name FROM users WHERE role = 'pastor' OR role = 'guest_speaker' ORDER BY name");
} catch (Exception $e) {
    $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error loading speakers: ' . htmlspecialchars($e->getMessage()) . '</div>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
        $title = trim($_POST['title']);
        $description = trim($_POST['description']);
        $speaker_id = intval($_POST['speaker_id'] ?? 0);
        $date = $_POST['date'] ?: date('Y-m-d');
        $scripture = trim($_POST['scripture'] ?? '');
        $video_url = trim($_POST['video_url'] ?? '');
        $audio_url = trim($_POST['audio_url'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        
        // Handle file uploads
        $video_path = '';
        $thumbnail_path = '';
        
        // Validate required fields
        if (empty($title)) {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please enter a title for the sermon.</div>';
        } elseif (empty($speaker_id)) {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please select a speaker.</div>';
        } else {
            // Process file uploads if any
            if (isset($_FILES['video_file']) && $_FILES['video_file']['error'] === UPLOAD_ERR_OK) {
                $allowed_video_types = ['video/mp4', 'video/webm', 'video/quicktime'];
                $max_video_size = 500 * 1024 * 1024; // 500MB
                
                if ($_FILES['video_file']['size'] > $max_video_size) {
                    $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Video file is too large. Maximum size is 500MB.</div>';
                } elseif (!in_array($_FILES['video_file']['type'], $allowed_video_types)) {
                    $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Invalid video file type. Please upload MP4, WebM, or MOV files.</div>';
                } else {
                    $upload_dir = '../uploads/sermons/videos/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }
                    
                    $file_extension = pathinfo($_FILES['video_file']['name'], PATHINFO_EXTENSION);
                    $filename = 'sermon_' . time() . '_' . uniqid() . '.' . $file_extension;
                    $upload_path = $upload_dir . $filename;
                    
                    if (move_uploaded_file($_FILES['video_file']['tmp_name'], $upload_path)) {
                        $video_path = 'uploads/sermons/videos/' . $filename;
                    } else {
                        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Failed to upload video file.</div>';
                    }
                }
            }
            
            // Process thumbnail upload
            if (empty($message) && isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
                $allowed_image_types = ['image/jpeg', 'image/png', 'image/webp'];
                $max_image_size = 5 * 1024 * 1024; // 5MB
                
                if ($_FILES['thumbnail']['size'] > $max_image_size) {
                    $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Thumbnail image is too large. Maximum size is 5MB.</div>';
                } elseif (!in_array($_FILES['thumbnail']['type'], $allowed_image_types)) {
                    $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Invalid image type. Please upload JPG, PNG, or WebP files.</div>';
                } else {
                    $upload_dir = '../uploads/sermons/thumbnails/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }
                    
                    $file_extension = pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION);
                    $filename = 'thumb_' . time() . '_' . uniqid() . '.' . $file_extension;
                    $upload_path = $upload_dir . $filename;
                    
                    if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $upload_path)) {
                        $thumbnail_path = 'uploads/sermons/thumbnails/' . $filename;
                    } else {
                        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Failed to upload thumbnail image.</div>';
                    }
                }
            }
            
            // If no errors, save to database
            if (empty($message)) {
                try {
                    $sermon_data = [
                        'title' => $title,
                        'description' => $description,
                        'speaker_id' => $speaker_id,
                        'date' => $date,
                        'scripture' => $scripture,
                        'video_url' => $video_url,
                        'audio_url' => $audio_url,
                        'notes' => $notes,
                        'created_by' => $user['id'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                    
                    if (!empty($video_path)) {
                        $sermon_data['video_path'] = $video_path;
                    }
                    
                    if (!empty($thumbnail_path)) {
                        $sermon_data['thumbnail_path'] = $thumbnail_path;
                    }
                    
                    $saved = $conn->saveSermon($sermon_data);
                    
                    if ($saved) {
                        $_SESSION['success_message'] = 'Sermon created successfully!';
                        header('Location: list.php');
                        exit();
                    } else {
                        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Failed to save sermon. Please try again.</div>';
                    }
                } catch (Exception $e) {
                    $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
                }
            }
        }
    }
}

// Set default date to today
$default_date = date('Y-m-d');

// Page title
$page_title = 'Upload New Sermon';

// Include header
include '../includes/header.php';
?>

<div class="container py-4">
    <!-- Page Header -->
    <div class="page-header mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <h1 class="h3 text-primary">
                <i class="fas fa-podcast me-2"></i>New Sermon
            </h1>
            <div>
                <a href="list.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Sermons
                </a>
            </div>
        </div>
        <nav aria-label="breadcrumb" class="mt-3">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../">Home</a></li>
                <li class="breadcrumb-item"><a href="list.php">Sermons</a></li>
                <li class="breadcrumb-item active" aria-current="page">New</li>
            </ol>
        </nav>
    </div>

    <?php if (!empty($message)): ?>
    <div class="row mb-4">
        <div class="col-12">
            <?php echo $message; ?>
        </div>
    </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        
        <div class="row">
            <!-- Left Column - Main Content -->
            <div class="col-lg-8">
                <!-- Basic Information Card -->
                <div class="card mb-4 shadow-sm">
                    <div class="card-header bg-white border-bottom py-3">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle text-primary me-2"></i>Sermon Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <!-- Title -->
                            <div class="col-12">
                                <label for="title" class="form-label">Sermon Title <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-heading"></i></span>
                                    <input type="text" class="form-control form-control-lg" id="title" name="title" 
                                           value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>" 
                                           placeholder="Enter sermon title" required>
                                </div>
                                <div class="invalid-feedback">Please provide a title for the sermon.</div>
                            </div>
                            
                            <!-- Speaker and Date -->
                            <div class="col-md-6">
                                <label for="speaker_id" class="form-label">Speaker <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <select class="form-select" id="speaker_id" name="speaker_id" required>
                                        <option value="">-- Select Speaker --</option>
                                        <?php foreach ($speakers as $speaker): ?>
                                            <option value="<?php echo $speaker['id']; ?>" 
                                                <?php echo (isset($_POST['speaker_id']) && $_POST['speaker_id'] == $speaker['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($speaker['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="invalid-feedback">Please select a speaker.</div>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="date" class="form-label">Date <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                    <input type="date" class="form-control" id="date" name="date" 
                                           value="<?php echo htmlspecialchars($_POST['date'] ?? $default_date); ?>" required>
                                </div>
                                <div class="invalid-feedback">Please select a date.</div>
                            </div>
                            
                            <!-- Scripture Reference -->
                            <div class="col-12">
                                <label for="scripture" class="form-label">Scripture Reference</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-bible"></i></span>
                                    <input type="text" class="form-control" id="scripture" name="scripture" 
                                           value="<?php echo htmlspecialchars($_POST['scripture'] ?? ''); ?>"
                                           placeholder="e.g., John 3:16-17">
                                </div>
                                <div class="form-text">Enter the main Bible passage for this sermon</div>
                            </div>
                            
                            <!-- Description -->
                            <div class="col-12">
                                <label for="description" class="form-label">Sermon Description <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="description" name="description" 
                                          rows="3" placeholder="Briefly describe this sermon" required><?php 
                                    echo htmlspecialchars($_POST['description'] ?? ''); 
                                ?></textarea>
                                <div class="form-text">This will be displayed on the sermons listing page</div>
                                <div class="invalid-feedback">Please provide a description for the sermon.</div>
                            </div>
                            
                            <!-- Speaker Notes -->
                            <div class="col-12">
                                <label for="notes" class="form-label">Speaker Notes</label>
                                <div class="position-relative">
                                    <textarea class="form-control" id="notes" name="notes" 
                                              rows="4" placeholder="Add private notes for this sermon (visible only to you and administrators)"><?php 
                                        echo htmlspecialchars($_POST['notes'] ?? ''); 
                                    ?></textarea>
                                    <div class="form-text">
                                        <i class="fas fa-lock me-1"></i> Private notes - only visible to you and administrators
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                                </div>
                                
                <!-- Media Uploads Card -->
                <div class="card mb-4 shadow-sm">
                    <div class="card-header bg-white border-bottom py-3">
                        <h5 class="mb-0">
                            <i class="fas fa-photo-video text-primary me-2"></i>Media & Files
                        </h5>
                    </div>
                    <div class="card-body">
                        <!-- Video Source Toggle -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Video Source</label>
                            <div class="d-flex gap-3 mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="video_source" id="video_upload" value="upload" checked>
                                    <label class="form-check-label" for="video_upload">
                                        <i class="fas fa-upload me-1"></i> Upload Video
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="video_source" id="video_url" value="url">
                                    <label class="form-check-label" for="video_url">
                                        <i class="fas fa-link me-1"></i> Video URL
                                    </label>
                                </div>
                            </div>
                            
                            <!-- Video Upload -->
                            <div id="video_upload_container" class="mb-4">
                                <div class="file-upload-wrapper">
                                    <label for="video_file" class="form-label d-block">Video File</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-video"></i></span>
                                        <input type="file" class="form-control" id="video_file" name="video_file" 
                                               accept="video/mp4,video/webm,video/quicktime">
                                    </div>
                                    <div class="form-text">
                                        <i class="fas fa-info-circle me-1"></i> 
                                        Supported formats: MP4, WebM, MOV. Max size: 500MB
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Video URL -->
                            <div id="video_url_container" class="mb-4" style="display: none;">
                                <label for="video_url_input" class="form-label">Video URL</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-link"></i></span>
                                    <input type="url" class="form-control" id="video_url_input" name="video_url" 
                                           placeholder="https://youtube.com/watch?v=... or https://vimeo.com/..." 
                                           value="<?php echo htmlspecialchars($_POST['video_url'] ?? ''); ?>">
                                </div>
                                <div class="form-text">
                                    <i class="fab fa-youtube me-1"></i> 
                                    Supports YouTube, Vimeo, or direct video URLs
                                </div>
                            </div>
                        </div>
                        
                        <!-- Thumbnail Upload -->
                        <div class="mb-4">
                            <label for="thumbnail" class="form-label fw-semibold">Thumbnail Image</label>
                            <div class="file-upload-wrapper">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-image"></i></span>
                                    <input type="file" class="form-control" id="thumbnail" name="thumbnail" 
                                           accept="image/jpeg,image/png,image/webp">
                                </div>
                                <div class="form-text">
                                    <i class="fas fa-info-circle me-1"></i> 
                                    Recommended: 1280×720px JPG, PNG, or WebP. Max 5MB
                                </div>
                            </div>
                        </div>
                        
                        <!-- Audio URL -->
                        <div class="mb-2">
                            <label for="audio_url" class="form-label fw-semibold">Audio Version (Optional)</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-music"></i></span>
                                <input type="url" class="form-control" id="audio_url" name="audio_url" 
                                       placeholder="https://example.com/audio.mp3" 
                                       value="<?php echo htmlspecialchars($_POST['audio_url'] ?? ''); ?>">
                            </div>
                            <div class="form-text">
                                <i class="fas fa-headphones me-1"></i> 
                                Direct link to MP3 audio file (for podcasting)
                            </div>
                        </div>
                    </div>
                </div>
                            </div>
                            
            <!-- Right Column - Sidebar -->
            <div class="col-lg-4">
                <!-- Publish Card -->
                <div class="card mb-4 shadow-sm sticky-top" style="top: 1rem;">
                    <div class="card-header bg-white border-bottom py-3">
                        <h5 class="mb-0">
                            <i class="fas fa-paper-plane text-primary me-2"></i>Publish
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button type="submit" name="action" value="publish" class="btn btn-primary btn-lg">
                                <i class="fas fa-cloud-upload-alt me-2"></i> Publish Sermon
                            </button>
                            <button type="submit" name="action" value="draft" class="btn btn-outline-secondary">
                                <i class="far fa-save me-2"></i> Save as Draft
                            </button>
                            <a href="list.php" class="btn btn-outline-danger">
                                <i class="fas fa-times me-2"></i> Discard
                            </a>
                        </div>
                        
                        <hr class="my-4">
                        
                        <!-- Status -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold d-block mb-2">Status</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" 
                                       id="is_published" name="is_published" value="1" checked>
                                <label class="form-check-label" for="is_published">
                                    <span class="badge bg-success">Published</span>
                                    <span class="d-block text-muted small mt-1">Drafts are only visible to administrators</span>
                                </label>
                            </div>
                        </div>
                        
                        <!-- Categories -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Categories</label>
                            <div class="list-group list-group-flush">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="category_sunday" 
                                           name="categories[]" value="Sunday Service" checked>
                                    <label class="form-check-label w-100" for="category_sunday">
                                        <i class="fas fa-church me-2 text-primary"></i> Sunday Service
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="category_bible_study" 
                                           name="categories[]" value="Bible Study">
                                    <label class="form-check-label w-100" for="category_bible_study">
                                        <i class="fas fa-book-open me-2 text-info"></i> Bible Study
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="category_special" 
                                           name="categories[]" value="Special Event">
                                    <label class="form-check-label w-100" for="category_special">
                                        <i class="fas fa-star me-2 text-warning"></i> Special Event
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tags -->
                        <div class="mb-2">
                            <label for="tags" class="form-label fw-semibold">Tags</label>
                            <input type="text" class="form-control" id="tags" name="tags" 
                                   placeholder="e.g., faith, prayer, love">
                            <div class="form-text">
                                <i class="fas fa-tags me-1"></i> 
                                Separate tags with commas
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Help Card -->
                <div class="card shadow-sm">
                    <div class="card-header bg-white border-bottom py-3">
                        <h5 class="mb-0">
                            <i class="fas fa-question-circle text-primary me-2"></i>Need Help?
                        </h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled mb-0">
                            <li class="mb-2">
                                <a href="#" class="text-decoration-none">
                                    <i class="fas fa-info-circle me-2 text-primary"></i> Formatting Guide
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="#" class="text-decoration-none">
                                    <i class="fas fa-video me-2 text-primary"></i> Video Upload Tips
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-decoration-none">
                                    <i class="fas fa-headset me-2 text-primary"></i> Contact Support
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                            </div>
        </div>
    </form>
</div>

<!-- Add custom styles for the form -->
<style>
    .form-control:focus, .form-select:focus, .form-check-input:focus {
        border-color: #e67e22;
        box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
    }
    
    .form-check-input:checked {
        background-color: #e67e22;
        border-color: #e67e22;
    }
    
    .file-upload-wrapper {
        background-color: #f8f9fa;
        border-radius: 0.375rem;
        padding: 1.25rem;
        border: 1px dashed #dee2e6;
        transition: all 0.2s;
    }
    
    .file-upload-wrapper:hover {
        border-color: #e67e22;
        background-color: #fff8f4;
    }
    
    .sticky-top {
        position: -webkit-sticky;
        position: sticky;
        z-index: 1020;
    }
    
    .form-label.required:after {
        content: " *";
        color: #dc3545;
    }
    
    .card {
        border: 1px solid rgba(0,0,0,.125);
    }
    
    .card-header {
        background-color: #f8f9fa;
    }
</style>

<script>
// Form validation
(function () {
    'use strict'
    
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
    
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
                
                // Scroll to the first invalid field
                const firstInvalid = form.querySelector(':invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstInvalid.focus();
                }
            }
            
            form.classList.add('was-validated')
        }, false)
    })
})()

// Toggle between video upload and URL
const videoUploadRadio = document.getElementById('video_upload');
const videoUrlRadio = document.getElementById('video_url');
const videoUploadContainer = document.getElementById('video_upload_container');
const videoUrlContainer = document.getElementById('video_url_container');
const videoFileInput = document.getElementById('video_file');
const videoUrlInput = document.getElementById('video_url_input');

function toggleVideoSource() {
    if (videoUploadRadio.checked) {
        videoUploadContainer.style.display = 'block';
        videoUrlContainer.style.display = 'none';
        videoUrlInput.removeAttribute('required');
        videoFileInput.setAttribute('required', 'required');
    } else {
        videoUploadContainer.style.display = 'none';
        videoUrlContainer.style.display = 'block';
        videoFileInput.removeAttribute('required');
        videoUrlInput.setAttribute('required', 'required');
    }
}

// Initialize the correct view on page load
document.addEventListener('DOMContentLoaded', function() {
    // Toggle video source
    toggleVideoSource();
    
    // Add event listeners for radio buttons
    videoUploadRadio.addEventListener('change', toggleVideoSource);
    videoUrlRadio.addEventListener('change', toggleVideoSource);
    
    // Add hover effects to file upload areas
    const fileUploads = document.querySelectorAll('.file-upload-wrapper');
    fileUploads.forEach(upload => {
        upload.addEventListener('dragover', (e) => {
            e.preventDefault();
            upload.classList.add('border-primary', 'bg-white');
        });
        
        upload.addEventListener('dragleave', () => {
            upload.classList.remove('border-primary', 'bg-white');
        });
        
        upload.addEventListener('drop', (e) => {
            e.preventDefault();
            upload.classList.remove('border-primary', 'bg-white');
        });
    });
    
    // Auto-resize textareas
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    });
});

// Format tags input
const tagInput = document.getElementById('tags');
if (tagInput) {
    tagInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            const value = this.value.trim();
            if (value) {
                const tags = value.split(',').map(tag => tag.trim()).filter(tag => tag);
                this.value = tags.join(', ');
            }
        }
    });
}
</script>

<?php include '../includes/footer.php'; ?>
