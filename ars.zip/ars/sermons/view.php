<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/db.php';
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

$sermon_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$sermon_id) {
    header('Location: list.php');
    exit();
}

// Get sermon details from JSON file
$sermons_file = dirname(__DIR__) . '/data/sermons.json';
$sermon = null;

// Debug output
echo "<!-- Debug: Looking for sermon ID: $sermon_id in $sermons_file -->";

try {
    if (file_exists($sermons_file)) {
        $sermons = json_decode(file_get_contents($sermons_file), true);
        
        // Debug output
        echo "<!-- Total sermons found: " . (is_array($sermons) ? count($sermons) : 0) . " -->";
        if (is_array($sermons)) {
            echo "<!-- Available sermon IDs: ";
            foreach ($sermons as $s) {
                echo $s['id'] . ' ';
            }
            echo "-->";
        }
        
        // Find the sermon with matching ID
        if (is_array($sermons)) {
            foreach ($sermons as $sermonItem) {
                if (isset($sermonItem['id']) && $sermonItem['id'] == $sermon_id) {
                    $sermon = $sermonItem;
                    // Debug output
                    echo "<!-- Found matching sermon: " . htmlspecialchars(print_r($sermon, true)) . " -->";
                    
                    // Set default author (since we don't have a users table in JSON)
                    $sermon['author'] = 'Pastor';
                    
                    // Add some sample content if empty
                    if (empty($sermon['content'])) {
                        $sermon['content'] = "This is a sample sermon content. The full content for '{$sermon['title']}' would be displayed here.";
                    }
                }
                break;
            }
        }
    }
} catch (Exception $e) {
    // Log error or handle it appropriately
    error_log('Error fetching sermon: ' . $e->getMessage());
    $sermon = null;
}

// Debug output (temporary)
echo "<!-- Debug: Looking for sermon ID: $sermon_id -->";
if (is_array($sermons)) {
    echo "<!-- Found " . count($sermons) . " sermons in database -->";
}

if (!$sermon) {
    // Debug: List available sermon IDs
    if (is_array($sermons) && !empty($sermons)) {
        $ids = [];
        foreach ($sermons as $s) {
            $ids[] = $s['id'] ?? 'undefined';
        }
        echo "<!-- Available sermon IDs: " . implode(', ', $ids) . " -->";
    }
    header('Location: list.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($sermon['title']); ?> - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="list.php">Sermons</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../events/list.php">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../announcements/list.php">Announcements</a>
                    </li>
                    <?php if ($user_id): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../dashboard/<?php echo $user_role; ?>.php">Dashboard</a></li>
                                <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../login.php">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h2 class="card-title"><?php echo htmlspecialchars($sermon['title']); ?></h2>
                            <span class="badge bg-primary"><?php echo date('M j, Y', strtotime($sermon['date'])); ?></span>
                        </div>
                        
                        <div class="mb-4">
                            <p class="text-muted">
                                <i class="fas fa-user me-2"></i>Preached by: <?php echo htmlspecialchars($sermon['author'] ?? 'Unknown'); ?>
                            </p>
                            <?php if ($sermon['scripture']): ?>
                            <p class="text-muted">
                                <i class="fas fa-book-open me-2"></i>Scripture: <?php echo htmlspecialchars($sermon['scripture']); ?>
                            </p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-4">
                            <h5>Sermon Content</h5>
                            <div class="sermon-content">
                                <?php echo nl2br(htmlspecialchars($sermon['content'])); ?>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <a href="list.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Back to Sermons
                            </a>
                            <?php if ($user_role === 'pastor'): ?>
                            <a href="edit.php?id=<?php echo $sermon_id; ?>" class="btn btn-primary">
                                <i class="fas fa-edit me-2"></i>Edit Sermon
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 