<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['pastor']);
$user = get_user();
$message = '';
$csrf_token = generate_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $scripture = trim($_POST['scripture']);
    $date = $_POST['date'];
    $video_path = null;

    // Handle video upload
    if (isset($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/webm'];
        $max_size = 100 * 1024 * 1024; // 100MB
        
        if ($_FILES['video']['size'] <= $max_size && in_array($_FILES['video']['type'], $allowed_types)) {
            $upload_dir = '../uploads/sermons/videos/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION);
            $filename = uniqid('sermon_') . '.' . $file_extension;
            $upload_path = $upload_dir . $filename;
            
            if (move_uploaded_file($_FILES['video']['tmp_name'], $upload_path)) {
                $video_path = 'uploads/sermons/videos/' . $filename;
            } else {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Failed to upload video.</div>';
            }
        } else {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Invalid video file. Please upload MP4, AVI, MOV, WMV, or WebM files under 100MB.</div>';
        }
    }
    
    if ($title && $date) {
        // Content is optional if video is provided
        if (!$content && !$video_path) {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please provide either sermon content or upload a video.</div>';
        } else {
            $saved = $conn->saveSermon([
                'title' => $title,
                'content' => $content,
                'scripture' => $scripture,
                'date' => $date,
                'uploaded_by' => $user['id'],
                'video_path' => $video_path
            ]);
            if ($saved) {
                $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Sermon uploaded successfully!</div>';
            } else {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error saving sermon.</div>';
            }
        }
    } else {
        $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
    }
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Sermon - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs-4.min.css" rel="stylesheet">
    <style>
        .upload-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0;
        }
        .form-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }
        .video-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(220, 53, 69, 0.9);
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
        }
    </style>
</head>
<body class="bg-light">
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="form-card">
                <div class="upload-header p-4">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-bible fa-2x me-3"></i>
                        <div>
                            <h3 class="mb-1">Upload Sermon/Devotional</h3>
                            <p class="mb-0">Share spiritual content with your congregation</p>
                        </div>
                    </div>
                </div>
                <div class="card-body p-4">
                    <?php echo $message; ?>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label class="form-label"><i class="fas fa-heading me-2"></i>Sermon Title *</label>
                                    <input type="text" name="title" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label"><i class="fas fa-calendar me-2"></i>Date *</label>
                                    <input type="date" name="date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-book-open me-2"></i>Scripture Reference</label>
                            <input type="text" name="scripture" class="form-control" placeholder="e.g., John 3:16, Matthew 28:19-20">
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-edit me-2"></i>Sermon Content *</label>
                            <textarea name="content" id="content" class="form-control" rows="15" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-video me-2"></i>Upload Video (Optional)</label>
                            <input type="file" name="video" class="form-control" accept="video/*">
                            <small class="form-text text-muted">Supported formats: MP4, AVI, MOV, WMV, WebM. Max size: 100MB</small>
                        </div>
                        <div class="d-flex justify-content-between">
                            <a href="list.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Back to Sermons
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-upload me-2"></i>Upload Sermon
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs-4.min.js"></script>
<script>
$(document).ready(function() {
    $('#content').summernote({
                height: 300,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'italic', 'clear']],
                    ['fontname', ['fontname']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['height', ['height']],
                    ['table', ['table']],
                    ['insert', ['link']],
                    ['view', ['fullscreen', 'codeview', 'help']]
                ]
            });
});
</script>
</body>
</html>
