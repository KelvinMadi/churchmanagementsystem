<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['member']);
$user = get_user();

// Payment gateways config (use your real keys in production)
$paystack_public_key = 'pk_test_xxxxxxxxxxxxxxxxxxxxx';
$flutterwave_public_key = 'FLWPUBK_TEST-xxxxxxxxxxxxxxxxxxxx';
$stripe_public_key = 'pk_test_xxxxxxxxxxxxxxxxxxxxx';

$paystack_secret = 'sk_test_xxxxxxxxxxxxxxxxxxxxx';
$flutterwave_secret = 'FLWSECK_TEST-xxxxxxxxxxxxxxxxxxxx';
$stripe_secret = 'sk_test_xxxxxxxxxxxxxxxxxxxxx';

$status = $_GET['status'] ?? null;
$message = '';

// --- Payment Verification Logic ---
if ($status === 'success') {
    // Paystack verification
    if (isset($_GET['reference'])) {
        $reference = $_GET['reference'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.paystack.co/transaction/verify/" . $reference);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $paystack_secret",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $res = json_decode($result, true);
        curl_close($ch);
        if (isset($res['status']) && $res['status'] && $res['data']['status'] === 'success') {
            // Record donation in DB
            $amount = $res['data']['amount'] / 100;
            $description = $res['data']['metadata']['description'] ?? 'Online Donation';
            $user_id = $res['data']['metadata']['user_id'] ?? $user['id'];
            $email = $res['data']['customer']['email'] ?? $user['email'];
            $date = date('Y-m-d');
            $stmt = $conn->prepare('INSERT INTO donations (amount, description, donor_name, date, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
            $stmt->execute([$amount, $description, $email, $date, $user_id]);
            $to = $email;
            $subject = 'Thank you for your donation';
            $body = "Dear donor,\n\nThank you for your generous donation of ₵" . number_format($amount, 2) . " on $date.\nDescription: $description\n\nWe appreciate your support!\n\nBest regards,\nChurch Management Team";
            $headers = 'From: no-reply@yourchurch.com';
            @mail($to, $subject, $body, $headers);
            $message = '<div class="alert alert-success">Payment verified and donation recorded! Thank you for your support. A receipt has been sent to your email.</div>';
        } else {
            $message = '<div class="alert alert-danger">Payment verification failed. Please contact support.</div>';
        }
    }
    // Flutterwave verification
    elseif (isset($_GET['tx_ref']) && isset($_GET['transaction_id'])) {
        $tx_ref = $_GET['tx_ref'];
        $transaction_id = $_GET['transaction_id'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.flutterwave.com/v3/transactions/$transaction_id/verify");
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $flutterwave_secret",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $res = json_decode($result, true);
        curl_close($ch);
        if (isset($res['status']) && $res['status'] === 'success' && $res['data']['status'] === 'successful') {
            $amount = $res['data']['amount'];
            $description = $res['data']['meta']['description'] ?? 'Online Donation';
            $user_id = $res['data']['meta']['user_id'] ?? $user['id'];
            $email = $res['data']['customer']['email'] ?? $user['email'];
            $date = date('Y-m-d');
            $stmt = $conn->prepare('INSERT INTO donations (amount, description, donor_name, date, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
            $stmt->execute([$amount, $description, $email, $date, $user_id]);
            $to = $email;
            $subject = 'Thank you for your donation';
            $body = "Dear donor,\n\nThank you for your generous donation of ₵" . number_format($amount, 2) . " on $date.\nDescription: $description\n\nWe appreciate your support!\n\nBest regards,\nChurch Management Team";
            $headers = 'From: no-reply@yourchurch.com';
            @mail($to, $subject, $body, $headers);
            $message = '<div class="alert alert-success">Payment verified and donation recorded! Thank you for your support. A receipt has been sent to your email.</div>';
        } else {
            $message = '<div class="alert alert-danger">Payment verification failed. Please contact support.</div>';
        }
    }
    // Stripe verification (stub)
    elseif (isset($_GET['session_id'])) {
        require_once '../vendor/autoload.php'; // Make sure Stripe PHP SDK is installed
        \Stripe\Stripe::setApiKey($stripe_secret);
        try {
            $session = \Stripe\Checkout\Session::retrieve($_GET['session_id']);
            if ($session && $session->payment_status === 'paid') {
                $amount = $session->amount_total / 100;
                $description = $session->metadata->description ?? 'Online Donation';
                $user_id = $session->metadata->user_id ?? $user['id'];
                $email = $session->customer_details->email ?? $user['email'];
                $date = date('Y-m-d');
                $stmt = $conn->prepare('INSERT INTO donations (amount, description, donor_name, date, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
                $stmt->execute([$amount, $description, $email, $date, $user_id]);
                $to = $email;
                $subject = 'Thank you for your donation';
                $body = "Dear donor,\n\nThank you for your generous donation of ₵" . number_format($amount, 2) . " on $date.\nDescription: $description\n\nWe appreciate your support!\n\nBest regards,\nChurch Management Team";
                $headers = 'From: no-reply@yourchurch.com';
                @mail($to, $subject, $body, $headers);
                $message = '<div class="alert alert-success">Stripe payment verified and donation recorded! Thank you for your support. A receipt has been sent to your email.</div>';
            } else {
                $message = '<div class="alert alert-danger">Stripe payment verification failed. Please contact support.</div>';
            }
        } catch (Exception $e) {
            $message = '<div class="alert alert-danger">Stripe error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
    }
}
elseif ($status === 'cancel') {
    $message = '<div class="alert alert-warning">Payment was cancelled.</div>';
} elseif ($status === 'failed') {
    $message = '<div class="alert alert-danger">Payment failed. Please try again.</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make a Donation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-hand-holding-usd me-2"></i>Make a Donation</h4>
                </div>
                <div class="card-body">
                    <?php echo $message; ?>
                    <form id="donationForm">
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount (GHS)</label>
                            <input type="number" min="1" step="0.01" class="form-control" id="amount" name="amount" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description (optional)</label>
                            <input type="text" class="form-control" id="description" name="description">
                        </div>
                        <div class="mb-3">
                            <label for="gateway" class="form-label">Payment Method</label>
                            <select class="form-select" id="gateway" name="gateway" required onchange="showPaymentDetails()">
                                <option value="">Select Payment Method</option>
                                <optgroup label="Online Payment Gateways">
                                    <option value="paystack">Paystack</option>
                                    <option value="flutterwave">Flutterwave</option>
                                    <option value="stripe">Stripe</option>
                                </optgroup>
                                <optgroup label="Mobile Money">
                                    <option value="mtn_momo">MTN Mobile Money</option>
                                    <option value="vodafone_cash">Vodafone Cash</option>
                                    <option value="airteltigo_money">AirtelTigo Money</option>
                                </optgroup>
                                <optgroup label="Bank Transfer">
                                    <option value="bank_transfer">Local Bank Transfer</option>
                                    <option value="gcb_bank">GCB Bank</option>
                                    <option value="ecobank">Ecobank Ghana</option>
                                    <option value="absa_bank">Absa Bank Ghana</option>
                                </optgroup>
                                <optgroup label="Cryptocurrency">
                                    <option value="bitcoin">Bitcoin (BTC)</option>
                                    <option value="ethereum">Ethereum (ETH)</option>
                                    <option value="usdt">Tether (USDT)</option>
                                    <option value="bnb">Binance Coin (BNB)</option>
                                </optgroup>
                            </select>
                        </div>
                        <!-- Payment Details Section -->
                        <div id="paymentDetails" class="mb-3" style="display: none;">
                            <!-- Mobile Money Details -->
                            <div id="momoDetails" class="payment-method-details" style="display: none;">
                                <div class="alert alert-info">
                                    <h6><i class="fas fa-mobile-alt me-2"></i>Mobile Money Instructions</h6>
                                    <p class="mb-2">Please follow these steps:</p>
                                    <ol class="mb-0">
                                        <li>Dial the USSD code for your network</li>
                                        <li>Select "Send Money" or "Transfer"</li>
                                        <li>Enter the church's mobile money number</li>
                                        <li>Enter the amount and confirm</li>
                                    </ol>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label">Your Mobile Number</label>
                                        <input type="tel" class="form-control" id="momo_number" placeholder="0XX XXX XXXX">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Network</label>
                                        <select class="form-select" id="momo_network">
                                            <option value="mtn">MTN (*170#)</option>
                                            <option value="vodafone">Vodafone (*110#)</option>
                                            <option value="airteltigo">AirtelTigo (*185#)</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <strong>Church Mobile Money Number: 054 526 5282</strong>
                                </div>
                            </div>
                            
                            <!-- Bank Transfer Details -->
                            <div id="bankDetails" class="payment-method-details" style="display: none;">
                                <div class="alert alert-info">
                                    <h6><i class="fas fa-university me-2"></i>Bank Transfer Details</h6>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <strong>Account Name:</strong><br>
                                            Grace Community Church<br><br>
                                            <strong>Account Number:</strong><br>
                                            1234567890<br><br>
                                            <strong>Bank:</strong><br>
                                            Ghana Commercial Bank
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Branch:</strong><br>
                                            Accra Main Branch<br><br>
                                            <strong>Sort Code:</strong><br>
                                            040123<br><br>
                                            <strong>Reference:</strong><br>
                                            DONATION-<?php echo strtoupper(substr(md5($user['email']), 0, 8)); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Transaction Reference/ID</label>
                                    <input type="text" class="form-control" id="bank_reference" placeholder="Enter your transaction reference">
                                </div>
                            </div>
                            
                            <!-- Cryptocurrency Details -->
                            <div id="cryptoDetails" class="payment-method-details" style="display: none;">
                                <div class="alert alert-warning">
                                    <h6><i class="fab fa-bitcoin me-2"></i>Cryptocurrency Donation</h6>
                                    <p class="mb-2">Send your donation to the wallet address below:</p>
                                </div>
                                <div id="cryptoWalletInfo">
                                    <!-- Will be populated by JavaScript -->
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Transaction Hash/ID</label>
                                    <input type="text" class="form-control" id="crypto_hash" placeholder="Enter transaction hash after sending">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Sender Wallet Address</label>
                                    <input type="text" class="form-control" id="sender_wallet" placeholder="Your wallet address">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Donate Now</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// Cryptocurrency wallet addresses
const cryptoWallets = {
    bitcoin: {
        address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
        network: 'Bitcoin',
        symbol: 'BTC'
    },
    ethereum: {
        address: '0x742d35Cc6634C0532925a3b8D4C4F8b4C8C8C8C8',
        network: 'Ethereum',
        symbol: 'ETH'
    },
    usdt: {
        address: '0x742d35Cc6634C0532925a3b8D4C4F8b4C8C8C8C8',
        network: 'Ethereum (ERC-20)',
        symbol: 'USDT'
    },
    bnb: {
        address: 'bnb1grpf0955h0ykzq3ar5nmum7y6gdfl6lxfn46h2',
        network: 'Binance Smart Chain',
        symbol: 'BNB'
    }
};

function showPaymentDetails() {
    const gateway = document.getElementById('gateway').value;
    const paymentDetails = document.getElementById('paymentDetails');
    const momoDetails = document.getElementById('momoDetails');
    const bankDetails = document.getElementById('bankDetails');
    const cryptoDetails = document.getElementById('cryptoDetails');
    
    // Hide all details first
    paymentDetails.style.display = 'none';
    momoDetails.style.display = 'none';
    bankDetails.style.display = 'none';
    cryptoDetails.style.display = 'none';
    
    if (gateway) {
        paymentDetails.style.display = 'block';
        
        // Show relevant payment method details
        if (['mtn_momo', 'vodafone_cash', 'airteltigo_money'].includes(gateway)) {
            momoDetails.style.display = 'block';
            updateMomoNetwork(gateway);
        } else if (['bank_transfer', 'gcb_bank', 'ecobank', 'absa_bank'].includes(gateway)) {
            bankDetails.style.display = 'block';
            updateBankDetails(gateway);
        } else if (['bitcoin', 'ethereum', 'usdt', 'bnb'].includes(gateway)) {
            cryptoDetails.style.display = 'block';
            updateCryptoWallet(gateway);
        }
    }
}

function updateMomoNetwork(gateway) {
    const networkSelect = document.getElementById('momo_network');
    const networkMap = {
        'mtn_momo': 'mtn',
        'vodafone_cash': 'vodafone',
        'airteltigo_money': 'airteltigo'
    };
    
    if (networkMap[gateway]) {
        networkSelect.value = networkMap[gateway];
    }
}

function updateBankDetails(gateway) {
    const bankInfo = document.querySelector('#bankDetails .alert-info');
    const bankDetails = {
        'gcb_bank': {
            name: 'Ghana Commercial Bank',
            account: '1234567890',
            branch: 'Accra Main Branch',
            sort: '040123'
        },
        'ecobank': {
            name: 'Ecobank Ghana',
            account: '0987654321',
            branch: 'Osu Branch',
            sort: '130456'
        },
        'absa_bank': {
            name: 'Absa Bank Ghana',
            account: '5555666677',
            branch: 'Airport City Branch',
            sort: '030789'
        }
    };
    
    if (bankDetails[gateway]) {
        const bank = bankDetails[gateway];
        bankInfo.innerHTML = `
            <h6><i class="fas fa-university me-2"></i>Bank Transfer Details</h6>
            <div class="row">
                <div class="col-md-6">
                    <strong>Account Name:</strong><br>
                    Grace Community Church<br><br>
                    <strong>Account Number:</strong><br>
                    ${bank.account}<br><br>
                    <strong>Bank:</strong><br>
                    ${bank.name}
                </div>
                <div class="col-md-6">
                    <strong>Branch:</strong><br>
                    ${bank.branch}<br><br>
                    <strong>Sort Code:</strong><br>
                    ${bank.sort}<br><br>
                    <strong>Reference:</strong><br>
                    DONATION-<?php echo strtoupper(substr(md5($user['email']), 0, 8)); ?>
                </div>
            </div>
        `;
    }
}

function updateCryptoWallet(gateway) {
    const cryptoWalletInfo = document.getElementById('cryptoWalletInfo');
    const wallet = cryptoWallets[gateway];
    
    if (wallet) {
        cryptoWalletInfo.innerHTML = `
            <div class="card bg-light mb-3">
                <div class="card-body">
                    <h6><i class="fab fa-bitcoin me-2"></i>${wallet.network} (${wallet.symbol})</h6>
                    <div class="mb-2">
                        <strong>Wallet Address:</strong>
                        <div class="input-group">
                            <input type="text" class="form-control font-monospace" value="${wallet.address}" readonly id="walletAddress">
                            <button class="btn btn-outline-secondary" type="button" onclick="copyWalletAddress()">
                                <i class="fas fa-copy"></i> Copy
                            </button>
                        </div>
                    </div>
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        Send only ${wallet.symbol} to this address. Sending other cryptocurrencies may result in permanent loss.
                    </small>
                </div>
            </div>
        `;
    }
}

function copyWalletAddress() {
    const walletInput = document.getElementById('walletAddress');
    walletInput.select();
    walletInput.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(walletInput.value);
    
    // Show feedback
    const copyBtn = event.target.closest('button');
    const originalText = copyBtn.innerHTML;
    copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
    copyBtn.classList.remove('btn-outline-secondary');
    copyBtn.classList.add('btn-success');
    
    setTimeout(() => {
        copyBtn.innerHTML = originalText;
        copyBtn.classList.remove('btn-success');
        copyBtn.classList.add('btn-outline-secondary');
    }, 2000);
}

document.getElementById('donationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const form = e.target;
    const gateway = document.getElementById('gateway').value;
    const amount = document.getElementById('amount').value;
    const description = document.getElementById('description').value;
    
    // Handle different payment methods
    if (['paystack', 'flutterwave', 'stripe'].includes(gateway)) {
        // Online payment gateways - use existing API
        const data = new FormData(form);
        fetch('../api/donations.php', {
            method: 'POST',
            body: data
        })
        .then(res => res.json())
        .then(res => {
            if (res.status === 'success' && res.redirect_url) {
                window.location.href = res.redirect_url;
            } else {
                alert(res.message || 'An error occurred.');
            }
        })
        .catch(() => alert('An error occurred.'));
    } else {
        // Manual payment methods - show confirmation
        handleManualPayment(gateway, amount, description);
    }
});

function handleManualPayment(gateway, amount, description) {
    const paymentMethods = {
        'mtn_momo': 'MTN Mobile Money',
        'vodafone_cash': 'Vodafone Cash',
        'airteltigo_money': 'AirtelTigo Money',
        'bank_transfer': 'Bank Transfer',
        'gcb_bank': 'GCB Bank Transfer',
        'ecobank': 'Ecobank Transfer',
        'absa_bank': 'Absa Bank Transfer',
        'bitcoin': 'Bitcoin',
        'ethereum': 'Ethereum',
        'usdt': 'Tether (USDT)',
        'bnb': 'Binance Coin'
    };
    
    const methodName = paymentMethods[gateway] || gateway;
    
    if (confirm(`Please complete your ${methodName} payment of GHS ${amount} and click OK to confirm. Make sure to save your transaction reference/hash.`)) {
        // Collect additional payment details
        const formData = new FormData();
        formData.append('amount', amount);
        formData.append('description', description || 'Manual Payment Donation');
        formData.append('gateway', gateway);
        
        // Add method-specific data
        if (['mtn_momo', 'vodafone_cash', 'airteltigo_money'].includes(gateway)) {
            const mobileNumber = document.getElementById('momo_number')?.value || '';
            formData.append('mobile_number', mobileNumber);
        } else if (['bank_transfer', 'gcb_bank', 'ecobank', 'absa_bank'].includes(gateway)) {
            const bankReference = document.getElementById('bank_reference')?.value || '';
            formData.append('transaction_reference', bankReference);
        } else if (['bitcoin', 'ethereum', 'usdt', 'bnb'].includes(gateway)) {
            const cryptoHash = document.getElementById('crypto_hash')?.value || '';
            const senderWallet = document.getElementById('sender_wallet')?.value || '';
            formData.append('crypto_hash', cryptoHash);
            formData.append('sender_wallet', senderWallet);
        }
        
        // Send to API
        fetch('../api/donations.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(res => {
            if (res.status === 'success') {
                alert(res.message);
                // Reset form
                document.getElementById('donationForm').reset();
                showPaymentDetails(); // Hide payment details
            } else {
                alert(res.message || 'An error occurred while processing your donation.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your donation. Please try again.');
        });
    }
}
</script>
</body>
</html>