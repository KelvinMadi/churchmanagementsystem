<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin', 'pastor']);

$user = get_user();
$db = new FileDB();
$csrf_token = generate_csrf_token();

// Handle verification actions
if ($_POST) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger">Invalid session token. Please refresh and try again.</div>';
    } else {
    $action = $_POST['action'] ?? '';
    $donationId = $_POST['donation_id'] ?? '';
    
    if ($action === 'verify' && $donationId) {
        $db->verifyDonation($donationId, $user['id']);
        $message = '<div class="alert alert-success">Donation verified successfully!</div>';
    } elseif ($action === 'reject' && $donationId) {
        $reason = $_POST['reason'] ?? 'No reason provided';
        $db->rejectDonation($donationId, $reason, $user['id']);
        $message = '<div class="alert alert-warning">Donation rejected.</div>';
    }
    }
}

$pendingDonations = $db->getPendingDonations();
$allDonations = $db->getAllDonations();

// Filter donations by status
$verifiedDonations = array_filter($allDonations, function($d) { return $d['status'] === 'verified'; });
$rejectedDonations = array_filter($allDonations, function($d) { return $d['status'] === 'rejected'; });
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-check-circle me-2"></i>Donation Verification</h2>
                <a href="../dashboard/<?php echo $user['role']; ?>.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to Dashboard
                </a>
            </div>
            
            <?php echo $message ?? ''; ?>
            
            <!-- Tabs -->
            <ul class="nav nav-tabs" id="donationTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab">
                        <i class="fas fa-clock me-1"></i>Pending Verification 
                        <span class="badge bg-warning text-dark"><?php echo count($pendingDonations); ?></span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="verified-tab" data-bs-toggle="tab" data-bs-target="#verified" type="button" role="tab">
                        <i class="fas fa-check me-1"></i>Verified 
                        <span class="badge bg-success"><?php echo count($verifiedDonations); ?></span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="rejected-tab" data-bs-toggle="tab" data-bs-target="#rejected" type="button" role="tab">
                        <i class="fas fa-times me-1"></i>Rejected 
                        <span class="badge bg-danger"><?php echo count($rejectedDonations); ?></span>
                    </button>
                </li>
            </ul>
            
            <div class="tab-content" id="donationTabContent">
                <!-- Pending Donations -->
                <div class="tab-pane fade show active" id="pending" role="tabpanel">
                    <div class="card mt-3">
                        <div class="card-body">
                            <?php if (empty($pendingDonations)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                                    <h5>No pending donations</h5>
                                    <p class="text-muted">All donations have been processed.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Donor</th>
                                                <th>Amount</th>
                                                <th>Payment Method</th>
                                                <th>Details</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($pendingDonations as $donation): ?>
                                                <tr>
                                                    <td><?php echo date('M j, Y', strtotime($donation['created_at'])); ?></td>
                                                    <td>
                                                        <strong><?php echo $donation['donor_name'] !== null ? htmlspecialchars($donation['donor_name']) : 'Anonymous'; ?></strong><br>
                                                        <small class="text-muted"><?php echo $donation['donor_email'] !== null ? htmlspecialchars($donation['donor_email']) : 'No email provided'; ?></small>
                                                    </td>
                                                    <td>
                                                        <strong>GHS <?php echo number_format($donation['amount'], 2); ?></strong><br>
                                                        <small class="text-muted"><?php echo $donation['description'] !== null ? htmlspecialchars($donation['description']) : 'No description'; ?></small>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $methodNames = [
                                                            'mtn_momo' => 'MTN MoMo',
                                                            'vodafone_cash' => 'Vodafone Cash',
                                                            'airteltigo_money' => 'AirtelTigo Money',
                                                            'bank_transfer' => 'Bank Transfer',
                                                            'gcb_bank' => 'GCB Bank',
                                                            'ecobank' => 'Ecobank',
                                                            'absa_bank' => 'Absa Bank',
                                                            'bitcoin' => 'Bitcoin',
                                                            'ethereum' => 'Ethereum',
                                                            'usdt' => 'USDT',
                                                            'bnb' => 'BNB'
                                                        ];
                                                        echo $methodNames[$donation['payment_method']] ?? $donation['payment_method'];
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($donation['transaction_reference']): ?>
                                                            <small><strong>Ref:</strong> <?php echo htmlspecialchars($donation['transaction_reference']); ?></small><br>
                                                        <?php endif; ?>
                                                        <?php if ($donation['crypto_hash']): ?>
                                                            <small><strong>Hash:</strong> <?php echo htmlspecialchars(substr($donation['crypto_hash'], 0, 20)) . '...'; ?></small><br>
                                                        <?php endif; ?>
                                                        <?php if ($donation['sender_wallet']): ?>
                                                            <small><strong>Wallet:</strong> <?php echo htmlspecialchars(substr($donation['sender_wallet'], 0, 15)) . '...'; ?></small><br>
                                                        <?php endif; ?>
                                                        <?php if ($donation['mobile_number']): ?>
                                                            <small><strong>Mobile:</strong> <?php echo htmlspecialchars($donation['mobile_number']); ?></small>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group" role="group">
                                                            <button type="button" class="btn btn-success btn-sm" onclick="verifyDonation('<?php echo $donation['id']; ?>')">
                                                                <i class="fas fa-check"></i> Verify
                                                            </button>
                                                            <button type="button" class="btn btn-danger btn-sm" onclick="rejectDonation('<?php echo $donation['id']; ?>')">
                                                                <i class="fas fa-times"></i> Reject
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Verified Donations -->
                <div class="tab-pane fade" id="verified" role="tabpanel">
                    <div class="card mt-3">
                        <div class="card-body">
                            <?php if (empty($verifiedDonations)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-inbox text-muted fa-3x mb-3"></i>
                                    <h5>No verified donations</h5>
                                    <p class="text-muted">Verified donations will appear here.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Donor</th>
                                                <th>Amount</th>
                                                <th>Payment Method</th>
                                                <th>Verified By</th>
                                                <th>Verified Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach (array_reverse($verifiedDonations) as $donation): ?>
                                                <tr>
                                                    <td><?php echo date('M j, Y', strtotime($donation['created_at'])); ?></td>
                                                    <td>
                                                        <strong><?php echo $donation['donor_name'] !== null ? htmlspecialchars($donation['donor_name']) : 'Anonymous'; ?></strong><br>
                                                        <small class="text-muted"><?php echo $donation['donor_email'] !== null ? htmlspecialchars($donation['donor_email']) : 'No email provided'; ?></small>
                                                    </td>
                                                    <td>
                                                        <strong>GHS <?php echo number_format($donation['amount'], 2); ?></strong><br>
                                                        <small class="text-muted"><?php echo $donation['description'] !== null ? htmlspecialchars($donation['description']) : 'No description'; ?></small>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $methodNames = [
                                                            'mtn_momo' => 'MTN MoMo',
                                                            'vodafone_cash' => 'Vodafone Cash',
                                                            'airteltigo_money' => 'AirtelTigo Money',
                                                            'bank_transfer' => 'Bank Transfer',
                                                            'gcb_bank' => 'GCB Bank',
                                                            'ecobank' => 'Ecobank',
                                                            'absa_bank' => 'Absa Bank',
                                                            'bitcoin' => 'Bitcoin',
                                                            'ethereum' => 'Ethereum',
                                                            'usdt' => 'USDT',
                                                            'bnb' => 'BNB'
                                                        ];
                                                        echo $methodNames[$donation['payment_method']] ?? $donation['payment_method'];
                                                        ?>
                                                    </td>
                                                    <td>Admin</td>
                                                    <td><?php echo date('M j, Y H:i', strtotime($donation['verified_at'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Rejected Donations -->
                <div class="tab-pane fade" id="rejected" role="tabpanel">
                    <div class="card mt-3">
                        <div class="card-body">
                            <?php if (empty($rejectedDonations)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-inbox text-muted fa-3x mb-3"></i>
                                    <h5>No rejected donations</h5>
                                    <p class="text-muted">Rejected donations will appear here.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Donor</th>
                                                <th>Amount</th>
                                                <th>Payment Method</th>
                                                <th>Reason</th>
                                                <th>Rejected Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach (array_reverse($rejectedDonations) as $donation): ?>
                                                <tr>
                                                    <td><?php echo date('M j, Y', strtotime($donation['created_at'])); ?></td>
                                                    <td>
                                                        <strong><?php echo $donation['donor_name'] !== null ? htmlspecialchars($donation['donor_name']) : 'Anonymous'; ?></strong><br>
                                                        <small class="text-muted"><?php echo $donation['donor_email'] !== null ? htmlspecialchars($donation['donor_email']) : 'No email provided'; ?></small>
                                                    </td>
                                                    <td>
                                                        <strong>GHS <?php echo number_format($donation['amount'], 2); ?></strong><br>
                                                        <small class="text-muted"><?php echo $donation['description'] !== null ? htmlspecialchars($donation['description']) : 'No description'; ?></small>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $methodNames = [
                                                            'mtn_momo' => 'MTN MoMo',
                                                            'vodafone_cash' => 'Vodafone Cash',
                                                            'airteltigo_money' => 'AirtelTigo Money',
                                                            'bank_transfer' => 'Bank Transfer',
                                                            'gcb_bank' => 'GCB Bank',
                                                            'ecobank' => 'Ecobank',
                                                            'absa_bank' => 'Absa Bank',
                                                            'bitcoin' => 'Bitcoin',
                                                            'ethereum' => 'Ethereum',
                                                            'usdt' => 'USDT',
                                                            'bnb' => 'BNB'
                                                        ];
                                                        echo $methodNames[$donation['payment_method']] ?? $donation['payment_method'];
                                                        ?>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($donation['rejection_reason'] ?? 'No reason provided'); ?></td>
                                                    <td><?php echo date('M j, Y H:i', strtotime($donation['rejected_at'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Verification Form -->
<form id="verificationForm" method="POST" style="display: none;">
    <input type="hidden" name="action" id="action">
    <input type="hidden" name="donation_id" id="donation_id">
    <input type="hidden" name="reason" id="reason">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function verifyDonation(donationId) {
    if (confirm('Are you sure you want to verify this donation?')) {
        document.getElementById('action').value = 'verify';
        document.getElementById('donation_id').value = donationId;
        document.getElementById('verificationForm').submit();
    }
}

function rejectDonation(donationId) {
    const reason = prompt('Please provide a reason for rejection:');
    if (reason !== null && reason.trim() !== '') {
        document.getElementById('action').value = 'reject';
        document.getElementById('donation_id').value = donationId;
        document.getElementById('reason').value = reason;
        document.getElementById('verificationForm').submit();
    }
}
</script>
</body>
</html>
