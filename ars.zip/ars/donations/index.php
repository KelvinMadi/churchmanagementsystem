<?php
// Permanent redirection to the financial/donations.php page
header("HTTP/1.1 301 Moved Permanently");
header("Location: /financial/donations.php");
exit();
?>
