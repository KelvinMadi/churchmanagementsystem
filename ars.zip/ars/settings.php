<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_login();
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

// Get user details
$user_details = $user;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'update_settings') {
            // Handle notification preferences
            $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
            $sms_notifications = isset($_POST['sms_notifications']) ? 1 : 0;
            $weekly_digest = isset($_POST['weekly_digest']) ? 1 : 0;
            
            // Update settings in the database
            $result = $conn->query("UPDATE users SET 
                email_notifications = '$email_notifications',
                sms_notifications = '$sms_notifications',
                weekly_digest = '$weekly_digest'
                WHERE id = " . $user['id']);
                
            if ($result) {
                $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Settings updated successfully!</div>';
            } else {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error updating settings. Please try again.</div>';
            }
        } elseif ($action === 'change_password') {
            // Handle password change
            $current_password = $_POST['current_password'] ?? '';
            $new_password = $_POST['new_password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
                $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all password fields.</div>';
            } elseif ($new_password !== $confirm_password) {
                $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>New passwords do not match.</div>';
            } else {
                // Verify current password
                $storedUser = $conn->getUserById($user['id']);
                if ($storedUser && isset($storedUser['password']) && password_verify($current_password, $storedUser['password'])) {
                    // Update password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $result = $conn->query("UPDATE users SET password = '$hashed_password' WHERE id = " . $user['id']);
                    
                    if ($result) {
                        $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Password changed successfully!</div>';
                    } else {
                        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error updating password. Please try again.</div>';
                    }
                } else {
                    $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Current password is incorrect.</div>';
                }
            }
        } elseif ($action === 'update_profile') {
            // Handle profile updates
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            
            if (empty($name) || empty($email)) {
                $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
            } else {
                // Update user details
                $result = $conn->query("UPDATE users SET 
                    name = '" . $conn->real_escape_string($name) . "', 
                    email = '" . $conn->real_escape_string($email) . "'
                    WHERE id = " . $user['id']);
                
                if ($result) {
                    // Update member details if exists
                    $conn->query("UPDATE members SET 
                        phone = '" . $conn->real_escape_string($phone) . "'
                        WHERE user_id = " . $user['id']);
                    
                    // Update session
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_email'] = $email;
                    
                    $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Profile updated successfully!</div>';
                } else {
                    $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error updating profile. Please try again.</div>';
                }
            }
        }
        
        // Refresh user data
        $user = get_user();
        $user_details = $user;
    }
}

// Get member details if available
$member = [];
$members_result = $conn->query("SELECT * FROM members WHERE user_id = " . intval($user['id']));
if ($members_result && $members_result->num_rows > 0) {
    $member = $members_result->fetch_assoc();
    $user_details = array_merge($user_details, $member);
}

// Set default values for settings
$email_notifications = $user['email_notifications'] ?? 1;
$sms_notifications = $user['sms_notifications'] ?? 1;
$weekly_digest = $user['weekly_digest'] ?? 1;

// Include header
require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-3 mb-4">
            <!-- Profile Card -->
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="avatar-xxl mb-3">
                        <?php 
                            $name_parts = explode(' ', $user_details['name'] ?? 'U');
                            $initials = '';
                            foreach ($name_parts as $part) {
                                $initials .= strtoupper(substr($part, 0, 1));
                                if (strlen($initials) >= 2) break;
                            }
                        ?>
                        <div class="avatar-text" style="width: 120px; height: 120px; font-size: 48px; background-color: #e67e22; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto;">
                            <?php echo $initials; ?>
                        </div>
                    </div>
                    <h4 class="mb-1"><?php echo htmlspecialchars($user_details['name']); ?></h4>
                    <p class="text-muted mb-3"><?php echo htmlspecialchars($user_details['email']); ?></p>
                    <div class="d-flex justify-content-center gap-2">
                        <a href="profile.php" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-user-edit me-1"></i> Edit Profile
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Navigation -->
            <div class="card">
                <div class="list-group list-group-flush">
                    <a href="#profile" class="list-group-item list-group-item-action active" data-bs-toggle="tab">
                        <i class="fas fa-user me-2"></i> Profile
                    </a>
                    <a href="#notifications" class="list-group-item list-group-item-action" data-bs-toggle="tab">
                        <i class="fas fa-bell me-2"></i> Notifications
                    </a>
                    <a href="#security" class="list-group-item list-group-item-action" data-bs-toggle="tab">
                        <i class="fas fa-lock me-2"></i> Security
                    </a>
                    <a href="#preferences" class="list-group-item list-group-item-action" data-bs-toggle="tab">
                        <i class="fas fa-cog me-2"></i> Preferences
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-lg-9">
            <?php echo $message; ?>
            
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Account Settings</h5>
                    <a href="dashboard-pastor.php" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                    </a>
                </div>
                <div class="card-body">
                    <div class="tab-content">
                        <!-- Profile Tab -->
                        <div class="tab-pane fade show active" id="profile">
                            <h5 class="mb-4">Profile Information</h5>
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="action" value="update_profile">
                                
                                <div class="row mb-3">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Full Name *</label>
                                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user_details['name'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Email Address *</label>
                                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user_details['email'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Phone Number</label>
                                        <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($user_details['phone'] ?? ''); ?>">
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-save me-1"></i> Save Changes
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Notifications Tab -->
                        <div class="tab-pane fade" id="notifications">
                            <h5 class="mb-4">Notification Preferences</h5>
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="action" value="update_settings">
                                
                                <div class="mb-4">
                                    <h6 class="mb-3">Email Notifications</h6>
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="emailNotifications" name="email_notifications" <?php echo $email_notifications ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="emailNotifications">Enable email notifications</label>
                                        <div class="form-text">Receive important updates via email</div>
                                    </div>
                                    
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="weeklyDigest" name="weekly_digest" <?php echo $weekly_digest ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="weeklyDigest">Weekly digest</label>
                                        <div class="form-text">Get a weekly summary of activities</div>
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <h6 class="mb-3">SMS Notifications</h6>
                                    <div class="form-check form-switch mb-3">
                                        <input class="form-check-input" type="checkbox" id="smsNotifications" name="sms_notifications" <?php echo $sms_notifications ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="smsNotifications">Enable SMS notifications</label>
                                        <div class="form-text">Receive important alerts via text message</div>
                                    </div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Save Preferences
                                </button>
                            </form>
                        </div>
                        
                        <!-- Security Tab -->
                        <div class="tab-pane fade" id="security">
                            <h5 class="mb-4">Change Password</h5>
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="action" value="change_password">
                                
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="mb-3">
                                            <label class="form-label">Current Password *</label>
                                            <input type="password" name="current_password" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">New Password *</label>
                                            <input type="password" name="new_password" class="form-control" required>
                                            <div class="form-text">Use 8 or more characters with a mix of letters, numbers & symbols</div>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Confirm New Password *</label>
                                            <input type="password" name="confirm_password" class="form-control" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-key me-1"></i> Update Password
                                        </button>
                                    </div>
                                </div>
                            </form>
                            
                            <hr class="my-4">
                            
                            <h5 class="mb-3">Sessions</h5>
                            <div class="card bg-light">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Current Session</h6>
                                            <p class="small text-muted mb-0">
                                                <i class="fas fa-circle text-success me-1"></i> Active now
                                            </p>
                                        </div>
                                        <div class="text-end">
                                            <p class="small mb-0"><?php echo date('F j, Y \a\t g:i A'); ?></p>
                                            <p class="small text-muted mb-0"><?php echo $_SERVER['REMOTE_ADDR']; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Preferences Tab -->
                        <div class="tab-pane fade" id="preferences">
                            <h5 class="mb-4">Display Preferences</h5>
                            <form>
                                <div class="mb-4">
                                    <h6 class="mb-3">Theme</h6>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="theme" id="lightTheme" checked>
                                        <label class="form-check-label" for="lightTheme">
                                            <i class="fas fa-sun me-2"></i> Light
                                        </label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="theme" id="darkTheme">
                                        <label class="form-check-label" for="darkTheme">
                                            <i class="fas fa-moon me-2"></i> Dark
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="theme" id="systemTheme">
                                        <label class="form-check-label" for="systemTheme">
                                            <i class="fas fa-desktop me-2"></i> System Default
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <h6 class="mb-3">Time Zone</h6>
                                    <select class="form-select" style="max-width: 300px;">
                                        <option>(UTC-05:00) Eastern Time (US & Canada)</option>
                                        <option>(UTC-06:00) Central Time (US & Canada)</option>
                                        <option>(UTC-07:00) Mountain Time (US & Canada)</option>
                                        <option>(UTC-08:00) Pacific Time (US & Canada)</option>
                                    </select>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Save Preferences
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .avatar-xxl {
        width: 120px;
        height: 120px;
        margin: 0 auto 1rem;
    }
    
    .avatar-text {
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #e67e22;
        color: white;
        font-weight: 600;
        border-radius: 50%;
    }
    
    .list-group-item {
        border-left: none;
        border-right: none;
        padding: 0.75rem 1.25rem;
    }
    
    .list-group-item:first-child {
        border-top: none;
    }
    
    .list-group-item.active {
        background-color: #f8f9fa;
        color: #e67e22;
        border-color: #f8f9fa;
        font-weight: 600;
    }
    
    .form-check-input:checked {
        background-color: #e67e22;
        border-color: #e67e22;
    }
    
    .form-check-input:focus {
        box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
        border-color: #e67e22;
    }
    
    .nav-tabs .nav-link {
        color: #6c757d;
        border: none;
        border-bottom: 2px solid transparent;
        padding: 0.75rem 1rem;
        font-weight: 500;
    }
    
    .nav-tabs .nav-link.active {
        color: #e67e22;
        background: none;
        border-bottom: 2px solid #e67e22;
    }
    
    .nav-tabs .nav-link:hover {
        border-color: transparent;
        color: #e67e22;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #e67e22;
        box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
    }
    
    .btn-primary {
        background-color: #e67e22;
        border-color: #e67e22;
    }
    
    .btn-primary:hover, .btn-primary:focus {
        background-color: #d35400;
        border-color: #d35400;
    }
    
    .btn-outline-primary {
        color: #e67e22;
        border-color: #e67e22;
    }
    
    .btn-outline-primary:hover {
        background-color: #e67e22;
        border-color: #e67e22;
    }
    
    .card {
        border: none;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        margin-bottom: 1.5rem;
    }
    
    .card-header {
        background-color: #fff;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        padding: 1.25rem 1.5rem;
    }
    
    .tab-content {
        padding: 1.5rem 0;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Activate tab from URL hash
    const hash = window.location.hash;
    if (hash) {
        const tab = document.querySelector(`.nav-link[href="${hash}"]`);
        if (tab) {
            const tabInstance = new bootstrap.Tab(tab);
            tabInstance.show();
        }
    }
    
    // Update URL hash when tab is shown
    const tabLinks = document.querySelectorAll('.nav-link[data-bs-toggle="tab"]');
    tabLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            window.location.hash = this.getAttribute('href');
        });
    });
    
    // Theme switcher
    const themeRadios = document.querySelectorAll('input[name="theme"]');
    themeRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            // This is a placeholder - you would implement theme switching logic here
            console.log('Theme changed to:', this.id);
        });
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
