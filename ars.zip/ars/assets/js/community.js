document.addEventListener('DOMContentLoaded', function() {
    // Handle like button clicks
    document.querySelectorAll('.like-btn').forEach(button => {
        button.addEventListener('click', function() {
            const postId = this.dataset.postId;
            const likeCount = this.querySelector('.like-count');
            const icon = this.querySelector('i');
            
            // Toggle like state
            const isLiked = this.classList.contains('liked');
            
            fetch('../community/api/like.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `post_id=${postId}&action=${isLiked ? 'unlike' : 'like'}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update UI
                    likeCount.textContent = data.like_count;
                    if (isLiked) {
                        this.classList.remove('liked');
                        icon.classList.remove('fas');
                        icon.classList.add('far');
                    } else {
                        this.classList.add('liked');
                        icon.classList.remove('far');
                        icon.classList.add('fas');
                    }
                }
            });
        });
    });

    // Handle comment submission
    document.querySelectorAll('.comment-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const postId = this.dataset.postId;
            const commentInput = this.querySelector('.comment-input');
            const commentsContainer = document.querySelector(`#comments-${postId} .comments-list`);
            
            fetch('../community/api/comment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `post_id=${postId}&content=${encodeURIComponent(commentInput.value)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add new comment to the list
                    const commentHtml = `
                        <div class="comment mb-3">
                            <div class="d-flex">
                                <img src="${data.user_avatar || '../images/default-avatar.png'}" 
                                     alt="${data.user_name}" class="profile-pic me-2">
                                <div>
                                    <div class="bg-light p-2 rounded">
                                        <strong>${data.user_name}</strong>
                                        <p class="mb-0">${data.comment.content}</p>
                                    </div>
                                    <small class="text-muted">Just now</small>
                                </div>
                            </div>
                        </div>
                    `;
                    
                    if (commentsContainer.children.length === 0) {
                        commentsContainer.innerHTML = commentHtml;
                    } else {
                        commentsContainer.insertAdjacentHTML('afterbegin', commentHtml);
                    }
                    
                    // Clear input
                    commentInput.value = '';
                    
                    // Update comment count
                    const commentCount = document.querySelector(`.comment-count[data-post-id="${postId}"]`);
                    if (commentCount) {
                        commentCount.textContent = parseInt(commentCount.textContent) + 1;
                    }
                }
            });
        });
    });

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
