document.addEventListener('DOMContentLoaded', function() {
    // Hero Slideshow
    const heroSlides = document.querySelectorAll('.hero-slide');
    let currentSlide = 0;
    const slideInterval = 5000; // Change slide every 5 seconds
    
    function showSlide(index) {
        // Hide all slides
        heroSlides.forEach(slide => slide.classList.remove('active'));
        
        // Show the current slide
        heroSlides[index].classList.add('active');
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % heroSlides.length;
        showSlide(currentSlide);
    }
    
    // Start the slideshow
    if (heroSlides.length > 1) {
        // Show first slide immediately
        showSlide(0);
        
        // Set interval for automatic slideshow
        setInterval(nextSlide, slideInterval);
        
        // Pause on hover
        const heroSection = document.querySelector('.hero-section');
        let slideIntervalId = setInterval(nextSlide, slideInterval);
        
        heroSection.addEventListener('mouseenter', () => {
            clearInterval(slideIntervalId);
        });
        
        heroSection.addEventListener('mouseleave', () => {
            clearInterval(slideIntervalId);
            slideIntervalId = setInterval(nextSlide, slideInterval);
        });
    } else if (heroSlides.length === 1) {
        // If there's only one slide, just show it
        showSlide(0);
    }
});
