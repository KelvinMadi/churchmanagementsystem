// Church Management System - Main JavaScript

// Document Ready Function
$(document).ready(function() {
    // Initialize Summernote Editor
    initializeSummernote();
    
    // Initialize Form Validation
    initializeFormValidation();
    
    // Initialize Tooltips
    initializeTooltips();
    
    // Initialize Animations
    initializeAnimations();
    
    // Initialize Search Functionality
    initializeSearch();
    
    // Initialize Dashboard Charts
    initializeCharts();
});

// Summernote Editor Initialization
function initializeSummernote() {
    if ($('#content').length) {
        $('#content').summernote({
            height: 300,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'italic', 'clear']],
                ['fontname', ['fontname']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['height', ['height']],
                ['table', ['table']],
                ['insert', ['link']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ],
            callbacks: {
                onImageUpload: function(files) {
                    // Handle image upload if needed
                    console.log('Image upload triggered');
                }
            }
        });
    }
}

// Form Validation
function initializeFormValidation() {
    // Login Form Validation
    $('form').on('submit', function(e) {
        let isValid = true;
        const requiredFields = $(this).find('[required]');
        
        requiredFields.each(function() {
            if (!$(this).val().trim()) {
                isValid = false;
                $(this).addClass('is-invalid');
                showAlert('Please fill all required fields.', 'warning');
            } else {
                $(this).removeClass('is-invalid');
            }
        });
        
        // Email validation
        const emailFields = $(this).find('input[type="email"]');
        emailFields.each(function() {
            const email = $(this).val();
            if (email && !isValidEmail(email)) {
                isValid = false;
                $(this).addClass('is-invalid');
                showAlert('Please enter a valid email address.', 'warning');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
        }
    });
    
    // Real-time validation
    $('input, select, textarea').on('blur', function() {
        validateField($(this));
    });
}

// Field Validation
function validateField(field) {
    const value = field.val().trim();
    const type = field.attr('type');
    const isRequired = field.prop('required');
    
    if (isRequired && !value) {
        field.addClass('is-invalid');
        return false;
    }
    
    if (type === 'email' && value && !isValidEmail(value)) {
        field.addClass('is-invalid');
        return false;
    }
    
    field.removeClass('is-invalid');
    return true;
}

// Email Validation
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Tooltip Initialization
function initializeTooltips() {
    $('[data-bs-toggle="tooltip"]').tooltip();
    $('[data-bs-toggle="popover"]').popover();
}

// Animation Initialization
function initializeAnimations() {
    // Fade in elements on scroll
    $(window).on('scroll', function() {
        $('.fade-in').each(function() {
            const elementTop = $(this).offset().top;
            const elementBottom = elementTop + $(this).outerHeight();
            const viewportTop = $(window).scrollTop();
            const viewportBottom = viewportTop + $(window).height();
            
            if (elementBottom > viewportTop && elementTop < viewportBottom) {
                $(this).addClass('fade-in');
            }
        });
    });
    
    // Card hover effects
    $('.card-hover').hover(
        function() {
            $(this).addClass('shadow-lg');
        },
        function() {
            $(this).removeClass('shadow-lg');
        }
    );
}

// Search Functionality
function initializeSearch() {
    // Real-time search
    $('#search-input').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        const searchableItems = $('.searchable-item');
        
        searchableItems.each(function() {
            const text = $(this).text().toLowerCase();
            if (text.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    
    // Clear search
    $('.clear-search').on('click', function() {
        $('#search-input').val('');
        $('.searchable-item').show();
    });
}

// Chart Initialization
function initializeCharts() {
    // Financial Chart (if Chart.js is available)
    if (typeof Chart !== 'undefined') {
        const ctx = document.getElementById('financialChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Tithes', 'Offerings', 'Other'],
                    datasets: [{
                        data: [60, 25, 15],
                        backgroundColor: [
                            '#28a745',
                            '#007bff',
                            '#ffc107'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }
}

// Alert System
function showAlert(message, type = 'info') {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Remove existing alerts
    $('.alert').remove();
    
    // Add new alert
    $('.container').first().prepend(alertHtml);
    
    // Auto-dismiss after 5 seconds
    setTimeout(function() {
        $('.alert').fadeOut();
    }, 5000);
}

// Loading Spinner
function showLoading() {
    const loadingHtml = `
        <div class="loading-overlay">
            <div class="spinner"></div>
            <p>Loading...</p>
        </div>
    `;
    $('body').append(loadingHtml);
}

function hideLoading() {
    $('.loading-overlay').remove();
}

// AJAX Form Submission
function submitFormAjax(form, successCallback) {
    const formData = new FormData(form);
    
    showLoading();
    
    $.ajax({
        url: form.action,
        type: form.method,
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            hideLoading();
            if (successCallback) {
                successCallback(response);
            }
        },
        error: function(xhr, status, error) {
            hideLoading();
            showAlert('An error occurred. Please try again.', 'danger');
        }
    });
}

// File Upload Handler
function handleFileUpload(input, previewElement) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            $(previewElement).attr('src', e.target.result);
        };
        reader.readAsDataURL(file);
    }
}

// Date Picker Initialization
function initializeDatePickers() {
    $('input[type="date"]').each(function() {
        if (!$(this).val()) {
            $(this).val(new Date().toISOString().split('T')[0]);
        }
    });
}

// Password Strength Checker
function checkPasswordStrength(password) {
    let strength = 0;
    const feedback = [];
    
    if (password.length >= 8) strength++;
    else feedback.push('At least 8 characters');
    
    if (/[a-z]/.test(password)) strength++;
    else feedback.push('Include lowercase letter');
    
    if (/[A-Z]/.test(password)) strength++;
    else feedback.push('Include uppercase letter');
    
    if (/[0-9]/.test(password)) strength++;
    else feedback.push('Include number');
    
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    else feedback.push('Include special character');
    
    return {
        strength: strength,
        feedback: feedback
    };
}

// Initialize Password Strength
$('input[type="password"]').on('input', function() {
    const password = $(this).val();
    const strength = checkPasswordStrength(password);
    const strengthBar = $(this).siblings('.password-strength');
    
    if (strengthBar.length) {
        strengthBar.find('.progress-bar').css('width', (strength.strength * 20) + '%');
        
        let strengthClass = 'bg-danger';
        if (strength.strength >= 4) strengthClass = 'bg-success';
        else if (strength.strength >= 3) strengthClass = 'bg-warning';
        
        strengthBar.find('.progress-bar').removeClass('bg-danger bg-warning bg-success').addClass(strengthClass);
    }
});

// Modal Functions
function openModal(modalId) {
    $(modalId).modal('show');
}

function closeModal(modalId) {
    $(modalId).modal('hide');
}

// Export Functions
function exportToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    const rows = table.getElementsByTagName('tr');
    let csv = [];
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const cols = row.querySelectorAll('td, th');
        const rowArray = [];
        
        for (let j = 0; j < cols.length; j++) {
            rowArray.push('"' + cols[j].innerText.replace(/"/g, '""') + '"');
        }
        
        csv.push(rowArray.join(','));
    }
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

// Print Functions
function printElement(elementId) {
    const element = document.getElementById(elementId);
    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Print</title></head><body>');
    printWindow.document.write(element.innerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
}

// Utility Functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Back to Top Button Functionality
function initializeBackToTop() {
    // Disabled: do not inject or show a Back to Top button
    return;
    const backToTopButton = $('<button>', {
        id: 'backToTop',
        class: 'btn btn-primary btn-lg back-to-top',
        html: '<i class="fas fa-arrow-up"></i>',
        title: 'Go to top',
        'aria-label': 'Back to top'
    }).appendTo('body');

    // Show/hide back to top button based on scroll position
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 300) {
            backToTopButton.addClass('show');
        } else {
            backToTopButton.removeClass('show');
        }
    });

    // Smooth scroll to top when back to top button is clicked
    backToTopButton.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({scrollTop: 0}, 800);
        return false;
    });
}

// Service Details Modal
function initializeServiceModal() {
    $('a[data-bs-toggle="modal"][data-bs-target="#serviceDetailsModal"]').on('click', function() {
        const service = $(this).data('service');
        const modal = $('#serviceDetailsModal');
        const modalTitle = modal.find('.modal-title');
        const modalBody = modal.find('.modal-body');
        const directionsBtn = $('#serviceDirectionsBtn');
        
        // Set modal content based on service
        let title = 'Service Details';
        let content = '';
        let directionsLink = 'https://maps.google.com?q=123+Church+Street';
        
        const serviceDetails = {
            'sunday': {
                title: 'Sunday Worship Service',
                content: `
                    <h5 class="mb-3">Join us for our main worship service</h5>
                    <p class="mb-4">Experience powerful worship, inspiring messages, and a welcoming community every Sunday morning.</p>
                    <div class="mb-4">
                        <h6>Service Details:</h6>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="far fa-clock me-2 text-primary"></i> Every Sunday at 11:00 AM</li>
                            <li class="mb-2"><i class="fas fa-map-marker-alt me-2 text-primary"></i> Main Sanctuary</li>
                            <li><i class="fas fa-user-friends me-2 text-primary"></i> All ages welcome</li>
                        </ul>
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Nursery and children's church available for kids up to 5th grade.
                    </div>
                `
            },
            'wednesday': {
                title: 'Wednesday Bible Study',
                content: `
                    <h5 class="mb-3">Midweek Bible Study</h5>
                    <p class="mb-4">Join us for an in-depth study of God's Word and prayer time in the middle of your week.</p>
                    <div class="mb-4">
                        <h6>Study Details:</h6>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="far fa-clock me-2 text-primary"></i> Every Wednesday at 7:00 PM</li>
                            <li class="mb-2"><i class="fas fa-map-marker-alt me-2 text-primary"></i> Fellowship Hall</li>
                            <li><i class="fas fa-book me-2 text-primary"></i> Current Study: Book of John</li>
                        </ul>
                    </div>
                `
            },
            'friday': {
                title: 'Friday Prayer Meeting',
                content: `
                    <h5 class="mb-3">Corporate Prayer</h5>
                    <p class="mb-4">Join us as we seek God's presence and intercede for our church, community, and world.</p>
                    <div class="mb-4">
                        <h6>Prayer Meeting Details:</h6>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="far fa-clock me-2 text-primary"></i> Every Friday at 7:00 PM</li>
                            <li class="mb-2"><i class="fas fa-map-marker-alt me-2 text-primary"></i> Prayer Room</li>
                            <li><i class="fas fa-pray me-2 text-primary"></i> All are welcome to join in prayer</li>
                        </ul>
                    </div>
                `
            },
            'sunday-school': {
                title: 'Sunday School',
                content: `
                    <h5 class="mb-3">Bible Classes for All Ages</h5>
                    <p class="mb-4">Grow in your faith through age-appropriate Bible teaching and discussion.</p>
                    <div class="mb-4">
                        <h6>Class Information:</h6>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="far fa-clock me-2 text-primary"></i> Sundays at 9:45 AM</li>
                            <li class="mb-2"><i class="fas fa-map-marker-alt me-2 text-primary"></i> Education Wing</li>
                            <li class="mb-2"><i class="fas fa-users me-2 text-primary"></i> Classes for all age groups</li>
                            <li><i class="fas fa-child me-2 text-primary"></i> Nursery available for young children</li>
                        </ul>
                    </div>
                `
            }
        };

        if (serviceDetails[service]) {
            title = serviceDetails[service].title;
            content = serviceDetails[service].content;
        }
        
        modalTitle.text(title);
        modalBody.html(content);
        directionsBtn.attr('href', directionsLink);
    });
}

// Smooth scrolling for anchor links
function initializeSmoothScrolling() {
    $('a[href^="#"]').on('click', function(e) {
        const targetId = $(this).attr('href');
        if (targetId === '#' || $(targetId).length === 0) return;
        
        e.preventDefault();
        const targetPosition = $(targetId).offset().top - 80; // Account for fixed header
        
        $('html, body').animate({
            scrollTop: targetPosition
        }, 800);
    });
}

// Initialize all components when DOM is ready
$(document).ready(function() {
    initializeDatePickers();
    
    // Add fade-in class to elements
    $('.card, .stat-card').addClass('fade-in');
    
    // Initialize any additional components
    console.log('Church Management System initialized successfully');
    
    // Initialize new components
    initializeBackToTop();
    initializeServiceModal();
    initializeSmoothScrolling();
});