(function () {
  const STORAGE_KEY = 'theme';
  const THEME_ATTR = 'data-theme';
  const DARK = 'dark';
  const LIGHT = 'light';

  function getStoredTheme() {
    try {
      return localStorage.getItem(STORAGE_KEY);
    } catch (e) {
      return null;
    }
  }

  function setStoredTheme(theme) {
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {
      // ignore
    }
  }

  function getSystemPref() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? DARK : LIGHT;
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute(THEME_ATTR, theme);
    // Update toggle icon/label if present
    const btn = document.getElementById('themeToggle');
    if (btn) {
      const isDark = theme === DARK;
      btn.setAttribute('aria-pressed', String(isDark));
      btn.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
      const icon = btn.querySelector('i');
      if (icon) {
        icon.className = isDark ? 'fas fa-moon' : 'fas fa-sun';
      }
    }
  }

  function initToggle() {
    // Inject floating toggle if none exists
    let btn = document.getElementById('themeToggle');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'themeToggle';
      btn.className = 'theme-toggle';
      btn.type = 'button';
      btn.innerHTML = '<i class="fas fa-moon"></i>';
      btn.title = 'Toggle theme';
      btn.setAttribute('aria-label', 'Toggle theme');
      btn.setAttribute('aria-pressed', 'false');
      document.body.appendChild(btn);
    }
    btn.addEventListener('click', function () {
      const current = document.documentElement.getAttribute(THEME_ATTR) || getSystemPref();
      const next = current === DARK ? LIGHT : DARK;
      setStoredTheme(next);
      applyTheme(next);
    });
  }

  // Apply initial theme - default to light theme for first-time visitors
  const stored = getStoredTheme();
  const systemPref = getSystemPref();
  const defaultTheme = 'light'; // Set light theme as default
  applyTheme(stored || defaultTheme);

  // Only listen for system changes if user hasn't made a choice
  // and respect the system preference as a fallback
  const mql = window.matchMedia('(prefers-color-scheme: dark)');
  if (!stored) {
    // Set light theme as default for first-time visitors
    setStoredTheme(defaultTheme);
    applyTheme(defaultTheme);
    
    // Still listen for system changes but don't apply them automatically
    if (mql && 'addEventListener' in mql) {
      mql.addEventListener('change', (e) => {
        // Only log the change, don't apply it
        console.log('System theme changed to:', e.matches ? 'dark' : 'light');
      });
    } else if (mql && 'addListener' in mql) {
      // Safari fallback
      mql.addListener((e) => {
        console.log('System theme changed to:', e.matches ? 'dark' : 'light');
      });
    }
  }

  // Initialize toggle after DOM ready
  document.addEventListener('DOMContentLoaded', function() {
    // Ensure the toggle button reflects the current theme
    const btn = document.getElementById('themeToggle');
    if (btn) {
      const currentTheme = document.documentElement.getAttribute(THEME_ATTR) || defaultTheme;
      const isDark = currentTheme === DARK;
      btn.setAttribute('aria-pressed', String(isDark));
      btn.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
      const icon = btn.querySelector('i');
      if (icon) {
        icon.className = isDark ? 'fas fa-moon' : 'fas fa-sun';
      }
    }
  });
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initToggle);
  } else {
    initToggle();
  }
})();
