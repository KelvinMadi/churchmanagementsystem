<?php
// Start session if not already started
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Include auth functions
require_once __DIR__ . '/auth.php';

// Get current user info
$user_id = $_SESSION['user_id'] ?? null;
$user_name = $_SESSION['user_name'] ?? null;
$user_role = $_SESSION['user_role'] ?? null;
$user_email = $_SESSION['user_email'] ?? null;

// Initialize avatar
if ($user_name) {
    $avatar_initial = strtoupper(substr($user_name, 0, 1));
    $avatar_colors = ['#e67e22', '#2c3e50', '#e74c3c', '#3498db', '#9b59b6', '#1abc9c', '#f1c40f'];
    $avatar_bg = $avatar_colors[ord($avatar_initial) % count($avatar_colors)];
    $first_name = explode(' ', $user_name)[0];
} else {
    $avatar_initial = 'U';
    $avatar_bg = '#e67e22';
    $first_name = 'User';
}

/**
 * Adjust the brightness of a hex color
 * @param string $hex Hex color code
 * @param int $steps Steps to adjust brightness (-255 to 255)
 * @return string Adjusted hex color
 */
function adjustBrightness($hex, $steps) {
    $steps = max(-255, min(255, $steps));
    $hex = str_replace('#', '', $hex);
    
    if (strlen($hex) == 3) {
        $hex = str_repeat(substr($hex, 0, 1), 2) . str_repeat(substr($hex, 1, 1), 2) . str_repeat(substr($hex, 2, 1), 2);
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    
    return '#' . $r_hex . $g_hex . $b_hex;
}

// Get current page for navigation highlighting
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$script_name = $_SERVER['SCRIPT_NAME'];

// For the homepage, explicitly set the current page
if ($request_uri === '/' || $request_uri === '/index.php' || $request_uri === '' || $script_name === '/index.php') {
    $current_page = 'index';
    $current_dir = '.';
} else {
    $current_page = basename($request_uri, '.php');
    $current_dir = basename(dirname($request_uri));
}

// Set base path
$base = isset($base_path) ? $base_path : '';

// Adjust base path for subdirectories
if (strpos($request_uri, '/ministry/') !== false) {
    $base = '../';
} elseif ($current_dir !== '.') {
    $base = ''; // Reset base if not in root
}

// Start output buffering to prevent any potential output before headers
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - ' : ''; ?>Church Management System</title>
    <script>
        // Early theme bootstrapping: set data-theme before CSS to avoid flash
        (function() {
            try {
                var stored = localStorage.getItem('theme');
            } catch (e) { stored = null; }
            var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            var theme = stored || (prefersDark ? 'dark' : 'light');
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo htmlspecialchars($base); ?>assets/css/style.css">
    <script src="<?php echo htmlspecialchars($base); ?>assets/js/theme-toggle.js" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Windsurf Accessibility -->
    <script src="https://cdn.jsdelivr.net/npm/@windsurf-ai/accessibility@latest/dist/windsurf-accessibility.min.js" async></script>
    <script>
        tailwind.config = {
            prefix: 'tw-',
            theme: {
                extend: {
                    colors: {
                        church: {
                            gold: '#d4af37',
                            blue: '#1e3a8a'
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="<?php echo ($current_page === 'index' && $current_dir === '.') ? 'home' : ''; ?> tw:bg-gray-50 tw:text-slate-800 tw:antialiased">
<!-- Main Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top tw:z-[1200] tw:bg-white tw:shadow-sm">
        <div class="container tw:max-w-7xl tw:px-4">
            <a class="navbar-brand" href="<?php echo htmlspecialchars($base); ?>index.php">
                <img src="<?php echo htmlspecialchars($base); ?>images/logo.webp" alt="Apostles Revelation Society" height="70">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page === 'index' && $current_dir === '.') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>index.php">
                            Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page === 'about') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>about.php">
                            About Us
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_dir === 'ministry') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>ministry/">
                            Ministries
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_dir === 'sermons') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>sermons/list.php">
                            Sermons
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_dir === 'events') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>events/list.php">
                            Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page === 'gallery') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>gallery.php">
                            Gallery
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page === 'service-times') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>service-times.php">
                            Service Times
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page === 'contact') ? 'active' : ''; ?>" 
                           href="<?php echo htmlspecialchars($base); ?>contact.php">
                            Contact
                        </a>
                    </li>
                    <?php if (isset($user_role) && in_array($user_role, ['admin', 'pastor'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-danger" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-lock me-1"></i>Admin
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminDropdown">
                            <?php if ($user_role === 'admin'): ?>
                            <li><h6 class="dropdown-header">Administration</h6></li>
                            <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>members/register.php">
                                <i class="fas fa-user-plus me-2"></i>Register Member
                            </a></li>
                            <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>reports/generate.php">
                                <i class="fas fa-chart-bar me-2"></i>Generate Reports
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><h6 class="dropdown-header">Quick Actions</h6></li>
                            <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>attendance/mark.php">
                                <i class="fas fa-clipboard-check me-2"></i>Mark Attendance
                            </a></li>
                            <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>financial/records.php">
                                <i class="fas fa-dollar-sign me-2"></i>Financial Records
                            </a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <ul class="navbar-nav ms-auto align-items-center">
                    <?php if ($user_id): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="position-relative me-2">
                                    <?php 
                                    $avatar_bg = '#e67e22'; // Default color
                                    $avatar_initial = strtoupper(substr($user_name, 0, 1));
                                    ?>
                                    <div class="avatar-container" style="width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, <?php echo $avatar_bg; ?> 0%, <?php echo adjustBrightness($avatar_bg, -20); ?> 100%); color: white; font-weight: 600; font-size: 1rem; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); transition: all 0.3s ease;">
                                        <?php echo $avatar_initial; ?>
                                    </div>
                                </div>
                                <span class="d-none d-md-inline"><?php echo htmlspecialchars($user_name); ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" style="min-width: 220px;">
                                <li class="px-3 py-3 border-bottom">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-container" style="width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, <?php echo $avatar_bg; ?> 0%, <?php echo adjustBrightness($avatar_bg, -20); ?> 100%); color: white; font-size: 1.25rem; font-weight: 600; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                                            <?php echo $avatar_initial; ?>
                                        </div>
                                        <div class="ms-3">
                                            <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($user_name); ?></h6>
                                            <small class="text-muted"><?php echo ucfirst($user_role); ?></small>
                                        </div>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>profile.php">
                                    <i class="fas fa-user me-2"></i>My Profile
                                </a></li>
                                <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>settings.php">
                                    <i class="fas fa-cog me-2"></i>Settings
                                </a></li>
                                <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>dashboard/member.php">
                                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                                </a></li>
                                <?php if (in_array($user_role, ['admin', 'pastor'])): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-primary" href="<?php echo htmlspecialchars($base); ?>admin/">
                                    <i class="fas fa-user-shield me-2"></i>Admin Dashboard
                                </a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?php echo htmlspecialchars($base); ?>logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                                </a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item me-2">
                            <a href="<?php echo htmlspecialchars($base); ?>register.php" class="btn btn-outline-primary px-3">
                                <i class="fas fa-user-plus me-1"></i> Join Us
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo htmlspecialchars($base); ?>login.php" class="btn btn-primary px-4">
                                <i class="fas fa-sign-in-alt me-1"></i> Login
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_id): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="position-relative me-2">
                                    <div class="avatar-container" style="width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, <?php echo $avatar_bg; ?> 0%, <?php echo adjustBrightness($avatar_bg, -20); ?> 100%); color: white; font-weight: 600; font-size: 1rem; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); transition: all 0.3s ease;">
                                        <?php echo $avatar_initial; ?>
                                        <span class="position-absolute bottom-0 end-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                                    </div>
                                </div>
                                <span class="d-none d-lg-inline ms-2 fw-medium text-dark">
                                    <?php echo htmlspecialchars($first_name); ?>
                                    <small class="d-block text-muted text-uppercase small" style="font-size: 0.65rem; letter-spacing: 0.5px;"><?php echo ucfirst($user_role); ?></small>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm" style="min-width: 220px; border: 1px solid rgba(0,0,0,0.05);">
                                <li class="px-3 py-2 border-bottom">
                                    <div class="d-flex align-items-center">
                                        <div class="me-3" style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, <?php echo $avatar_bg; ?> 0%, <?php echo adjustBrightness($avatar_bg, -20); ?> 100%); color: white; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 1.1rem;">
                                            <?php echo $avatar_initial; ?>
                                        </div>
                                        <div>
                                            <div class="fw-medium"><?php echo htmlspecialchars($user_name); ?></div>
                                            <small class="text-muted"><?php echo ucfirst($user_role); ?></small>
                                        </div>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider my-2"></li>
                                <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>dashboard/<?php echo strtolower($user_role); ?>.php">
                                    <i class="fas fa-tachometer-alt me-2 text-muted"></i> Dashboard
                                </a></li>
                                <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>profile.php">
                                    <i class="fas fa-user-circle me-2 text-muted"></i> My Profile
                                </a></li>
                                <li><a class="dropdown-item" href="<?php echo htmlspecialchars($base); ?>settings.php">
                                    <i class="fas fa-cog me-2 text-muted"></i> Settings
                                </a></li>
                                <li><hr class="dropdown-divider my-2"></li>
                                <li><a class="dropdown-item text-danger" href="<?php echo htmlspecialchars($base); ?>logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                                </a></li>
                            </ul>
                            <ul class="dropdown-menu dropdown-menu-end" style="min-width: 220px;">
                                <li class="px-3 py-3 border-bottom">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-container" style="width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, <?php echo $avatar_bg; ?> 0%, <?php echo adjustBrightness($avatar_bg, -20); ?> 100%); color: white; font-size: 1.25rem; font-weight: 600; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                                            <?php echo $avatar_initial; ?>
                                        </div>
                                        <div>
                                            <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h6>
                                            <small class="text-muted"><?php echo ucfirst($user_role); ?> Account</small>
                                        </div>
                                    </div>
                                </li>
                                <li><a class="dropdown-item py-2 d-flex align-items-center" href="<?php echo htmlspecialchars($base); ?>profile.php">
                                    <i class="fas fa-user-circle me-2" style="width: 20px; text-align: center; color: #6c757d;"></i>
                                    <span>My Profile</span>
                                </a></li>
                                <li><a class="dropdown-item py-2 d-flex align-items-center" href="<?php echo htmlspecialchars($base); ?>dashboard/<?php echo htmlspecialchars($user_role); ?>.php">
                                    <i class="fas fa-tachometer-alt me-2" style="width: 20px; text-align: center; color: #6c757d;"></i>
                                    <span>Dashboard</span>
                                </a></li>
                                <li><a class="dropdown-item py-2 d-flex align-items-center" href="<?php echo htmlspecialchars($base); ?>settings.php">
                                    <i class="fas fa-cog me-2" style="width: 20px; text-align: center; color: #6c757d;"></i>
                                    <span>Settings</span>
                                </a></li>
                                <li><hr class="dropdown-divider my-1"></li>
                                <li><a class="dropdown-item py-2 d-flex align-items-center text-danger" href="<?php echo htmlspecialchars($base); ?>logout.php">
                                    <i class="fas fa-sign-out-alt me-2" style="width: 20px; text-align: center;"></i>
                                    <span>Logout</span>
                                </a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
                
                <!-- Search Button (inside collapse) -->
                <div class="ms-3 d-none d-lg-block">
                    <button class="btn btn-outline-secondary border-0 tw:ring-1 tw:ring-slate-200 tw:hover:tw:ring-slate-300 tw:transition" type="button" data-bs-toggle="collapse" data-bs-target="#searchCollapse" aria-expanded="false" aria-controls="searchCollapse">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
            <!-- Right-aligned actions: Theme Toggle -->
            <div class="d-flex align-items-center ms-auto">
                <button id="themeToggle" class="btn btn-outline-secondary tw:ring-1 tw:ring-slate-200 tw:hover:tw:ring-slate-300 tw:transition" type="button" aria-label="Toggle theme" aria-pressed="false" title="Toggle theme">
                    <i class="fas fa-moon"></i>
                </button>
            </div>
        </div>
    </nav>
    
    <!-- Search Bar Collapse -->
    <div class="collapse bg-white" id="searchCollapse">
        <div class="container py-3 tw:max-w-7xl tw:px-4">
            <form class="d-flex" action="<?php echo htmlspecialchars($base); ?>search.php" method="GET">
                <div class="input-group tw:shadow-sm tw:ring-1 tw:ring-slate-200 tw:rounded-lg tw:overflow-hidden">
                    <input type="text" class="form-control" name="q" placeholder="Search our website..." aria-label="Search">
                    <button class="btn btn-primary tw:px-4" type="submit">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($current_page === 'index' && $current_dir === '.'): ?>
    <!-- Hero section has been moved to index.php for better control -->
    <?php endif; ?>

    <!-- Main Content -->
    <main class="mt-0">
        <?php if (isset($show_page_header) && $show_page_header): ?>
        <div class="container mt-4">
            <div class="row">
                <div class="col-12">
                    <h1 class="display-4 mb-3 text-center"><?php echo htmlspecialchars($page_title); ?></h1>
                    <?php if (isset($page_subtitle)): ?>
                    <p class="lead text-center mb-4"><?php echo htmlspecialchars($page_subtitle); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="container py-4">