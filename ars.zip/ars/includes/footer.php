    <!-- Footer -->
    <footer class="footer tw-bg-[#2c3e50] tw-text-white tw-pt-16 tw-pb-8 tw-relative tw-overflow-hidden">
        <!-- Wave Decoration -->
        <div class="tw-absolute tw-top-0 tw-left-0 tw-w-full tw-h-16 tw-overflow-hidden">
            <svg class="tw-absolute tw-bottom-0 tw-w-full tw-h-16" viewBox="0 0 1200 120" preserveAspectRatio="none">
                <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" class="tw-fill-current tw-text-[#e67e22]"></path>
            </svg>
        </div>
        
        <div class="container tw-max-w-7xl tw-px-4 tw-relative">
            <div class="row tw-gap-y-8">
                <!-- Brand/About -->
                <div class="col-lg-4 col-md-6">
                    <div class="tw-flex tw-items-center tw-mb-4">
                        <img src="<?php echo isset($base_path) ? $base_path : ''; ?>images/logo.webp" alt="Church" class="tw-h-12 tw-mr-3">
                        <h3 class="tw-text-2xl tw-font-bold tw-mb-0 tw-text-[#ffd700]">Apostolic Church</h3>
                    </div>
                    <p class="tw-text-gray-300 tw-mb-6">Empowering lives through faith, hope, and love. Join us in worship and community as we grow together in Christ.</p>
                    <div class="tw-flex tw-space-x-4">
                        <a href="#" class="tw-w-10 tw-h-10 tw-rounded-full tw-bg-[#e67e22] tw-flex tw-items-center tw-justify-center hover:tw-bg-[#d35400] tw-transition-colors tw-duration-300" aria-label="Facebook">
                            <i class="fab fa-facebook-f tw-text-white"></i>
                        </a>
                        <a href="#" class="tw-w-10 tw-h-10 tw-rounded-full tw-bg-[#e67e22] tw-flex tw-items-center tw-justify-center hover:tw-bg-[#d35400] tw-transition-colors tw-duration-300" aria-label="Twitter">
                            <i class="fab fa-twitter tw-text-white"></i>
                        </a>
                        <a href="#" class="tw-w-10 tw-h-10 tw-rounded-full tw-bg-[#e67e22] tw-flex tw-items-center tw-justify-center hover:tw-bg-[#d35400] tw-transition-colors tw-duration-300" aria-label="Instagram">
                            <i class="fab fa-instagram tw-text-white"></i>
                        </a>
                        <a href="#" class="tw-w-10 tw-h-10 tw-rounded-full tw-bg-[#e67e22] tw-flex tw-items-center tw-justify-center hover:tw-bg-[#d35400] tw-transition-colors tw-duration-300" aria-label="YouTube">
                            <i class="fab fa-youtube tw-text-white"></i>
                        </a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-2 col-md-6">
                    <h4 class="tw-text-lg tw-font-semibold tw-mb-4 tw-relative tw-pb-2 tw-text-[#ffd700]">
                        Quick Links
                        <span class="tw-absolute tw-bottom-0 tw-left-0 tw-w-10 tw-h-0.5 tw-bg-[#e67e22]"></span>
                    </h4>
                    <ul class="tw-space-y-2">
                        <li><a href="<?php echo isset($base_path) ? $base_path : ''; ?>index.php" class="tw-text-gray-300 hover:tw-text-white hover:tw-pl-2 tw-transition-all tw-duration-300 tw-inline-block tw-w-full">Home</a></li>
                        <li><a href="<?php echo isset($base_path) ? $base_path : ''; ?>about.php" class="tw-text-gray-300 hover:tw-text-white hover:tw-pl-2 tw-transition-all tw-duration-300 tw-inline-block tw-w-full">About Us</a></li>
                        <li><a href="<?php echo isset($base_path) ? $base_path : ''; ?>sermons/list.php" class="tw-text-gray-300 hover:tw-text-white hover:tw-pl-2 tw-transition-all tw-duration-300 tw-inline-block tw-w-full">Sermons</a></li>
                        <li><a href="<?php echo isset($base_path) ? $base_path : ''; ?>events/list.php" class="tw-text-gray-300 hover:tw-text-white hover:tw-pl-2 tw-transition-all tw-duration-300 tw-inline-block tw-w-full">Events</a></li>
                        <li><a href="<?php echo isset($base_path) ? $base_path : ''; ?>ministries.php" class="tw-text-gray-300 hover:tw-text-white hover:tw-pl-2 tw-transition-all tw-duration-300 tw-inline-block tw-w-full">Ministries</a></li>
                        <li><a href="<?php echo isset($base_path) ? $base_path : ''; ?>contact.php" class="tw-text-gray-300 hover:tw-text-white hover:tw-pl-2 tw-transition-all tw-duration-300 tw-inline-block tw-w-full">Contact</a></li>
                    </ul>
                </div>

                <!-- Service Times -->
                <div class="col-lg-3 col-md-6">
                    <h4 class="tw-text-lg tw-font-semibold tw-mb-4 tw-relative tw-pb-2 tw-text-[#ffd700]">
                        Service Times
                        <span class="tw-absolute tw-bottom-0 tw-left-0 tw-w-10 tw-h-0.5 tw-bg-[#e67e22]"></span>
                    </h4>
                    <ul class="tw-space-y-3">
                        <li class="tw-flex tw-items-start">
                            <div class="tw-w-2 tw-h-2 tw-rounded-full tw-bg-[#e67e22] tw-mt-2 tw-mr-3"></div>
                            <div>
                                <h5 class="tw-font-medium tw-text-white">Sunday Service</h5>
                                <p class="tw-text-sm tw-text-gray-300">9:00 AM - 12:00 PM</p>
                            </div>
                        </li>
                        <li class="tw-flex tw-items-start">
                            <div class="tw-w-2 tw-h-2 tw-rounded-full tw-bg-[#e67e22] tw-mt-2 tw-mr-3"></div>
                            <div>
                                <h5 class="tw-font-medium tw-text-white">Bible Study</h5>
                                <p class="tw-text-sm tw-text-gray-300">Wednesday, 7:00 PM</p>
                            </div>
                        </li>
                        <li class="tw-flex tw-items-start">
                            <div class="tw-w-2 tw-h-2 tw-rounded-full tw-bg-[#e67e22] tw-mt-2 tw-mr-3"></div>
                            <div>
                                <h5 class="tw-font-medium tw-text-white">Prayer Meeting</h5>
                                <p class="tw-text-sm tw-text-gray-300">Friday, 6:30 PM</p>
                            </div>
                        </li>
                    </ul>
                </div>

                <!-- Contact & Newsletter -->
                <div class="col-lg-3 col-md-6">
                    <h4 class="tw-text-lg tw-font-semibold tw-mb-4 tw-relative tw-pb-2 tw-text-[#ffd700]">
                        Contact Us
                        <span class="tw-absolute tw-bottom-0 tw-left-0 tw-w-10 tw-h-0.5 tw-bg-[#e67e22]"></span>
                    </h4>
                    <ul class="tw-mb-6 tw-space-y-3">
                        <li class="tw-flex tw-items-start">
                            <i class="fas fa-map-marker-alt tw-text-[#e67e22] tw-mt-1 tw-mr-3"></i>
                            <span class="tw-text-gray-300">123 Faith Avenue, Louisville, KY 40202</span>
                        </li>
                        <li class="tw-flex tw-items-center">
                            <i class="fas fa-phone-alt tw-text-[#e67e22] tw-mr-3"></i>
                            <a href="tel:+15025551234" class="tw-text-gray-300 hover:tw-text-white">(502) 555-1234</a>
                        </li>
                        <li class="tw-flex tw-items-center">
                            <i class="fas fa-envelope tw-text-[#e67e22] tw-mr-3"></i>
                            <a href="mailto:info@apostoliclouisville.org" class="tw-text-gray-300 hover:tw-text-white">info@apostoliclouisville.org</a>
                        </li>
                    </ul>
                    
                    <div class="tw-mt-8">
                        <h4 class="tw-text-lg tw-font-semibold tw-mb-4 tw-relative tw-pb-2 tw-text-[#ffd700]">
                            Newsletter
                            <span class="tw-absolute tw-bottom-0 tw-left-0 tw-w-10 tw-h-0.5 tw-bg-[#e67e22]"></span>
                        </h4>
                        <p class="tw-text-gray-300 tw-mb-3">Subscribe to receive updates and inspiration.</p>
                        <form action="#" method="post" class="tw-space-y-3">
                            <input type="email" class="tw-w-full tw-px-4 tw-py-2 tw-rounded tw-border-0 tw-bg-[#3a4f66] tw-text-white placeholder-gray-400 focus:tw-ring-2 focus:tw-ring-[#e67e22] focus:tw-outline-none" placeholder="Your email" required>
                            <button type="submit" class="tw-w-full tw-bg-[#e67e22] hover:tw-bg-[#d35400] tw-text-white tw-font-medium tw-py-2 tw-px-4 tw-rounded tw-transition-colors tw-duration-300">
                                Subscribe
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Copyright -->
            <div class="tw-border-t tw-border-gray-700 tw-mt-12 tw-pt-6 tw-flex tw-flex-col md:tw-flex-row md:tw-justify-between md:tw-items-center">
                <p class="tw-text-gray-400 tw-text-sm tw-mb-4 md:tw-mb-0">
                    &copy; <?php echo date('Y'); ?> Apostolic Church. All rights reserved.
                </p>
                <div class="tw-flex tw-space-x-4">
                    <a href="<?php echo isset($base_path) ? $base_path : ''; ?>privacy-policy.php" class="tw-text-gray-400 hover:tw-text-white tw-text-sm tw-transition-colors tw-duration-300">Privacy Policy</a>
                    <span class="tw-text-gray-600">|</span>
                    <span class="tw-text-gray-600">|</span>
                    <a href="<?php echo isset($base_path) ? $base_path : ''; ?>sitemap.php" class="tw-text-gray-400 hover:tw-text-white tw-text-sm tw-transition-colors tw-duration-300">Sitemap</a>
                </div>
    </footer>

<!-- JavaScript Libraries -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Core JS Files -->
<script src="<?php echo isset($base_path) ? $base_path : ''; ?>assets/js/theme-toggle.js"></script>
<script src="<?php echo isset($base_path) ? $base_path : ''; ?>assets/js/main.js"></script>

<!-- Page-specific JS -->
<?php if (strpos($_SERVER['REQUEST_URI'], 'index.php') !== false || $_SERVER['REQUEST_URI'] === '/'): ?>
<script src="<?php echo isset($base_path) ? $base_path : ''; ?>assets/js/hero-slideshow.js"></script>
<?php endif; ?>

<!-- Initialize components -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize theme toggle
        if (typeof initThemeToggle === 'function') {
            initThemeToggle();
        }
        
        // Initialize hero slideshow if it exists on the page
        if (document.querySelector('.hero-slideshow')) {
            const slides = document.querySelectorAll('.hero-slide');
            let currentSlide = 0;
            const slideInterval = 5000; // 5 seconds
            
            function showNextSlide() {
                // Remove active class from current slide
                slides[currentSlide].classList.remove('active');
                
                // Move to next slide
                currentSlide = (currentSlide + 1) % slides.length;
                
                // Add active class to new slide
                slides[currentSlide].classList.add('active');
            }
            
            // Start slideshow
            let slideShow = setInterval(showNextSlide, slideInterval);
            
            // Pause on hover
            const slideshowContainer = document.querySelector('.hero-slideshow');
            if (slideshowContainer) {
                slideshowContainer.addEventListener('mouseenter', () => {
                    clearInterval(slideShow);
                });
                
                slideshowContainer.addEventListener('mouseleave', () => {
                    slideShow = setInterval(showNextSlide, slideInterval);
                });
            }
        
        // Initialize chat if it exists on the page
        if (typeof initChat === 'function' && document.getElementById('chat-container')) {
            initChat();
        }
    });
</script>

<!-- Chatbot - Only load on pages that need it -->
<?php if (strpos($_SERVER['REQUEST_URI'], 'contact') !== false || strpos($_SERVER['REQUEST_URI'], 'about') !== false || strpos($_SERVER['REQUEST_URI'], 'index') !== false || $_SERVER['REQUEST_URI'] === '/'): ?>
<link rel="stylesheet" href="<?php echo isset($base_path) ? $base_path : ''; ?>assets/chat/chat.css">
<script src="<?php echo isset($base_path) ? $base_path : ''; ?>assets/chat/chat.js"></script>
<?php endif; ?>
</body>
</html>