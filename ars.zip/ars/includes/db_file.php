<?php
// File-based database solution (no drivers needed)
class FileDB {
    private $data_dir;
    
    public function __construct() {
        $this->data_dir = __DIR__ . '/../data/';
        if (!is_dir($this->data_dir)) {
            mkdir($this->data_dir, 0777, true);
        }
    }
    
    public function prepare($sql) {
        return new FileStatement($this, $sql);
    }
    
    public function query($sql) {
        // Simple query implementation
        return new FileResult([]);
    }
    
    public function set_charset($charset) {
        // Not needed for file-based storage
    }
    
    public function close() {
        // Nothing to close
    }
    
    public function findUserByRememberToken($token) {
        $users_file = $this->data_dir . 'users.json';
        
        if (!file_exists($users_file)) {
            return false;
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        
        foreach ($users as $user) {
            if (isset($user['remember_token']) && $user['remember_token'] === $token) {
                return $user;
            }
        }
        
        return false;
    }
    
    public function updateRememberToken($userId, $token) {
        $users_file = $this->data_dir . 'users.json';
        $users = [];
        
        if (file_exists($users_file)) {
            $users = json_decode(file_get_contents($users_file), true) ?: [];
        }
        
        foreach ($users as &$user) {
            if ($user['id'] == $userId) {
                $user['remember_token'] = $token;
                file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
                return true;
            }
        }
        
        return false;
    }
    
    public function saveUser($name, $email, $password, $role) {
        $users_file = $this->data_dir . 'users.json';
        $users = [];
        
        if (file_exists($users_file)) {
            $users = json_decode(file_get_contents($users_file), true) ?: [];
        }
        
        // Check if email exists
        foreach ($users as $user) {
            if ($user['email'] === $email) {
                return false; // Email already exists
            }
        }
        
        // Add new user
        $users[] = [
            'id' => count($users) + 1,
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'role' => $role,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        return true;
    }
    
    public function findUserByEmail($email) {
        $users_file = $this->data_dir . 'users.json';
        
        if (!file_exists($users_file)) {
            return null;
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        
        foreach ($users as $user) {
            if ($user['email'] === $email) {
                return $user;
            }
        }
        
        return null;
    }
}

class FileStatement {
    private $db;
    private $sql;
    private $params = [];
    public $num_rows = 0;
    public $error = '';
    
    public function __construct($db, $sql) {
        $this->db = $db;
        $this->sql = $sql;
    }
    
    public function bind_param($types, ...$params) {
        $this->params = $params;
    }
    
    public function execute() {
        try {
            // Handle INSERT for users
            if (strpos($this->sql, 'INSERT INTO users') !== false) {
                $result = $this->db->saveUser($this->params[0], $this->params[1], $this->params[2], $this->params[3]);
                return $result;
            }
            
            // Handle SELECT for users
            if (strpos($this->sql, 'SELECT id FROM users WHERE email') !== false) {
                $user = $this->db->findUserByEmail($this->params[0]);
                $this->num_rows = $user ? 1 : 0;
                return true;
            }
            
            return true;
        } catch (Exception $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }
    
    public function store_result() {
        // Not needed for file-based storage
    }
    
    public function close() {
        // Nothing to close
    }
}

class FileResult {
    private $data;
    
    public function __construct($data) {
        $this->data = $data;
    }
}

// Create connection
$conn = new FileDB();
?>
