<?php
// SQLite database connection (no additional drivers needed)
$database_file = __DIR__ . '/../church_management.db';

try {
    // Create SQLite connection
    $pdo = new PDO("sqlite:$database_file", null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
    
    // Create a wrapper class to make it compatible with MySQLi syntax
    class PDOWrapper {
        private $pdo;
        
        public function __construct($pdo) {
            $this->pdo = $pdo;
        }
        
        public function prepare($sql) {
            return new PDOStatementWrapper($this->pdo->prepare($sql));
        }
        
        public function query($sql) {
            return $this->pdo->query($sql);
        }
        
        public function set_charset($charset) {
            // SQLite handles UTF-8 by default
        }
        
        public function close() {
            $this->pdo = null;
        }
    }
    
    class PDOStatementWrapper {
        private $stmt;
        public $num_rows = 0;
        public $error = '';
        
        public function __construct($stmt) {
            $this->stmt = $stmt;
        }
        
        public function bind_param($types, ...$params) {
            for ($i = 0; $i < count($params); $i++) {
                $this->stmt->bindValue($i + 1, $params[$i]);
            }
        }
        
        public function execute() {
            try {
                $result = $this->stmt->execute();
                $this->num_rows = $this->stmt->rowCount();
                return $result;
            } catch (PDOException $e) {
                $this->error = $e->getMessage();
                return false;
            }
        }
        
        public function store_result() {
            // Not needed for PDO
        }
        
        public function close() {
            $this->stmt = null;
        }
    }
    
    $conn = new PDOWrapper($pdo);
    
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
