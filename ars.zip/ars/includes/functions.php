<?php
/**
 * General helper functions for the application
 */

/**
 * Check if a user is logged in
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if user has specific permission
 * @param string $module Module name (e.g., 'counseling')
 * @param string $action Action name (e.g., 'schedule')
 * @return bool
 */
function hasPermission($module, $action = '') {
    // For now, allow access to all logged-in users
    // In production, implement proper role-based access control
    return isset($_SESSION['user_id']);
    
    // Original admin-only access:
    // return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Format date for display
 * @param string $date Date string
 * @param string $format Output format (default: 'F j, Y')
 * @return string
 */
function formatDate($date, $format = 'F j, Y') {
    return date($format, strtotime($date));
}

/**
 * Format time for display
 * @param string $time Time string
 * @param string $format Output format (default: 'g:i A')
 * @return string
 */
function formatTime($time, $format = 'g:i A') {
    return date($format, strtotime($time));
}

/**
 * Generate a random string
 * @param int $length Length of the string
 * @return string
 */
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

/**
 * Sanitize input data
 * @param string $data
 * @return string
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Redirect to a different page
 * @param string $url
 * @return void
 */
function redirect($url) {
    header("Location: $url");
    exit();
}

/**
 * Check if string starts with a specific substring
 * @param string $haystack
 * @param string $needle
 * @return bool
 */
function startsWith($haystack, $needle) {
    return substr($haystack, 0, strlen($needle)) === $needle;
}

/**
 * Check if string ends with a specific substring
 * @param string $haystack
 * @param string $needle
 * @return bool
 */
function endsWith($haystack, $needle) {
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }
    return (substr($haystack, -$length) === $needle);
}

/**
 * Generate a CSRF token
 * @return string
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 * @param string $token
 * @return bool
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Get the current URL
 * @param bool $withQueryString Include query string
 * @return string
 */
function getCurrentUrl($withQueryString = true) {
    $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    return $withQueryString ? $url : strtok($url, '?');
}

/**
 * Get the base URL of the application
 * @return string
 */
function getBaseUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $scriptName = dirname($_SERVER['SCRIPT_NAME']);
    
    // If we're not in the root directory, include the subdirectory
    $basePath = rtrim(str_replace('\\', '/', $scriptName), '/');
    
    return $protocol . $host . $basePath;
}

/**
 * Debug function
 * @param mixed $data
 * @param bool $die Whether to terminate the script
 * @return void
 */
function debug($data, $die = true) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    if ($die) die();
}

/**
 * Get the current user's IP address
 * @return string
 */
function getClientIP() {
    $ip = '';
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

/**
 * Check if the request is AJAX
 * @return bool
 */
function isAjax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

/**
 * Set a flash message
 * @param string $key
 * @param string $message
 * @return void
 */
function setFlash($key, $message) {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][$key] = $message;
}

/**
 * Get a flash message
 * @param string $key
 * @param mixed $default
 * @return mixed
 */
function getFlash($key, $default = null) {
    if (isset($_SESSION['flash_messages'][$key])) {
        $message = $_SESSION['flash_messages'][$key];
        unset($_SESSION['flash_messages'][$key]);
        return $message;
    }
    return $default;
}

/**
 * Check if a flash message exists
 * @param string $key
 * @return bool
 */
function hasFlash($key) {
    return !empty($_SESSION['flash_messages'][$key]);
}

/**
 * Convert array to JSON and set appropriate headers
 * @param array $data
 * @param int $statusCode
 * @return void
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

/**
 * Check if email is valid
 * @param string $email
 * @return bool
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Truncate text to a certain number of words
 * @param string $text
 * @param int $limit
 * @param string $ellipsis
 * @return string
 */
function truncateWords($text, $limit, $ellipsis = '...') {
    $words = preg_split("/\s+/", $text);
    if (count($words) > $limit) {
        return implode(' ', array_slice($words, 0, $limit)) . $ellipsis;
    }
    return $text;
}

/**
 * Generate a slug from a string
 * @param string $text
 * @return string
 */
function slugify($text) {
    // Replace non letter or digits by -
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    // Transliterate
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    // Remove unwanted characters
    $text = preg_replace('~[^-\w]+~', '', $text);
    // Trim
    $text = trim($text, '-');
    // Remove duplicate -
    $text = preg_replace('~-+~', '-', $text);
    // Lowercase
    $text = strtolower($text);
    
    if (empty($text)) {
        return 'n-a';
    }
    
    return $text;
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
