<?php
// File-based database solution (no drivers needed)
class FileDB {
    private $data_dir;
    
    public function __construct() {
        $this->data_dir = __DIR__ . '/../data/';
        if (!is_dir($this->data_dir)) {
            mkdir($this->data_dir, 0777, true);
        }
    }
    
    public function prepare($sql) {
        return new FileStatement($this, $sql);
    }
    
    public function query($sql) {
        // Handle remember token queries
        if (strpos($sql, 'SELECT * FROM users WHERE remember_token = ?') !== false) {
            $token = $this->last_token;
            $user = $this->findUserByRememberToken($token);
            return new FileResult($user ? [$user] : []);
        }
        
        // Handle different query types
        if (strpos($sql, 'SELECT * FROM sermons') !== false) {
            return $this->getSermons();
        }
        if (strpos($sql, 'SELECT * FROM events') !== false) {
            return $this->getEvents();
        }
        if (strpos($sql, 'SELECT * FROM announcements') !== false) {
            return $this->getAnnouncements();
        }
        
        // Handle COUNT queries
        if (strpos($sql, 'SELECT COUNT(*) as count FROM users WHERE role') !== false) {
            return $this->getUserCount($sql);
        }
        if (strpos($sql, 'SELECT COUNT(*) as count FROM events') !== false) {
            return $this->getEventCount();
        }
        if (strpos($sql, 'SELECT COUNT(*) as count FROM attendance') !== false) {
            return $this->getAttendanceCount();
        }
        if (strpos($sql, 'SELECT COUNT(*) as count FROM sermons WHERE uploaded_by') !== false) {
            return $this->getSermonsCount($sql);
        }
        if (strpos($sql, 'SELECT COUNT(*) as count FROM announcements WHERE posted_by') !== false) {
            return $this->getAnnouncementsCount($sql);
        }
        if (strpos($sql, 'SELECT COUNT(*) as count FROM events WHERE created_by') !== false) {
            return $this->getEventsCountByUser($sql);
        }
        
        // Handle SUM queries
        if (strpos($sql, 'SELECT SUM(amount) as total FROM donations') !== false) {
            return $this->getDonationTotal();
        }
        
        // Handle recent queries
        if (strpos($sql, 'SELECT u.name, u.email, u.created_at FROM users u WHERE u.role') !== false) {
            return $this->getRecentMembers();
        }
        if (strpos($sql, 'SELECT name, date, time FROM events ORDER BY date DESC') !== false) {
            return $this->getRecentEvents();
        }
        if (strpos($sql, 'SELECT title, created_at FROM announcements ORDER BY created_at DESC') !== false) {
            return $this->getRecentAnnouncements();
        }
        
        // Handle member queries for attendance
        if (strpos($sql, 'SELECT u.id, u.name, m.ministry FROM users u LEFT JOIN members m') !== false) {
            return $this->getMembersWithMinistry();
        }
        
        return new FileResult([]);
    }
    
    public function set_charset($charset) {
        // Not needed for file-based storage
    }
    
    public function close() {
        // Nothing to close
    }
    
    public function getMembersWithMinistry() {
        $users_file = $this->data_dir . 'users.json';
        if (!file_exists($users_file)) {
            return new FileResult([]);
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        $members = array_filter($users, function($user) { 
            return isset($user['role']) && $user['role'] === 'member'; 
        });
        
        // Format the members array with the expected structure
        $result = [];
        foreach ($members as $member) {
            $result[] = [
                'id' => $member['id'],
                'name' => $member['name'] ?? 'Unknown',
                'ministry' => $member['ministry'] ?? 'Not Specified'
            ];
        }
        
        return new FileResult($result);
    }
    
    public function findUserByRememberToken($token) {
        $users_file = $this->data_dir . 'users.json';
        
        if (!file_exists($users_file)) {
            return false;
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        
        foreach ($users as $user) {
            if (isset($user['remember_token']) && $user['remember_token'] === $token) {
                return $user;
            }
        }
        
        return false;
    }
    
    public function updateRememberToken($userId, $token) {
        $users_file = $this->data_dir . 'users.json';
        $users = [];
        
        if (file_exists($users_file)) {
            $users = json_decode(file_get_contents($users_file), true) ?: [];
        }
        
        $user_updated = false;
        foreach ($users as &$user) {
            if ($user['id'] == $userId) {
                $user['remember_token'] = $token;
                $user_updated = true;
                break;
            }
        }
        
        if ($user_updated) {
            file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        }
        
        return $user_updated;
    }
    
    public function saveUser($name, $email, $password, $role) {
        $users_file = $this->data_dir . 'users.json';
        $users = [];
        
        if (file_exists($users_file)) {
            $users = json_decode(file_get_contents($users_file), true) ?: [];
        }
        
        // Check if email exists
        foreach ($users as $user) {
            if ($user['email'] === $email) {
                return false; // Email already exists
            }
        }
        
        // Add new user
        $users[] = [
            'id' => count($users) + 1,
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'role' => $role,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        return true;
    }
    
    public function findUserByEmail($email) {
        $users_file = $this->data_dir . 'users.json';
        
        if (!file_exists($users_file)) {
            return null;
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        
        foreach ($users as $user) {
            if ($user['email'] === $email) {
                return $user;
            }
        }
        
        return null;
    }

    public function getUserById($id) {
        $users_file = $this->data_dir . 'users.json';
        if (!file_exists($users_file)) {
            return null;
        }
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        foreach ($users as $user) {
            if ((int)$user['id'] === (int)$id) {
                return $user;
            }
        }
        return null;
    }
    
    public function getSermons() {
        $sermons_file = $this->data_dir . 'sermons.json';
        
        if (!file_exists($sermons_file)) {
            // Create the data directory if it doesn't exist
            if (!is_dir($this->data_dir)) {
                mkdir($this->data_dir, 0777, true);
            }
            
            // Create sample sermons data
            $sample_sermons = [
                [
                    'id' => 1,
                    'title' => 'The Power of Faith',
                    'content' => 'In this inspiring message, we explore how faith can move mountains and transform lives.',
                    'scripture' => 'Hebrews 11:1',
                    'date' => date('Y-m-d'),
                    'author' => 'Pastor John Smith',
                    'category' => 'Sunday Service',
                    'view_count' => 0,
                    'duration' => '45:30',
                    'image' => 'https://source.unsplash.com/random/800x600/?faith',
                    'video_path' => 'https://www.youtube.com/embed/example1',
                    'tags' => json_encode(['faith', 'inspiration', 'bible']),
                    'is_featured' => true
                ],
                [
                    'id' => 2,
                    'title' => 'Walking in Love',
                    'content' => 'Discover the transformative power of walking in love in every area of your life.',
                    'scripture' => '1 Corinthians 13:4-7',
                    'date' => date('Y-m-d', strtotime('-1 week')),
                    'author' => 'Pastor Sarah Johnson',
                    'category' => 'Midweek Service',
                    'view_count' => 0,
                    'duration' => '38:15',
                    'image' => 'https://source.unsplash.com/random/800x600/?love',
                    'video_path' => 'https://www.youtube.com/embed/example2',
                    'tags' => json_encode(['love', 'relationships', 'christian living']),
                    'is_featured' => true
                ]
            ];
            
            // Save the sample data to the file
            file_put_contents($sermons_file, json_encode($sample_sermons, JSON_PRETTY_PRINT));
            
            // Return the sample data
            return new FileResult($sample_sermons);
        }
        
        // If file exists, read and return the data
        $sermons = json_decode(file_get_contents($sermons_file), true);
        return new FileResult($sermons);
    }

    public function saveSermon($sermon) {
        $file = $this->data_dir . 'sermons.json';
        $sermons = [];
        if (file_exists($file)) {
            $sermons = json_decode(file_get_contents($file), true) ?: [];
        }
        $sermon['id'] = count($sermons) ? (max(array_column($sermons, 'id')) + 1) : 1;
        $sermons[] = $sermon;
        file_put_contents($file, json_encode($sermons, JSON_PRETTY_PRINT));
        return true;
    }
    
    public function getEvents() {
        $events_file = $this->data_dir . 'events.json';
        
        if (!file_exists($events_file)) {
            // Create sample events data
            $sample_events = [
                [
                    'id' => 1,
                    'name' => 'Sunday Service',
                    'description' => 'Weekly Sunday worship service',
                    'date' => date('Y-m-d', strtotime('+1 week')),
                    'time' => '10:00:00',
                    'location' => 'Main Sanctuary'
                ],
                [
                    'id' => 2,
                    'name' => 'Youth Bible Study',
                    'description' => 'Weekly youth group meeting',
                    'date' => date('Y-m-d', strtotime('+3 days')),
                    'time' => '18:00:00',
                    'location' => 'Youth Room'
                ]
            ];
            file_put_contents($events_file, json_encode($sample_events, JSON_PRETTY_PRINT));
            return new FileResult($sample_events);
        }
        
        $events = json_decode(file_get_contents($events_file), true) ?: [];
        return new FileResult(array_slice($events, 0, 3)); // Limit to 3 upcoming
    }

    public function saveEvent($event) {
        $events_file = $this->data_dir . 'events.json';
        $events = [];
        if (file_exists($events_file)) {
            $events = json_decode(file_get_contents($events_file), true) ?: [];
        }
        $event['id'] = count($events) ? (max(array_column($events, 'id')) + 1) : 1;
        $events[] = $event;
        file_put_contents($events_file, json_encode($events, JSON_PRETTY_PRINT));
        return true;
    }
    
    public function getAnnouncements() {
        $announcements_file = $this->data_dir . 'announcements.json';
        
        if (!file_exists($announcements_file)) {
            // Create empty announcements file if it doesn't exist
            file_put_contents($announcements_file, json_encode([], JSON_PRETTY_PRINT));
            return new FileResult([]);
        }
        
        $announcements = json_decode(file_get_contents($announcements_file), true) ?: [];
        
        // Sort announcements by creation date (newest first)
        usort($announcements, function($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });
        
        return new FileResult($announcements);
    }

    public function saveAnnouncement($announcement) {
        $file = $this->data_dir . 'announcements.json';
        $announcements = [];
        
        if (file_exists($file)) {
            $announcements = json_decode(file_get_contents($file), true) ?: [];
        }
        
        // Add ID if not set
        if (!isset($announcement['id'])) {
            $announcement['id'] = uniqid();
        }
        
        // Add creation timestamp if not set
        if (!isset($announcement['created_at'])) {
            $announcement['created_at'] = date('Y-m-d H:i:s');
        }
        
        // Add to beginning of array (most recent first)
        array_unshift($announcements, $announcement);
        
        // Save to file
        file_put_contents($file, json_encode($announcements, JSON_PRETTY_PRINT));
        
        return true;
    }
    
    public function getUserCount($sql) {
        $users_file = $this->data_dir . 'users.json';
        if (!file_exists($users_file)) {
            return new FileResult([['count' => 0]]);
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        
        // Extract role from SQL
        if (strpos($sql, "role = 'member'") !== false) {
            $count = count(array_filter($users, function($user) { return $user['role'] === 'member'; }));
        } else {
            $count = count($users);
        }
        
        return new FileResult([['count' => $count]]);
    }
    
    public function getEventCount() {
        $events_file = $this->data_dir . 'events.json';
        if (!file_exists($events_file)) {
            return new FileResult([['count' => 0]]);
        }
        
        $events = json_decode(file_get_contents($events_file), true) ?: [];
        return new FileResult([['count' => count($events)]]);
    }
    
    public function getAttendanceCount() {
        $attendance_file = $this->data_dir . 'attendance.json';
        if (!file_exists($attendance_file)) {
            return new FileResult([['count' => 0]]);
        }
        
        $attendance = json_decode(file_get_contents($attendance_file), true) ?: [];
        return new FileResult([['count' => count($attendance)]]);
    }
    
    public function getDonationTotal() {
        $donations_file = $this->data_dir . 'donations.json';
        if (!file_exists($donations_file)) {
            return new FileResult([['total' => 0]]);
        }
        
        $donations = json_decode(file_get_contents($donations_file), true) ?: [];
        $total = array_sum(array_column($donations, 'amount'));
        return new FileResult([['total' => $total]]);
    }
    
    public function getRecentMembers() {
        $users_file = $this->data_dir . 'users.json';
        if (!file_exists($users_file)) {
            return new FileResult([]);
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        $members = array_filter($users, function($user) { return $user['role'] === 'member'; });
        
        // Sort by created_at desc and limit to 5
        usort($members, function($a, $b) { return strtotime($b['created_at']) - strtotime($a['created_at']); });
        return new FileResult(array_slice($members, 0, 5));
    }
    
    public function getRecentEvents() {
        $events_file = $this->data_dir . 'events.json';
        if (!file_exists($events_file)) {
            return new FileResult([]);
        }
        
        $events = json_decode(file_get_contents($events_file), true) ?: [];
        
        // Sort by date desc and limit to 5
        usort($events, function($a, $b) { return strtotime($b['date']) - strtotime($a['date']); });
        return new FileResult(array_slice($events, 0, 5));
    }
    
    public function getRecentAnnouncements() {
        $announcements_file = $this->data_dir . 'announcements.json';
        if (!file_exists($announcements_file)) {
            return new FileResult([]);
        }
        
        $announcements = json_decode(file_get_contents($announcements_file), true) ?: [];
        
        // Sort by created_at desc and limit to 5
        usort($announcements, function($a, $b) { return strtotime($b['created_at']) - strtotime($a['created_at']); });
        return new FileResult(array_slice($announcements, 0, 5));
    }
    
    public function getSermonsCount($sql) {
        $sermons_file = $this->data_dir . 'sermons.json';
        if (!file_exists($sermons_file)) {
            return new FileResult([['count' => 0]]);
        }
        
        $sermons = json_decode(file_get_contents($sermons_file), true) ?: [];
        
        // Extract user ID from SQL if present
        preg_match('/uploaded_by = (\d+)/', $sql, $matches);
        if (isset($matches[1])) {
            $user_id = (int)$matches[1];
            $count = count(array_filter($sermons, function($sermon) use ($user_id) { 
                return isset($sermon['uploaded_by']) && $sermon['uploaded_by'] == $user_id; 
            }));
        } else {
            $count = count($sermons);
        }
        
        return new FileResult([['count' => $count]]);
    }
    
    public function getAnnouncementsCount($sql) {
        $announcements_file = $this->data_dir . 'announcements.json';
        if (!file_exists($announcements_file)) {
            return new FileResult([['count' => 0]]);
        }
        
        $announcements = json_decode(file_get_contents($announcements_file), true) ?: [];
        
        // Extract user ID from SQL if present
        preg_match('/posted_by = (\d+)/', $sql, $matches);
        if (isset($matches[1])) {
            $user_id = (int)$matches[1];
            $count = count(array_filter($announcements, function($announcement) use ($user_id) { 
                return isset($announcement['posted_by']) && $announcement['posted_by'] == $user_id; 
            }));
        } else {
            $count = count($announcements);
        }
        
        return new FileResult([['count' => $count]]);
    }
    
    public function getEventsCountByUser($sql) {
        $events_file = $this->data_dir . 'events.json';
        if (!file_exists($events_file)) {
            return new FileResult([['count' => 0]]);
        }
        
        $events = json_decode(file_get_contents($events_file), true) ?: [];
        
        // Extract user ID from SQL if present
        preg_match('/created_by = (\d+)/', $sql, $matches);
        if (isset($matches[1])) {
            $user_id = (int)$matches[1];
            $count = count(array_filter($events, function($event) use ($user_id) { 
                return isset($event['created_by']) && $event['created_by'] == $user_id; 
            }));
        } else {
            $count = count($events);
        }
        
        return new FileResult([['count' => $count]]);
    }
    
    public function saveAttendance($attendance_data) {
        $attendance_file = $this->data_dir . 'attendance.json';
        $attendance_records = [];
        
        if (file_exists($attendance_file)) {
            $attendance_records = json_decode(file_get_contents($attendance_file), true) ?: [];
        }
        
        $attendance_records[] = $attendance_data;
        
        return file_put_contents($attendance_file, json_encode($attendance_records, JSON_PRETTY_PRINT)) !== false;
    }
    
    
    public function getAttendanceSummary() {
        $attendance_file = $this->data_dir . 'attendance.json';
        if (!file_exists($attendance_file)) {
            return new FileResult([]);
        }
        
        $attendance_records = json_decode(file_get_contents($attendance_file), true) ?: [];
        
        // Sort by date desc
        usort($attendance_records, function($a, $b) { 
            return strtotime($b['service_date']) - strtotime($a['service_date']); 
        });
        
        return new FileResult($attendance_records);
    }
    
    public function saveFeedback($feedback_data) {
        $feedback_file = $this->data_dir . 'feedback.json';
        $feedback_records = [];
        
        if (file_exists($feedback_file)) {
            $feedback_records = json_decode(file_get_contents($feedback_file), true) ?: [];
        }
        
        $feedback_records[] = $feedback_data;
        
        return file_put_contents($feedback_file, json_encode($feedback_records, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function getFeedback() {
        $feedback_file = $this->data_dir . 'feedback.json';
        if (!file_exists($feedback_file)) {
            return new FileResult([]);
        }
        
        $feedback_records = json_decode(file_get_contents($feedback_file), true) ?: [];
        
        // Sort by created_at desc
        usort($feedback_records, function($a, $b) { 
            return strtotime($b['created_at']) - strtotime($a['created_at']); 
        });
        
        return new FileResult($feedback_records);
    }
    
    public function markFeedbackAsRead($feedback_id) {
        $feedback_file = $this->data_dir . 'feedback.json';
        if (!file_exists($feedback_file)) {
            return false;
        }
        
        $feedback_records = json_decode(file_get_contents($feedback_file), true) ?: [];
        
        foreach ($feedback_records as &$feedback) {
            if ($feedback['id'] == $feedback_id) {
                $feedback['status'] = 'read';
                break;
            }
        }
        
        return file_put_contents($feedback_file, json_encode($feedback_records, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function getUnreadFeedbackCount() {
        $feedback_file = $this->data_dir . 'feedback.json';
        if (!file_exists($feedback_file)) {
            return 0;
        }
        
        $feedback_records = json_decode(file_get_contents($feedback_file), true) ?: [];
        
        $unread_count = 0;
        foreach ($feedback_records as $feedback) {
            if ($feedback['status'] === 'unread') {
                $unread_count++;
            }
        }
        
        return $unread_count;
    }
    
    public function saveCounselingRequest($request_data) {
        $requests_file = $this->data_dir . 'counseling_requests.json';
        $requests = [];
        
        if (file_exists($requests_file)) {
            $requests = json_decode(file_get_contents($requests_file), true) ?: [];
        }
        
        $requests[] = $request_data;
        
        return file_put_contents($requests_file, json_encode($requests, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function getCounselingRequests() {
        $requests_file = $this->data_dir . 'counseling_requests.json';
        if (!file_exists($requests_file)) {
            return new FileResult([]);
        }
        
        $requests = json_decode(file_get_contents($requests_file), true) ?: [];
        
        // Sort by created_at desc
        usort($requests, function($a, $b) { 
            return strtotime($b['created_at']) - strtotime($a['created_at']); 
        });
        
        return new FileResult($requests);
    }
    
    public function getPendingCounselingRequests() {
        $requests_file = $this->data_dir . 'counseling_requests.json';
        if (!file_exists($requests_file)) {
            return new FileResult([]);
        }
        
        $requests = json_decode(file_get_contents($requests_file), true) ?: [];
        $pending_requests = array_filter($requests, function($request) {
            return $request['status'] === 'pending';
        });
        
        return new FileResult(array_values($pending_requests));
    }
    
    public function approveCounselingRequest($request_id, $scheduled_date, $scheduled_time, $notes = '') {
        $requests_file = $this->data_dir . 'counseling_requests.json';
        if (!file_exists($requests_file)) {
            return false;
        }
        
        $requests = json_decode(file_get_contents($requests_file), true) ?: [];
        
        foreach ($requests as &$request) {
            if ($request['id'] == $request_id) {
                $request['status'] = 'approved';
                $request['scheduled_date'] = $scheduled_date;
                $request['scheduled_time'] = $scheduled_time;
                $request['notes'] = $notes;
                $request['approved_at'] = date('Y-m-d H:i:s');
                
                // Also create a counseling session
                $this->createCounselingSession($request);
                break;
            }
        }
        
        return file_put_contents($requests_file, json_encode($requests, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function declineCounselingRequest($request_id, $decline_reason) {
        $requests_file = $this->data_dir . 'counseling_requests.json';
        if (!file_exists($requests_file)) {
            return false;
        }
        
        $requests = json_decode(file_get_contents($requests_file), true) ?: [];
        
        foreach ($requests as &$request) {
            if ($request['id'] == $request_id) {
                $request['status'] = 'declined';
                $request['decline_reason'] = $decline_reason;
                $request['declined_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        
        return file_put_contents($requests_file, json_encode($requests, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function createCounselingSession($request) {
        $sessions_file = $this->data_dir . 'counseling_sessions.json';
        $sessions = [];
        
        if (file_exists($sessions_file)) {
            $sessions = json_decode(file_get_contents($sessions_file), true) ?: [];
        }
        
        $session_data = [
            'id' => time() . rand(100, 999),
            'request_id' => $request['id'],
            'member_id' => $request['member_id'],
            'member_name' => $request['member_name'],
            'session_type' => $request['request_type'],
            'scheduled_date' => $request['scheduled_date'],
            'scheduled_time' => $request['scheduled_time'],
            'status' => 'scheduled',
            'notes' => '',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $sessions[] = $session_data;
        
        return file_put_contents($sessions_file, json_encode($sessions, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function getCounselingSessionsCount() {
        $sessions_file = $this->data_dir . 'counseling_sessions.json';
        if (!file_exists($sessions_file)) {
            return 0;
        }
        
        $sessions = json_decode(file_get_contents($sessions_file), true) ?: [];
        return count($sessions);
    }
    
    public function getUpcomingSessions() {
        $sessions_file = $this->data_dir . 'counseling_sessions.json';
        if (!file_exists($sessions_file)) {
            return new FileResult([]);
        }
        
        $sessions = json_decode(file_get_contents($sessions_file), true) ?: [];
        $upcoming = array_filter($sessions, function($session) {
            return $session['status'] === 'scheduled' && 
                   strtotime($session['scheduled_date']) >= strtotime(date('Y-m-d'));
        });
        
        // Sort by date/time
        usort($upcoming, function($a, $b) {
            return strtotime($a['scheduled_date'] . ' ' . $a['scheduled_time']) - 
                   strtotime($b['scheduled_date'] . ' ' . $b['scheduled_time']);
        });
        
        return new FileResult(array_values($upcoming));
    }
    
    public function getCounselingSessions() {
        // Load counseling sessions from the database
        $sessions = $this->loadData('counseling_sessions.json');
        return $sessions ?: [];
    }
    
    public function getActiveCounselees() {
        $sessions = $this->getCounselingSessions();
        $activeCounselees = [];
        
        foreach ($sessions as $session) {
            if ($session['status'] === 'scheduled' || $session['status'] === 'in_progress') {
                $activeCounselees[$session['member_id']] = $session['member_name'];
            }
        }
        
        return count($activeCounselees);
    }
    
    public function savePendingDonation($donationData) {
        $donations = $this->loadData('donations.json');
        
        $donation = [
            'id' => uniqid(),
            'amount' => $donationData['amount'],
            'description' => $donationData['description'],
            'payment_method' => $donationData['payment_method'],
            'status' => 'pending_verification',
            'donor_name' => $donationData['user_name'],
            'donor_email' => $donationData['user_email'],
            'user_id' => $donationData['user_id'],
            'transaction_reference' => $donationData['transaction_reference'] ?? '',
            'crypto_hash' => $donationData['crypto_hash'] ?? '',
            'sender_wallet' => $donationData['sender_wallet'] ?? '',
            'mobile_number' => $donationData['mobile_number'] ?? '',
            'date' => date('Y-m-d'),
            'created_at' => date('Y-m-d H:i:s'),
            'verified_at' => null,
            'verified_by' => null
        ];
        
        $donations[] = $donation;
        $this->saveData('donations.json', $donations);
        
        return $donation['id'];
    }
    
    protected function loadData($filename) {
        $filepath = __DIR__ . '/../data/' . $filename;
        if (!file_exists($filepath)) {
            return [];
        }
        $json = file_get_contents($filepath);
        return json_decode($json, true) ?: [];
    }
    
    protected function saveData($filename, $data) {
        $filepath = __DIR__ . '/../data/' . $filename;
        file_put_contents($filepath, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    public function getPendingDonations() {
        $donations = $this->loadData('donations.json');
        return array_filter($donations, function($donation) {
            return $donation['status'] === 'pending_verification';
        });
    }
    
    public function verifyDonation($donationId, $verifiedBy) {
        $donations = $this->loadData('donations.json');
        
        foreach ($donations as &$donation) {
            if ($donation['id'] === $donationId) {
                $donation['status'] = 'verified';
                $donation['verified_at'] = date('Y-m-d H:i:s');
                $donation['verified_by'] = $verifiedBy;
                break;
            }
        }
        
        $this->saveData('donations.json', $donations);
        return true;
    }
    
    public function rejectDonation($donationId, $reason, $rejectedBy) {
        $donations = $this->loadData('donations.json');
        
        foreach ($donations as &$donation) {
            if ($donation['id'] === $donationId) {
                $donation['status'] = 'rejected';
                $donation['rejection_reason'] = $reason;
                $donation['rejected_at'] = date('Y-m-d H:i:s');
                $donation['rejected_by'] = $rejectedBy;
                break;
            }
        }
        
        $this->saveData('donations.json', $donations);
        return true;
    }
    
    public function getAllDonations() {
        return $this->loadData('donations.json');
    }
    
    // Member management methods
    public function getAllMembers() {
        return $this->loadData('members.json');
    }
    
    public function updateMemberStatus($memberId, $status) {
        $members = $this->loadData('members.json');
        
        foreach ($members as &$member) {
            if ($member['id'] == $memberId) {
                $member['status'] = $status;
                $member['updated_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        
        $this->saveData('members.json', $members);
        return true;
    }
    
    public function deleteMember($memberId) {
        $members = $this->loadData('members.json');
        
        $members = array_filter($members, function($member) use ($memberId) {
            return $member['id'] != $memberId;
        });
        
        $this->saveData('members.json', array_values($members));
        return true;
    }
}

class FileStatement {
    private $db;
    private $sql;
    private $params = [];
    private $param_types = '';
    public $num_rows = 0;
    public $error = '';
    public $user_data = null;
    
    public function __construct($db, $sql) {
        $this->db = $db;
        $this->sql = $sql;
    }
    
    public function bind_param($types, ...$params) {
        if (strpos($this->sql, 'remember_token') !== false) {
            $this->last_token = $params[0];
        }
        $this->params = $params;
        $this->param_types = $types;
        return true;
    }
    
    private $last_token;  // Store the last token for query processing
    
    public function execute() {
        try {
            // Handle INSERT for users
            if (strpos($this->sql, 'INSERT INTO users') !== false) {
                $result = $this->db->saveUser($this->params[0], $this->params[1], $this->params[2], $this->params[3]);
                return $result;
            }
            
            // Handle SELECT for users (registration check)
            if (strpos($this->sql, 'SELECT id FROM users WHERE email') !== false) {
                $user = $this->db->findUserByEmail($this->params[0]);
                $this->num_rows = $user ? 1 : 0;
                return true;
            }
            
            // Handle SELECT for login
            if (strpos($this->sql, 'SELECT id, name, password, role FROM users WHERE email') !== false) {
                $user = $this->db->findUserByEmail($this->params[0]);
                $this->num_rows = $user ? 1 : 0;
                $this->user_data = $user;
                return true;
            }
            
            return true;
        } catch (Exception $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }
    
    public function store_result() {
        // Not needed for file-based storage
    }
    
    public function bind_result(&...$vars) {
        // Store references to variables for bind_result
        $this->bound_vars = $vars;
    }
    
    public function fetch() {
        if ($this->user_data && isset($this->bound_vars)) {
            // Assign user data to bound variables
            $this->bound_vars[0] = $this->user_data['id'];
            $this->bound_vars[1] = $this->user_data['name'];
            $this->bound_vars[2] = $this->user_data['password'];
            $this->bound_vars[3] = $this->user_data['role'];
            return true;
        }
        return false;
    }
    
    public function close() {
        // Nothing to close
    }
    
    public function findUserByRememberToken($token) {
        $users_file = $this->data_dir . 'users.json';
        if (!file_exists($users_file)) {
            return false;
        }
        
        $users = json_decode(file_get_contents($users_file), true) ?: [];
        
        foreach ($users as $user) {
            if (isset($user['remember_token']) && hash_equals($user['remember_token'], $token)) {
                return $user;
            }
        }
        
        return false;
    }
}

class FileResult {
    private $data;
    public $num_rows = 0;
    private $position = 0;
    
    public function __construct($data) {
        $this->data = is_array($data) ? $data : [];
        $this->num_rows = count($this->data);
    }
    
    public function fetch_assoc() {
        if (isset($this->data[$this->position])) {
            return $this->data[$this->position++];
        }
        return null;
    }
    
    public function fetchAll() {
        return $this->data;
    }
}

// Create connection
$conn = new FileDB();
?>