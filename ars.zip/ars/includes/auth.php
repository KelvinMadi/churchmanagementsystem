<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    // Set session cookie parameters before starting the session
    $lifetime = 60 * 60 * 24 * 30; // 30 days
    session_set_cookie_params($lifetime, '/', '', false, true);
    session_start();
    
    // Check for remember_me cookie
    if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_me'])) {
        require_once 'db.php';
        $token = $_COOKIE['remember_me'];
        $user = $GLOBALS['conn']->findUserByRememberToken($token);
        
        if ($user) {
            // Valid token, log the user in
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_email'] = $user['email'];
            
            // Refresh the token for security
            $new_token = bin2hex(random_bytes(32));
            $expires = time() + (60 * 60 * 24 * 30); // 30 days
            setcookie('remember_me', $new_token, $expires, '/', '', true, true);
            $GLOBALS['conn']->query("UPDATE users SET remember_token = '$new_token' WHERE id = " . $user['id']);
        } else {
            // Invalid token, clear the cookie
            setcookie('remember_me', '', time() - 3600, '/', '', true, true);
        }
    }
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: ../login.php');
        exit();
    }
}

function get_user() {
    if (!is_logged_in()) return null;
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'],
        'role' => $_SESSION['user_role'],
        'email' => isset($_SESSION['user_email']) ? $_SESSION['user_email'] : null
    ];
}

function require_role($allowed_roles) {
    require_login();
    $user = get_user();
    if (!in_array($user['role'], $allowed_roles)) {
        header('Location: ../login.php');
        exit();
    }
}

// CSRF utilities
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}
?>