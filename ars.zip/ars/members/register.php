<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin']);
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $birth_date = !empty($_POST['birth_date']) ? $_POST['birth_date'] : null;
        $baptism_date = !empty($_POST['baptism_date']) ? $_POST['baptism_date'] : null;
        $ministry = $_POST['ministry'];
        $emergency_contact = trim($_POST['emergency_contact']);
        $emergency_phone = trim($_POST['emergency_phone']);

        if ($name && $email) {
            // Check if email already exists
            $stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Email already registered.</div>';
            } else {
                // Generate a random password
                $password = bin2hex(random_bytes(8));
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert into users table
                $stmt = $conn->prepare('INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, "member", NOW())');
                $stmt->bind_param('sss', $name, $email, $hashed);
                
                if ($stmt->execute()) {
                    $user_id = $conn->insert_id;
                    
                    // Insert into members table
                    $stmt = $conn->prepare('INSERT INTO members (user_id, phone, address, birth_date, baptism_date, ministry, emergency_contact, emergency_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                    $stmt->bind_param('isssssss', $user_id, $phone, $address, $birth_date, $baptism_date, $ministry, $emergency_contact, $emergency_phone);
                    
                    if ($stmt->execute()) {
                        $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Member registered successfully! Temporary password: <strong>' . $password . '</strong></div>';
                    } else {
                        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error registering member: ' . $stmt->error . '</div>';
                    }
                } else {
                    $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error creating user account: ' . $stmt->error . '</div>';
                }
            }
            $stmt->close();
        } else {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Member - Church Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333;
            --text-light: #7f8c8d;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        body {
            background-color: #f5f7fa;
            font-family: 'Poppins', sans-serif;
            color: var(--text);
        }
        
        .navbar {
            background: var(--secondary) !important;
            box-shadow: var(--shadow);
        }
        
        .form-card {
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            overflow: hidden;
            margin: 2rem 0;
            transition: var(--transition);
        }
        
        .form-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .upload-header {
            background: linear-gradient(135deg, var(--secondary) 0%, var(--dark) 100%);
            color: white;
            padding: 2rem 1.5rem !important;
        }
        
        .upload-header i {
            color: var(--accent);
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .form-control, .form-select {
            border: 1px solid #e0e0e0;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            transition: var(--transition);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(230, 126, 34, 0.25);
        }
        
        .btn-primary {
            background: var(--primary);
            border: none;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: var(--transition);
        }
        
        .btn-primary:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
        }
        
        .form-label {
            font-weight: 500;
            color: var(--secondary);
            margin-bottom: 0.5rem;
        }
        
        .form-label i {
            color: var(--primary);
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        .alert {
            border-radius: 8px;
            border: none;
            padding: 1rem 1.25rem;
        }
        
        .alert i {
            margin-right: 0.5rem;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="../index.php">
                <i class="fas fa-church me-2 text-warning"></i>
                <span class="fw-bold">Apostolic Church</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                            <div class="me-2 d-flex align-items-center">
                                <i class="fas fa-user-circle me-2" style="font-size: 1.5rem;"></i>
                                <span class="d-none d-md-inline"><?php echo htmlspecialchars($user['name']); ?></span>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="../dashboard/<?php echo $user['role']; ?>.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user-edit me-2"></i>Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="form-card">
                    <div class="upload-header text-center">
                        <i class="fas fa-user-plus"></i>
                        <h3 class="mb-2">Register New Member</h3>
                        <p class="mb-0 opacity-75">Add a new member to our church family</p>
                    </div>
                    <div class="card-body p-4">
                        <?php echo $message; ?>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas fa-user"></i>Full Name *</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fas fa-user text-muted"></i></span>
                                        <input type="text" name="name" class="form-control" placeholder="John Doe" required>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas fa-envelope"></i>Email *</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fas fa-at text-muted"></i></span>
                                        <input type="email" name="email" class="form-control" placeholder="john@example.com" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas fa-phone"></i>Phone</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fas fa-phone-alt text-muted"></i></span>
                                        <input type="tel" name="phone" class="form-control" placeholder="(123) 456-7890">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas fa-calendar"></i>Birth Date</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="far fa-calendar-alt text-muted"></i></span>
                                        <input type="date" name="birth_date" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label"><i class="fas fa-map-marker-alt"></i>Address</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-home text-muted"></i></span>
                                    <textarea name="address" class="form-control" rows="2" placeholder="123 Church St, City, State ZIP"></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas fa-water"></i>Baptism Date</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fas fa-baptism text-muted"></i></span>
                                        <input type="date" name="baptism_date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas-hands-helping"></i>Ministry</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fas fa-hands-helping text-muted"></i></span>
                                        <select name="ministry" class="form-select">
                                            <option value="" selected>Select Ministry</option>
                                            <option value="worship">Worship Team</option>
                                            <option value="youth">Youth Ministry</option>
                                            <option value="children">Children's Ministry</option>
                                            <option value="outreach">Outreach</option>
                                            <option value="prayer">Prayer Team</option>
                                            <option value="ushering">Ushering</option>
                                            <option value="technical">Technical Team</option>
                                            <option value="none">Not currently serving</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas fa-user-shield"></i>Emergency Contact</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fas fa-user-shield text-muted"></i></span>
                                        <input type="text" name="emergency_contact" class="form-control" placeholder="Contact Name">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"><i class="fas fa-phone-alt"></i>Emergency Phone</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fas fa-phone-alt text-muted"></i></span>
                                        <input type="tel" name="emergency_phone" class="form-control" placeholder="(123) 456-7890">
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mt-5 pt-3 border-top">
                                <a href="../dashboard/admin.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                                </a>
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="fas fa-user-plus me-2"></i>Register Member
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add animation to form inputs on focus
        document.querySelectorAll('.form-control, .form-select').forEach(input => {
            input.addEventListener('focus', function() {
                this.closest('.mb-4').style.transform = 'translateY(-2px)';
                this.closest('.mb-4').style.transition = 'all 0.3s ease';
            });
            
            input.addEventListener('blur', function() {
                this.closest('.mb-4').style.transform = 'translateY(0)';
            });
        });
        
        // Add phone number formatting
        document.querySelectorAll('input[type="tel"]').forEach(input => {
            input.addEventListener('input', function(e) {
                let x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
                e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
            });
        });
    </script>
</body>
</html>