<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin']);
$user = get_user();

$report_type = $_GET['type'] ?? '';
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

$report_data = [];

if ($report_type && $start_date && $end_date) {
    switch ($report_type) {
        case 'attendance':
            $report_data = $conn->query("
                SELECT a.service_date, a.service_type, COUNT(am.member_id) as present_count,
                       (SELECT COUNT(*) FROM users WHERE role = 'member') as total_members
                FROM attendance a
                LEFT JOIN attendance_members am ON a.id = am.attendance_id
                WHERE a.service_date BETWEEN '$start_date' AND '$end_date'
                GROUP BY a.id
                ORDER BY a.service_date DESC
            ");
            break;
            
        case 'financial':
            $report_data = $conn->query("
                SELECT 'Donations' as type, SUM(amount) as total, COUNT(*) as count
                FROM donations 
                WHERE date BETWEEN '$start_date' AND '$end_date'
                UNION ALL
                SELECT 'Expenses' as type, SUM(amount) as total, COUNT(*) as count
                FROM expenses 
                WHERE date BETWEEN '$start_date' AND '$end_date'
            ");
            break;
            
        case 'members':
            $report_data = $conn->query("
                SELECT u.name, u.email, m.ministry, m.phone, u.created_at
                FROM users u
                LEFT JOIN members m ON u.id = m.user_id
                WHERE u.role = 'member'
                ORDER BY u.created_at DESC
            ");
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user['name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../dashboard/<?php echo $user['role']; ?>.php">Dashboard</a></li>
                            <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-file-alt me-2"></i>Generate Reports</h2>
            <button class="btn btn-primary" onclick="window.print()">
                <i class="fas fa-print me-2"></i>Print Report
            </button>
        </div>

        <!-- Report Selection -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-cog me-2"></i>Report Settings</h5>
            </div>
            <div class="card-body">
                <form method="GET" class="row">
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Report Type</label>
                        <select name="type" class="form-select" required>
                            <option value="">Select Report</option>
                            <option value="attendance" <?php echo $report_type === 'attendance' ? 'selected' : ''; ?>>Attendance Report</option>
                            <option value="financial" <?php echo $report_type === 'financial' ? 'selected' : ''; ?>>Financial Report</option>
                            <option value="members" <?php echo $report_type === 'members' ? 'selected' : ''; ?>>Members Report</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Start Date</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo $start_date; ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">End Date</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo $end_date; ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-2"></i>Generate Report
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Report Results -->
        <?php if ($report_type && $report_data): ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <?php
                        switch ($report_type) {
                            case 'attendance': echo '<i class="fas fa-clipboard-list me-2"></i>Attendance Report'; break;
                            case 'financial': echo '<i class="fas fa-chart-pie me-2"></i>Financial Report'; break;
                            case 'members': echo '<i class="fas fa-users me-2"></i>Members Report'; break;
                        }
                        ?>
                        <small class="text-muted ms-2">(<?php echo date('M j, Y', strtotime($start_date)); ?> - <?php echo date('M j, Y', strtotime($end_date)); ?>)</small>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($report_type === 'attendance'): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Service Type</th>
                                        <th>Present</th>
                                        <th>Total Members</th>
                                        <th>Attendance %</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = $report_data->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo date('M j, Y', strtotime($row['service_date'])); ?></td>
                                        <td><?php echo ucwords(str_replace('_', ' ', $row['service_type'])); ?></td>
                                        <td><?php echo $row['present_count']; ?></td>
                                        <td><?php echo $row['total_members']; ?></td>
                                        <td>
                                            <?php 
                                            $percentage = $row['total_members'] > 0 ? round(($row['present_count'] / $row['total_members']) * 100, 1) : 0;
                                            echo $percentage . '%';
                                            ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif ($report_type === 'financial'): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>Total Amount</th>
                                        <th>Number of Transactions</th>
                                        <th>Average Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = $report_data->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $row['type']; ?></td>
                                        <td class="<?php echo $row['type'] === 'Donations' ? 'text-success' : 'text-danger'; ?>">
                                            $<?php echo number_format($row['total'], 2); ?>
                                        </td>
                                        <td><?php echo $row['count']; ?></td>
                                        <td>$<?php echo $row['count'] > 0 ? number_format($row['total'] / $row['count'], 2) : '0.00'; ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif ($report_type === 'members'): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Ministry</th>
                                        <th>Phone</th>
                                        <th>Registration Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = $report_data->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['ministry'] ?? 'None'); ?></td>
                                        <td><?php echo htmlspecialchars($row['phone'] ?? 'N/A'); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($row['created_at'])); ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif ($report_type): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>No data found for the selected criteria.
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 