<?php
/**
 * Ministries Page - Apostolic Church
 * A modern, responsive page showcasing church ministries
 */

// Enable error reporting for development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set page metadata
$pageTitle = 'Our Ministries';
$pageDescription = 'Discover and join our diverse ministries at Apostolic Church. Find your place to grow, serve, and connect with others.';
$activePage = 'ministries';

// Start output buffering
ob_start();

try {
    // Include header
    include __DIR__ . '/../includes/header.php';
    
    // Add custom header styles to match index.php
    echo '<style>
        /* Container with small padding */
        .container {
            padding-left: 15px !important;
            padding-right: 15px !important;
            max-width: 100% !important;
        }
        
        /* Navigation Styling */
        .navbar {
            background-color: #ffffff !important;
            box-shadow: 0 2px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }
        
        .navbar.scrolled {
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .navbar .nav-link {
            color: #2c3e50 !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            margin: 0 0.25rem;
            position: relative;
            transition: all 0.3s ease;
        }
        
        .navbar .nav-link::after {
            content: "";
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 50%;
            background-color: #e67e22;
            transition: all 0.3s ease;
            transform: translateX(-50%);
        }
        
        .navbar .nav-link:hover::after,
        .navbar .nav-link.active::after {
            width: 60%;
        }
        
        .navbar .nav-link:hover,
        .navbar .nav-link.active {
            color: #e67e22 !important;
        }
        
        /* Hero Section Styling */
        .hero-section {
            padding-top: 120px;
            background: linear-gradient(135deg, rgba(44, 62, 80, 0.95) 0%, rgba(26, 37, 47, 0.95) 100%), url("https://images.unsplash.com/photo-1501612780327-45045538702b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80") center/cover;
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background: url("data:image/svg+xml,%3Csvg width=\'100\' height=\'100\' viewBox=\'0 0 100 100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c0-1.657 1.343-3 3-3s3 1.343 3 3-1.343 3-3 3-3-1.343-3-3zm0-32c0-1.657 1.343-3 3-3s3 1.343 3 3-1.343 3-3 3-3-1.343-3-3z\' fill=\'%23e67e22\' fill-opacity=\'0.05\' fill-rule=\'evenodd\'/%3E%3C/svg%3E") repeat;
            opacity: 0.5;
            z-index: 0;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
        }
        
        /* Ministry Cards */
        .ministry-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            border-radius: 12px;
            overflow: hidden;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .ministry-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
        }
        
        .ministry-card .card-img-top {
            height: 200px;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .ministry-card:hover .card-img-top {
            transform: scale(1.05);
        }
        
        .ministry-card .card-body {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .ministry-card .card-footer {
            background: transparent;
            border-top: 1px solid rgba(0,0,0,0.05);
        }
        
        /* Section Styling */
        .section-title {
            position: relative;
            display: inline-block;
            margin-bottom: 2rem;
        }
        
        .section-title:after {
            content: "";
            position: absolute;
            width: 50px;
            height: 3px;
            background: #e67e22;
            bottom: -10px;
            left: 0;
            border-radius: 3px;
        }
        
        .section-title.text-center:after {
            left: 50%;
            transform: translateX(-50%);
        }
    </style>';
    
    // Add JavaScript for scroll effects
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Navbar scroll effect
        var navbar = document.querySelector('.navbar');
        
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
        
        // Smooth scroll for anchor links
        var links = document.querySelectorAll('a[href^="#"]');
        for (var i = 0; i < links.length; i++) {
            links[i].addEventListener('click', function(e) {
                e.preventDefault();
                
                var targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                var targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Update URL without page jump
                    window.history.pushState(null, null, targetId);
                }
            });
        }
    });
    </script>
    <?php

    // Sample ministries data (replace with database query in production)
    $ministries = [
        [
            'title' => 'Children\'s Ministry',
            'slug' => 'children',
            'description' => 'Nurturing young hearts in faith through engaging Bible lessons, worship, and fun activities.',
            'age_range' => 'Ages 3-12',
            'meeting_time' => 'Sundays at 9:30 AM',
            'leader' => 'Sarah Johnson',
            'image' => 'https://images.unsplash.com/photo-1588072432836-e10032774350?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=70',
            'icon' => 'child',
            'color' => 'primary'
        ],
        [
            'title' => 'Youth Ministry',
            'slug' => 'youth',
            'description' => 'Empowering the next generation to live for Christ through dynamic worship, relevant teaching, and authentic relationships.',
            'age_range' => 'Ages 13-18',
            'meeting_time' => 'Fridays at 7:00 PM',
            'leader' => 'Michael Chen',
            'image' => 'https://images.unsplash.com/photo-1511632765486-a01980e01d1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=70',
            'icon' => 'users',
            'color' => 'success'
        ],
        [
            'title' => 'Worship Team',
            'slug' => 'worship',
            'description' => 'Leading the congregation in passionate worship and creating an atmosphere where people can encounter God.',
            'age_range' => 'Ages 16+',
            'meeting_time' => 'Thursdays at 6:30 PM',
            'leader' => 'David Wilson',
            'image' => 'https://images.unsplash.com/photo-1501612780327-45045538702b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=70',
            'icon' => 'music',
            'color' => 'info'
        ],
        [
            'title' => 'Men\'s Ministry',
            'slug' => 'men',
            'description' => 'Building godly men through fellowship, accountability, and biblical teaching.',
            'age_range' => 'Ages 18+',
            'meeting_time' => '1st Saturday at 8:00 AM',
            'leader' => 'Robert Taylor',
            'image' => 'https://images.unsplash.com/photo-1527689368864-3a821dbccc34?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=70',
            'icon' => 'users',
            'color' => 'primary'
        ],
        [
            'title' => 'Women\'s Ministry',
            'slug' => 'women',
            'description' => 'Encouraging and equipping women to grow in their relationship with Christ and each other.',
            'age_range' => 'Ages 18+',
            'meeting_time' => '2nd Saturday at 10:00 AM',
            'leader' => 'Jennifer Adams',
            'image' => 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=70',
            'icon' => 'users',
            'color' => 'danger'
        ],
        [
            'title' => 'Outreach & Missions',
            'slug' => 'outreach',
            'description' => 'Sharing the love of Christ in our community and around the world through service and evangelism.',
            'age_range' => 'All Ages',
            'meeting_time' => '3rd Saturday at 9:00 AM',
            'leader' => 'Daniel Kim',
            'image' => 'https://images.unsplash.com/photo-1454165804606-c88441fbf5b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=70',
            'icon' => 'hands-helping',
            'color' => 'warning'
        ]
    ];
    
    // Sample testimonials
    $testimonials = [
        [
            'name' => 'Sarah Johnson',
            'role' => 'Ministry Leader',
            'content' => 'Serving in the children\'s ministry has been one of the most rewarding experiences of my life. Seeing kids grow in their faith is truly amazing!',
            'image' => 'https://randomuser.me/api/portraits/women/32.jpg'
        ],
        [
            'name' => 'Michael Chen',
            'role' => 'Youth Pastor',
            'content' => 'Our youth group is like a second family. We have so much fun together while growing closer to God!',
            'image' => 'https://randomuser.me/api/portraits/men/22.jpg'
        ],
        [
            'name' => 'Emily Rodriguez',
            'role' => 'Volunteer',
            'content' => 'Joining the worship team has helped me use my musical gifts to glorify God and lead others in worship.',
            'image' => 'https://randomuser.me/api/portraits/women/44.jpg'
        ]
    ];
    
    // Sample events
    $events = [
        [
            'title' => 'Ministry Fair',
            'date' => '2023-09-15',
            'time' => '12:00 PM',
            'location' => 'Church Lobby',
            'description' => 'Learn about all our ministries and find your place to serve!'
        ],
        [
            'title' => 'Volunteer Training',
            'date' => '2023-09-20',
            'time' => '6:30 PM',
            'location' => 'Room 201',
            'description' => 'Training session for all new ministry volunteers.'
        ],
        [
            'title' => 'Outreach Day',
            'date' => '2023-09-30',
            'time' => '8:00 AM',
            'location' => 'City Park',
            'description' => 'Join us as we serve our community and share God\'s love.'
        ]
    ];
    ?>

    <!-- Hero Section -->
    <section class="hero-section py-8 py-lg-10">
        <div class="container">
            <div class="row min-vh-75 align-items-center">
                <div class="col-lg-8 mx-auto text-center text-white hero-content">
                    <span class="badge bg-white bg-opacity-20 text-white border-0 rounded-pill px-4 py-2 mb-4 d-inline-flex align-items-center animate__animated animate__fadeIn">
                        <i class="fas fa-hands-helping me-2"></i> Serving Together in Faith
                    </span>
                    <h1 class="display-3 fw-bold mb-4 animate__animated animate__fadeInUp">
                        Discover Your <span class="text-warning">Ministry</span>
                    </h1>
                    <p class="lead mb-5 px-lg-5 mx-lg-5 animate__animated animate__fadeInUp animate__delay-1s">
                        Find your place to grow, serve, and connect with others in our church family. 
                        Your unique gifts can make an eternal difference in the lives of others.
                    </p>
                    <div class="d-flex flex-column flex-sm-row justify-content-center gap-3 animate__animated animate__fadeInUp animate__delay-1s">
                        <a href="#ministries" class="btn btn-light btn-lg px-5 py-3 fw-medium rounded-pill shadow">
                            <i class="fas fa-search me-2"></i> Explore Ministries
                        </a>
                        <a href="#contact" class="btn btn-outline-light btn-lg px-5 py-3 fw-medium rounded-pill border-2">
                            <i class="fas fa-hand-holding-heart me-2"></i> Get Involved
                        </a>
                    </div>
                    
                    <!-- Stats Counter -->
                    <div class="row g-4 mt-7 pt-4 border-top border-white-10">
                        <div class="col-4 col-md-4">
                            <div class="counter">
                                <span class="display-4 fw-bold text-white">15+</span>
                                <p class="text-white-75 mb-0 small">Ministries</p>
                            </div>
                        </div>
                        <div class="col-4 col-md-4">
                            <div class="counter">
                                <span class="display-4 fw-bold text-white">200+</span>
                                <p class="text-white-50 mb-0 small">Volunteers</p>
                            </div>
                        </div>
                        <div class="col-4 col-md-4">
                            <div class="counter">
                                <span class="display-4 fw-bold text-white">100%</span>
                                <p class="text-white-50 mb-0 small">Impact</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="position-absolute bottom-0 start-50 translate-middle-x mb-4 text-center">
            <a href="#ministries" class="text-white text-decoration-none d-flex flex-column align-items-center">
                <span class="d-block mb-2">Scroll to Explore</span>
                <i class="fas fa-chevron-down animate-bounce"></i>
            </a>
        </div>
        
        <!-- Wave Divider -->
        <div class="position-absolute bottom-0 start-0 w-100" style="z-index: 1;">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120" preserveAspectRatio="none">
                <path fill="#ffffff" d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"></path>
            </svg>
        </div>
    </section>

    <!-- Ministries Grid -->
    <section id="ministries" class="py-7 bg-light">
        <div class="container">
            <div class="text-center mb-6">
                <span class="badge bg-primary bg-opacity-10 text-primary px-4 py-2 rounded-pill mb-3">Our Ministries</span>
                <h2 class="fw-bold display-5 mb-3">Find Your <span class="text-gradient-primary">Ministry</span></h2>
                <p class="lead text-muted mx-auto" style="max-width: 700px;">
                    We have various ministries for all ages and interests. Find the perfect place to grow, serve, and connect with others.
                </p>
            </div>
            
            <!-- Search and Filter -->
            <div class="row justify-content-center mb-5">
                <div class="col-lg-8">
                    <div class="input-group input-group-lg mb-3">
                        <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
                        <input type="text" id="ministrySearch" class="form-control border-start-0" placeholder="Search ministries...">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Filter by Category
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item active" href="#" data-filter="all">All Ministries</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" data-filter="children">Children</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="youth">Youth</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="worship">Worship</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="men">Men</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="women">Women</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="outreach">Outreach</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Ministries Grid -->
            <div class="row g-4" id="ministryContainer">
                <?php foreach ($ministries as $ministry): ?>
                <div class="col-md-6 col-lg-4" data-category="<?php echo $ministry['slug']; ?>">
                    <div class="card h-100 border-0 shadow-sm overflow-hidden transition-all hover-zoom">
                        <div class="position-relative" style="height: 200px;">
                            <img src="<?php echo $ministry['image']; ?>" class="card-img-top h-100 w-100 object-cover" alt="<?php echo htmlspecialchars($ministry['title']); ?>">
                            <div class="position-absolute top-0 end-0 m-3">
                                <span class="badge bg-<?php echo $ministry['color']; ?> bg-opacity-90 px-3 py-2 rounded-pill">
                                    <i class="fas fa-<?php echo $ministry['icon']; ?> me-1"></i> <?php echo $ministry['age_range']; ?>
                                </span>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-<?php echo $ministry['color']; ?> bg-opacity-10 text-<?php echo $ministry['color']; ?> rounded-circle p-3 me-3">
                                    <i class="fas fa-<?php echo $ministry['icon']; ?> fa-2x"></i>
                                </div>
                                <h3 class="h4 mb-0"><?php echo htmlspecialchars($ministry['title']); ?></h3>
                            </div>
                            <p class="text-muted mb-4"><?php echo htmlspecialchars($ministry['description']); ?></p>
                            <ul class="list-unstyled mb-4">
                                <li class="mb-2">
                                    <i class="far fa-clock text-<?php echo $ministry['color']; ?> me-2"></i> 
                                    <strong>Meets:</strong> <?php echo htmlspecialchars($ministry['meeting_time']); ?>
                                </li>
                                <li class="mb-2">
                                    <i class="fas fa-user text-<?php echo $ministry['color']; ?> me-2"></i> 
                                    <strong>Leader:</strong> <?php echo htmlspecialchars($ministry['leader']); ?>
                                </li>
                            </ul>
                            <div class="d-flex justify-content-between align-items-center">
                                <a href="ministry/<?php echo $ministry['slug']; ?>" class="btn btn-sm btn-outline-<?php echo $ministry['color']; ?> rounded-pill px-4">Learn More</a>
                                <a href="#contact" class="btn btn-sm btn-<?php echo $ministry['color']; ?> rounded-pill px-4">Join Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-6">
                <p class="lead mb-4">Don't see a ministry that fits your interests?</p>
                <a href="#contact" class="btn btn-primary btn-lg px-5 rounded-pill">Start a New Ministry</a>
            </div>
        </div>
    </section>

    <!-- Why Serve Section -->
    <section class="py-7 bg-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <span class="badge bg-primary bg-opacity-10 text-primary px-4 py-2 rounded-pill mb-3">Why Serve?</span>
                    <h2 class="fw-bold display-5 mb-4">Every Member <span class="text-gradient-primary">Has a Role</span></h2>
                    <p class="lead text-muted mb-4">
                        God has given each of us unique gifts and talents to serve one another and build up the body of Christ.
                    </p>
                    <div class="d-flex mb-4">
                        <div class="me-4">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="fas fa-hands-helping fa-lg"></i>
                            </div>
                        </div>
                        <div>
                            <h4 class="h5 mb-2">Make a Difference</h4>
                            <p class="text-muted mb-0">Your unique gifts can impact lives and help build God's kingdom.</p>
                        </div>
                    </div>
                    <div class="d-flex mb-4">
                        <div class="me-4">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="fas fa-users fa-lg"></i>
                            </div>
                        </div>
                        <div>
                            <h4 class="h5 mb-2">Build Community</h4>
                            <p class="text-muted mb-0">Connect with others and form meaningful relationships as you serve together.</p>
                        </div>
                    </div>
                    <div class="d-flex">
                        <div class="me-4">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                <i class="fas fa-heart fa-lg"></i>
                            </div>
                        </div>
                        <div>
                            <h4 class="h5 mb-2">Grow Spiritually</h4>
                            <p class="text-muted mb-0">Serving helps you grow in faith and discover God's purpose for your life.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="position-relative">
                        <div class="row g-4">
                            <div class="col-6">
                                <div class="card border-0 shadow-sm rounded-3 overflow-hidden h-100">
                                    <div class="card-body p-4 text-center">
                                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 70px; height: 70px;">
                                            <i class="fas fa-users fa-2x"></i>
                                        </div>
                                        <h3 class="display-4 fw-bold text-primary mb-0">12+</h3>
                                        <p class="text-muted mb-0">Active Ministries</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="card border-0 shadow-sm rounded-3 overflow-hidden h-100">
                                    <div class="card-body p-4 text-center">
                                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 70px; height: 70px;">
                                            <i class="fas fa-user-friends fa-2x"></i>
                                        </div>
                                        <h3 class="display-4 fw-bold text-primary mb-0">200+</h3>
                                        <p class="text-muted mb-0">Volunteers</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="card border-0 shadow-sm rounded-3 overflow-hidden h-100">
                                    <div class="card-body p-4 text-center">
                                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 70px; height: 70px;">
                                            <i class="fas fa-hands-helping fa-2x"></i>
                                        </div>
                                        <h3 class="display-4 fw-bold text-primary mb-0">50+</h3>
                                        <p class="text-muted mb-0">Outreach Events</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="card border-0 shadow-sm rounded-3 overflow-hidden h-100">
                                    <div class="card-body p-4 text-center">
                                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 70px; height: 70px;">
                                            <i class="fas fa-heart fa-2x"></i>
                                        </div>
                                        <h3 class="display-4 fw-bold text-primary mb-0">100%</h3>
                                        <p class="text-muted mb-0">Dedicated to Service</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="position-absolute top-n5 start-n5 z-n1">
                            <div class="bg-primary bg-opacity-10 rounded-circle" style="width: 300px; height: 300px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-7 py-lg-9 bg-light position-relative overflow-hidden">
        <!-- Decorative elements -->
        <div class="position-absolute top-0 start-0 w-100 h-100" style="background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgcGF0dGVyblRyYW5zZm9ybT0icm90YXRlKDApIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHBhdGggZD0iTTAgMEgxMDBWNDBINDBWMTBIMFYwWiIgZmlsbD0iI2U2N2UyMiIgZmlsbC1vcGFjaXR5PSIwLjA1Ii8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI3BhdHRlcm4pIi8+PC9zdmc+'); opacity: 0.3;"></div>
        
        <div class="container position-relative">
            <div class="text-center mb-7">
                <span class="badge bg-primary bg-opacity-10 text-primary px-4 py-2 rounded-pill mb-3">Testimonials</span>
                <h2 class="fw-bold display-5 mb-3 section-title">What People Are <span class="text-gradient-primary">Saying</span></h2>
                <p class="lead text-muted mx-auto" style="max-width: 700px;">
                    Hear from those who have found purpose, community, and joy through serving in our ministries.
                </p>
            </div>
            
            <!-- Testimonials Carousel -->
            <div class="testimonial-carousel position-relative">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <?php foreach ($testimonials as $testimonial): ?>
                        <div class="swiper-slide">
                            <div class="card h-100 border-0 shadow-sm p-4 p-lg-5 testimonial-card">
                                <div class="card-body text-center p-0">
                                    <div class="testimonial-avatar mx-auto mb-4">
                                        <img src="<?php echo $testimonial['image']; ?>" class="rounded-circle shadow" width="100" height="100" alt="<?php echo htmlspecialchars($testimonial['name']); ?>">
                                        <div class="quote-icon bg-primary text-white rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="fas fa-quote-left"></i>
                                        </div>
                                    </div>
                                    <p class="lead fst-italic mb-4 px-3">"<?php echo htmlspecialchars($testimonial['content']); ?>"</p>
                                    <div class="testimonial-rating mb-3">
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                        <i class="fas fa-star text-warning"></i>
                                    </div>
                                    <h5 class="mb-1"><?php echo htmlspecialchars($testimonial['name']); ?></h5>
                                    <p class="text-muted mb-0"><?php echo htmlspecialchars($testimonial['role']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination mt-4"></div>
                    <!-- Add Navigation -->
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
            
            <div class="text-center mt-7">
                <a href="#" class="btn btn-primary btn-lg px-5 rounded-pill shadow-sm">
                    Share Your Story <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
        
        <style>
            /* Testimonial Card Styles */
            .testimonial-card {
                transition: all 0.3s ease;
                border-radius: 12px;
                background: rgba(255, 255, 255, 0.9);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.5);
            }
            
            .testimonial-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1) !important;
            }
            
            .testimonial-avatar {
                width: 100px;
                height: 100px;
                position: relative;
                margin-top: -60px;
                margin-bottom: 20px;
            }
            
            .testimonial-avatar img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                border: 5px solid #fff;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
            }
            
            .quote-icon {
                position: absolute;
                bottom: -10px;
                right: -10px;
                width: 40px;
                height: 40px;
                font-size: 14px;
                box-shadow: 0 4px 10px rgba(230, 126, 34, 0.3);
            }
            
            .testimonial-rating {
                color: #ffc107;
                font-size: 1.1rem;
                letter-spacing: 2px;
                margin-bottom: 15px;
            }
            
            /* Swiper Customization */
            .swiper-container {
                padding: 20px 0 40px;
            }
            
            .swiper-pagination-bullet {
                width: 10px;
                height: 10px;
                background: #d1d5db;
                opacity: 1;
            }
            
            .swiper-pagination-bullet-active {
                background: #e67e22;
                width: 30px;
                border-radius: 5px;
            }
            
            .swiper-button-next,
            .swiper-button-prev {
                color: #e67e22;
                background: rgba(255, 255, 255, 0.8);
                width: 50px;
                height: 50px;
                border-radius: 50%;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
            }
            
            .swiper-button-next:after,
            .swiper-button-prev:after {
                font-size: 1.2rem;
                font-weight: bold;
            }
            
            .swiper-button-next:hover,
            .swiper-button-prev:hover {
                background: #e67e22;
                color: #fff;
                transform: scale(1.1);
            }
        </style>
        
        <!-- Initialize Swiper -->
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var swiper = new Swiper('.swiper-container', {
                    slidesPerView: 1,
                    spaceBetween: 30,
                    loop: true,
                    autoplay: {
                        delay: 5000,
                        disableOnInteraction: false,
                    },
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                    },
                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev',
                    },
                    breakpoints: {
                        768: {
                            slidesPerView: 2,
                        },
                        992: {
                            slidesPerView: 3,
                        }
                    }
                });
            });
        </script>
    </section>

    <!-- Call to Action -->
    <section class="py-7 bg-primary text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mb-4 mb-lg-0">
                    <h2 class="fw-bold display-5 mb-3">Ready to Make a Difference?</h2>
                    <p class="lead mb-0" style="opacity: 0.9;">Join one of our ministries today and start your journey of faith and service.</p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <a href="#contact" class="btn btn-light btn-lg px-5 rounded-pill">Get Involved</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Upcoming Events -->
    <section class="py-7 bg-white">
        <div class="container">
            <div class="text-center mb-6">
                <span class="badge bg-primary bg-opacity-10 text-primary px-4 py-2 rounded-pill mb-3">What's Happening</span>
                <h2 class="fw-bold display-5 mb-3">Upcoming <span class="text-gradient-primary">Events</span></h2>
                <p class="lead text-muted mx-auto" style="max-width: 700px;">
                    Join us for our upcoming ministry events and activities. There's always something exciting happening!
                </p>
            </div>
            
            <div class="row g-4">
                <?php foreach ($events as $event): ?>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm overflow-hidden">
                        <div class="card-body p-0">
                            <div class="d-flex">
                                <div class="bg-primary text-white text-center p-4" style="min-width: 100px;">
                                    <?php 
                                        $date = new DateTime($event['date']);
                                        echo '<div class="h2 fw-bold mb-0">' . $date->format('d') . '</div>';
                                        echo '<div class="text-uppercase">' . $date->format('M') . '</div>';
                                    ?>
                                </div>
                                <div class="p-4">
                                    <h5 class="mb-2"><?php echo htmlspecialchars($event['title']); ?></h5>
                                    <p class="text-muted small mb-2">
                                        <i class="far fa-clock me-1"></i> <?php echo date('g:i A', strtotime($event['time'])); ?>
                                        <span class="mx-2">•</span>
                                        <i class="fas fa-map-marker-alt me-1"></i> <?php echo htmlspecialchars($event['location']); ?>
                                    </p>
                                    <p class="small mb-0"><?php echo htmlspecialchars($event['description']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent border-top-0 text-end">
                            <a href="#" class="btn btn-sm btn-outline-primary rounded-pill px-3">Learn More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-6">
                <a href="#" class="btn btn-primary btn-lg px-5 rounded-pill">View All Events</a>
            </div>
        </div>
    </section>


    <!-- FAQ Section -->
    <section class="py-7 bg-white">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <span class="badge bg-primary bg-opacity-10 text-primary px-4 py-2 rounded-pill mb-3">FAQs</span>
                    <h2 class="fw-bold display-5 mb-5">Frequently Asked <span class="text-gradient-primary">Questions</span></h2>
                </div>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    How do I join a ministry?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Joining a ministry is easy! You can fill out the contact form on this page, visit our Connect Desk on Sundays, or speak directly to a ministry leader. We'd love to help you find the perfect place to serve.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Do I need experience to serve in a ministry?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    No prior experience is necessary to serve in most of our ministries. We provide training and support to help you grow in your role. The most important qualification is a willing heart to serve God and others.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    How much time commitment is required?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    The time commitment varies by ministry. Some ministries meet weekly, while others meet monthly or for special events. We have opportunities that can fit any schedule, from regular weekly commitments to one-time volunteer opportunities.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    Are there background checks for volunteers?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Yes, we conduct background checks for all volunteers working with minors or vulnerable populations. The safety and security of our church family is our top priority.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item border-0 shadow-sm rounded-3 overflow-hidden">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    What if I'm not sure which ministry is right for me?
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    That's completely normal! We'd love to help you discover your spiritual gifts and find a ministry that aligns with your passions and talents. You can take our spiritual gifts assessment or speak with one of our ministry leaders for guidance.
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-5">
                        <p class="mb-3">Still have questions? We're here to help!</p>
                        <a href="../contact/" class="btn btn-outline-primary btn-lg px-4 rounded-pill">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Newsletter Section -->
    <section class="py-7 bg-primary text-white">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="fw-bold display-5 mb-4">Stay Connected</h2>
                    <p class="lead mb-5" style="opacity: 0.9;">Subscribe to our newsletter to receive updates on ministry events, volunteer opportunities, and inspiring stories.</p>
                    
                    <form class="row g-3 justify-content-center">
                        <div class="col-md-8">
                            <div class="input-group">
                                <input type="email" class="form-control form-control-lg" placeholder="Enter your email address" required>
                                <button class="btn btn-light text-primary px-4" type="submit">Subscribe</button>
                            </div>
                            <div class="form-text text-white-50 mt-2">We'll never share your email. Unsubscribe at any time.</div>
                        </div>
                    </form>
                    
                    <div class="d-flex justify-content-center gap-4 mt-5">
                        <a href="#" class="text-white opacity-75 hover-opacity-100 transition-all"><i class="fab fa-facebook-f fa-lg"></i></a>
                        <a href="#" class="text-white opacity-75 hover-opacity-100 transition-all"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white opacity-75 hover-opacity-100 transition-all"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white opacity-75 hover-opacity-100 transition-all"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Custom JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize AOS if it's included
            if (typeof AOS !== 'undefined') {
                AOS.init({
                    duration: 800,
                    easing: 'ease-in-out',
                    once: true
                });
            }

            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // Search and filter functionality
            const searchInput = document.getElementById('ministrySearch');
            const ministryContainer = document.getElementById('ministryContainer');
            const ministryItems = ministryContainer ? Array.from(ministryContainer.children) : [];
            const filterButtons = document.querySelectorAll('[data-filter]');

            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    filterMinistries(searchTerm);
                });
            }

            if (filterButtons.length > 0) {
                filterButtons.forEach(button => {
                    button.addEventListener('click', function(e) {
                        e.preventDefault();
                        const filter = this.getAttribute('data-filter');
                        
                        // Update active state
                        document.querySelectorAll('[data-filter]').forEach(btn => {
                            btn.classList.remove('active');
                        });
                        this.classList.add('active');

                        // Filter ministries
                        if (filter === 'all') {
                            ministryItems.forEach(item => {
                                item.style.display = '';
                            });
                        } else {
                            ministryItems.forEach(item => {
                                if (item.getAttribute('data-category') === filter) {
                                    item.style.display = '';
                                } else {
                                    item.style.display = 'none';
                                }
                            });
                        }
                    });
                });
            }

            function filterMinistries(searchTerm) {
                if (!ministryContainer) return;
                
                ministryItems.forEach(item => {
                    const title = item.querySelector('.card-title') ? item.querySelector('.card-title').textContent.toLowerCase() : '';
                    const description = item.querySelector('.card-text') ? item.querySelector('.card-text').textContent.toLowerCase() : '';
                    
                    if (title.includes(searchTerm) || description.includes(searchTerm)) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
            }

            // Form validation
            const contactForm = document.getElementById('contactForm');
            if (contactForm) {
                contactForm.addEventListener('submit', function(event) {
                    if (!contactForm.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    
                    contactForm.classList.add('was-validated');
                    
                    if (contactForm.checkValidity()) {
                        // Form is valid, you can submit it via AJAX or let it submit normally
                        event.preventDefault();
                        // Here you would typically make an AJAX call to submit the form
                        alert('Thank you for your message! We will get back to you soon.');
                        contactForm.reset();
                        contactForm.classList.remove('was-validated');
                    }
                }, false);
            }

            // Lazy load images
            const lazyImages = document.querySelectorAll('.lazy-load');
            
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const lazyImage = entry.target;
                            lazyImage.style.backgroundImage = `url('${lazyImage.dataset.src}')`;
                            lazyImage.classList.remove('lazy-load');
                            imageObserver.unobserve(lazyImage);
                        }
                    });
                });

                lazyImages.forEach(lazyImage => {
                    imageObserver.observe(lazyImage);
                });
            }

            // Counter animation
            const animateValue = (id, start, end, duration) => {
                const obj = document.getElementById(id);
                if (!obj) return;
                
                let startTimestamp = null;
                const step = (timestamp) => {
                    if (!startTimestamp) startTimestamp = timestamp;
                    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                    const value = Math.floor(progress * (end - start) + start);
                    obj.innerHTML = value + (obj.getAttribute('data-suffix') || '');
                    if (progress < 1) {
                        window.requestAnimationFrame(step);
                    }
                };
                window.requestAnimationFrame(step);
            };

            // Animate counters when they come into view
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        // Animate counters when they come into view
                        animateValue('ministryCounter1', 0, 12, 2000);
                        animateValue('ministryCounter2', 0, 200, 2000);
                        animateValue('ministryCounter3', 0, 50, 2000);
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });

            const counterSection = document.querySelector('.counter-section');
            if (counterSection) {
                observer.observe(counterSection);
            }
        });
    </script>
    
    <?php
    // Include footer
    include __DIR__ . '/../includes/footer.php';
    
} catch (Exception $e) {
    // Log the error
    error_log('Ministry page error: ' . $e->getMessage());
    
    // Clear any output that might have been generated
    ob_clean();
    
    // Output a basic error page
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error - <?php echo htmlspecialchars($pageTitle); ?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            .error-container { height: 100vh; display: flex; align-items: center; justify-content: center; }
            .error-card { max-width: 500px; width: 100%; padding: 2rem; text-align: center; }
        </style>
    </head>
    <body class="bg-light">
        <div class="error-container">
            <div class="error-card card shadow">
                <div class="card-body">
                    <h1 class="text-danger mb-4">Oops! Something went wrong</h1>
                    <p class="lead">We're having trouble loading the page you requested. Please try again later.</p>
                    <p class="text-muted small">Error: <?php echo htmlspecialchars($e->getMessage()); ?></p>
                    <a href="/" class="btn btn-primary mt-3">Return to Home</a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
}

// Flush the output buffer
ob_end_flush();
?>