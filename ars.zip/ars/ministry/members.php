<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['admin', 'pastor']);

$user = get_user();
$db = new FileDB();

// Get all members from the database
$members = $db->getAllMembers();

// Handle member actions
if ($_POST) {
    $action = $_POST['action'] ?? '';
    $memberId = $_POST['member_id'] ?? '';
    
    if ($action === 'activate' && $memberId) {
        $db->updateMemberStatus($memberId, 'active');
        $message = '<div class="alert alert-success">Member activated successfully!</div>';
    } elseif ($action === 'deactivate' && $memberId) {
        $db->updateMemberStatus($memberId, 'inactive');
        $message = '<div class="alert alert-warning">Member deactivated.</div>';
    } elseif ($action === 'delete' && $memberId) {
        $db->deleteMember($memberId);
        $message = '<div class="alert alert-danger">Member deleted.</div>';
    }
    
    // Refresh members list
    $members = $db->getAllMembers();
}

// Filter members by status
$activeMembers = array_filter($members, function($m) { return ($m['status'] ?? 'active') === 'active'; });
$inactiveMembers = array_filter($members, function($m) { return ($m['status'] ?? 'active') === 'inactive'; });
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ministry Members | Church Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #1a1a2e;
            --text: #2d3436;
            --text-light: #7f8c8d;
            --gradient-primary: linear-gradient(135deg, #e67e22 0%, #d35400 100%);
            --gradient-secondary: linear-gradient(135deg, #2c3e50 0%, #1a1a2e 100%);
            --gradient-accent: linear-gradient(135deg, #ffd700 0%, #f39c12 100%);
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --card-border-radius: 12px;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f8f9fa;
            color: var(--text);
            line-height: 1.7;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Playfair Display', serif;
            font-weight: 600;
        }

        .navbar {
            background: var(--secondary) !important;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .card {
            border: none;
            border-radius: var(--card-border-radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
            overflow: hidden;
            margin-bottom: 1.5rem;
            background: white;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }

        .card.stat-card {
            border-left: 4px solid var(--primary);
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .card.stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .card.stat-card .card-body {
            padding: 1.5rem;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            color: white;
            margin-bottom: 1rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0.5rem 0;
            color: var(--dark);
            font-family: 'Playfair Display', serif;
        }

        .stat-label {
            color: var(--text-light);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }

        .nav-tabs {
            border: none;
            margin-bottom: 1.5rem;
            background: white;
            padding: 0.5rem;
            border-radius: 50px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .nav-tabs .nav-link {
            border: none;
            color: var(--text-light);
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            border-radius: 50px;
            margin: 0 0.25rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .nav-tabs .nav-link i {
            margin-right: 8px;
        }

        .nav-tabs .nav-link.active {
            background: var(--gradient-primary);
            color: white;
            box-shadow: 0 4px 15px rgba(230, 126, 34, 0.3);
        }

        .nav-tabs .nav-link:not(.active):hover {
            color: var(--primary);
            background: rgba(230, 126, 34, 0.1);
        }

        .badge {
            font-weight: 600;
            padding: 0.4em 0.8em;
            border-radius: 50px;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
        }

        .btn {
            font-weight: 500;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn i {
            margin-right: 0.5rem;
        }

        .btn-primary {
            background: var(--gradient-primary);
            border: none;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(230, 126, 34, 0.3);
        }

        .table {
            --bs-table-hover-bg: rgba(230, 126, 34, 0.05);
        }

        .table th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
            color: var(--text-light);
            border-bottom: 2px solid #f1f1f1;
        }

        .table td {
            vertical-align: middle;
            padding: 1.25rem 1.5rem;
            border-color: #f8f9fa;
        }

        .member-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--gradient-primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            margin-right: 12px;
        }

        .member-name {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 0;
            display: flex;
            align-items: center;
        }

        .member-role {
            font-size: 0.8rem;
            color: var(--text-light);
        }

        .action-buttons .btn {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
            margin: 0 2px;
        }

        .empty-state {
            padding: 3rem 1rem;
            text-align: center;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.3;
        }

        .empty-state h5 {
            color: var(--dark);
            margin-bottom: 0.5rem;
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.6s ease-out forwards;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .stat-card {
                margin-bottom: 1rem;
            }
            
            .table-responsive {
                border-radius: 8px;
                border: 1px solid #eee;
            }
        }
    </style>
</head>
<body class="bg-light">
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark shadow-sm sticky-top mb-4">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="../index.php">
            <i class="fas fa-church me-2 text-warning"></i>
            <span>Church Management</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="me-2 d-flex align-items-center">
                            <i class="fas fa-user-circle me-2" style="font-size: 1.5rem;"></i>
                            <span class="d-none d-md-inline"><?php echo htmlspecialchars($user['name']); ?></span>
                        </div>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../dashboard/<?php echo $user['role']; ?>.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                        <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user-edit me-2"></i>Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="row mb-5">
        <div class="col-12">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4">
                <div class="mb-3 mb-md-0">
                    <h1 class="h3 mb-2" data-aos="fade-right">Ministry Members</h1>
                    <p class="text-muted mb-0" data-aos="fade-right" data-aos-delay="100">Manage and track all church members in one place</p>
                </div>
                <div class="d-flex" data-aos="fade-left">
                    <a href="../members/register.php" class="btn btn-primary me-2">
                        <i class="fas fa-user-plus me-2"></i>Add New Member
                    </a>
                    <a href="../dashboard/<?php echo $user['role']; ?>.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                    </a>
                </div>
            </div>
            
            <?php echo $message ?? ''; ?>
            
            <!-- Statistics Cards -->
            <div class="row g-4 mb-5">
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                    <div class="card stat-card h-100 border-0">
                        <div class="card-body p-4">
                            <div class="stat-icon" style="background: var(--gradient-primary);">
                                <i class="fas fa-users"></i>
                            </div>
                            <h2 class="stat-number"><?php echo count($members); ?></h2>
                            <p class="stat-label">Total Members</p>
                            <div class="progress" style="height: 4px;">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                    <div class="card stat-card h-100 border-0">
                        <div class="card-body p-4">
                            <div class="stat-icon" style="background: var(--gradient-secondary);">
                                <i class="fas fa-user-check"></i>
                            </div>
                            <h2 class="stat-number"><?php echo count($activeMembers); ?></h2>
                            <p class="stat-label">Active Members</p>
                            <div class="progress" style="height: 4px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                    <div class="card stat-card h-100 border-0">
                        <div class="card-body p-4">
                            <div class="stat-icon" style="background: linear-gradient(135deg, #f39c12 0%, #e74c3c 100%);">
                                <i class="fas fa-user-times"></i>
                            </div>
                            <h2 class="stat-number"><?php echo count($inactiveMembers); ?></h2>
                            <p class="stat-label">Inactive Members</p>
                            <div class="progress" style="height: 4px;">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                    <div class="card stat-card h-100 border-0">
                        <div class="card-body p-4">
                            <div class="stat-icon" style="background: var(--gradient-accent);">
                                <i class="fas fa-crown"></i>
                            </div>
                            <h2 class="stat-number"><?php echo count(array_filter($members, function($m) { return ($m['role'] ?? 'member') === 'leader'; })); ?></h2>
                            <p class="stat-label">Ministry Leaders</p>
                            <div class="progress" style="height: 4px;">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Tabs -->
            <div class="bg-white rounded-3 shadow-sm p-2 mb-4" data-aos="fade-up">
                <ul class="nav nav-tabs nav-fill" id="memberTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active d-flex align-items-center justify-content-center" id="active-tab" data-bs-toggle="tab" data-bs-target="#active" type="button" role="tab">
                            <i class="fas fa-user-check me-2"></i>Active Members 
                            <span class="badge bg-success ms-2"><?php echo count($activeMembers); ?></span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link d-flex align-items-center justify-content-center" id="inactive-tab" data-bs-toggle="tab" data-bs-target="#inactive" type="button" role="tab">
                            <i class="fas fa-user-times me-2"></i>Inactive Members 
                            <span class="badge bg-warning text-dark ms-2"><?php echo count($inactiveMembers); ?></span>
                        </button>
                    </li>
                </ul>
            </div>
            
            <div class="tab-content" id="memberTabContent">
                <!-- Active Members -->
                <div class="tab-pane fade show active" id="active" role="tabpanel">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-0">
                            <?php if (empty($activeMembers)): ?>
                                <div class="empty-state" data-aos="fade-up">
                                    <i class="fas fa-users"></i>
                                    <h5>No Active Members</h5>
                                    <p>There are currently no active members in the system.</p>
                                    <a href="../members/register.php" class="btn btn-primary mt-3">
                                        <i class="fas fa-user-plus me-2"></i>Add New Member
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th class="ps-4">Member</th>
                                                <th>Contact</th>
                                                <th>Role</th>
                                                <th>Status</th>
                                                <th>Joined</th>
                                                <th class="text-end pe-4">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            $delay = 0;
                                            foreach ($activeMembers as $member): 
                                                $delay += 50;
                                                $initials = '';
                                                $nameParts = explode(' ', $member['name']);
                                                $initials = strtoupper(substr($nameParts[0], 0, 1) . (count($nameParts) > 1 ? substr(end($nameParts), 0, 1) : ''));
                                            ?>
                                                <tr class="fade-in" style="animation-delay: <?php echo $delay; ?>ms;">
                                                    <td class="ps-4">
                                                        <div class="d-flex align-items-center">
                                                            <div class="member-avatar">
                                                                <?php echo $initials; ?>
                                                            </div>
                                                            <div>
                                                                <p class="member-name mb-0">
                                                                    <?php echo htmlspecialchars($member['name']); ?>
                                                                    <?php if (($member['role'] ?? 'member') === 'leader'): ?>
                                                                        <i class="fas fa-crown text-warning ms-2" title="Leader"></i>
                                                                    <?php endif; ?>
                                                                </p>
                                                                <small class="member-role">Member since <?php echo date('M Y', strtotime($member['created_at'] ?? 'now')); ?></small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex flex-column">
                                                            <a href="mailto:<?php echo htmlspecialchars($member['email']); ?>" class="text-dark">
                                                                <i class="fas fa-envelope text-muted me-2"></i><?php echo htmlspecialchars($member['email']); ?>
                                                            </a>
                                                            <small class="text-muted">
                                                                <i class="fas fa-phone-alt me-2"></i><?php echo !empty($member['phone']) ? htmlspecialchars($member['phone']) : 'N/A'; ?>
                                                            </small>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?php echo ($member['role'] ?? 'member') === 'leader' ? 'warning text-dark' : 'primary'; ?> px-3 py-2">
                                                            <i class="fas fa-<?php echo ($member['role'] ?? 'member') === 'leader' ? 'crown' : 'user'; ?> me-1"></i>
                                                            <?php echo ucfirst($member['role'] ?? 'member'); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-success bg-opacity-10 text-success">
                                                            <i class="fas fa-circle me-1" style="font-size: 0.5rem;"></i> Active
                                                        </span>
                                                    </td>
                                                    <td><?php echo date('M j, Y', strtotime($member['created_at'] ?? 'now')); ?></td>
                                                    <td class="text-end pe-4">
                                                        <div class="action-buttons">
                                                            <button type="button" class="btn btn-sm btn-outline-warning" 
                                                                    data-bs-toggle="tooltip" 
                                                                    title="Deactivate"
                                                                    onclick="deactivateMember('<?php echo $member['id']; ?>', '<?php echo htmlspecialchars(addslashes($member['name'])); ?>')">
                                                                <i class="fas fa-user-slash"></i>
                                                            </button>
                                                            <button type="button" class="btn btn-sm btn-outline-danger ms-1" 
                                                                    data-bs-toggle="tooltip" 
                                                                    title="Delete"
                                                                    onclick="deleteMember('<?php echo $member['id']; ?>', '<?php echo htmlspecialchars(addslashes($member['name'])); ?>')">
                                                                <i class="fas fa-trash-alt"></i>
                                                            </button>
                                                            <button type="button" class="btn btn-sm btn-outline-primary ms-1" 
                                                                    data-bs-toggle="tooltip" 
                                                                    title="View Profile">
                                                                <i class="fas fa-eye"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Inactive Members -->
                <div class="tab-pane fade" id="inactive" role="tabpanel">
                    <div class="card mt-3">
                        <div class="card-body">
                            <?php if (empty($inactiveMembers)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-user-times text-muted fa-3x mb-3"></i>
                                    <h5>No inactive members</h5>
                                    <p class="text-muted">Inactive members will appear here.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Role</th>
                                                <th>Joined Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($inactiveMembers as $member): ?>
                                                <tr class="table-secondary">
                                                    <td>
                                                        <strong><?php echo htmlspecialchars($member['name']); ?></strong>
                                                        <?php if (($member['role'] ?? 'member') === 'leader'): ?>
                                                            <i class="fas fa-crown text-warning ms-1" title="Leader"></i>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($member['email']); ?></td>
                                                    <td><?php echo htmlspecialchars($member['phone'] ?? 'N/A'); ?></td>
                                                    <td>
                                                        <span class="badge bg-<?php echo ($member['role'] ?? 'member') === 'leader' ? 'warning' : 'secondary'; ?>">
                                                            <?php echo ucfirst($member['role'] ?? 'member'); ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo date('M j, Y', strtotime($member['created_at'] ?? 'now')); ?></td>
                                                    <td>
                                                        <div class="btn-group" role="group">
                                                            <button type="button" class="btn btn-success btn-sm" onclick="activateMember('<?php echo $member['id']; ?>', '<?php echo htmlspecialchars($member['name']); ?>')">
                                                                <i class="fas fa-user-check"></i> Activate
                                                            </button>
                                                            <button type="button" class="btn btn-danger btn-sm" onclick="deleteMember('<?php echo $member['id']; ?>', '<?php echo htmlspecialchars($member['name']); ?>')">
                                                                <i class="fas fa-trash"></i> Delete
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Action Form -->
<form id="actionForm" method="POST" style="display: none;">
    <input type="hidden" name="action" id="action">
    <input type="hidden" name="member_id" id="member_id">
</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function activateMember(memberId, memberName) {
    if (confirm(`Are you sure you want to activate ${memberName}?`)) {
        document.getElementById('action').value = 'activate';
        document.getElementById('member_id').value = memberId;
        document.getElementById('actionForm').submit();
    }
}

function deactivateMember(memberId, memberName) {
    if (confirm(`Are you sure you want to deactivate ${memberName}?`)) {
        document.getElementById('action').value = 'deactivate';
        document.getElementById('member_id').value = memberId;
        document.getElementById('actionForm').submit();
    }
}

function deleteMember(memberId, memberName) {
    if (confirm(`Are you sure you want to permanently delete ${memberName}? This action cannot be undone.`)) {
        document.getElementById('action').value = 'delete';
        document.getElementById('member_id').value = memberId;
        document.getElementById('actionForm').submit();
    }
}
</script>
</body>
</html>
