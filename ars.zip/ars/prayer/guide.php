<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
$page_title = 'Prayer Guide';
$show_page_header = true;
$base_path = '../';
include '../includes/header.php';
?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h2 class="h4 mb-3">Weekly Prayer Focus</h2>
                    <ol>
                        <li>Thanksgiving and praise</li>
                        <li>Personal growth and holiness</li>
                        <li>Church leadership and ministries</li>
                        <li>Community outreach and missions</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>

