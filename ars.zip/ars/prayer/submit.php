<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['member']);
$user = get_user();

$success_message = '';
$error_message = '';
$csrf_token = generate_csrf_token();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid session token. Please refresh and try again.';
    } else {
    $request = trim($_POST['request'] ?? '');
    
    if (empty($request)) {
        $error_message = 'Please enter your prayer request.';
    } else {
        // Check if prayer_requests table exists
        $result = $conn->query("SHOW TABLES LIKE 'prayer_requests'");
        if ($result->num_rows == 0) {
            // Create prayer_requests table if it doesn't exist
            $sql = "CREATE TABLE IF NOT EXISTS prayer_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                request TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            $conn->query($sql);
        }
        
        // Insert the prayer request
        $stmt = $conn->prepare("INSERT INTO prayer_requests (user_id, request) VALUES (?, ?)");
        $stmt->bind_param("is", $user['id'], $request);
        
        if ($stmt->execute()) {
            $success_message = 'Your prayer request has been submitted successfully.';
        } else {
            $error_message = 'Failed to submit your prayer request. Please try again.';
        }
        
        $stmt->close();
    }
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Prayer Request - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .prayer-form {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 30px;
            margin-top: 30px;
        }
        .header-icon {
            font-size: 3rem;
            color: #0984e3;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="text-center mb-4">
                    <i class="fas fa-pray header-icon mb-3"></i>
                    <h2>Submit a Prayer Request</h2>
                    <p class="text-muted">Share your prayer needs with our church community</p>
                </div>
                
                <?php if (!empty($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
                <?php endif; ?>
                
                <div class="prayer-form">
                    <form method="post" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <div class="mb-4">
                            <label for="request" class="form-label">Your Prayer Request</label>
                            <textarea class="form-control" id="request" name="request" rows="6" placeholder="Please share your prayer request here..."></textarea>
                            <div class="form-text">Your request will be shared with our prayer team.</div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">Submit Prayer Request</button>
                        </div>
                    </form>
                </div>
                
                <div class="text-center mt-4">
                    <a href="../dashboard/member.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>