<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['pastor']);
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

// Handle request actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
    $action = $_POST['action'];
    $request_id = $_POST['request_id'];
    
    if ($action === 'approve') {
        $scheduled_date = $_POST['scheduled_date'];
        $scheduled_time = $_POST['scheduled_time'];
        $notes = trim($_POST['notes']);
        
        if ($conn->approveCounselingRequest($request_id, $scheduled_date, $scheduled_time, $notes)) {
            $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Request approved and session scheduled!</div>';
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error approving request.</div>';
        }
    } elseif ($action === 'decline') {
        $decline_reason = trim($_POST['decline_reason']);
        if ($conn->declineCounselingRequest($request_id, $decline_reason)) {
            $message = '<div class="alert alert-info"><i class="fas fa-info-circle me-2"></i>Request declined.</div>';
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error declining request.</div>';
        }
    }
}
}

// Get counseling requests
$requests = $conn->getCounselingRequests();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Counseling Requests - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user['name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../dashboard/pastor.php">Dashboard</a></li>
                            <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-inbox me-2"></i>Counseling Requests</h2>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Counseling
                    </a>
                </div>
            </div>
        </div>

        <?php echo $message; ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-list me-2"></i>All Requests</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($requests && $requests->num_rows > 0): ?>
                            <?php while($request = $requests->fetch_assoc()): ?>
                            <div class="card mb-3 <?php echo $request['status'] === 'pending' ? 'border-warning' : ($request['status'] === 'approved' ? 'border-success' : 'border-secondary'); ?>">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-0"><?php echo htmlspecialchars($request['member_name']); ?></h6>
                                        <small class="text-muted"><?php echo ucwords(str_replace('_', ' ', $request['request_type'])); ?></small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-<?php echo $request['status'] === 'pending' ? 'warning' : ($request['status'] === 'approved' ? 'success' : 'secondary'); ?>">
                                            <?php echo ucfirst($request['status']); ?>
                                        </span>
                                        <?php if ($request['is_urgent']): ?>
                                            <span class="badge bg-danger ms-1">Urgent</span>
                                        <?php endif; ?>
                                        <br>
                                        <small class="text-muted"><?php echo date('M j, Y g:i A', strtotime($request['created_at'])); ?></small>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <p class="mb-2"><strong>Preferred Date/Time:</strong> <?php echo date('M j, Y', strtotime($request['preferred_date'])); ?> at <?php echo date('g:i A', strtotime($request['preferred_time'])); ?></p>
                                    <p class="mb-3"><strong>Description:</strong><br><?php echo nl2br(htmlspecialchars($request['description'])); ?></p>
                                    
                                    <?php if ($request['status'] === 'pending'): ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#approveModal<?php echo $request['id']; ?>">
                                                <i class="fas fa-check me-1"></i>Approve
                                            </button>
                                            <button class="btn btn-danger btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#declineModal<?php echo $request['id']; ?>">
                                                <i class="fas fa-times me-1"></i>Decline
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <!-- Approve Modal -->
                                    <div class="modal fade" id="approveModal<?php echo $request['id']; ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Approve Request</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form method="POST">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                        <input type="hidden" name="action" value="approve">
                                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Scheduled Date</label>
                                                            <input type="date" name="scheduled_date" class="form-control" value="<?php echo $request['preferred_date']; ?>" required>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Scheduled Time</label>
                                                            <input type="time" name="scheduled_time" class="form-control" value="<?php echo $request['preferred_time']; ?>" required>
                                                        </div>
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Notes (Optional)</label>
                                                            <textarea name="notes" class="form-control" rows="3" placeholder="Any additional notes for the member..."></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-success">Approve & Schedule</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Decline Modal -->
                                    <div class="modal fade" id="declineModal<?php echo $request['id']; ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Decline Request</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form method="POST">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                                        <input type="hidden" name="action" value="decline">
                                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label">Reason for Declining</label>
                                                            <textarea name="decline_reason" class="form-control" rows="3" placeholder="Please provide a reason..." required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">Decline Request</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php elseif ($request['status'] === 'approved'): ?>
                                    <div class="alert alert-success mb-0">
                                        <i class="fas fa-calendar-check me-2"></i>
                                        <strong>Scheduled:</strong> <?php echo date('M j, Y g:i A', strtotime($request['scheduled_date'] . ' ' . $request['scheduled_time'])); ?>
                                        <?php if ($request['notes']): ?>
                                            <br><strong>Notes:</strong> <?php echo htmlspecialchars($request['notes']); ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php elseif ($request['status'] === 'declined'): ?>
                                    <div class="alert alert-secondary mb-0">
                                        <i class="fas fa-times-circle me-2"></i>
                                        <strong>Declined:</strong> <?php echo htmlspecialchars($request['decline_reason']); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No Counseling Requests</h5>
                                <p class="text-muted">Counseling requests from members will appear here.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
