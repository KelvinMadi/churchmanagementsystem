<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Check if user is logged in and has appropriate permissions
if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Check if user has permission to schedule sessions
if (!hasPermission('counseling', 'schedule')) {
    header('Location: ../unauthorized.php');
    exit();
}

$db = new FileDB();
$success = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $member_id = filter_input(INPUT_POST, 'member_id', FILTER_VALIDATE_INT);
        $counselor_id = $_SESSION['user_id'];
        $scheduled_date = filter_input(INPUT_POST, 'scheduled_date', FILTER_SANITIZE_STRING);
        $scheduled_time = filter_input(INPUT_POST, 'scheduled_time', FILTER_SANITIZE_STRING);
        $notes = filter_input(INPUT_POST, 'notes', FILTER_SANITIZE_STRING);
        $status = 'scheduled';

        // Validate input
        if (!$member_id || !$scheduled_date || !$scheduled_time) {
            $error = 'Please fill in all required fields.';
        } else {
            // Create session data array
            $session_data = [
                'member_id' => $member_id,
                'counselor_id' => $counselor_id,
                'scheduled_date' => $scheduled_date,
                'scheduled_time' => $scheduled_time,
                'notes' => $notes,
                'status' => $status,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            // Save to database
            $sessions = $db->loadData('counseling_sessions.json');
            $sessions[] = $session_data;
            $db->saveData('counseling_sessions.json', $sessions);
            
            $success = 'Counseling session scheduled successfully!';
        }
    }
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Get active members for the dropdown
$members = $db->getAllMembers();

// Get upcoming sessions
$upcoming_sessions = $db->getUpcomingSessions();
?>

<?php include '../includes/header.php'; ?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">Schedule Counseling Session</h3>
                </div>
                <div class="card-body">
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        
                        <div class="mb-3">
                            <label for="member_id" class="form-label">Select Member</label>
                            <select class="form-select" id="member_id" name="member_id" required>
                                <option value="">-- Select Member --</option>
                                <?php foreach ($members as $member): ?>
                                    <option value="<?php echo htmlspecialchars($member['id']); ?>">
                                        <?php echo htmlspecialchars($member['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="scheduled_date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="scheduled_date" name="scheduled_date" 
                                       min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="scheduled_time" class="form-label">Time</label>
                                <input type="time" class="form-control" id="scheduled_time" name="scheduled_time" 
                                       min="09:00" max="17:00" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">Notes (Optional)</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Schedule Session</button>
                        <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
                    </form>
                </div>
            </div>
            
            <!-- Upcoming Sessions -->
            <div class="card mt-4">
                <div class="card-header bg-light">
                    <h4 class="mb-0">Upcoming Sessions</h4>
                </div>
                <div class="card-body">
                    <?php if (count($upcoming_sessions) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Member</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($upcoming_sessions as $session): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($session['member_name'] ?? 'N/A'); ?></td>
                                            <td><?php echo date('M j, Y', strtotime($session['scheduled_date'])); ?></td>
                                            <td><?php echo date('g:i A', strtotime($session['scheduled_time'])); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $session['status'] === 'completed' ? 'success' : 
                                                         ($session['status'] === 'cancelled' ? 'danger' : 'primary'); 
                                                ?>">
                                                    <?php echo ucfirst(htmlspecialchars($session['status'])); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No upcoming sessions scheduled.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
