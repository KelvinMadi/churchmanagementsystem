<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['pastor']);
$user = get_user();

// Get counseling statistics
$total_sessions = $conn->getCounselingSessionsCount();
$pending_requests = $conn->getPendingCounselingRequests();
$upcoming_sessions = $conn->getUpcomingSessions();

$page_title = "Counseling Management";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Counseling Management - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user['name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../dashboard/pastor.php">Dashboard</a></li>
                            <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-hands-helping me-2"></i>Counseling Management</h2>
                    <div>
                        <a href="schedule.php" class="btn btn-primary">
                            <i class="fas fa-calendar-plus me-2"></i>Schedule Session
                        </a>
                        <a href="requests.php" class="btn btn-info">
                            <i class="fas fa-inbox me-2"></i>View Requests
                            <?php if ($pending_requests && $pending_requests->num_rows > 0): ?>
                                <span class="badge bg-danger ms-1"><?php echo $pending_requests->num_rows; ?></span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar-check fa-2x mb-2"></i>
                        <h4><?php echo $total_sessions; ?></h4>
                        <p class="mb-0">Total Sessions</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-clock fa-2x mb-2"></i>
                        <h4><?php echo $pending_requests ? $pending_requests->num_rows : 0; ?></h4>
                        <p class="mb-0">Pending Requests</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar-day fa-2x mb-2"></i>
                        <h4><?php echo $upcoming_sessions ? $upcoming_sessions->num_rows : 0; ?></h4>
                        <p class="mb-0">Upcoming Sessions</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-2x mb-2"></i>
                        <h4><?php echo $conn->getActiveCounselees(); ?></h4>
                        <p class="mb-0">Active Counselees</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <a href="schedule.php" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-calendar-plus me-2"></i>Schedule Session
                                </a>
                            </div>
                            <div class="col-md-4 mb-3">
                                <a href="requests.php" class="btn btn-outline-warning w-100">
                                    <i class="fas fa-inbox me-2"></i>View Requests
                                </a>
                            </div>
                            <div class="col-md-4 mb-3">
                                <a href="sessions.php" class="btn btn-outline-success w-100">
                                    <i class="fas fa-history me-2"></i>Session History
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Upcoming Sessions</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($upcoming_sessions && $upcoming_sessions->num_rows > 0): ?>
                            <?php while($session = $upcoming_sessions->fetch_assoc()): ?>
                            <div class="d-flex justify-content-between align-items-center mb-3 p-2 border rounded">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($session['member_name']); ?></h6>
                                    <small class="text-muted"><?php echo $session['session_type']; ?></small>
                                </div>
                                <div class="text-end">
                                    <small class="text-muted"><?php echo date('M j, g:i A', strtotime($session['scheduled_date'] . ' ' . $session['scheduled_time'])); ?></small>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center">No upcoming sessions scheduled.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-bell me-2"></i>Pending Requests</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($pending_requests && $pending_requests->num_rows > 0): ?>
                            <?php while($request = $pending_requests->fetch_assoc()): ?>
                            <div class="d-flex justify-content-between align-items-center mb-3 p-2 border rounded">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($request['member_name']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($request['request_type']); ?></small>
                                </div>
                                <div class="text-end">
                                    <small class="text-muted"><?php echo date('M j', strtotime($request['created_at'])); ?></small>
                                    <br>
                                    <a href="requests.php?view=<?php echo $request['id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center">No pending requests.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="mt-3">
            <a href="../dashboard/pastor.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
