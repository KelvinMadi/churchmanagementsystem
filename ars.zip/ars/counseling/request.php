<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_role(['member', 'admin', 'accountant', 'leader']);
$user = get_user();

$message = '';
$csrf_token = generate_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Invalid session token. Please refresh and try again.</div>';
    } else {
    $request_type = $_POST['request_type'];
    $preferred_date = $_POST['preferred_date'];
    $preferred_time = $_POST['preferred_time'];
    $description = trim($_POST['description']);
    $is_urgent = isset($_POST['is_urgent']) ? 1 : 0;
    $is_confidential = isset($_POST['is_confidential']) ? 1 : 0;
    
    if ($request_type && $preferred_date && $preferred_time && $description) {
        $request_data = [
            'id' => time() . rand(100, 999),
            'member_id' => $user['id'],
            'member_name' => $user['name'],
            'request_type' => $request_type,
            'description' => htmlspecialchars($description),
            'preferred_date' => $preferred_date,
            'preferred_time' => $preferred_time,
            'is_urgent' => $is_urgent,
            'is_confidential' => $is_confidential,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        if ($conn->saveCounselingRequest($request_data)) {
            $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Counseling request submitted successfully! The pastor will review it soon.</div>';
            $_POST = [];
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error submitting request. Please try again.</div>';
        }
    } else {
        $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all required fields.</div>';
    }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Counseling - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($user['name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../dashboard/<?php echo $user['role']; ?>.php">Dashboard</a></li>
                            <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="form-card">
                    <div class="upload-header text-center p-4">
                        <i class="fas fa-hands-helping fa-3x mb-3"></i>
                        <h3>Request Counseling Session</h3>
                        <p class="mb-0">Schedule a private counseling session with the pastor</p>
                    </div>
                    <div class="card-body p-4">
                        <?php echo $message; ?>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-tag me-2"></i>Type of Counseling *</label>
                                <select name="request_type" class="form-select" required>
                                    <option value="">Select Type</option>
                                    <option value="personal">Personal Issues</option>
                                    <option value="marriage">Marriage Counseling</option>
                                    <option value="family">Family Issues</option>
                                    <option value="spiritual">Spiritual Guidance</option>
                                    <option value="grief">Grief Counseling</option>
                                    <option value="addiction">Addiction Support</option>
                                    <option value="financial">Financial Guidance</option>
                                    <option value="career">Career/Life Direction</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label"><i class="fas fa-calendar me-2"></i>Preferred Date *</label>
                                        <input type="date" name="preferred_date" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label"><i class="fas fa-clock me-2"></i>Preferred Time *</label>
                                        <select name="preferred_time" class="form-select" required>
                                            <option value="">Select Time</option>
                                            <option value="09:00">9:00 AM</option>
                                            <option value="10:00">10:00 AM</option>
                                            <option value="11:00">11:00 AM</option>
                                            <option value="14:00">2:00 PM</option>
                                            <option value="15:00">3:00 PM</option>
                                            <option value="16:00">4:00 PM</option>
                                            <option value="17:00">5:00 PM</option>
                                            <option value="19:00">7:00 PM</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-comment-alt me-2"></i>Description *</label>
                                <textarea name="description" class="form-control" rows="4" required placeholder="Please provide a brief description of what you'd like to discuss..."></textarea>
                                <small class="form-text text-muted">This information will help the pastor prepare for your session.</small>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_urgent" id="is_urgent">
                                    <label class="form-check-label" for="is_urgent">
                                        <i class="fas fa-exclamation-triangle text-warning me-1"></i>This is urgent
                                    </label>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_confidential" id="is_confidential" checked>
                                    <label class="form-check-label" for="is_confidential">
                                        <i class="fas fa-lock text-info me-1"></i>Keep this request confidential
                                    </label>
                                    <small class="form-text text-muted d-block">Your request details will only be visible to the pastor</small>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="../dashboard/<?php echo $user['role']; ?>.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Request
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
