<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

$page_title = "Contact Us";
$show_page_header = false;
$base_path = '';

// CSRF token
$csrf_token = generate_csrf_token();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $submission_success = false;
        $error_message = 'Invalid session token. Please refresh and try again.';
    } else {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $message = $_POST['message'] ?? '';
    
        // Simple validation & optional email send
        if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && $message) {
            $to = 'info@arschurch.org';
            $subject = 'Contact Form: ' . ($_POST['subject'] ?? 'General Inquiry');
            $body = "From: $name <$email>\n\n$message";
            $headers = 'From: no-reply@arschurch.com';
            @mail($to, $subject, $body, $headers);
            $submission_success = true;
        } else {
            $error_message = 'Please provide a valid name, email and message.';
        }
    }
}

include 'includes/header.php';
?>

<!-- Modern Header with Animated Background -->
<header class="contact-header">
    <div class="header-content">
        <h1 class="display-4 fw-bold text-white mb-3">Get In Touch</h1>
        <p class="lead text-white-50">We're here to help and answer any questions you might have.</p>
    </div>
    <div class="header-shape">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512,54.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" fill="#fff"></path>
            <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" fill="#fff"></path>
            <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" fill="#fff"></path>
        </svg>
    </div>
</header>

<!-- Contact Section -->
<section class="contact-section">
    <div class="container">
        <div class="contact-container">
            <!-- Contact Form -->
            <div class="contact-form-container">
                <?php if (isset($submission_success) && $submission_success): ?>
                    <div class="success-message">
                        <div class="success-icon">
                            <svg viewBox="0 0 100 100">
                                <circle cx="50" cy="50" r="45" fill="#19875420" />
                                <path d="M30,50 l18,18 l32-32" fill="none" stroke="#198754" stroke-width="8" stroke-linecap="round" />
                            </svg>
                        </div>
                        <h3>Message Sent Successfully!</h3>
                        <p>Thank you for reaching out. We'll get back to you soon.</p>
                        <a href="contact.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i> Back to Contact
                        </a>
                    </div>
                <?php else: ?>
                    <div class="form-header">
                        <h2>Send Us a Message</h2>
                        <p>Fill out the form below and we'll get back to you as soon as possible.</p>
                    </div>
                    
                    <form action="contact.php" method="POST" class="contact-form" novalidate>
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        
                        <div class="form-group">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                                <label for="name">
                                    <i class="fas fa-user"></i>
                                    <span>Your Name</span>
                                </label>
                                <div class="form-underline"></div>
                            </div>
                            <div class="invalid-feedback">Please enter your name</div>
                        </div>
                        
                        <div class="form-group">
                            <div class="form-floating">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
                                <label for="email">
                                    <i class="fas fa-envelope"></i>
                                    <span>Email Address</span>
                                </label>
                                <div class="form-underline"></div>
                            </div>
                            <div class="invalid-feedback">Please enter a valid email</div>
                        </div>
                        
                        <div class="form-group">
                            <div class="form-floating">
                                <select class="form-select" id="subject" name="subject" required>
                                    <option value="" selected disabled></option>
                                    <option value="General Inquiry">General Inquiry</option>
                                    <option value="Prayer Request">Prayer Request</option>
                                    <option value="Ministry Question">Ministry Question</option>
                                    <option value="Event Information">Event Information</option>
                                    <option value="Other">Other</option>
                                </select>
                                <label for="subject">
                                    <i class="fas fa-tag"></i>
                                    <span>How can we help you?</span>
                                </label>
                                <div class="form-underline"></div>
                                <div class="select-arrow">
                                    <i class="fas fa-chevron-down"></i>
                                </div>
                            </div>
                            <div class="invalid-feedback">Please select a subject</div>
                        </div>
                        
                        <div class="form-group">
                            <div class="form-floating">
                                <textarea class="form-control" id="message" name="message" placeholder="Your message" style="height: 150px;" required></textarea>
                                <label for="message">
                                    <i class="fas fa-comment-alt"></i>
                                    <span>Your Message</span>
                                </label>
                                <div class="form-underline"></div>
                                <div class="char-counter"><span>0</span>/500</div>
                            </div>
                            <div class="invalid-feedback">Please enter your message</div>
                        </div>
                        
                        <div class="form-submit">
                            <button type="submit" class="btn-submit">
                                <span class="btn-text">Send Message</span>
                                <span class="btn-icon">
                                    <i class="fas fa-paper-plane"></i>
                                </span>
                                <span class="btn-loader">
                                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                </span>
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
            
            <!-- Contact Information -->
            <div class="contact-info">
                <div class="info-header">
                    <h3>Contact Information</h3>
                    <p>We'd love to hear from you. Here's how you can reach us.</p>
                </div>
                
                <div class="info-cards">
                    <div class="info-card">
                        <div class="card-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="card-content">
                            <h4>Our Location</h4>
                            <p>123 Church Street, City, State 12345</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="card-icon">
                            <i class="fas fa-phone-alt"></i>
                        </div>
                        <div class="card-content">
                            <h4>Phone Number</h4>
                            <p>+1 (123) 456-7890</p>
                            <p>+1 (123) 456-7891</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="card-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="card-content">
                            <h4>Email Address</h4>
                            <p>info@arschurch.org</p>
                            <p>support@arschurch.org</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="card-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="card-content">
                            <h4>Service Hours</h4>
                            <p>Sunday: 8:00 AM - 12:00 PM</p>
                            <p>Wednesday: 6:30 PM - 8:00 PM</p>
                        </div>
                    </div>
                </div>
                
                <div class="social-links">
                    <h4>Follow Us</h4>
                    <div class="social-icons">
                        <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-youtube"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<div class="map-container">
    <div class="map-overlay">
        <div class="map-content">
            <h3>Find Us on Map</h3>
            <p>Visit our church and be part of our community</p>
            <a href="#" class="btn btn-outline-light">
                <i class="fas fa-directions me-2"></i> Get Directions
            </a>
        </div>
    </div>
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215209056537!2d-73.9878446845938!3d40.75798537932698!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1234567890123!5m2!1sen!2sus" 
        width="100%" 
        height="450" 
        style="border:0;" 
        allowfullscreen="" 
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>

<style>
    /* Base Styles */
    :root {
        --primary: #e67e22;
        --primary-light: #f39c12;
        --primary-dark: #d35400;
        --secondary: #2c3e50;
        --light: #f8f9fa;
        --dark: #2c3e50;
        --gray: #6c757d;
        --light-gray: #e9ecef;
        --success: #198754;
        --danger: #dc3545;
        --white: #ffffff;
        --box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        --transition: all 0.3s ease;
    }
    
    /* Header Styles */
    .contact-header {
        position: relative;
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color: white;
        padding: 6rem 0 8rem;
        text-align: center;
        overflow: hidden;
    }
    
    .header-content {
        position: relative;
        z-index: 2;
        max-width: 800px;
        margin: 0 auto;
        padding: 0 1.5rem;
    }
    
    .header-shape {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        overflow: hidden;
        line-height: 0;
    }
    
    .header-shape svg {
        position: relative;
        display: block;
        width: calc(100% + 1.3px);
        height: 100px;
    }
    
    /* Contact Section */
    .contact-section {
        padding: 5rem 0;
        background-color: #f8f9fa;
    }
    
    .contact-container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        max-width: 1400px;
        margin: -6rem auto 0;
        padding: 0 1.5rem;
        position: relative;
        z-index: 10;
    }
    
    /* Contact Form */
    .contact-form-container {
        background: var(--white);
        border-radius: 15px;
        padding: 2.5rem;
        box-shadow: var(--box-shadow);
        position: relative;
        overflow: hidden;
    }
    
    .form-header {
        text-align: center;
        margin-bottom: 2.5rem;
    }
    
    .form-header h2 {
        color: var(--dark);
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 0.75rem;
    }
    
    .form-header p {
        color: var(--gray);
        margin-bottom: 0;
    }
    
    .form-group {
        margin-bottom: 1.75rem;
        position: relative;
    }
    
    .form-floating {
        position: relative;
    }
    
    .form-control, .form-select {
        height: 60px;
        padding: 1.2rem 1rem 0.5rem 3rem;
        border: 2px solid var(--light-gray);
        border-radius: 10px;
        font-size: 1rem;
        transition: var(--transition);
        background-color: #f8f9fa;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 0.25rem rgba(230, 126, 34, 0.25);
        background-color: var(--white);
    }
    
    .form-control:focus ~ .form-underline::after {
        width: 100%;
    }
    
    .form-underline {
        position: relative;
    }
    
    .form-underline::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 0;
        height: 2px;
        background-color: var(--primary);
        transition: var(--transition);
    }
    
    .form-label {
        position: absolute;
        top: 0;
        left: 0;
        height: 100%;
        padding: 1rem 0 0 3rem;
        color: var(--gray);
        pointer-events: none;
        transition: var(--transition);
        display: flex;
        align-items: center;
    }
    
    .form-label i {
        margin-right: 0.75rem;
        color: var(--primary);
        width: 1.5rem;
        text-align: center;
        font-size: 1.1rem;
    }
    
    .form-control:focus ~ .form-label,
    .form-control:not(:placeholder-shown) ~ .form-label,
    .form-select:not([value=""]) ~ .form-label {
        padding-top: 0.5rem;
        font-size: 0.8rem;
        color: var(--primary);
    }
    
    textarea.form-control {
        height: 150px !important;
        padding-top: 1.5rem !important;
        resize: none;
    }
    
    .char-counter {
        position: absolute;
        bottom: 0.5rem;
        right: 1rem;
        font-size: 0.75rem;
        color: var(--gray);
    }
    
    .char-counter span {
        color: var(--primary);
        font-weight: 600;
    }
    
    .select-arrow {
        position: absolute;
        right: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--gray);
        pointer-events: none;
    }
    
    /* Submit Button */
    .form-submit {
        margin-top: 2rem;
    }
    
    .btn-submit {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0.8rem 2.5rem;
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color: white;
        border: none;
        border-radius: 50px;
        font-size: 1rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        cursor: pointer;
        overflow: hidden;
        transition: var(--transition);
        width: 100%;
    }
    
    .btn-submit:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 20px rgba(230, 126, 34, 0.3);
    }
    
    .btn-submit:active {
        transform: translateY(-1px);
    }
    
    .btn-text {
        transition: var(--transition);
    }
    
    .btn-icon {
        position: absolute;
        right: 2rem;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: var(--transition);
        transform: translateX(100%);
        opacity: 0;
    }
    
    .btn-submit:hover .btn-text {
        transform: translateX(-1rem);
    }
    
    .btn-submit:hover .btn-icon {
        transform: translateX(0);
        opacity: 1;
    }
    
    .btn-loader {
        position: absolute;
        display: none;
    }
    
    /* Contact Info */
    .contact-info {
        background: var(--white);
        border-radius: 15px;
        padding: 2.5rem;
        box-shadow: var(--box-shadow);
    }
    
    .info-header {
        text-align: center;
        margin-bottom: 2.5rem;
    }
    
    .info-header h3 {
        color: var(--dark);
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 0.75rem;
    }
    
    .info-header p {
        color: var(--gray);
        margin-bottom: 0;
    }
    
    .info-cards {
        display: grid;
        grid-template-columns: 1fr;
        gap: 1.5rem;
        margin-bottom: 2.5rem;
    }
    
    .info-card {
        display: flex;
        align-items: flex-start;
        padding: 1.5rem;
        border-radius: 10px;
        background-color: var(--light);
        transition: var(--transition);
    }
    
    .info-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
    
    .card-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        height: 50px;
        border-radius: 12px;
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color: white;
        font-size: 1.25rem;
        margin-right: 1.25rem;
        flex-shrink: 0;
    }
    
    .card-content h4 {
        font-size: 1.1rem;
        font-weight: 600;
        margin-bottom: 0.5rem;
        color: var(--dark);
    }
    
    .card-content p {
        margin: 0;
        color: var(--gray);
        font-size: 0.95rem;
        line-height: 1.6;
    }
    
    .social-links {
        text-align: center;
        padding-top: 2rem;
        border-top: 1px solid var(--light-gray);
    }
    
    .social-links h4 {
        font-size: 1.25rem;
        margin-bottom: 1.25rem;
        color: var(--dark);
    }
    
    .social-icons {
        display: flex;
        justify-content: center;
        gap: 1rem;
    }
    
    .social-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: var(--light);
        color: var(--primary);
        font-size: 1rem;
        transition: var(--transition);
    }
    
    .social-icon:hover {
        background: var(--primary);
        color: white;
        transform: translateY(-3px);
    }
    
    /* Map Section */
    .map-container {
        position: relative;
        height: 500px;
        overflow: hidden;
    }
    
    .map-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6));
        z-index: 5;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        color: white;
        padding: 2rem;
    }
    
    .map-content {
        max-width: 600px;
    }
    
    .map-content h3 {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .map-content p {
        font-size: 1.1rem;
        margin-bottom: 1.5rem;
        opacity: 0.9;
    }
    
    .map-container iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: none;
        z-index: 1;
    }
    
    /* Success Message */
    .success-message {
        text-align: center;
        padding: 3rem 1rem;
    }
    
    .success-icon {
        width: 100px;
        height: 100px;
        margin: 0 auto 2rem;
        position: relative;
    }
    
    .success-icon svg {
        width: 100%;
        height: 100%;
    }
    
    .success-message h3 {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: var(--dark);
    }
    
    .success-message p {
        color: var(--gray);
        margin-bottom: 2rem;
        font-size: 1.1rem;
    }
    
    /* Responsive Styles */
    @media (max-width: 1199px) {
        .contact-container {
            grid-template-columns: 1fr;
            max-width: 800px;
            margin-top: -4rem;
        }
        
        .contact-info {
            margin-top: 2rem;
        }
    }
    
    @media (max-width: 767px) {
        .contact-header {
            padding: 5rem 0 6rem;
        }
        
        .header-content h1 {
            font-size: 2.5rem;
        }
        
        .contact-form-container,
        .contact-info {
            padding: 1.5rem;
        }
        
        .form-header h2 {
            font-size: 1.75rem;
        }
        
        .map-content h3 {
            font-size: 2rem;
        }
    }
    
    @media (max-width: 575px) {
        .header-content h1 {
            font-size: 2rem;
        }
        
        .form-header h2 {
            font-size: 1.5rem;
        }
        
        .info-card {
            flex-direction: column;
            text-align: center;
        }
        
        .card-icon {
            margin: 0 auto 1rem;
        }
        
        .map-content h3 {
            font-size: 1.75rem;
        }
    }
    
    /* Animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-fade-in-up {
        animation: fadeInUp 0.6s ease-out forwards;
    }
    
    /* Form Validation */
    .was-validated .form-control:invalid,
    .was-validated .form-select:invalid {
        border-color: var(--danger);
        padding-right: calc(1.5em + 0.75rem);
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right calc(0.375em + 0.1875rem) center;
        background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
    }
    
    .was-validated .form-control:valid,
    .was-validated .form-select:valid {
        border-color: var(--success);
        padding-right: calc(1.5em + 0.75rem);
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right calc(0.375em + 0.1875rem) center;
        background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
    }
    
    .invalid-feedback {
        display: none;
        width: 100%;
        margin-top: 0.25rem;
        font-size: 0.875em;
        color: var(--danger);
    }
    
    .was-validated .form-control:invalid ~ .invalid-feedback,
    .was-validated .form-select:invalid ~ .invalid-feedback {
        display: block;
    }
    
    /* Loading State */
    .is-loading .btn-text {
        visibility: hidden;
    }
    
    .is-loading .btn-loader {
        display: block;
    }
    
    /* Custom Scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: var(--primary);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: var(--primary-dark);
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Character counter for message textarea
        const messageInput = document.getElementById('message');
        const charCounter = document.querySelector('.char-counter span');
        
        if (messageInput && charCounter) {
            messageInput.addEventListener('input', function() {
                const currentLength = this.value.length;
                charCounter.textContent = currentLength;
                
                // Change color when approaching limit
                if (currentLength > 400) {
                    charCounter.parentElement.style.color = '#ff6b6b';
                } else {
                    charCounter.parentElement.style.color = '';
                }
                
                // Limit to 500 characters
                if (currentLength > 500) {
                    this.value = this.value.substring(0, 500);
                    charCounter.textContent = 500;
                }
            });
        }
        
        // Form submission handling
        const contactForm = document.querySelector('.contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                if (!this.checkValidity()) {
                    e.preventDefault();
                    e.stopPropagation();
                } else {
                    // Show loading state
                    const submitBtn = this.querySelector('.btn-submit');
                    if (submitBtn) {
                        submitBtn.classList.add('is-loading');
                        submitBtn.disabled = true;
                    }
                }
                
                this.classList.add('was-validated');
            }, false);
        }
        
        // Animate form elements on scroll
        const animateOnScroll = function() {
            const elements = document.querySelectorAll('.form-group, .info-card, .form-header, .info-header');
            
            elements.forEach(element => {
                const elementTop = element.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                
                if (elementTop < windowHeight - 100) {
                    element.classList.add('animate-fade-in-up');
                }
            });
        };
        
        // Initial check
        animateOnScroll();
        
        // Check on scroll
        window.addEventListener('scroll', animateOnScroll);
    });
</script>

<?php include 'includes/footer.php'; ?>
