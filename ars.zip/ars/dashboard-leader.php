<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    
    // Check if this is a first-time visit
    if (!isset($_COOKIE['has_visited'])) {
        // Clear all session data
        $_SESSION = array();
        
        // Delete the session cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        // Destroy the session
        session_destroy();
        
        // Set a cookie to remember this is not the first visit (expires in 30 days)
        setcookie('has_visited', '1', time() + (86400 * 30), "/");
        
        // Redirect to login page
        header('Location: login.php');
        exit();
    }
}

// Include database and auth first
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Define allowed roles for leader dashboard
$allowed_roles = ['leader', 'admin', 'pastor', 'elder', 'minister'];
$user_role = strtolower($_SESSION['user_role'] ?? '');

// Check if user has required role
if (!in_array($user_role, array_map('strtolower', $allowed_roles))) {
    // Log the unauthorized access attempt
    error_log('Unauthorized access attempt by user ID: ' . $_SESSION['user_id'] . ' with role: ' . $user_role);
    
    // Try to find a suitable dashboard
    $dashboard_file = "dashboard-{$user_role}.php";
    if (file_exists($dashboard_file)) {
        header("Location: $dashboard_file");
        exit();
    }
    
    // If no specific dashboard, show access denied
    header('HTTP/1.1 403 Forbidden');
    echo '<h1>Access Denied</h1>';
    echo '<p>You do not have permission to access this page.</p>';
    echo '<p><a href="index.php">Return to Home</a></p>';
    exit();
}

// Now include the header after all checks are done
require_once 'includes/header.php';

// Log successful access
error_log('Access granted to user ID: ' . $_SESSION['user_id'] . ' with role: ' . $user_role);

// Get current user
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'] ?? 'Leader';

// Sample data - In a real app, this would come from the database
$group_members = [
    ['name' => 'John Doe', 'email' => 'john@example.com', 'phone' => '123-456-7890'],
    ['name' => 'Jane Smith', 'email' => 'jane@example.com', 'phone' => '123-456-7891']
];
$upcoming_events = [
    ['title' => 'Weekly Prayer Meeting', 'date' => '2023-11-15', 'time' => '19:00'],
    ['title' => 'Bible Study', 'date' => '2023-11-17', 'time' => '18:30']
];
$recent_activities = [
    ['action' => 'New member joined', 'date' => '2023-11-10 14:30'],
    ['action' => 'Prayer request submitted', 'date' => '2023-11-09 09:15']
];

// Debug information
echo '<!-- Debug: User ID: ' . $user_id . ' -->';
echo '<!-- Debug: User Role: ' . $user_role . ' -->';
echo '<!-- Debug: Session Data: ' . print_r($_SESSION, true) . ' -->';

// Try to load data from JSON files
$data_dir = __DIR__ . '/data/';

// Load group members
if (file_exists($data_dir . 'members.json')) {
    $group_members = json_decode(file_get_contents($data_dir . 'members.json'), true) ?: [];
}

// Initialize events array
$upcoming_events = [];

// Debug: Check if data directory exists and is writable
if (!is_dir($data_dir)) {
    error_log('Data directory does not exist: ' . $data_dir);
    @mkdir($data_dir, 0755, true);
}

// Debug: Check directory permissions
if (!is_writable($data_dir)) {
    error_log('Data directory is not writable: ' . $data_dir);
}

// Load events with error handling
try {
    $events_file = $data_dir . 'events.json';
    if (file_exists($events_file)) {
        $json_content = file_get_contents($events_file);
        if ($json_content !== false) {
            $all_events = json_decode($json_content, true);
            
            // Log for debugging
            error_log('Loaded events: ' . print_r($all_events, true));
            
            if (json_last_error() === JSON_ERROR_NONE && is_array($all_events)) {
                foreach ($all_events as $event) {
                    if (is_array($event)) {
                        $upcoming_events[] = [
                            'title' => $event['title'] ?? 'Untitled Event',
                            'date' => $event['date'] ?? date('Y-m-d'),
                            'time' => $event['time'] ?? '12:00',
                            'location' => $event['location'] ?? 'Main Sanctuary',
                            'raw_data' => $event // Keep original data for debugging
                        ];
                    }
                }
                // Sort events by date (newest first)
                usort($upcoming_events, function($a, $b) {
                    return strtotime($a['date'] . ' ' . $a['time']) - strtotime($b['date'] . ' ' . $b['time']);
                });
                $upcoming_events = array_slice($upcoming_events, 0, 5); // Get first 5 events
            } else {
                error_log('JSON decode error: ' . json_last_error_msg());
            }
        } else {
            error_log('Failed to read events file: ' . $events_file);
        }
    } else {
        error_log('Events file not found: ' . $events_file);
        // Add sample data for demo purposes
        $upcoming_events = [
            [
                'title' => 'Weekly Prayer Meeting',
                'date' => date('Y-m-d', strtotime('+1 day')),
                'time' => '19:00',
                'location' => 'Main Sanctuary'
            ],
            [
                'title' => 'Bible Study',
                'date' => date('Y-m-d', strtotime('+3 days')),
                'time' => '18:30',
                'location' => 'Fellowship Hall'
            ]
        ];
    }
} catch (Exception $e) {
    error_log('Error loading events: ' . $e->getMessage());
    $upcoming_events = [];
}

// Load activities with error handling
try {
    $activities_file = $data_dir . 'activities.json';
    if (file_exists($activities_file)) {
        $json_content = file_get_contents($activities_file);
        if ($json_content !== false) {
            $recent_activities = json_decode($json_content, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($recent_activities)) {
                $recent_activities = array_slice($recent_activities, 0, 5);
            } else {
                error_log('Activities JSON decode error: ' . json_last_error_msg());
                $recent_activities = [];
            }
        } else {
            error_log('Failed to read activities file: ' . $activities_file);
            $recent_activities = [];
        }
    } else {
        error_log('Activities file not found: ' . $activities_file);
        // Add sample activities for demo
        $recent_activities = [
            ['action' => 'New member joined', 'date' => date('Y-m-d H:i:s'), 'user' => 'John Doe'],
            ['action' => 'Prayer request submitted', 'date' => date('Y-m-d H:i:s', strtotime('-1 hour')), 'user' => 'Jane Smith']
        ];
    }
} catch (Exception $e) {
    error_log('Error loading activities: ' . $e->getMessage());
    $recent_activities = [];
}

/**
 * Format a timestamp to a human-readable time difference
 * 
 * @param string|DateTime $datetime The datetime to compare against now
 * @param bool $full Whether to show all time units or just the largest one
 * @return string The formatted time difference
 */
function time_elapsed_string($datetime, bool $full = false): string {
    try {
        $now = new DateTime();
        $ago = ($datetime instanceof DateTime) ? $datetime : new DateTime($datetime);
        $diff = $now->diff($ago);

        // Convert DateInterval to array
        $diffArray = [
            'y' => $diff->y,
            'm' => $diff->m,
            'd' => $diff->d,
            'h' => $diff->h,
            'i' => $diff->i,
            's' => $diff->s,
        ];

        // Calculate weeks from days
        $weeks = floor($diff->d / 7);
        $days = $diff->d % 7;

        $string = [];
        $units = [
            'y' => 'year',
            'm' => 'month',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        ];

        // Add weeks if needed
        if ($weeks > 0) {
            $string['w'] = $weeks . ' week' . ($weeks > 1 ? 's' : '');
            $diffArray['d'] = $days; // Update days to remaining days after weeks
        }

        // Process each time unit
        foreach ($units as $key => $unit) {
            if ($diffArray[$key] > 0) {
                $string[$key] = $diffArray[$key] . ' ' . $unit . ($diffArray[$key] > 1 ? 's' : '');
            }
        }

        // If we have no time difference, return 'just now'
        if (empty($string)) {
            return 'just now';
        }

        // If not full, return only the first time unit
        if (!$full) {
            $string = [reset($string)];
        } else {
            // For full format, ensure weeks don't appear with days if both are present
            if (isset($string['w']) && isset($string['d'])) {
                unset($string['d']);
            }
        }

        return implode(', ', $string) . ' ago';
    } catch (Exception $e) {
        // Log error and return a fallback message
        error_log('Error in time_elapsed_string: ' . $e->getMessage());
        return 'recently';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leader Dashboard - Apostles Revelation Society</title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            /* Color Scheme */
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333333;
            --text-light: #7f8c8d;
            --border-radius: 10px;
            --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --sidebar-width: 280px;
        }
        
        body {
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text);
            background-color: #f5f7fa;
            line-height: 1.6;
            overflow-x: hidden;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            color: var(--dark);
        }
        
        /* Sidebar Styles */
        .sidebar {
            min-height: 100vh;
            background: var(--secondary);
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            color: rgba(255, 255, 255, 0.9);
            position: fixed;
            width: var(--sidebar-width);
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .sidebar-brand {
            padding: 1.5rem 1.5rem 1rem;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 0.5rem;
        }
        
        .sidebar-brand h4 {
            color: white;
            font-weight: 700;
            margin-bottom: 0.25rem;
            font-size: 1.5rem;
            letter-spacing: 0.5px;
        }
        
        .sidebar-brand small {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.8rem;
        }
        
        .sidebar-nav {
            padding: 0.5rem 1rem 1rem;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1.5rem;
            margin: 0.25rem 0.5rem;
            border-radius: 8px;
            transition: var(--transition);
            font-family: 'Montserrat', sans-serif;
            font-weight: 500;
            font-size: 0.95rem;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
        }
        
        .nav-link::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background: var(--primary);
            transform: scaleY(0);
            transform-origin: center;
            transition: var(--transition);
            border-radius: 0 4px 4px 0;
        }
        
        .nav-link:hover, .nav-link.active {
            background: rgba(255, 255, 255, 0.05);
            color: white;
            transform: translateX(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .nav-link.active {
            background: rgba(255, 255, 255, 0.08);
            font-weight: 600;
        }
        
        .nav-link.active::before {
            transform: scaleY(1);
        }
        
        .nav-link i {
            width: 20px;
            margin-right: 10px;
            text-align: center;
        }
        
        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 4rem 2.5rem 2rem; /* Further increased top padding to 4rem */
            transition: var(--transition);
            min-height: 100vh;
            background-color: #f8fafc;
        }
        
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 1.5rem;
            }
            
            .sidebar {
                transform: translateX(-100%);
                z-index: 1050;
            }
            
            .sidebar.show {
                transform: translateX(0);
                box-shadow: 5px 0 25px rgba(0, 0, 0, 0.2);
            }
            
            .navbar-brand {
                font-size: 1.2rem;
            }
        }
        
        /* Cards */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
            margin-bottom: 1.5rem;
            border: 1px solid rgba(0, 0, 0, 0.03);
            overflow: hidden;
            background: white;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid rgba(0, 0, 0, 0.03);
            font-weight: 600;
            padding: 1.25rem 1.75rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        }
        
        .card-header h5 {
            font-weight: 700;
            color: var(--dark);
            margin: 0;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
        }
        
        .card-header h5 i {
            margin-right: 10px;
            color: var(--primary);
            font-size: 1.1em;
        }
        
        /* Stats Cards */
        .stat-card {
            padding: 1.75rem 1.5rem;
            border-radius: 12px;
            color: white;
            position: relative;
            overflow: hidden;
            z-index: 1;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            border: none;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 120px;
            height: 120px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transform: translate(30%, -30%);
            z-index: -1;
            transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .stat-card:hover::before {
            transform: translate(10%, -10%) scale(1.2);
            opacity: 0.8;
        }
        
        .stat-card i {
            font-size: 2.5rem;
            opacity: 0.9;
            margin-bottom: 1.25rem;
            display: inline-flex;
            width: 60px;
            height: 60px;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover i {
            transform: scale(1.1) rotate(5deg);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
        
        .stat-card .number {
            font-size: 2.25rem;
            font-weight: 800;
            margin: 0.5rem 0 0.25rem;
            font-family: 'Montserrat', sans-serif;
            line-height: 1.2;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card .label {
            font-size: 0.95rem;
            opacity: 0.9;
            font-weight: 500;
            letter-spacing: 0.3px;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .trend {
            font-size: 0.85rem;
            margin-top: auto;
            padding-top: 0.75rem;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            display: flex;
            align-items: center;
        }
        
        .trend i {
            font-size: 1rem !important;
            width: auto !important;
            height: auto !important;
            background: transparent !important;
            margin: 0 0.25rem 0 0 !important;
            padding: 0 !important;
        }
        
        .trend.up {
            color: rgba(255, 255, 255, 0.9);
        }
        
        .trend.down {
            color: rgba(255, 220, 220, 0.9);
        }
        
        /* Buttons */
        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.5rem;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: none;
            font-size: 0.9rem;
            letter-spacing: 0.3px;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .btn i {
            font-size: 1em;
            transition: transform 0.2s ease;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            background-image: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%);
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 100%;
            background: linear-gradient(135deg, var(--primary-hover) 0%, var(--primary) 100%);
            transition: all 0.4s ease;
            z-index: -1;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(230, 126, 34, 0.3);
        }
        
        /* Responsive Adjustments */
        @media (max-width: 1199px) {
            .main-content {
                padding: 3.5rem 1.75rem 1.75rem; /* Further increased top padding */
            }
        }
        
        @media (max-width: 991px) {
            .main-content {
                padding: 3rem 1.5rem 1.5rem; /* Further increased top padding */
            }
            
            .stat-card {
                padding: 1.5rem 1.25rem;
            }
            
            .stat-card .number {
                font-size: 2rem;
            }
        }
        
        @media (max-width: 767px) {
            .main-content {
                padding: 2.5rem 1.25rem 1.25rem; /* Further increased top padding */
            }
            
            .card-header {
                padding: 1rem 1.25rem;
            }
            
            .stat-card {
                padding: 1.25rem 1rem;
            }
            
            .stat-card .number {
                font-size: 1.75rem;
            }
            
            .stat-card i {
                width: 50px;
                height: 50px;
                font-size: 1.75rem;
            }
        }
        
        @media (max-width: 575px) {
            :root {
                --sidebar-width: 260px;
            }
            
            .main-content {
                padding: 2.25rem 1rem 1rem; /* Further increased top padding */
            }
            
            .stat-card {
                margin-bottom: 1rem;
            }
            
            .btn {
                padding: 0.5rem 1.25rem;
                font-size: 0.85rem;
            }
        }
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333333;
            --text-light: #7f8c8d;
            --border-radius: 10px;
            --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s ease;
        }
        
        body {
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text);
            background-color: #f5f7fa;
            line-height: 1.6;
            overflow-x: hidden;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            color: var(--dark);
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95) !important;
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
        }
        
        .navbar-brand img {
            height: 50px;
            transition: var(--transition);
        }
        
        .nav-link {
            font-family: 'Montserrat', sans-serif;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            padding: 0.5rem 1rem !important;
            margin: 0 0.25rem;
            color: var(--dark) !important;
            position: relative;
        }
        
        .nav-link:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 50%;
            background: var(--primary);
            transition: var(--transition);
            transform: translateX(-50%);
        }
        
        .nav-link:hover:after,
        .nav-link.active:after {
            width: 80%;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
            transition: var(--transition);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(230, 126, 34, 0.3);
        }
        /* Body styles already defined in the base styles */
        /* Sidebar styles already defined above */
        /* Main content styles already defined above */
        /* Card styles already defined above */
        .card:hover {
            transform: translateY(-5px);
        }
        /* Card header styles already defined above */
        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%);
            color: white;
            padding: 3.5rem 3rem;
            border-radius: 16px;
            margin: 0 0 3rem 0;
            box-shadow: 0 12px 35px rgba(230, 126, 34, 0.25);
            position: relative;
            overflow: hidden;
            border: none;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .welcome-banner h1 {
            font-weight: 900;
            font-size: 2.5rem;
            margin-bottom: 0.75rem;
            line-height: 1.2;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            letter-spacing: -0.5px;
        }
        
        .welcome-banner p.lead {
            font-size: 1.25rem;
            opacity: 0.95;
            max-width: 650px;
            margin-bottom: 2rem;
            line-height: 1.6;
            font-weight: 400;
        }
        
        .welcome-banner .btn {
            border-radius: 10px;
            padding: 0.75rem 2rem;
            font-weight: 700;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
        }
        
        .welcome-banner .btn-light {
            background-color: rgba(255, 255, 255, 0.98);
            color: var(--primary);
            border: 2px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .welcome-banner .btn-light:hover {
            background-color: white;
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(0, 0, 0, 0.15);
            border-color: white;
        }
        
        .welcome-banner .btn-outline-light {
            border: 2px solid rgba(255, 255, 255, 0.4);
            background-color: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(8px);
            margin-left: 1rem;
        }
        
        .welcome-banner .btn-outline-light:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(0, 0, 0, 0.1);
            border-color: rgba(255, 255, 255, 0.6);
        }
        
        .welcome-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0) 60%);
            pointer-events: none;
            opacity: 0.8;
            transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .welcome-banner:hover::before {
            transform: scale(1.1);
            opacity: 1;
        }
        
        .welcome-banner h1 {
            font-weight: 900;
            margin-bottom: 0.75rem;
            font-size: 2.5rem;
            position: relative;
            z-index: 1;
            line-height: 1.1;
            max-width: 700px;
        }
        
        .welcome-banner p {
            font-size: 1.2rem;
            opacity: 0.95;
            margin-bottom: 1.5rem;
            max-width: 750px;
            position: relative;
            z-index: 1;
            line-height: 1.6;
            font-weight: 400;
        }
        
        @media (max-width: 991px) {
            .welcome-banner {
                padding: 2.5rem 2rem;
                text-align: center;
                background-position: center right;
            }
            
            .welcome-banner h1 {
                font-size: 2rem;
                margin-left: auto;
                margin-right: auto;
            }
            
            .welcome-banner p {
                font-size: 1.1rem;
                margin-left: auto;
                margin-right: auto;
            }
            
            .welcome-banner .btn {
                display: block;
                width: 100%;
                margin-bottom: 1rem;
            }
            
            .welcome-banner .btn-outline-light {
                margin-left: 0;
            }
        }
        /* Action Cards */
        .action-card .card {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0, 0, 0, 0.03);
            overflow: hidden;
            position: relative;
            z-index: 1;
            border-radius: 12px;
            background: white;
            height: 100%;
        }
        
        .action-card .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%);
            opacity: 0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: -1;
        }
        
        .action-card:hover .card {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.08) !important;
        }
        
        .action-card:hover .card::before {
            opacity: 1;
        }
        
        .action-card .card-body {
            padding: 2rem 1.5rem;
            position: relative;
            z-index: 2;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .action-card i {
            font-size: 2rem;
            margin-bottom: 1.25rem;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 70px;
            height: 70px;
            border-radius: 16px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .action-card:hover i {
            transform: scale(1.1) rotate(5deg);
        }
        
        .action-card h6 {
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--dark);
            font-size: 1.1rem;
            transition: all 0.3s ease;
            letter-spacing: 0.3px;
        }
        
        .action-card p {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 0;
            line-height: 1.5;
            transition: all 0.3s ease;
        }
        
        .action-card:hover h6 {
            color: var(--primary);
        }
        
        .action-card:hover p {
            color: #495057;
        }
        
        .hover-lift {
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), 
                        box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .hover-lift:hover {
            transform: translateY(-5px);
            box-shadow: 0 0.75rem 1.5rem rgba(0, 0, 0, 0.08) !important;
        }
        
        /* Stat card styles already defined above */
        /* Stat card icon styles already defined above */
        /* Stat card number styles already defined above */
        /* Stat card label styles already defined above */
        /* Nav link styles already defined above */
        /* Nav link hover/active styles already defined above */
        /* Nav link icon styles already defined above */
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <h4>ARS Ministry</h4>
            <small>Leadership Dashboard</small>
        </div>
        
        <div class="sidebar-nav">
            <a href="#" class="nav-link active">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="#" class="nav-link">
                <i class="fas fa-users"></i>
                <span>Members</span>
                <span class="badge bg-primary rounded-pill ms-auto">24</span>
            </a>
            <a href="#" class="nav-link">
                <i class="fas fa-calendar-alt"></i>
                <span>Events</span>
                <span class="badge bg-success rounded-pill ms-auto">5</span>
            </a>
            <a href="#" class="nav-link">
                <i class="fas fa-chart-line"></i>
                <span>Reports</span>
            </a>
            <a href="#" class="nav-link">
                <i class="fas fa-envelope"></i>
                <span>Messages</span>
                <span class="badge bg-danger rounded-pill ms-auto">3</span>
            </a>
            <a href="#" class="nav-link">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
        </div>
        
        <div class="position-absolute bottom-0 w-100 p-3">
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="position-relative">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user_name); ?>" alt="User" width="36" height="36" class="rounded-circle me-2 border border-2 border-white">
                        <span class="position-absolute bottom-0 end-0 bg-success rounded-circle border border-2 border-white" style="width: 10px; height: 10px;"></span>
                    </div>
                    <div class="d-flex flex-column ms-1">
                        <span class="fw-medium"><?php echo htmlspecialchars($user_name); ?></span>
                        <small class="text-white-50">Administrator</small>
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end w-100">
                    <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-circle me-2"></i> My Profile</a></li>
                    <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i> Account Settings</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-bell me-2"></i> Notifications</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white rounded-3 mb-4 shadow-sm">
            <div class="container-fluid">
                <button class="btn btn-link p-0 d-md-none" id="sidebarToggler" type="button">
                    <i class="fas fa-bars fa-lg text-dark"></i>
                </button>
                
                <!-- Search Bar -->
                <form class="d-none d-md-flex ms-3" style="max-width: 400px;">
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-end-0">
                            <i class="fas fa-search text-muted"></i>
                        </span>
                        <input type="text" class="form-control border-start-0" placeholder="Search members, events, reports..." aria-label="Search">
                    </div>
                </form>
                
                <div class="d-flex align-items-center ms-auto">
                    <!-- Notifications -->
                    <div class="dropdown me-3">
                        <a href="#" class="position-relative text-dark" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bell fa-lg"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                3
                                <span class="visually-hidden">unread notifications</span>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end dropdown-menu-lg-end p-0" style="width: 320px;">
                            <div class="p-3 border-bottom">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0">Notifications</h6>
                                    <span class="badge bg-primary rounded-pill">3 New</span>
                                </div>
                            </div>
                            <div class="list-group list-group-flush" style="max-height: 300px; overflow-y: auto;">
                                <a href="#" class="list-group-item list-group-item-action border-0 py-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0 me-3">
                                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-user-plus"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">New member joined</h6>
                                            <p class="mb-0 text-muted small">John Doe just registered</p>
                                            <small class="text-muted">10 min ago</small>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="list-group-item list-group-item-action border-0 py-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0 me-3">
                                            <div class="bg-success bg-opacity-10 text-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-calendar-check"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">New event created</h6>
                                            <p class="mb-0 text-muted small">Bible Study this Friday</p>
                                            <small class="text-muted">2 hours ago</small>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="list-group-item list-group-item-action border-0 py-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0 me-3">
                                            <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-exclamation-triangle"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">System Update</h6>
                                            <p class="mb-0 text-muted small">Scheduled maintenance tonight</p>
                                            <small class="text-muted">5 hours ago</small>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="p-2 border-top text-center">
                                <a href="#" class="text-primary">View all notifications</a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Messages -->
                    <div class="dropdown me-3 d-none d-lg-block">
                        <a href="#" class="position-relative text-dark" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-envelope fa-lg"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                                2
                                <span class="visually-hidden">unread messages</span>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end p-0" style="width: 320px;">
                            <div class="p-3 border-bottom">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0">Messages</h6>
                                    <span class="badge bg-success rounded-pill">2 New</span>
                                </div>
                            </div>
                            <div class="list-group list-group-flush" style="max-height: 300px; overflow-y: auto;">
                                <a href="#" class="list-group-item list-group-item-action border-0 py-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0 me-3">
                                            <img src="https://ui-avatars.com/api/?name=Jane+Smith" alt="User" width="40" height="40" class="rounded-circle">
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="d-flex justify-content-between">
                                                <h6 class="mb-1">Jane Smith</h6>
                                                <small class="text-muted">12:30 PM</small>
                                            </div>
                                            <p class="mb-0 text-muted small text-truncate" style="max-width: 200px;">Hi there! I have a question about the upcoming event...</p>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="list-group-item list-group-item-action border-0 py-3">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0 me-3">
                                            <img src="https://ui-avatars.com/api/?name=John+Doe" alt="User" width="40" height="40" class="rounded-circle">
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="d-flex justify-content-between">
                                                <h6 class="mb-1">John Doe</h6>
                                                <small class="text-muted">10:15 AM</small>
                                            </div>
                                            <p class="mb-0 text-muted small text-truncate" style="max-width: 200px;">Thanks for the update! Looking forward to it...</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="p-2 border-top text-center">
                                <a href="#" class="text-primary">View all messages</a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- User Menu -->
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="position-relative d-none d-md-block me-2">
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user_name); ?>" alt="User" width="40" height="40" class="rounded-circle border-2 border-white shadow-sm">
                                <span class="position-absolute bottom-0 end-0 bg-success rounded-circle border border-2 border-white" style="width: 12px; height: 12px;"></span>
                            </div>
                            <span class="d-none d-lg-inline text-dark fw-medium"><?php echo htmlspecialchars($user_name); ?></span>
                            <i class="fas fa-chevron-down ms-1 text-muted d-none d-lg-inline"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm" style="min-width: 200px;">
                            <li>
                                <div class="d-flex align-items-center p-3 border-bottom">
                                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user_name); ?>" alt="User" width="48" height="48" class="rounded-circle me-2 border">
                                    <div>
                                        <h6 class="mb-0"><?php echo htmlspecialchars($user_name); ?></h6>
                                        <small class="text-muted">Administrator</small>
                                    </div>
                                </div>
                            </li>
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-circle me-2 text-muted"></i> My Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2 text-muted"></i> Settings</a></li>
                            <li><a class="dropdown-item" href="#"><i class="fas fa-bell me-2 text-muted"></i> Notifications</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        
        <!-- Welcome Banner -->
        <div class="welcome-banner mb-5" data-aos="fade-up">
            <div class="container">
                <div class="row align-items-center
                <div class="col-lg-8">
                    <h1>Welcome back, <?php echo htmlspecialchars($user_name); ?>! 👋</h1>
                    <p class="lead">Here's what's happening with your ministry today. You have <strong><?php echo count($upcoming_events); ?> upcoming events</strong> and <strong><?php echo count($recent_activities); ?> new activities</strong>.</p>
                    <div class="d-flex gap-2 mt-3">
                        <button class="btn btn-light">
                            <i class="fas fa-plus me-2"></i> Create New
                        </button>
                        <button class="btn btn-outline-light">
                            <i class="fas fa-chart-line me-2"></i> View Analytics
                        </button>
                    </div>
                </div>
                <div class="col-lg-4 d-none d-lg-block">
                    <div class="text-end">
                        <img src="assets/img/dashboard-illustration.svg" alt="Dashboard Illustration" class="img-fluid" style="max-height: 180px;">
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row g-3 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="col-6 col-md-3">
                <a href="#" class="text-decoration-none action-card">
                    <div class="card h-100 border-0 shadow-sm hover-lift">
                        <div class="card-body text-center p-3">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-3 d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px;">
                                <i class="fas fa-user-plus fa-lg"></i>
                            </div>
                            <h6 class="mb-0 fw-semibold text-dark">Add Member</h6>
                            <p class="small text-muted mt-1 mb-0">Register new church members</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="#" class="text-decoration-none action-card">
                    <div class="card h-100 border-0 shadow-sm hover-lift">
                        <div class="card-body text-center p-3">
                            <div class="bg-success bg-opacity-10 text-success rounded-3 d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px;">
                                <i class="fas fa-calendar-plus fa-lg"></i>
                            </div>
                            <h6 class="mb-0 fw-semibold text-dark">Create Event</h6>
                            <p class="small text-muted mt-1 mb-0">Schedule new gatherings</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="#" class="text-decoration-none action-card">
                    <div class="card h-100 border-0 shadow-sm hover-lift">
                        <div class="card-body text-center p-3">
                            <div class="bg-info bg-opacity-10 text-info rounded-3 d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px;">
                                <i class="fas fa-file-import fa-lg"></i>
                            </div>
                            <h6 class="mb-0 fw-semibold text-dark">Import Data</h6>
                            <p class="small text-muted mt-1 mb-0">Bulk import members/events</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-md-3">
                <a href="#" class="text-decoration-none action-card">
                    <div class="card h-100 border-0 shadow-sm hover-lift">
                        <div class="card-body text-center p-3">
                            <div class="bg-warning bg-opacity-10 text-warning rounded-3 d-inline-flex align-items-center justify-content-center mb-2" style="width: 50px; height: 50px;">
                                <i class="fas fa-chart-pie fa-lg"></i>
                            </div>
                            <h6 class="mb-0 fw-semibold text-dark">View Reports</h6>
                            <p class="small text-muted mt-1 mb-0">Analytics & insights</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                <div class="stat-card h-100" style="background: linear-gradient(135deg, #e67e22 0%, #d35400 100%);">
                    <i class="fas fa-users"></i>
                    <div class="number"><?php echo count($group_members); ?></div>
                    <div class="label">Total Members</div>
                    <div class="trend up">
                        <i class="fas fa-arrow-up me-1"></i> 12% increase from last month
                    </div>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="stat-card h-100" style="background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);">
                    <i class="fas fa-calendar-check"></i>
                    <div class="number"><?php echo count($upcoming_events); ?></div>
                    <div class="label">Upcoming Events</div>
                    <div class="trend up">
                        <i class="fas fa-arrow-up me-1"></i> 3 new events this week
                    </div>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
                <div class="stat-card h-100" style="background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);">
                    <i class="fas fa-church"></i>
                    <div class="number">85%</div>
                    <div class="label">Attendance Rate</div>
                    <div class="trend down">
                        <i class="fas fa-arrow-down me-1"></i> 5% decrease from last week
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="row g-4">
            <!-- Recent Activities -->
            <div class="col-lg-8" data-aos="fade-up" data-aos-delay="100">
                <div class="card h-100">
                    <div class="card-header">
                        <h5><i class="fas fa-history me-2"></i> Recent Activities</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush">
                            <?php 
                            $activityIcons = [
                                'joined' => 'user-plus',
                                'created' => 'plus-circle',
                                'updated' => 'edit',
                                'deleted' => 'trash-alt',
                                'logged in' => 'sign-in-alt',
                                'registered' => 'user-check',
                                'submitted' => 'paper-plane',
                                'completed' => 'check-circle',
                                'cancelled' => 'times-circle',
                                'default' => 'circle'
                            ];
                            
                            foreach ($recent_activities as $activity): 
                                $action = strtolower($activity['action']);
                                $icon = 'circle';
                                
                                foreach ($activityIcons as $key => $iconName) {
                                    if (strpos($action, $key) !== false) {
                                        $icon = $iconName;
                                        break;
                                    }
                                }
                                
                                $timeAgo = !empty($activity['date']) ? time_elapsed_string($activity['date']) : 'Just now';
                                $user = $activity['user'] ?? 'System';
                            ?>
                            <div class="list-group-item border-0 px-4 py-3">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3">
                                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                            <i class="fas fa-<?php echo $icon; ?> fa-fw"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between">
                                            <h6 class="mb-1 fw-semibold"><?php echo htmlspecialchars($activity['action']); ?></h6>
                                            <small class="text-muted"><?php echo $timeAgo; ?></small>
                                        </div>
                                        <p class="mb-0 text-muted small">
                                            <span class="text-dark fw-medium"><?php echo htmlspecialchars($user); ?></span> 
                                            <?php 
                                            $description = $activity['details'] ?? 'performed this action';
                                            echo htmlspecialchars($description);
                                            ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="text-center p-3 border-top">
                            <a href="#" class="btn btn-sm btn-outline-primary">
                                View All Activities
                                <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Upcoming Events -->
            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="150">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-calendar-day me-2"></i> Upcoming Events</h5>
                        <a href="#" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if (!empty($upcoming_events)): ?>
                            <?php 
                            // Sort events by date and time
                            usort($upcoming_events, function($a, $b) {
                                $timeA = strtotime(($a['date'] ?? '') . ' ' . ($a['time'] ?? ''));
                                $timeB = strtotime(($b['date'] ?? '') . ' ' . ($b['time'] ?? ''));
                                return $timeA - $timeB;
                            });
                            
                            $eventCount = 0;
                            $today = new DateTime();
                            $today->setTime(0, 0, 0);
                            
                            foreach ($upcoming_events as $event): 
                                if ($eventCount >= 4) break; // Limit to 4 events
                                
                                $title = htmlspecialchars($event['title'] ?? 'Untitled Event');
                                $eventDate = !empty($event['date']) ? new DateTime($event['date']) : null;
                                $formattedDate = $eventDate ? $eventDate->format('M j, Y') : 'Date TBD';
                                $time = !empty($event['time']) ? date('g:i A', strtotime($event['time'])) : 'Time TBD';
                                $location = htmlspecialchars($event['location'] ?? 'Location TBD');
                                $isToday = $eventDate ? ($eventDate->format('Y-m-d') === $today->format('Y-m-d')) : false;
                                
                                // Skip past events
                                if ($eventDate && $eventDate < $today && !$isToday) continue;
                                
                                $eventCount++;
                            ?>
                            <div class="border-bottom p-3">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3 text-center" style="width: 50px;">
                                        <?php if ($isToday): ?>
                                            <div class="bg-danger text-white rounded-3 p-2">
                                                <div class="fw-bold">NOW</div>
                                            </div>
                                        <?php else: ?>
                                            <div class="bg-light rounded-3 p-2">
                                                <div class="text-uppercase fw-bold text-primary" style="font-size: 0.7rem; line-height: 1;">
                                                    <?php echo $eventDate ? $eventDate->format('M') : '---'; ?>
                                                </div>
                                                <div class="h4 fw-bold mb-0">
                                                    <?php echo $eventDate ? $eventDate->format('d') : '--'; ?>
                                                </div>
                                                <div class="text-muted small" style="font-size: 0.65rem; line-height: 1;">
                                                    <?php echo $eventDate ? $eventDate->format('D') : '---'; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1 fw-semibold">
                                            <a href="#" class="text-dark text-decoration-none"><?php echo $title; ?></a>
                                            <?php if ($isToday): ?>
                                                <span class="badge bg-danger bg-opacity-10 text-danger ms-2">Today</span>
                                            <?php endif; ?>
                                        </h6>
                                        <div class="d-flex flex-wrap align-items-center text-muted small">
                                            <span class="me-3"><i class="far fa-clock me-1"></i> <?php echo $time; ?></span>
                                            <span><i class="fas fa-map-marker-alt me-1"></i> <?php echo $location; ?></span>
                                        </div>
                                        <?php if (isset($event['description']) && !empty(trim($event['description']))): ?>
                                        <p class="mt-2 mb-0 small text-muted text-truncate">
                                            <?php echo htmlspecialchars($event['description']); ?>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            
                            <?php if ($eventCount === 0): ?>
                                <div class="text-center p-4">
                                    <div class="mb-3">
                                        <i class="far fa-calendar-alt fa-3x text-muted opacity-25"></i>
                                    </div>
                                    <h5 class="text-muted mb-2">No Upcoming Events</h5>
                                    <p class="text-muted small mb-0">Check back later for scheduled events.</p>
                                    <a href="#" class="btn btn-sm btn-primary mt-3">
                                        <i class="fas fa-plus me-1"></i> Create Event
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                        <?php else: ?>
                            <div class="text-center p-4">
                                <div class="mb-3">
                                    <i class="far fa-calendar-alt fa-3x text-muted opacity-25"></i>
                                </div>
                                <h5 class="text-muted mb-2">No Upcoming Events</h5>
                                <p class="text-muted small mb-0">Check back later for scheduled events.</p>
                                <a href="#" class="btn btn-sm btn-primary mt-3">
                                    <i class="fas fa-plus me-1"></i> Create Event
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($eventCount > 0): ?>
                            <div class="text-center p-3 border-top">
                                <a href="#" class="btn btn-sm btn-outline-primary">
                                    View All Events
                                    <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Quick Stats -->
                <div class="card mt-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i> Quick Stats</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span class="small text-muted">Weekly Attendance</span>
                                <span class="small fw-medium">78%</span>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: 78%" aria-valuenow="78" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span class="small text-muted">New Members</span>
                                <span class="small fw-medium">+12%</span>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 45%" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="mb-0">
                            <div class="d-flex justify-content-between mb-1">
                                <span class="small text-muted">Engagement</span>
                                <span class="small fw-medium">62%</span>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 62%" aria-valuenow="62" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($_GET['debug']) && $_GET['debug'] === 'true'): ?>
        <!-- Debug Information (Only shown when ?debug=true is in URL) -->
        <div class="card mt-4 border-danger">
            <div class="card-header bg-danger bg-opacity-10 text-danger d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-bug me-2"></i> Debug Information</h5>
                <small class="text-muted">Development Mode</small>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Application Info</h6>
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="40%">Data Directory:</th>
                                <td><code><?php echo htmlspecialchars($data_dir); ?></code></td>
                            </tr>
                            <tr>
                                <th>Events File:</th>
                                <td>
                                    <span class="badge bg-<?php echo file_exists($data_dir . 'events.json') ? 'success' : 'danger'; ?> me-2">
                                        <?php echo file_exists($data_dir . 'events.json') ? 'Exists' : 'Missing'; ?>
                                    </span>
                                    <small class="text-muted"><?php echo htmlspecialchars($data_dir . 'events.json'); ?></small>
                                </td>
                            </tr>
                            <tr>
                                <th>Events Count:</th>
                                <td><?php echo count($upcoming_events); ?></td>
                            </tr>
                            <tr>
                                <th>User Role:</th>
                                <td><span class="badge bg-primary"><?php echo htmlspecialchars($_SESSION['user_role'] ?? 'Not set'); ?></span></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Server Info</h6>
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="40%">PHP Version:</th>
                                <td><?php echo phpversion(); ?></td>
                            </tr>
                            <tr>
                                <th>Server Software:</th>
                                <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'N/A'; ?></td>
                            </tr>
                            <tr>
                                <th>Server Name:</th>
                                <td><?php echo $_SERVER['SERVER_NAME'] ?? 'N/A'; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <div class="mt-3">
                    <h6>Session Data</h6>
                    <pre class="bg-light p-3 rounded" style="max-height: 200px; overflow: auto;"><?php print_r($_SESSION); ?></pre>
                </div>
            </div>
        </div>
        <?php endif; ?>
Request Method: <?php echo $_SERVER['REQUEST_METHOD'] ?? 'N/A'; ?>
Script Name: <?php echo $_SERVER['SCRIPT_NAME'] ?? 'N/A'; ?></pre>
            </div>
        </div>
            </div>
            
            <!-- Quick Links -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-link text-primary me-2"></i> Quick Links</h5>
                </div>
                <div class="list-group list-group-flush">
                    <a href="#" class="list-group-item list-group-item-action">
                        <i class="fas fa-file-alt text-primary me-2"></i> Monthly Report
                    </a>
                    <a href="#" class="list-group-item list-group-item-action">
                        <i class="fas fa-users text-primary me-2"></i> Member Directory
                    </a>
                    <a href="#" class="list-group-item list-group-item-action">
                        <i class="fas fa-calendar-plus text-primary me-2"></i> Create Event
                    </a>
                    <a href="#" class="list-group-item list-group-item-action">
                        <i class="fas fa-envelope text-primary me-2"></i> Send Announcement
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="mt-5 pt-4 pb-3 text-center text-muted">
        <p class="mb-0">© <?php echo date('Y'); ?> Apostles Revelation Society. All rights reserved.</p>
        <p class="small mb-0">Version 1.0.0</p>
    </footer>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- AOS Animation -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
    // Initialize AOS
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true
    });
    
    // Toggle sidebar on mobile
    document.getElementById('sidebarToggler').addEventListener('click', function() {
        document.querySelector('.sidebar').classList.toggle('show');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(event) {
        const sidebar = document.querySelector('.sidebar');
        const sidebarToggler = document.getElementById('sidebarToggler');
        
        if (window.innerWidth <= 992 && 
            !sidebar.contains(event.target) && 
            !sidebarToggler.contains(event.target)) {
            sidebar.classList.remove('show');
        }
    });
    
    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(link => {
        if (link.href === window.location.href) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
</script>
</body>
</html>