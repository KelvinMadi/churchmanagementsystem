<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

$page_title = "Service Times";
$show_page_header = false;
$base_path = '';

include 'includes/header.php';
?>

<style>
    /* Ensure nav is white on service times page */
    .navbar {
        background-color: #ffffff !important;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Ensure nav links are visible on white background */
    .navbar .nav-link {
        color: #2c3e50 !important;
    }
    
    .navbar .nav-link:hover {
        color: #e67e22 !important;
    }
    
    /* Active link styling */
    .navbar .nav-link.active {
        color: #e67e22 !important;
        font-weight: 600;
    }
    
    /* Adjust hero section padding to account for fixed header */
    .service-times-section {
        padding-top: 100px;
    }
</style>

<!-- Service Times Section with Glass Morphism -->
<section class="service-times-section py-6 position-relative overflow-hidden" id="service-times" style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
    <!-- Decorative Elements -->
    <div class="position-absolute top-0 start-0 w-100 h-100" style="z-index: 0; opacity: 0.1;">
        <div class="position-absolute" style="top: 20%; left: 10%; width: 300px; height: 300px; border-radius: 50%; background: var(--primary); filter: blur(80px);"></div>
        <div class="position-absolute" style="bottom: 10%; right: 15%; width: 250px; height: 250px; border-radius: 50%; background: var(--accent); filter: blur(60px);"></div>
    </div>
    
    <div class="container position-relative" style="z-index: 1;">
        <div class="text-center mb-6">
            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill mb-3">Worship With Us</span>
            <h2 class="display-4 fw-bold mb-3 text-dark">Service Times</h2>
            <p class="lead text-warning">Join our community for worship, prayer, and fellowship</p>
            <div class="divider bg-primary mx-auto" style="width: 80px; height: 3px;"></div>
        </div>
        
        <div class="row g-4 justify-content-center">
            <!-- Sunday Worship -->
            <div class="col-lg-5 col-md-6">
                <div class="service-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="service-card-inner">
                        <div class="service-card-front text-center p-5">
                            <div class="service-icon mb-4">
                                <i class="fas fa-church"></i>
                            </div>
                            <h3 class="h3 mb-3 fw-bold">Sunday Worship</h3>
                            <div class="service-time">
                                <span class="badge bg-warning text-dark px-3 py-2 mb-3">
                                    <i class="far fa-clock me-2"></i>11:00 AM - 1:00 PM
                                </span>
                            </div>
                            <p class="mb-0">Main Sanctuary</p>
                        </div>
                        <div class="service-card-back p-4">
                            <h4>Sunday Worship</h4>
                            <p>Experience powerful worship and biblical teaching in our main sanctuary service. Perfect for the whole family with children's ministry available.</p>
                            <a href="#" class="btn btn-outline-light btn-sm mt-3">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Wednesday Bible Study -->
            <div class="col-lg-5 col-md-6">
                <div class="service-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="service-card-inner">
                        <div class="service-card-front text-center p-5">
                            <div class="service-icon mb-4">
                                <i class="fas fa-bible"></i>
                            </div>
                            <h3 class="h3 mb-3 fw-bold">Bible Study</h3>
                            <div class="service-time">
                                <span class="badge bg-warning text-dark px-3 py-2 mb-3">
                                    <i class="far fa-clock me-2"></i>7:00 PM - 8:30 PM
                                </span>
                            </div>
                            <p class="mb-0">Fellowship Hall</p>
                        </div>
                        <div class="service-card-back p-4">
                            <h4>Bible Study</h4>
                            <p>Midweek Bible study and prayer meeting designed for spiritual growth and deeper understanding of God's Word.</p>
                            <a href="#" class="btn btn-outline-light btn-sm mt-3">Join Study</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Friday Prayer -->
            <div class="col-lg-5 col-md-6">
                <div class="service-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="service-card-inner">
                        <div class="service-card-front text-center p-5">
                            <div class="service-icon mb-4">
                                <i class="fas fa-pray"></i>
                            </div>
                            <h3 class="h3 mb-3 fw-bold">Prayer Night</h3>
                            <div class="service-time">
                                <span class="badge bg-warning text-dark px-3 py-2 mb-3">
                                    <i class="far fa-clock me-2"></i>7:00 PM - 8:30 PM
                                </span>
                            </div>
                            <p class="mb-0">Prayer Room</p>
                        </div>
                        <div class="service-card-back p-4">
                            <h4>Prayer Night</h4>
                            <p>Join us for a powerful time of corporate prayer, intercession, and seeking God's presence together.</p>
                            <a href="#" class="btn btn-outline-light btn-sm mt-3">Pray With Us</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Sunday School -->
            <div class="col-lg-5 col-md-6">
                <div class="service-card" data-aos="fade-up" data-aos-delay="400">
                    <div class="service-card-inner">
                        <div class="service-card-front text-center p-5">
                            <div class="service-icon mb-4">
                                <i class="fas fa-users"></i>
                            </div>
                            <h3 class="h3 mb-3 fw-bold">Sunday School</h3>
                            <div class="service-time">
                                <span class="badge bg-warning text-dark px-3 py-2 mb-3">
                                    <i class="far fa-clock me-2"></i>9:30 AM - 10:45 AM
                                </span>
                            </div>
                            <p class="mb-0">Education Wing</p>
                        </div>
                        <div class="service-card-back p-4">
                            <h4>Sunday School</h4>
                            <p>Engaging Bible study classes for all age groups. Grow in your faith with relevant teaching and community.</p>
                            <a href="#" class="btn btn-outline-light btn-sm mt-3">Find a Class</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Live Stream CTA -->
        <div class="text-center mt-6 pt-4">
            <div class="live-stream-cta p-4 p-lg-5 rounded-4" style="background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(10px);">
                <h3 class="h2 mb-4">Can't join us in person?</h3>
                <p class="lead mb-4">Watch our services live online and be part of our community from anywhere in the world.</p>
                <a href="#" class="btn btn-danger btn-lg px-5 py-3 fw-bold">
                    <i class="fas fa-play-circle me-2"></i> Watch Live Now
                </a>
                <div class="mt-3">
                    <span class="live-indicator"></span>
                    <span class="ms-2 text-uppercase small fw-bold">Live Every Sunday at 11:00 AM</span>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Service Times Section Styling */
.service-times-section {
    position: relative;
    padding: 6rem 0;
    overflow: hidden;
}

.service-card {
    perspective: 1000px;
    height: 100%;
    min-height: 300px;
}

.service-card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    transition: transform 0.8s;
    transform-style: preserve-3d;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.service-card:hover .service-card-inner {
    transform: rotateY(180deg);
}

.service-card-front, .service-card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    border-radius: 15px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 2rem;
}

.service-card-front {
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #2c3e50;
}

.service-card-back {
    background: linear-gradient(135deg, #e67e22 0%, #d35400 100%);
    color: white;
    transform: rotateY(180deg);
    padding: 2rem;
    text-align: center;
}

.service-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #e67e22 0%, #d35400 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
    color: white;
    font-size: 2rem;
    box-shadow: 0 5px 15px rgba(230, 126, 34, 0.3);
    transition: all 0.3s ease;
}

.service-card:hover .service-icon {
    transform: scale(1.1) translateY(-5px);
    box-shadow: 0 10px 25px rgba(230, 126, 34, 0.4);
}

.service-time {
    margin: 1rem 0;
}

.live-stream-cta {
    max-width: 800px;
    margin: 0 auto;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
}

.live-indicator {
    display: inline-block;
    width: 12px;
    height: 12px;
    background-color: #e74c3c;
    border-radius: 50%;
    animation: pulse 1.5s infinite;
}

@keyframes pulse {
    0% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.7);
    }
    70% {
        transform: scale(1.1);
        box-shadow: 0 0 0 10px rgba(231, 76, 60, 0);
    }
    100% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(231, 76, 60, 0);
    }
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .service-card {
        margin-bottom: 2rem;
    }
    
    .service-card-front, 
    .service-card-back {
        padding: 1.5rem;
    }
    
    .service-icon {
        width: 70px;
        height: 70px;
        font-size: 1.75rem;
    }
}
</style>

<!-- Location Section with Enhanced Design -->
<section class="location-section py-6 position-relative overflow-hidden" style="background: linear-gradient(135deg, #2c3e50 0%, #1a252f 100%); color: white;">
    <!-- Decorative Elements -->
    <div class="position-absolute top-0 start-0 w-100 h-100" style="z-index: 0; opacity: 0.05;">
        <div class="position-absolute" style="top: 20%; right: 10%; width: 200px; height: 200px; border-radius: 50%; background: white; filter: blur(60px);"></div>
        <div class="position-absolute" style="bottom: 10%; left: 15%; width: 250px; height: 250px; border-radius: 50%; background: var(--accent); filter: blur(80px);"></div>
    </div>
    
    <div class="container position-relative" style="z-index: 1;">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade-right">
                <div class="pe-lg-5">
                    <span class="badge bg-warning text-dark px-3 py-2 rounded-pill mb-3">Find Us</span>
                    <h2 class="display-5 fw-bold mb-4 text-white">Our Location</h2>
                    <p class="lead mb-4">We're located in the heart of the city, easily accessible by public transportation and with ample parking available.</p>
                    
                    <div class="location-info mb-5">
                        <div class="d-flex mb-3">
                            <div class="me-4">
                                <div class="bg-primary bg-opacity-10 p-3 rounded-circle d-inline-block">
                                    <i class="fas fa-map-marker-alt text-warning"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-1">Address</h5>
                                <p class="mb-0">123 Faith Avenue<br>Louisville, KY 40202</p>
                            </div>
                        </div>
                        
                        <div class="d-flex mb-3">
                            <div class="me-4">
                                <div class="bg-primary bg-opacity-10 p-3 rounded-circle d-inline-block">
                                    <i class="fas fa-phone-alt text-warning"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-1">Phone</h5>
                                <p class="mb-0">(502) 555-0123</p>
                            </div>
                        </div>
                        
                        <div class="d-flex">
                            <div class="me-4">
                                <div class="bg-primary bg-opacity-10 p-3 rounded-circle d-inline-block">
                                    <i class="fas fa-envelope text-warning"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-1">Email</h5>
                                <p class="mb-0">info@apostolicchurchlouisville.org</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex flex-wrap gap-3">
                        <a href="#" class="btn btn-warning btn-lg px-4 fw-bold">
                            <i class="fas fa-directions me-2"></i> Get Directions
                        </a>
                        <a href="#" class="btn btn-outline-light btn-lg px-4">
                            <i class="fas fa-download me-2"></i> Parking Info
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6" data-aos="fade-left" data-aos-delay="200">
                <div class="map-container rounded-3 overflow-hidden shadow-lg">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3132.6212000000003!2d-85.7588704244009!3d38.25601337184144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88690cd3a1e442e5%3A0x7f8e9b7c5c1b3f1e!2sLouisville%2C%20KY!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus" 
                        width="100%" 
                        height="500" 
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy"
                        class="map-iframe"
                        aria-label="Map to Apostolic Church Louisville">
                    </iframe>
                    <div class="map-overlay"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* Location Section Styling */
.location-section {
    position: relative;
    padding: 6rem 0;
    overflow: hidden;
}

.map-container {
    position: relative;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.map-container:hover {
    transform: translateY(-5px);
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
}

.map-iframe {
    display: block;
    width: 100%;
    height: 500px;
    border: none;
    position: relative;
    z-index: 1;
}

.map-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(44, 62, 80, 0.1) 0%, rgba(26, 37, 47, 0.1) 100%);
    pointer-events: none;
    z-index: 2;
}

.location-info h5 {
    color: var(--accent);
    font-weight: 600;
}

.location-info p {
    color: rgba(255, 255, 255, 0.9);
    margin-bottom: 0;
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .location-section {
        text-align: center;
    }
    
    .location-info > div {
        justify-content: center;
        text-align: left;
    }
    
    .map-container {
        margin-top: 3rem;
    }
}
</style>

<?php include 'includes/footer.php'; ?>
