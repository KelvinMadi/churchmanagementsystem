<?php
require_once '../includes/db.php';
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

$event_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = '';

if (!$event_id) {
    header('Location: list.php');
    exit();
}

// Get event details
$event_sql = 'SELECT e.*, u.name as organizer FROM events e ';
$event_sql .= 'LEFT JOIN users u ON e.organizer_id = u.id ';
$event_sql .= 'WHERE e.id = ' . (int)$event_id;
$event_result = $conn->query($event_sql);
$event = $event_result ? $event_result->fetch_assoc() : null;

if (!$event) {
    header('Location: list.php');
    exit();
}

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user_id) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'register') {
        // Check if already registered
        $reg_sql = 'SELECT id FROM event_registrations WHERE event_id = ' . (int)$event_id . ' AND user_id = ' . (int)$user_id;
        $registration = $conn->query($reg_sql);
        $registration = $registration ? $registration->fetch_assoc() : null;
        
        if ($registration) {
            $message = '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>You are already registered for this event.</div>';
        } else {
            $insert_sql = 'INSERT INTO event_registrations (event_id, user_id, registration_date) VALUES (' . 
                (int)$event_id . ', ' . (int)$user_id . ', "' . date('Y-m-d H:i:s') . '")';
            $result = $conn->query($insert_sql);
            
            if ($result) {
                $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Successfully registered for this event!</div>';
            } else {
                $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error registering for event.</div>';
            }
        }
    } elseif ($action === 'unregister') {
        $delete_sql = 'DELETE FROM event_registrations WHERE event_id = ' . (int)$event_id . ' AND user_id = ' . (int)$user_id;
        $result = $conn->query($delete_sql);
        
        if ($result) {
            $message = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Successfully unregistered from this event.</div>';
        } else {
            $message = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error unregistering from event.</div>';
        }
    }
}

// Check if user is registered
$is_registered = false;
if ($user_id) {
    $reg_check_sql = 'SELECT id FROM event_registrations WHERE event_id = ' . (int)$event_id . ' AND user_id = ' . (int)$user_id;
    $reg_result = $conn->query($reg_check_sql);
    $is_registered = $reg_result && $reg_result->num_rows > 0;
}

// Get registered participants
$participants_sql = 'SELECT u.name, er.registration_date FROM event_registrations er ';
$participants_sql .= 'JOIN users u ON er.user_id = u.id ';
$participants_sql .= 'WHERE er.event_id = ' . (int)$event_id . ' ORDER BY er.registration_date';
$participants = $conn->query($participants_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
{{ ... }}
    <title><?php echo htmlspecialchars($event['name']); ?> - Church Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../sermons/list.php">Sermons</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="list.php">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../announcements/list.php">Announcements</a>
                    </li>
                    <?php if ($user_id): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../dashboard/<?php echo $user_role; ?>.php">Dashboard</a></li>
                                <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../login.php">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h2 class="card-title"><?php echo htmlspecialchars($event['name']); ?></h2>
                            <span class="badge bg-primary"><?php echo date('M j, Y', strtotime($event['date'])); ?></span>
                        </div>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <p class="text-muted mb-2">
                                    <i class="fas fa-clock me-2"></i><?php echo date('g:i A', strtotime($event['time'])); ?>
                                </p>
                                <?php if ($event['location']): ?>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($event['location']); ?>
                                </p>
                                <?php endif; ?>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-user me-2"></i>Organized by: <?php echo htmlspecialchars($event['organizer'] ?? 'Unknown'); ?>
                                </p>
                            </div>
                            <div class="col-md-6">
                                <?php if ($event['max_participants']): ?>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-users me-2"></i>Max Participants: <?php echo $event['max_participants']; ?>
                                </p>
                                <?php endif; ?>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-globe me-2"></i><?php echo $event['is_public'] ? 'Public Event' : 'Private Event'; ?>
                                </p>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h5>Description</h5>
                            <p class="card-text"><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                        </div>
                        
                        <?php if ($user_id): ?>
                        <div class="mb-4">
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="<?php echo $is_registered ? 'unregister' : 'register'; ?>">
                                <?php if ($is_registered): ?>
                                    <button type="submit" class="btn btn-warning">
                                        <i class="fas fa-times me-2"></i>Unregister
                                    </button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-check me-2"></i>Register for Event
                                    </button>
                                <?php endif; ?>
                            </form>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>Please <a href="../login.php">login</a> to register for this event.
                        </div>
                        <?php endif; ?>
                        
                        <?php echo $message; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-users me-2"></i>Registered Participants</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($participants && $participants->num_rows > 0): ?>
                            <div class="list-group list-group-flush">
                                <?php while($participant = $participants->fetch_assoc()): ?>
                                <div class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><?php echo htmlspecialchars($participant['name']); ?></span>
                                    <small class="text-muted"><?php echo date('M j', strtotime($participant['registration_date'])); ?></small>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No participants registered yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="mt-4">
            <a href="list.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to Events
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 