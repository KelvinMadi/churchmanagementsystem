<!-- Preloader -->
<div class="luxury-preloader">
    <div class="luxury-spinner">
        <div class="luxury-spinner-inner"></div>
        <div class="luxury-spinner-text">Loading Divine Moments...</div>
    </div>
</div>

<!-- Luxury Header -->
<header class="luxury-header position-relative overflow-hidden">
    <!-- Animated Background -->
    <div class="luxury-bg-overlay"></div>
    <div class="luxury-particles" id="luxury-particles"></div>
    
    <!-- Decorative Elements -->
    <div class="luxury-ornament-1"></div>
    <div class="luxury-ornament-2"></div>
    
    <div class="container position-relative z-3">
        <!-- Top Bar -->
        <div class="luxury-top-bar py-3 d-none d-lg-block">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-map-marker-alt me-2 text-gold"></i>
                        <span class="text-white-50 small">123 Faith Avenue, Louisville, KY 40202</span>
                    </div>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <div class="d-inline-flex align-items-center">
                        <a href="#" class="text-white-50 me-4 hover-gold">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="text-white-50 me-4 hover-gold">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="text-white-50 me-4 hover-gold">
                            <i class="fab fa-youtube"></i>
                        </a>
                        <a href="#" class="text-white-50 hover-gold">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark py-3">
            <div class="container-fluid px-0">
                <a class="navbar-brand fw-bold fs-3" href="../">
                    <span class="text-white">APOSTOLIC</span> 
                    <span class="text-gold">CHURCH</span>
                </a>
                <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="../events">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../ministry">Ministries</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../sermons">Sermons</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../contact">Contact</a>
                        </li>
                        <li class="nav-item ms-lg-3 mt-2 mt-lg-0">
                            <a href="#" class="btn btn-gold btn-sm px-4">Give</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        
        <!-- Hero Content -->
        <div class="luxury-hero-content text-center py-10 py-lg-12">
            <div class="luxury-hero-overlay"></div>
            <div class="container position-relative z-3">
                <div class="luxury-breadcrumb mb-4" data-aos="fade-down">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a href="../" class="text-gold hover-gold">Home</a></li>
                            <li class="breadcrumb-item active text-white" aria-current="page">Divine Events</li>
                        </ol>
                    </nav>
                </div>
                
                <h1 class="display-2 fw-bold mb-4 text-uppercase luxury-title" data-aos="fade-up">
                    <span class="d-inline-block position-relative">
                        <span class="luxury-title-text">Divine Gatherings</span>
                        <span class="luxury-title-line"></span>
                    </span>
                </h1>
                
                <p class="lead mb-5 mx-auto luxury-subtitle" data-aos="fade-up" data-aos-delay="100">
                    Experience spiritual growth through our sacred events and holy gatherings. Join us on a journey of faith, 
                    fellowship, and divine connection in the heart of our vibrant community.
                </p>
                
                <div class="luxury-scroll-prompt" data-aos="fade-up" data-aos-delay="300">
                    <span class="d-block mb-2 text-uppercase small text-gold">Explore Events</span>
                    <div class="luxury-mouse-scroll">
                        <div class="luxury-mouse">
                            <div class="luxury-wheel"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Luxury Search -->
            <div class="row justify-content-center mb-5" data-aos="fade-up" data-aos-delay="150">
                <div class="col-lg-8 col-xl-6">
                    <form class="luxury-search">
                        <div class="input-group">
                            <span class="input-group-text bg-dark border-end-0">
                                <i class="fas fa-search text-gold"></i>
                            </span>
                            <input type="text" class="form-control border-start-0" placeholder="Search events...">
                            <button class="btn btn-gold" type="submit">
                                <span>Search</span>
                                <i class="fas fa-arrow-right ms-2"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Event Filters -->
            <div class="luxury-filters" data-aos="fade-up" data-aos-delay="200">
                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <a href="#" class="btn btn-filter active" data-filter="all">All Events</a>
                    <a href="#" class="btn btn-filter" data-filter="worship">
                        <i class="fas fa-pray me-2"></i> Worship
                    </a>
                    <a href="#" class="btn btn-filter" data-filter="bible">
                        <i class="fas fa-bible me-2"></i> Bible Study
                    </a>
                    <a href="#" class="btn btn-filter" data-filter="fellowship">
                        <i class="fas fa-users me-2"></i> Fellowship
                    </a>
                    <a href="#" class="btn btn-filter" data-filter="outreach">
                        <i class="fas fa-hands-helping me-2"></i> Outreach
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scroll Indicator -->
    <div class="luxury-scroll-indicator" data-aos="fade-up" data-aos-delay="300">
        <a href="#events" class="text-white text-decoration-none d-inline-flex flex-column align-items-center">
            <span class="luxury-scroll-text">EXPLORE EVENTS</span>
            <div class="luxury-mouse">
                <div class="luxury-wheel"></div>
            </div>
        </a>
    </div>
    
    <!-- Decorative Elements -->
    <div class="luxury-ornament-3"></div>
    <div class="luxury-ornament-4"></div>
</header>

<!-- Main Content -->
<main class="luxury-main">
    <!-- Upcoming Events -->
    <section id="events" class="py-10 py-lg-12 position-relative">
        <div class="luxury-section-pattern"></div>
        <div class="container position-relative z-2">
            <div class="section-header text-center mb-8" data-aos="fade-up">
                <span class="d-inline-block text-gold text-uppercase letter-spacing-2 mb-3">Divine Experiences</span>
                <h2 class="display-4 fw-bold mb-4">Upcoming <span class="text-gold">Events</span></h2>
                <div class="section-divider mx-auto">
                    <span class="divider-line"></span>
                    <i class="fas fa-cross text-gold mx-3"></i>
                    <span class="divider-line"></span>
                </div>
                <p class="lead text-muted mt-4 max-w-3xl mx-auto">Join us for these transformative spiritual gatherings designed to uplift, inspire, and connect our community in faith and fellowship.</p>
            </div>
            
            <!-- Event Grid -->
            <div class="row g-4">
                <!-- Event Item 1 -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="luxury-card h-100">
                        <div class="luxury-card-image">
                            <img src="https://source.unsplash.com/600x400/?worship,church" alt="Sunday Worship" class="img-fluid">
                            <div class="luxury-card-date">
                                <span class="day">15</span>
                                <span class="month">OCT</span>
                            </div>
                            <div class="luxury-card-overlay">
                                <a href="#" class="btn btn-gold btn-sm">View Details</a>
                            </div>
                        </div>
                        <div class="luxury-card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="luxury-card-category"><i class="fas fa-pray me-2"></i>Worship</span>
                                <div class="luxury-card-share">
                                    <a href="#" class="text-muted me-2"><i class="far fa-heart"></i></a>
                                    <a href="#" class="text-muted"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <h3 class="luxury-card-title">Sunday Morning Worship</h3>
                            <div class="luxury-card-meta mb-3">
                                <span><i class="far fa-clock text-gold me-1"></i> 10:00 AM - 12:00 PM</span>
                                <span><i class="fas fa-map-marker-alt text-gold me-1"></i> Main Sanctuary</span>
                            </div>
                            <p class="luxury-card-text">Experience the presence of God in our powerful Sunday worship service. Join us for anointed praise, heartfelt worship, and life-changing Word.</p>
                            <div class="luxury-card-footer mt-auto">
                                <div class="d-flex align-items-center">
                                    <div class="luxury-card-avatar-group me-3">
                                        <img src="https://randomuser.me/api/portraits/men/32.jpg" class="luxury-avatar" alt="Speaker">
                                        <img src="https://randomuser.me/api/portraits/women/44.jpg" class="luxury-avatar" alt="Worship Leader">
                                    </div>
                                    <div>
                                        <div class="small text-muted">Featuring</div>
                                        <div class="fw-medium">Pastor John & Team</div>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-gold btn-sm px-3">Join Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Event Item 2 -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="luxury-card h-100">
                        <div class="luxury-card-image">
                            <img src="https://source.unsplash.com/600x400/?bible,study" alt="Bible Study" class="img-fluid">
                            <div class="luxury-card-date">
                                <span class="day">17</span>
                                <span class="month">OCT</span>
                            </div>
                            <div class="luxury-card-overlay">
                                <a href="#" class="btn btn-gold btn-sm">View Details</a>
                            </div>
                        </div>
                        <div class="luxury-card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="luxury-card-category"><i class="fas fa-bible me-2"></i>Bible Study</span>
                                <div class="luxury-card-share">
                                    <a href="#" class="text-muted me-2"><i class="far fa-heart"></i></a>
                                    <a href="#" class="text-muted"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <h3 class="luxury-card-title">Midweek Bible Study</h3>
                            <div class="luxury-card-meta mb-3">
                                <span><i class="far fa-clock text-gold me-1"></i> 7:00 PM - 8:30 PM</span>
                                <span><i class="fas fa-map-marker-alt text-gold me-1"></i> Fellowship Hall</span>
                            </div>
                            <p class="luxury-card-text">Join Pastor John for an in-depth exploration of the Book of Romans. This study will transform your understanding of grace, faith, and righteousness.</p>
                            <div class="luxury-card-footer mt-auto">
                                <div class="d-flex align-items-center">
                                    <div class="luxury-card-avatar-group me-3">
                                        <img src="https://randomuser.me/api/portraits/men/32.jpg" class="luxury-avatar" alt="Pastor">
                                    </div>
                                    <div>
                                        <div class="small text-muted">Led by</div>
                                        <div class="fw-medium">Pastor John Smith</div>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-gold btn-sm px-3">Join Study</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Event Item 3 -->
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="luxury-card h-100">
                        <div class="luxury-card-image">
                            <img src="https://source.unsplash.com/600x400/?youth,group" alt="Youth Night" class="img-fluid">
                            <div class="luxury-card-date">
                                <span class="day">19</span>
                                <span class="month">OCT</span>
                            </div>
                            <div class="luxury-card-overlay">
                                <a href="#" class="btn btn-gold btn-sm">View Details</a>
                            </div>
                        </div>
                        <div class="luxury-card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="luxury-card-category"><i class="fas fa-users me-2"></i>Youth</span>
                                <div class="luxury-card-share">
                                    <a href="#" class="text-muted me-2"><i class="far fa-heart"></i></a>
                                    <a href="#" class="text-muted"><i class="fas fa-share-alt"></i></a>
                                </div>
                            </div>
                            <h3 class="luxury-card-title">Friday Night Youth</h3>
                            <div class="luxury-card-meta mb-3">
                                <span><i class="far fa-clock text-gold me-1"></i> 6:30 PM - 9:00 PM</span>
                                <span><i class="fas fa-map-marker-alt text-gold me-1"></i> Youth Center</span>
                            </div>
                            <p class="luxury-card-text">An unforgettable night of fun, faith, and fellowship for teens. Featuring exciting games, powerful worship, and relevant Bible teaching that speaks to your life.</p>
                            <div class="luxury-card-footer mt-auto">
                                <div class="d-flex align-items-center">
                                    <div class="luxury-card-avatar-group me-3">
                                        <img src="https://randomuser.me/api/portraits/men/45.jpg" class="luxury-avatar" alt="Youth Pastor">
                                        <img src="https://randomuser.me/api/portraits/women/28.jpg" class="luxury-avatar" alt="Worship Leader">
                                    </div>
                                    <div>
                                        <div class="small text-muted">With</div>
                                        <div class="fw-medium">Pastor Mike & Team</div>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-gold btn-sm px-3">Join Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- View All Button -->
            <div class="text-center mt-8 position-relative z-2" data-aos="fade-up">
                <a href="#" class="btn btn-gold btn-lg px-5 py-3 position-relative overflow-hidden">
                    <span class="position-relative z-2">View All Events</span>
                    <span class="btn-glow"></span>
                </a>
                <p class="text-muted mt-3 mb-0">Can't find what you're looking for? <a href="#" class="text-gold hover-gold text-decoration-underline">Contact us</a></p>
            </div>
        </div>
    </section>
    
    <!-- Call to Action -->
    <section class="luxury-cta py-8 py-lg-10 position-relative">
        <div class="container position-relative z-1">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <h2 class="display-5 fw-bold mb-4">Can't Find What You're Looking For?</h2>
                    <p class="lead mb-5">Contact us for more information about our events and ministries. We'd love to help you get connected.</p>
                    <div class="d-flex flex-wrap justify-content-center gap-3">
                        <a href="../contact" class="btn btn-gold btn-lg px-5">Contact Us</a>
                        <a href="#" class="btn btn-outline-light btn-lg px-5">View Calendar</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Footer -->
<footer class="luxury-footer bg-dark text-white pt-8 pb-4">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4">
                <div class="mb-4">
                    <h3 class="h4 text-uppercase mb-4">APOSTOLIC CHURCH</h3>
                    <p class="text-white-50">A vibrant community of faith dedicated to spreading the love and teachings of Christ in Louisville and beyond.</p>
                </div>
                <div class="d-flex gap-3">
                    <a href="#" class="text-gold hover-white"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-gold hover-white"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-gold hover-white"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-gold hover-white"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-4">
                <h4 class="h5 text-uppercase mb-4">Quick Links</h4>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="../" class="text-white-50 hover-gold text-decoration-none">Home</a></li>
                    <li class="mb-2"><a href="../about" class="text-white-50 hover-gold text-decoration-none">About Us</a></li>
                    <li class="mb-2"><a href="../ministry" class="text-white-50 hover-gold text-decoration-none">Ministries</a></li>
                    <li class="mb-2"><a href="../sermons" class="text-white-50 hover-gold text-decoration-none">Sermons</a></li>
                    <li class="mb-2"><a href="../events" class="text-white-50 hover-gold text-decoration-none">Events</a></li>
                    <li><a href="../contact" class="text-white-50 hover-gold text-decoration-none">Contact</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4">
                <h4 class="h5 text-uppercase mb-4">Contact Info</h4>
                <ul class="list-unstyled text-white-50">
                    <li class="mb-3 d-flex">
                        <i class="fas fa-map-marker-alt text-gold mt-1 me-3"></i>
                        <span>123 Faith Avenue<br>Louisville, KY 40202</span>
                    </li>
                    <li class="mb-3">
                        <i class="fas fa-phone-alt text-gold me-3"></i>
                        <a href="tel:+15025550123" class="text-white-50 hover-gold text-decoration-none">(502) 555-0123</a>
                    </li>
                    <li class="mb-3">
                        <i class="fas fa-envelope text-gold me-3"></i>
                        <a href="mailto:info@apostolicchurchlouisville.org" class="text-white-50 hover-gold text-decoration-none">info@apostolicchurchlouisville.org</a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4">
                <h4 class="h5 text-uppercase mb-4">Service Times</h4>
                <ul class="list-unstyled text-white-50">
                    <li class="d-flex justify-content-between mb-2">
                        <span>Sunday Morning</span>
                        <span>10:00 AM</span>
                    </li>
                    <li class="d-flex justify-content-between mb-2">
                        <span>Sunday Evening</span>
                        <span>6:00 PM</span>
                    </li>
                    <li class="d-flex justify-content-between mb-2">
                        <span>Wednesday Bible Study</span>
                        <span>7:00 PM</span>
                    </li>
                </ul>
                <a href="#" class="btn btn-gold btn-sm mt-3">View Full Schedule</a>
            </div>
        </div>
        <hr class="my-5 border-secondary">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                <p class="mb-0 text-white-50 small">&copy; 2025 Apostolic Church. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <a href="#" class="text-white-50 small me-3 hover-gold text-decoration-none">Privacy Policy</a>
                <a href="#" class="text-white-50 small hover-gold text-decoration-none">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top -->
<a href="#" class="btn btn-gold btn-lg rounded-circle back-to-top">
    <i class="fas fa-arrow-up"></i>
</a>

<!-- Styles -->
<style>
/* Base Styles */
:root {
    --primary: #1a1a1a;
    --primary-rgb: 26, 26, 26;
    --secondary: #e67e22;
    --gold: #d4af37;
    --gold-rgb: 212, 175, 55;
    --dark: #121212;
    --light: #f8f9fa;
    --transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
    --box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    --box-shadow-hover: 0 15px 40px rgba(0, 0, 0, 0.15);
    --border-radius: 8px;
    --border-radius-lg: 12px;
    --letter-spacing: 1px;
    --max-w-lg: 1200px;
    --max-w-md: 800px;
    --max-w-sm: 600px;
    --max-w-xs: 400px;
}

body {
    font-family: 'Playfair Display', serif;
    color: #333;
    overflow-x: hidden;
    background-color: #f9f9f9;
}

/* Typography */
h1, h2, h3, h4, h5, h6,
.h1, .h2, .h3, .h4, .h5, .h6 {
    font-family: 'Playfair Display', serif;
    font-weight: 700;
    line-height: 1.3;
}

/* Utility Classes */
.text-gold { color: var(--gold) !important; }
.bg-gold { background-color: var(--gold) !important; }
.btn-gold { 
    background-color: var(--gold);
    color: #fff;
    border: none;
    padding: 0.75rem 2rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    transition: var(--transition);
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.btn-gold:before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.1);
    transition: all 0.3s ease;
    z-index: -1;
}

.btn-gold:hover:before {
    left: 0;
}

.btn-gold:hover {
    color: #fff;
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
}

/* Preloader */
.luxury-preloader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: var(--dark);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
    transition: opacity 0.6s cubic-bezier(0.77, 0, 0.175, 1), visibility 0.6s;
}

.luxury-preloader.fade-out {
    opacity: 0;
    visibility: hidden;
}

.luxury-spinner {
    text-align: center;
    position: relative;
    z-index: 1;
}

.luxury-spinner-inner {
    width: 60px;
    height: 60px;
    border: 3px solid rgba(255, 255, 255, 0.05);
    border-radius: 50%;
    border-top-color: var(--gold);
    border-right-color: var(--gold);
    border-bottom-color: var(--gold);
    animation: spin 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
    margin: 0 auto 1.5rem;
    position: relative;
}

.luxury-spinner-inner:before {
    content: '';
    position: absolute;
    top: -8px;
    left: -8px;
    right: -8px;
    bottom: -8px;
    border: 2px solid rgba(212, 175, 55, 0.2);
    border-radius: 50%;
    animation: pulse 2s linear infinite;
}

.luxury-spinner-text {
    color: var(--gold);
    font-size: 0.875rem;
    letter-spacing: 2px;
    text-transform: uppercase;
    font-weight: 500;
    margin-top: 1.5rem;
    animation: fadeInOut 2s ease-in-out infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

@keyframes pulse {
    0% { transform: scale(0.8); opacity: 0.5; }
    50% { transform: scale(1.2); opacity: 0.8; }
    100% { transform: scale(0.8); opacity: 0.5; }
}

@keyframes fadeInOut {
    0% { opacity: 0.5; }
    50% { opacity: 1; }
    100% { opacity: 0.5; }
}

/* Header */
.luxury-header {
    background: linear-gradient(135deg, #1a1a1a 0%, #2c3e50 100%);
    color: #fff;
    position: relative;
    overflow: hidden;
    padding-top: 1rem;
}

.luxury-bg-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgcGF0dGVyblRyYW5zZm9ybT0icm90YXRlKDQ1KSI+PHJlY3Qgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjAyIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI3BhdHRlcm4pIi8+PC9zdmc+');
    opacity: 0.3;
    z-index: 1;
}

.luxury-particles {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 2;
}

/* Navigation */
.navbar {
    padding: 1rem 0;
    z-index: 1000;
}

.navbar-brand {
    font-size: 1.75rem;
    letter-spacing: 1px;
}

.nav-link {
    color: rgba(255, 255, 255, 0.8) !important;
    font-weight: 500;
    padding: 0.5rem 1rem !important;
    margin: 0 0.25rem;
    position: relative;
    transition: var(--transition);
}

.nav-link:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 0;
    height: 2px;
    background: var(--gold);
    transition: var(--transition);
    transform: translateX(-50%);
}

.nav-link:hover,
.nav-link.active {
    color: #fff !important;
}

.nav-link:hover:after,
.nav-link.active:after {
    width: 60%;
}

/* Hero Content */
.luxury-hero-content {
    padding: 10rem 0 12rem;
    position: relative;
    z-index: 3;
    overflow: hidden;
}

.luxury-hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(26, 26, 26, 0.95) 0%, rgba(44, 62, 80, 0.9) 100%);
    z-index: 1;
}

.luxury-title {
    font-size: 4.5rem;
    letter-spacing: 3px;
    margin-bottom: 1.5rem;
    text-transform: uppercase;
    position: relative;
    display: inline-block;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    line-height: 1.2;
}

.luxury-title-text {
    position: relative;
    display: inline-block;
    background: linear-gradient(to right, #fff 0%, #f1f1f1 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.luxury-title:after {
    content: '';
    position: absolute;
    bottom: -15px;
    left: 50%;
    transform: translateX(-50%);
    width: 120px;
    height: 4px;
    background: linear-gradient(90deg, transparent, var(--gold), transparent);
    border-radius: 2px;
}

.luxury-subtitle {
    font-size: 1.5rem;
    color: rgba(255, 255, 255, 0.85);
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 3rem;
    line-height: 1.6;
    font-weight: 300;
    letter-spacing: 0.5px;
}

/* Scroll Prompt */
.luxury-scroll-prompt {
    position: absolute;
    bottom: 3rem;
    left: 50%;
    transform: translateX(-50%);
    z-index: 5;
    text-align: center;
    opacity: 0;
    animation: fadeInUp 1s ease 1.5s forwards;
}

.luxury-mouse-scroll {
    width: 30px;
    height: 50px;
    border: 2px solid var(--gold);
    border-radius: 15px;
    position: relative;
    margin: 0 auto;
    padding: 5px;
}

.luxury-mouse {
    width: 20px;
    height: 20px;
    position: relative;
    margin: 0 auto;
    animation: scroll 2s infinite;
}

.luxury-wheel {
    width: 6px;
    height: 6px;
    background: var(--gold);
    border-radius: 50%;
    position: absolute;
    top: 5px;
    left: 50%;
    transform: translateX(-50%);
}

@keyframes scroll {
    0% { transform: translateY(0); opacity: 1; }
    100% { transform: translateY(15px); opacity: 0; }
}

/* Section Pattern */
.luxury-section-pattern {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23d4af37' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");
    opacity: 0.5;
    z-index: 1;
}

/* Search Form */
.luxury-search {
    position: relative;
    max-width: 600px;
    margin: 0 auto;
}

.luxury-search .form-control {
    height: 60px;
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 0;
    background: rgba(255, 255, 255, 0.95);
    font-size: 1rem;
    transition: var(--transition);
}

.luxury-search .input-group-text {
    background: rgba(255, 255, 255, 0.95);
    border: none;
    padding: 0 1.5rem;
    font-size: 1.1rem;
}

.luxury-search .btn {
    padding: 0 2rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Filters */
.luxury-filters {
    margin: 2rem 0;
}

.btn-filter {
    background: transparent;
    color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 50px;
    padding: 0.5rem 1.5rem;
    font-size: 0.875rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 1px;
    transition: var(--transition);
}

.btn-filter:hover,
.btn-filter.active {
    background: var(--gold);
    border-color: var(--gold);
    color: #fff;
    transform: translateY(-2px);
}

/* Scroll Indicator */
.luxury-scroll-indicator {
    position: absolute;
    bottom: 2rem;
    left: 0;
    width: 100%;
    text-align: center;
    z-index: 10;
}

.luxury-scroll-text {
    font-size: 0.75rem;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.7);
    margin-bottom: 1rem;
    display: block;
}

.luxury-mouse {
    width: 30px;
    height: 50px;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-radius: 20px;
    display: flex;
    justify-content: center;
    padding-top: 10px;
    margin: 0 auto;
}

.luxury-wheel {
    width: 4px;
    height: 10px;
    background-color: #fff;
    border-radius: 2px;
    animation: scroll 2s infinite;
}

@keyframes scroll {
    0% { transform: translateY(0); opacity: 1; }
    100% { transform: translateY(10px); opacity: 0; }
}

/* Section Headers */
.section-header {
    margin-bottom: 4rem;
    position: relative;
}

.section-title {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 1rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    position: relative;
    display: inline-block;
}

.section-divider {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 1.5rem 0;
}

.divider-line {
    width: 50px;
    height: 2px;
    background: var(--gold);
    display: inline-block;
}

.section-divider i {
    color: var(--gold);
    margin: 0 1rem;
    font-size: 1.25rem;
}

.section-subtitle {
    font-size: 1.1rem;
    color: #6c757d;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
}

/* Cards */
.luxury-card {
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
    transition: var(--transition);
    height: 100%;
    display: flex;
    flex-direction: column;
}

.luxury-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
}

.luxury-card-image {
    position: relative;
    overflow: hidden;
    padding-top: 60%;
}

.luxury-card-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.luxury-card:hover .luxury-card-image img {
    transform: scale(1.05);
}

.luxury-card-date {
    position: absolute;
    top: 20px;
    left: 20px;
    background: var(--gold);
    color: #fff;
    padding: 10px 15px;
    border-radius: 4px;
    text-align: center;
    line-height: 1.2;
}

.luxury-card-date .day {
    font-size: 1.5rem;
    font-weight: 700;
    display: block;
}

.luxury-card-date .month {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.luxury-card-category {
    position: absolute;
    top: 20px;
    right: 20px;
}

.luxury-card-category .badge {
    background: rgba(0, 0, 0, 0.7);
    color: #fff;
    padding: 5px 12px;
    border-radius: 50px;
    font-size: 0.7rem;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.luxury-card-content {
    padding: 1.75rem;
    flex: 1;
    display: flex;
    flex-direction: column;
}

.luxury-card-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin-bottom: 1rem;
    font-size: 0.85rem;
    color: #6c757d;
}

.luxury-card-meta i {
    color: var(--gold);
    margin-right: 0.5rem;
}

.luxury-card-title {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 1rem;
    color: var(--dark);
}

.luxury-card-text {
    color: #6c757d;
    margin-bottom: 1.5rem;
    flex: 1;
}

.luxury-card-actions a {
    color: #6c757d;
    margin-left: 0.75rem;
    transition: var(--transition);
}

.luxury-card-actions a:hover {
    color: var(--gold);
}

/* Call to Action */
.luxury-cta {
    background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url('https://source.unsplash.com/1920x1080/?church,stained-glass') no-repeat center center/cover;
    color: #fff;
    padding: 6rem 0;
    position: relative;
    background-attachment: fixed;
}

.luxury-cta:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, rgba(212, 175, 55, 0.1) 0%, rgba(44, 62, 80, 0.1) 100%);
    z-index: 1;
}

.luxury-cta .container {
    position: relative;
    z-index: 2;
}

/* Footer */
.luxury-footer {
    position: relative;
    overflow: hidden;
}

.luxury-footer:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: linear-gradient(90deg, var(--gold), var(--secondary));
}

.luxury-footer h4 {
    color: #fff;
    font-weight: 600;
    margin-bottom: 1.5rem;
    position: relative;
    padding-bottom: 1rem;
}

.luxury-footer h4:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 50px;
    height: 2px;
    background: var(--gold);
}

.luxury-footer ul li {
    margin-bottom: 0.75rem;
}

.luxury-footer a {
    color: rgba(255, 255, 255, 0.7);
    text-decoration: none;
    transition: var(--transition);
}

.luxury-footer a:hover {
    color: var(--gold);
    padding-left: 5px;
}

/* Back to Top */
.back-to-top {
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--gold);
    color: #fff;
    border-radius: 50%;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    opacity: 0;
    visibility: hidden;
    transition: var(--transition);
    z-index: 999;
}

.back-to-top.active {
    opacity: 1;
    visibility: visible;
    bottom: 50px;
}

.back-to-top:hover {
    background: var(--secondary);
    color: #fff;
    transform: translateY(-3px);
}

/* Animations */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.fadeInUp {
    animation: fadeInUp 0.6s ease forwards;
}

/* Hover Effects */
.hover-gold {
    transition: var(--transition);
}

.hover-gold:hover {
    color: var(--gold) !important;
}

/* Responsive */
@media (max-width: 991.98px) {
    .luxury-title {
        font-size: 3rem;
    }
    
    .luxury-hero-content {
        padding: 4rem 0 6rem;
    }
    
    .navbar-collapse {
        background: rgba(26, 26, 26, 0.95);
        padding: 1.5rem;
        margin-top: 1rem;
        border-radius: 8px;
    }
    
    .nav-link {
        padding: 0.75rem 0 !important;
        margin: 0;
    }
    
    .nav-link:after {
        display: none;
    }
}

@media (max-width: 767.98px) {
    .luxury-title {
        font-size: 2.5rem;
    }
    
    .section-title {
        font-size: 2rem;
    }
    
    .luxury-card {
        margin-bottom: 2rem;
    }
    
    .luxury-cta {
        padding: 4rem 0;
        background-attachment: scroll;
    }
}

@media (max-width: 575.98px) {
    .luxury-title {
        font-size: 2rem;
    }
    
    .section-title {
        font-size: 1.75rem;
    }
    
    .luxury-search .btn {
        display: none;
    }
}
</style>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
// Preloader
window.addEventListener('load', function() {
    const preloader = document.querySelector('.luxury-preloader');
    preloader.classList.add('fade-out');
    
    setTimeout(() => {
        preloader.style.display = 'none';
    }, 500);
});

// Initialize AOS
AOS.init({
    duration: 1000,
    once: true,
    easing: 'ease-in-out'
});

// Back to Top Button
const backToTop = document.querySelector('.back-to-top');

window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
        backToTop.classList.add('active');
    } else {
        backToTop.classList.remove('active');
    }
});

backToTop.addEventListener('click', function(e) {
    e.preventDefault();
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Smooth Scrolling for Anchor Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            window.scrollTo({
                top: target.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

// Initialize Tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
});

// Particles.js Configuration
if (document.getElementById('luxury-particles')) {
    particlesJS('luxury-particles', {
        particles: {
            number: {
                value: 80,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: '#ffffff'
            },
            shape: {
                type: 'circle',
                stroke: {
                    width: 0,
                    color: '#000000'
                }
            },
            opacity: {
                value: 0.3,
                random: true,
                animation: {
                    enable: true,
                    speed: 1,
                    minimumValue: 0.1,
                    sync: false
                }
            },
            size: {
                value: 3,
                random: true,
                animation: {
                    enable: true,
                    speed: 2,
                    minimumValue: 0.1,
                    sync: false
                }
            },
            lineLinked: {
                enable: true,
                distance: 150,
                color: '#ffffff',
                opacity: 0.2,
                width: 1
            },
            move: {
                enable: true,
                speed: 1,
                direction: 'none',
                random: true,
                straight: false,
                outMode: 'out',
                attract: {
                    enable: false,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detectOn: 'canvas',
            events: {
                onhover: {
                    enable: true,
                    mode: 'grab'
                },
                onclick: {
                    enable: true,
                    mode: 'push'
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 140,
                    lineLinked: {
                        opacity: 0.5
                    }
                },
                push: {
                    particles_nb: 4
                }
            }
        },
        retina_detect: true
    });
}
</script>
