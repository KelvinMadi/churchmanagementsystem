<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!is_logged_in()) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header('Location: ../login.php');
    exit();
}

$user = get_user();
$event_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = '';

// Get event details
$events = $conn->query('SELECT * FROM events WHERE id = ' . (int)$event_id)->fetchAll();
$event = !empty($events) ? $events[0] : null;

// Ensure event has all required fields with default values
if ($event) {
    $event['max_participants'] = $event['max_participants'] ?? 0; // 0 means no limit
    $event['registered_count'] = $event['registered_count'] ?? 0;
}

// Get organizer name
if ($event) {
    // Set default organizer_id if not set
    if (!isset($event['organizer_id'])) {
        $event['organizer_id'] = 1; // Default to admin user or handle as needed
    }
    
    $organizer = $conn->query('SELECT name FROM users WHERE id = ' . (int)$event['organizer_id'])->fetch_assoc();
    $event['organizer_name'] = $organizer ? $organizer['name'] : 'System';
    
    // Get registration count
    $registrations = $conn->query('SELECT * FROM event_registrations WHERE event_id = ' . (int)$event_id)->fetchAll();
    $event['registered_count'] = count($registrations);
}

// Check if event exists
if (!$event) {
    header('Location: list.php');
    exit();
}

// Check if registration is already done
$existing = $conn->query('SELECT id FROM event_registrations WHERE event_id = ' . (int)$event_id . ' AND user_id = ' . (int)$user['id'])->fetchAll();
$already_registered = !empty($existing);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$already_registered) {
    // Check if event is full
    if ($event['max_participants'] && $event['registered_count'] >= $event['max_participants']) {
        $message = '<div class="alert alert-warning">Sorry, this event is already full.</div>';
    } else {
        // Register user for the event
        $registration = [
            'event_id' => $event_id,
            'user_id' => $user['id'],
            'registration_date' => date('Y-m-d H:i:s')
        ];
        
        // Save registration to file
        $registrations_file = __DIR__ . '/../data/event_registrations.json';
        $all_registrations = [];
        
        if (file_exists($registrations_file)) {
            $all_registrations = json_decode(file_get_contents($registrations_file), true) ?: [];
        }
        
        $all_registrations[] = $registration;
        
        if (file_put_contents($registrations_file, json_encode($all_registrations, JSON_PRETTY_PRINT))) {
            $message = '<div class="alert alert-success">Successfully registered for this event!</div>';
            $already_registered = true;
            // Update the registered count
            $event['registered_count']++;
        } else {
            $message = '<div class="alert alert-danger">Error registering for the event. Please try again.</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register for Event - <?php echo htmlspecialchars($event['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .event-header {
            background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            color: white;
            padding: 3rem 0;
            margin-bottom: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .event-details {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .detail-item {
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
        }
        .detail-item i {
            width: 24px;
            margin-right: 10px;
            color: #4b6cb7;
        }
        .btn-register {
            background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(75, 108, 183, 0.4);
        }
        .availability-badge {
            font-size: 1rem;
            padding: 8px 15px;
            border-radius: 20px;
        }
        .back-link {
            color: #4b6cb7;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        .back-link:hover {
            color: #182848;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <?php 
    $navbar_path = __DIR__ . '/../includes/navbar.php';
    if (file_exists($navbar_path)) {
        include $navbar_path;
    } else {
        // Fallback navigation or error handling
        echo '<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="/">Church CMS</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/events/list.php">Events</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>';
    }
    ?>

    <div class="container py-5">
        <!-- Back Button -->
        <div class="mb-4">
            <a href="view.php?id=<?php echo $event_id; ?>" class="back-link">
                <i class="fas fa-arrow-left me-2"></i>Back to Event
            </a>
        </div>

        <!-- Event Header -->
        <div class="event-header text-center">
            <h1 class="display-5 fw-bold"><?php echo htmlspecialchars($event['name']); ?></h1>
            <p class="lead mb-0">Join us for this special event</p>
        </div>

        <?php if ($message): ?>
            <div class="mb-4"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="row">
            <!-- Event Details -->
            <div class="col-lg-8">
                <div class="event-details">
                    <h3 class="mb-4">Event Details</h3>
                    
                    <div class="detail-item">
                        <i class="far fa-calendar-alt"></i>
                        <div>
                            <h6 class="mb-0">Date & Time</h6>
                            <p class="mb-0">
                                <?php 
                                $event_date = new DateTime($event['date'] . ' ' . $event['time']);
                                echo $event_date->format('l, F j, Y \a\t g:i A'); 
                                ?>
                            </p>
                        </div>
                    </div>

                    <?php if ($event['location']): ?>
                    <div class="detail-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h6 class="mb-0">Location</h6>
                            <p class="mb-0"><?php echo htmlspecialchars($event['location']); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="detail-item">
                        <i class="fas fa-user-tie"></i>
                        <div>
                            <h6 class="mb-0">Organizer</h6>
                            <p class="mb-0"><?php echo htmlspecialchars($event['organizer_name']); ?></p>
                        </div>
                    </div>

                    <?php if ($event['max_participants']): ?>
                    <div class="detail-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <h6 class="mb-0">Availability</h6>
                            <p class="mb-0">
                                <?php 
                                $remaining = $event['max_participants'] - $event['registered_count'];
                                $is_full = $remaining <= 0;
                                $availability_class = $is_full ? 'bg-danger' : 'bg-success';
                                $availability_text = $is_full ? 'Fully Booked' : "$remaining spots remaining";
                                ?>
                                <span class="badge <?php echo $availability_class; ?> availability-badge">
                                    <?php echo $availability_text; ?>
                                </span>
                            </p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if ($event['description']): ?>
                    <div class="mt-4">
                        <h5>About This Event</h5>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Registration Form -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h4 class="mb-4">Register Now</h4>
                        
                        <?php if ($already_registered): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-2"></i>
                                You are already registered for this event.
                            </div>
                            <a href="list.php" class="btn btn-outline-primary w-100 mt-3">
                                <i class="fas fa-calendar-alt me-2"></i>View Other Events
                            </a>
                        <?php else: ?>
                            <?php 
                            $is_full = $event['max_participants'] > 0 && $event['registered_count'] >= $event['max_participants'];
                            $remaining_slots = $event['max_participants'] - $event['registered_count'];
                            ?>
                            
                            <?php if ($is_full): ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    This event is currently full. Please check back later for availability.
                                </div>
                            <?php else: ?>
                                <p class="text-muted mb-4">
                                    Complete the form below to register for this event.
                                    <?php if ($event['max_participants'] > 0): ?>
                                        <br><small class="text-muted">
                                            <i class="fas fa-users me-1"></i> 
                                            <?php echo $remaining_slots; ?> of <?php echo $event['max_participants']; ?> spots remaining
                                        </small>
                                    <?php endif; ?>
                                </p>
                                <form method="post" action="">
                                    <div class="mb-3">
                                        <label class="form-label">Your Name</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Your Email</label>
                                        <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-register w-100">
                                        <i class="fas fa-user-plus me-2"></i>Register Now
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add any additional JavaScript here
        document.addEventListener('DOMContentLoaded', function() {
            // Any client-side validation or interactivity can go here
        });
    </script>
</body>
</html>
