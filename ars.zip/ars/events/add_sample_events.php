<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Get admin user ID for organizer
$admin_user = get_user_by_email('admin@example.com');
$organizer_id = $admin_user ? $admin_user['id'] : 1; // Fallback to user ID 1 if admin not found

// Sample event data
$sample_events = [
    [
        'name' => 'Sunday Worship Service',
        'description' => 'Join us for our weekly Sunday worship service featuring inspiring music and a powerful message.',
        'date' => date('Y-m-d', strtotime('next Sunday')),
        'time' => '10:00:00',
        'location' => 'Main Sanctuary',
        'max_participants' => 200,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Bible Study: Book of Romans',
        'description' => 'In-depth study of the Book of Romans. All are welcome to join this engaging Bible study session.',
        'date' => date('Y-m-d', strtotime('next Tuesday')),
        'time' => '19:00:00',
        'location' => 'Fellowship Hall',
        'max_participants' => 50,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Youth Group Meeting',
        'description' => 'Fun and fellowship for our youth members. Games, worship, and relevant Bible teaching.',
        'date' => date('Y-m-d', strtotime('next Friday')),
        'time' => '18:30:00',
        'location' => 'Youth Center',
        'max_participants' => 75,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Prayer Meeting',
        'description' => 'Corporate prayer gathering. Come join us as we lift up our church, community, and world in prayer.',
        'date' => date('Y-m-d', strtotime('next Wednesday')),
        'time' => '19:00:00',
        'location' => 'Prayer Room',
        'max_participants' => 100,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Men\'s Breakfast',
        'description' => 'Fellowship and teaching time for men of all ages. Breakfast will be served.',
        'date' => date('Y-m-d', strtotime('+2 Saturdays')),
        'time' => '08:00:00',
        'location' => 'Fellowship Hall',
        'max_participants' => 60,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Women\'s Bible Study',
        'description' => 'Weekly women\'s Bible study group. Childcare provided upon request.',
        'date' => date('Y-m-d', strtotime('+2 Thursdays')),
        'time' => '10:00:00',
        'location' => 'Room 101',
        'max_participants' => 40,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Community Outreach Day',
        'description' => 'Join us as we serve our local community through various outreach projects.',
        'date' => date('Y-m-d', strtotime('+3 Saturdays')),
        'time' => '09:00:00',
        'location' => 'Meet at Church',
        'max_participants' => 100,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Worship Night',
        'description' => 'An evening of extended worship and prayer. Come experience God\'s presence with us.',
        'date' => date('Y-m-d', strtotime('+2 Fridays')),
        'time' => '19:30:00',
        'location' => 'Main Sanctuary',
        'max_participants' => 300,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'New Members Class',
        'description' => 'Learn about our church\'s vision, values, and how to get connected. Required for membership.',
        'date' => date('Y-m-d', strtotime('+3 Sundays')),
        'time' => '12:30:00',
        'location' => 'Room 201',
        'max_participants' => 30,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => 'Baptism Service',
        'description' => 'Celebrate with us as believers publicly declare their faith through water baptism.',
        'date' => date('Y-m-d', strtotime('+4 Sundays')),
        'time' => '16:00:00',
        'location' => 'Baptismal Pool',
        'max_participants' => 200,
        'is_public' => 1,
        'organizer_id' => $organizer_id,
        'created_at' => date('Y-m-d H:i:s')
    ]
];

// Add events to the database
$added = 0;
foreach ($sample_events as $event) {
    if ($conn->saveEvent($event)) {
        $added++;
    }
}

echo "Successfully added $added events to the database. <a href='list.php'>View Events</a>";

// Helper function to get user by email (since it might not be available in this context)
function get_user_by_email($email) {
    global $conn;
    $result = $conn->query("SELECT * FROM users WHERE email = '" . $conn->real_escape_string($email) . "' LIMIT 1");
    return $result ? $result->fetch_assoc() : null;
}
?>
