<?php
require_once '../includes/db.php';
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$user_role = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;

// Search and filter functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';
$timeframe = isset($_GET['timeframe']) ? $_GET['timeframe'] : '';

// Get all events
$events = [];
$events_file = __DIR__ . '/../data/events.json';

if (file_exists($events_file)) {
    $events = json_decode(file_get_contents($events_file), true) ?: [];
}

// Filter events
if (!empty($events)) {
    $filtered_events = [];
    $now = new DateTime();
    
    foreach ($events as $event) {
        // Skip if event is in the past
        $event_date = new DateTime($event['date']);
        if ($event_date < $now) continue;
        
        // Apply search filter
        if ($search) {
            $search = strtolower($search);
            $name_match = isset($event['name']) && stripos(strtolower($event['name']), $search) !== false;
            $desc_match = isset($event['description']) && stripos(strtolower($event['description']), $search) !== false;
            $loc_match = isset($event['location']) && stripos(strtolower($event['location']), $search) !== false;
            if (!($name_match || $desc_match || $loc_match)) continue;
        }
        
        // Apply category filter
        if ($category && isset($event['category']) && strtolower($event['category']) !== strtolower($category)) {
            continue;
        }
        
        // Apply timeframe filter
        if ($timeframe) {
            $today = new DateTime();
            $interval = $event_date->diff($today)->days;
            
            switch ($timeframe) {
                case 'today':
                    if ($today->format('Y-m-d') !== $event_date->format('Y-m-d')) continue 2;
                    break;
                case 'week':
                    if ($interval > 7) continue 2;
                    break;
                case 'month':
                    if ($interval > 30) continue 2;
                    break;
            }
        }
        
        $filtered_events[] = $event;
    }
    
    $events = $filtered_events;
}

// Sort events by date
usort($events, function($a, $b) {
    return strtotime($a['date'] ?? '') - strtotime($b['date'] ?? '');
});

// Get unique categories for filter
$categories = [];
if (file_exists($events_file)) {
    $all_events = json_decode(file_get_contents($events_file), true) ?: [];
    $categories = array_unique(array_column($all_events, 'category'));
    sort($categories);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events - Church Community</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/vanillajs-datepicker@1.2.0/dist/css/datepicker.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root {
            --primary: #e67e22;
            --primary-hover: #d35400;
            --secondary: #2c3e50;
            --accent: #ffd700;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --text: #333;
            --text-light: #7f8c8d;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #4bbf73;
            --warning: #f0ad4e;
            --danger: #d9534f;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
            color: #1e293b;
        }
        
        .navbar {
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
        }
        
        .hero-section {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 5rem 0;
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC4wMyI+PC9yZWN0PjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSI+PC9yZWN0Pjwvc3ZnPg==');
            opacity: 0.1;
            z-index: 1;
        }
        
        .hero-content {
            position: relative;
            z-index: 2;
        }
        
        .search-box {
            max-width: 700px;
            margin: 0 auto;
        }
        
        .search-box .form-control {
            padding: 1rem 1.5rem;
            border: none;
            border-radius: 50px 0 0 50px;
            font-size: 1.05rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .search-box .btn {
            padding: 0.75rem 2rem;
            border-radius: 0 50px 50px 0;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        
        .search-box .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        
        .section-title {
            position: relative;
            display: inline-block;
            margin-bottom: 2rem;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -10px;
            width: 50px;
            height: 3px;
            background: var(--primary);
            border-radius: 3px;
        }
        
        .event-card {
            border: none;
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            margin-bottom: 1.5rem;
            background: white;
            height: 100%;
        }
        
        .event-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .event-date {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 1.5rem;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-height: 100%;
        }
        
        .event-day {
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 0.25rem;
        }
        
        .event-month {
            font-size: 0.9rem;
            opacity: 0.9;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
        }
        
        .event-time {
            font-size: 0.9rem;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            display: inline-block;
        }
        
        .event-category {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.75rem;
        }
        
        .event-title {
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 0.75rem;
            color: var(--dark);
        }
        
        .event-location {
            color: #64748b;
            margin-bottom: 1rem;
            font-size: 0.95rem;
        }
        
        .event-description {
            color: #64748b;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
            line-height: 1.6;
        }
        
        .btn-details {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-details:hover {
            background: var(--secondary);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .filter-buttons .btn {
            margin: 0.25rem;
            border-radius: 50px;
            padding: 0.5rem 1.25rem;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid #e2e8f0;
            background: white;
            color: #64748b;
        }
        
        .filter-buttons .btn:hover,
        .filter-buttons .btn.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #cbd5e1;
            margin-bottom: 1.5rem;
        }
        
        .empty-state h3 {
            color: #475569;
            margin-bottom: 1rem;
        }
        
        .empty-state p {
            color: #94a3b8;
            max-width: 500px;
            margin: 0 auto 1.5rem;
        }
        
        .create-event-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.75rem 1.75rem;
            border-radius: 50px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3);
        }
        
        .create-event-btn:hover {
            background: var(--secondary);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(67, 97, 238, 0.4);
        }
        
        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            height: 100%;
            border: 1px solid #e2e8f0;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 1.5rem;
            color: white;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 0.5rem;
            line-height: 1;
        }
        
        .stats-label {
            color: #64748b;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }
        
        .category-badge {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .featured-tag {
            position: absolute;
            top: 15px;
            right: 15px;
            background: var(--warning);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            z-index: 2;
        }
        
        @media (max-width: 767.98px) {
            .hero-section {
                padding: 3rem 0;
            }
            
            .event-card {
                margin-bottom: 1.5rem;
            }
            
            .search-box .form-control {
                border-radius: 50px;
                margin-bottom: 0.5rem;
            }
            
            .search-box .btn {
                width: 100%;
                border-radius: 50px;
            }
            
            .filter-buttons .btn {
                margin: 0.15rem;
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="../index.php">
                <i class="fas fa-church me-2"></i>Church Community
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../sermons/list.php">Sermons</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="list.php">Events</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../announcements/list.php">Announcements</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <?php if ($user_id): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                                <div class="me-2 d-flex align-items-center justify-content-center bg-white text-primary rounded-circle" style="width: 32px; height: 32px; font-weight: 600;">
                                    <?php echo strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1)); ?>
                                </div>
                                <span class="d-none d-lg-inline"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="../dashboard/<?php echo $user_role; ?>.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                                <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../login.php">Login</a>
                        </li>
                        <li class="nav-item d-none d-md-block">
                            <a href="../register.php" class="btn btn-outline-light ms-2">Sign Up</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section with Background -->
    <section class="position-relative pt-10 pb-7 overflow-hidden" style="background: linear-gradient(135deg, #2c3e50 0%, #1a252f 100%);">
        <!-- Animated Background -->
        <div class="position-absolute top-0 start-0 w-100 h-100 overflow-hidden">
            <!-- Main Background Image with Overlay -->
            <div class="position-absolute w-100 h-100" style="
                background: 
                    linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(26, 37, 47, 0.95) 100%),
                    url('https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80') center/cover;
                filter: blur(0px);
                transform: scale(1.01);
                will-change: transform;
                transition: transform 10s ease-in-out;
            "></div>
            
            <!-- Animated Gradient Overlay -->
            <div class="position-absolute w-100 h-100" style="
                background: linear-gradient(
                    135deg,
                    rgba(230, 126, 34, 0.1) 0%,
                    rgba(44, 62, 80, 0.2) 50%,
                    rgba(255, 215, 0, 0.1) 100%
                );
                opacity: 0.5;
                animation: gradientShift 15s ease infinite;
                background-size: 200% 200%;
            "></div>
            
            <!-- Subtle Pattern Overlay -->
            <div class="position-absolute w-100 h-100" style="
                background-image: radial-gradient(
                    circle at 1px 1px,
                    rgba(255, 255, 255, 0.1) 1px,
                    transparent 1px
                );
                background-size: 20px 20px;
                mask-image: radial-gradient(
                    circle at center,
                    rgba(0,0,0,0.8) 0%,
                    rgba(0,0,0,0) 70%
                );
            "></div>
            
            <!-- Animated Particles -->
            <div class="position-absolute w-100 h-100" style="overflow: hidden;">
                <?php for ($i = 0; $i < 20; $i++): ?>
                    <div class="position-absolute rounded-circle" style="
                        width: <?php echo rand(3, 8); ?>px;
                        height: <?php echo rand(3, 8); ?>px;
                        background: rgba(255, 255, 255, <?php echo rand(5, 15)/100; ?>);
                        left: <?php echo rand(0, 100); ?>%;
                        top: <?php echo rand(0, 100); ?>%;
                        animation: float <?php echo 10 + rand(0, 20); ?>s linear infinite;
                        animation-delay: -<?php echo rand(0, 10); ?>s;
                    "></div>
                <?php endfor; ?>
            </div>
            
            <style>
                @keyframes gradientShift {
                    0% { background-position: 0% 50%; }
                    50% { background-position: 100% 50%; }
                    100% { background-position: 0% 50%; }
                }
                
                @keyframes float {
                    0% {
                        transform: translate(0, 0) rotate(0deg);
                        opacity: 0;
                    }
                    10% { opacity: 1; }
                    90% { opacity: 1; }
                    100% {
                        transform: translate(
                            <?php echo rand(-100, 100); ?>px, 
                            <?php echo rand(-100, 100); ?>px
                        ) rotate(<?php echo rand(0, 360); ?>deg);
                        opacity: 0;
                    }
                }
                
                /* Add hover effect to the parent section */
                .hero-section:hover .position-absolute:first-child > div:first-child {
                    transform: scale(1.05);
                    transition: transform 15s cubic-bezier(0.2, 0.4, 0.3, 1);
                }
            </style>
        </div>
        
        <div class="container position-relative">
            <!-- Section Header -->
            <div class="text-center mb-7">
                <span class="badge bg-primary bg-opacity-20 text-white mb-3 px-4 py-2 rounded-pill d-inline-flex align-items-center">
                    <i class="fas fa-calendar-alt me-2"></i> Upcoming Events
                </span>
                <h1 class="display-5 fw-bold text-white mb-3">Join Our Community <span class="text-warning">Events</span></h1>
                <p class="lead text-white-50 mb-0">Experience fellowship, worship, and spiritual growth with our church family</p>
            </div>

            <!-- Search and Filter -->
            <div class="row justify-content-center mb-6">
                <div class="col-lg-10">
                    <div class="card shadow-lg border-0">
                        <div class="card-body p-4">
                            <form method="GET" class="row g-2">
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class="fas fa-search text-muted"></i>
                                        </span>
                                        <input type="text" 
                                               name="search" 
                                               class="form-control border-start-0 ps-2" 
                                               placeholder="Search events by name, description, or location..." 
                                               value="<?php echo htmlspecialchars($search); ?>">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <select class="form-select" name="category">
                                        <option value="" <?php echo empty($category) ? 'selected' : ''; ?>>All Categories</option>
                                        <?php foreach ($categories as $cat): ?>
                                            <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category === $cat ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($cat); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2 d-grid">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-filter me-2"></i> Filter
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Spacer -->
            <div class="pt-5"></div>
            
            <!-- Animated Stats -->
            <div class="row g-4 justify-content-center text-center">
                <!-- Events Card -->
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="stats-card h-100 p-4 rounded-4 position-relative overflow-hidden" 
                         style="background: linear-gradient(145deg, rgba(230, 126, 34, 0.15) 0%, rgba(44, 62, 80, 0.25) 100%);
                                backdrop-filter: blur(10px);
                                border: 1px solid rgba(255, 255, 255, 0.1);
                                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.1);">
                        <!-- Animated Border -->
                        <div class="position-absolute top-0 start-0 w-100 h-100 overflow-hidden">
                            <div class="position-absolute" style="
                                width: 150%; height: 200%;
                                background: conic-gradient(
                                    transparent 0deg,
                                    transparent 180deg,
                                    rgba(230, 126, 34, 0.6) 180deg,
                                    rgba(255, 215, 0, 0.4) 300deg,
                                    transparent 360deg
                                );
                                animation: rotate 8s linear infinite;
                                top: -50%; left: -25%;
                                transform-origin: center center;
                            "></div>
                        </div>
                        
                        <!-- Content -->
                        <div class="position-relative">
                            <div class="stats-icon d-inline-flex align-items-center justify-content-center mb-3 mx-auto" 
                                 style="width: 70px; height: 70px; 
                                        background: linear-gradient(135deg, rgba(230, 126, 34, 0.2) 0%, rgba(211, 84, 0, 0.3) 100%);
                                        border: 2px solid rgba(255, 255, 255, 0.1);
                                        border-radius: 20px;
                                        transition: all 0.3s ease;">
                                <i class="fas fa-calendar-alt fa-xl" style="color: #e67e22;"></i>
                            </div>
                            <div class="counter display-5 fw-bold mb-2" data-target="12" style="color: #fff;">0</div>
                            <div class="stats-label text-uppercase fw-medium" style="letter-spacing: 1px; color: rgba(255, 255, 255, 0.8);">
                                Events This Month
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gatherings Card -->
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="stats-card h-100 p-4 rounded-4 position-relative overflow-hidden" 
                         style="background: linear-gradient(145deg, rgba(52, 152, 219, 0.15) 0%, rgba(41, 128, 185, 0.25) 100%);
                                backdrop-filter: blur(10px);
                                border: 1px solid rgba(255, 255, 255, 0.1);
                                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.1);">
                        <!-- Animated Border -->
                        <div class="position-absolute top-0 start-0 w-100 h-100 overflow-hidden">
                            <div class="position-absolute" style="
                                width: 150%; height: 200%;
                                background: conic-gradient(
                                    transparent 0deg,
                                    transparent 180deg,
                                    rgba(52, 152, 219, 0.6) 180deg,
                                    rgba(41, 128, 185, 0.4) 300deg,
                                    transparent 360deg
                                );
                                animation: rotate 8s linear infinite reverse;
                                top: -50%; left: -25%;
                                transform-origin: center center;
                            "></div>
                        </div>
                        
                        <div class="position-relative">
                            <div class="stats-icon d-inline-flex align-items-center justify-content-center mb-3 mx-auto" 
                                 style="width: 70px; height: 70px; 
                                        background: linear-gradient(135deg, rgba(52, 152, 219, 0.2) 0%, rgba(41, 128, 185, 0.3) 100%);
                                        border: 2px solid rgba(255, 255, 255, 0.1);
                                        border-radius: 20px;
                                        transition: all 0.3s ease;">
                                <i class="fas fa-users fa-xl" style="color: #3498db;"></i>
                            </div>
                            <div class="counter display-5 fw-bold mb-2" data-target="5" style="color: #fff;">0</div>
                            <div class="stats-label text-uppercase fw-medium" style="letter-spacing: 1px; color: rgba(255, 255, 255, 0.8);">
                                Weekly Gatherings
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Members Card -->
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="stats-card h-100 p-4 rounded-4 position-relative overflow-hidden" 
                         style="background: linear-gradient(145deg, rgba(46, 204, 113, 0.15) 0%, rgba(39, 174, 96, 0.25) 100%);
                                backdrop-filter: blur(10px);
                                border: 1px solid rgba(255, 255, 255, 0.1);
                                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.1);">
                        <!-- Animated Border -->
                        <div class="position-absolute top-0 start-0 w-100 h-100 overflow-hidden">
                            <div class="position-absolute" style="
                                width: 150%; height: 200%;
                                background: conic-gradient(
                                    transparent 0deg,
                                    transparent 180deg,
                                    rgba(46, 204, 113, 0.6) 180deg,
                                    rgba(39, 174, 96, 0.4) 300deg,
                                    transparent 360deg
                                );
                                animation: rotate 10s linear infinite;
                                top: -50%; left: -25%;
                                transform-origin: center center;
                            "></div>
                        </div>
                        
                        <div class="position-relative">
                            <div class="stats-icon d-inline-flex align-items-center justify-content-center mb-3 mx-auto" 
                                 style="width: 70px; height: 70px; 
                                        background: linear-gradient(135deg, rgba(46, 204, 113, 0.2) 0%, rgba(39, 174, 96, 0.3) 100%);
                                        border: 2px solid rgba(255, 255, 255, 0.1);
                                        border-radius: 20px;
                                        transition: all 0.3s ease;">
                                <i class="fas fa-church fa-xl" style="color: #2ecc71;"></i>
                            </div>
                            <div class="counter display-5 fw-bold mb-2" data-target="100" data-plus="true" style="color: #fff;">0</div>
                            <div class="stats-label text-uppercase fw-medium" style="letter-spacing: 1px; color: rgba(255, 255, 255, 0.8);">
                                Active Members
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <style>
                /* Animation for the rotating border */
                @keyframes rotate {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
                
                /* Hover effects */
                .stats-card {
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                    transform: translateY(0);
                }
                
                .stats-card:hover {
                    transform: translateY(-5px);
                    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
                }
                
                .stats-card:hover .stats-icon {
                    transform: scale(1.1) rotate(5deg);
                }
                
                /* Counter animation */
                .counter {
                    transition: all 0.3s ease-out;
                }
            </style>
            
            <script>
                // Animate counters when they come into view
                document.addEventListener('DOMContentLoaded', function() {
                    const counters = document.querySelectorAll('.counter');
                    const speed = 200; // The lower the faster
                    
                    const animateCounters = () => {
                        counters.forEach(counter => {
                            const updateCount = () => {
                                const target = +counter.getAttribute('data-target');
                                const count = +counter.innerText;
                                const increment = target / speed;
                                
                                if (count < target) {
                                    counter.innerText = Math.ceil(count + increment);
                                    setTimeout(updateCount, 1);
                                } else {
                                    if (counter.hasAttribute('data-plus')) {
                                        counter.innerText = target + '+';
                                    } else {
                                        counter.innerText = target;
                                    }
                                }
                            };
                            
                            updateCount();
                        });
                    };
                    
                    // Only start the animation when the stats section is in view
                    const observer = new IntersectionObserver((entries) => {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                animateCounters();
                                observer.unobserve(entry.target);
                            }
                        });
                    }, { threshold: 0.5 });
                    
                    document.querySelectorAll('.stats-card').forEach(card => {
                        observer.observe(card);
                    });
                });
            </script>
        </div>
    </section>

    <!-- Events Section -->
    <section class="py-6 bg-light">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-lg-10 text-center">
                    <h2 class="section-title d-inline-block">Upcoming Events</h2>
                    <p class="lead text-muted mb-4">Discover and join our upcoming gatherings and activities</p>
                    
                    <!-- Event Filters -->
                    <div class="filter-buttons mb-5">
                        <a href="?" class="btn <?php echo empty($timeframe) && empty($category) ? 'active' : ''; ?>">
                            <i class="fas fa-calendar-day me-1"></i> All Events
                        </a>
                        <a href="?timeframe=today" class="btn <?php echo $timeframe === 'today' ? 'active' : ''; ?>">
                            <i class="fas fa-calendar-day me-1"></i> Today
                        </a>
                        <a href="?timeframe=week" class="btn <?php echo $timeframe === 'week' ? 'active' : ''; ?>">
                            <i class="fas fa-calendar-week me-1"></i> This Week
                        </a>
                        <a href="?timeframe=month" class="btn <?php echo $timeframe === 'month' ? 'active' : ''; ?>">
                            <i class="far fa-calendar-alt me-1"></i> This Month
                        </a>
                        
                        <?php if (!empty($categories)): ?>
                            <div class="dropdown d-inline-block">
                                <button class="btn dropdown-toggle" type="button" id="categoryDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-tags me-1"></i> 
                                    <?php echo $category ? htmlspecialchars(ucfirst($category)) : 'Categories'; ?>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="categoryDropdown">
                                    <li><a class="dropdown-item" href="?">All Categories</a></li>
                                    <?php foreach ($categories as $cat): ?>
                                        <?php if (!empty($cat)): ?>
                                            <li>
                                                <a class="dropdown-item <?php echo strtolower($category) === strtolower($cat) ? 'active' : ''; ?>" 
                                                   href="?category=<?php echo urlencode(strtolower($cat)); ?>">
                                                    <?php echo htmlspecialchars(ucfirst($cat)); ?>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (in_array($user_role, ['admin', 'pastor', 'leader'])): ?>
                            <a href="create.php" class="btn btn-primary ms-2">
                                <i class="fas fa-plus me-1"></i> Create Event
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if (!empty($events)): ?>
                <div class="row g-4 justify-content-center">
                <?php 
                $month_year = '';
                $month_count = 0;
                
                foreach($events as $row) { 
                    $event_date = new DateTime($row['date'] ?? '');
                    $current_month_year = $event_date->format('F Y');
                    $now = new DateTime();
                    $is_upcoming = $event_date >= $now;
                    $is_today = $event_date->format('Y-m-d') === $now->format('Y-m-d');
                    $is_tomorrow = $event_date->format('Y-m-d') === $now->modify('+1 day')->format('Y-m-d');
                    
                    // Display month/year header if it's a new month
                    if ($current_month_year !== $month_year) {
                        $month_year = $current_month_year;
                        $month_count++;
                        echo '<div class="col-12 ' . ($month_count > 1 ? 'mt-5' : '') . '">';
                        echo '<div class="d-flex align-items-center mb-4">';
                        echo '<h3 class="h5 fw-bold text-uppercase text-muted mb-0 me-3">' . $month_year . '</h3>';
                        echo '<div class="flex-grow-1 border-top"></div>';
                        echo '</div></div>';
                    }
                ?>
                <div class="col-12 col-lg-8 mx-auto">
                    <div class="card event-card border-0 shadow-sm overflow-hidden h-100 transition-all" style="border-radius: 15px; transition: transform 0.3s ease, box-shadow 0.3s ease;">
                        <div class="row g-0 h-100">
                            <!-- Event Date Box -->
                            <div class="col-md-3 position-relative">
                                <div class="h-100 d-flex flex-column justify-content-center p-4 text-center" style="background: linear-gradient(135deg, #e67e22 0%, #d35400 100%);">
                                    <div class="text-white mb-1" style="font-size: 0.9rem;"><?php echo $event_date->format('l'); ?></div>
                                    <div class="display-4 fw-bold text-white mb-1"><?php echo $event_date->format('d'); ?></div>
                                    <div class="text-white text-uppercase" style="letter-spacing: 1px; font-size: 0.9rem;"><?php echo $event_date->format('M Y'); ?></div>
                                    
                                    <?php if ($is_today): ?>
                                    <span class="position-absolute top-0 end-0 m-2 badge bg-white text-danger px-3 py-1">
                                        <i class="fas fa-bolt me-1"></i> Today
                                    </span>
                                    <?php elseif ($is_tomorrow): ?>
                                    <span class="position-absolute top-0 end-0 m-2 badge bg-white text-primary px-3 py-1">
                                        <i class="fas fa-calendar-day me-1"></i> Tomorrow
                                    </span>
                                    <?php endif; ?>
                                    
                                    <div class="mt-3">
                                        <span class="badge bg-white bg-opacity-20 text-white px-3 py-1">
                                            <i class="far fa-clock me-1"></i> <?php echo date('g:i A', strtotime($row['time'])); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Event Details -->
                            <div class="col-md-9">
                                <div class="card-body p-4 h-100 d-flex flex-column">
                                    <!-- Event Category -->
                                    <div class="mb-2">
                                        <span class="badge bg-warning bg-opacity-10 text-warning px-3 py-1">
                                            <i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($row['category'] ?? 'General'); ?>
                                        </span>
                                    </div>
                                    
                                    <!-- Event Title -->
                                    <h3 class="h4 mb-2"><?php echo htmlspecialchars($row['name']); ?></h3>
                                    
                                    <!-- Event Location -->
                                    <?php if (!empty($row['location'])): ?>
                                    <div class="d-flex align-items-center text-muted mb-3">
                                        <i class="fas fa-map-marker-alt me-2 text-primary"></i>
                                        <span><?php echo htmlspecialchars($row['location']); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <!-- Event Description -->
                                    <p class="card-text text-muted mb-4 flex-grow-1">
                                        <?php 
                                        $description = strip_tags($row['description']);
                                        echo strlen($description) > 120 ? substr($description, 0, 120) . '...' : $description;
                                        ?>
                                    </p>
                                    
                                    <!-- Event Footer -->
                                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mt-auto pt-3 border-top">
                                        <div class="d-flex align-items-center mb-3 mb-md-0">
                                            <div class="avatar me-3">
                                                <div class="avatar-initial bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-user"></i>
                                                </div>
                                            </div>
                                            <div>
                                                <div class="fw-medium small"><?php echo htmlspecialchars($row['organizer'] ?? 'Church Staff'); ?></div>
                                                <small class="text-muted">Event Organizer</small>
                                            </div>
                                        </div>
                                        <div class="d-flex gap-2">
                                            <a href="view.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary btn-sm">
                                                <i class="far fa-eye me-1"></i> Details
                                            </a>
                                            <?php if ($user_id && $is_upcoming): ?>
                                            <a href="register.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-check me-1"></i> Register
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                    } // End foreach events
                ?>
                </div>
            </div>
        <?php else: ?>
            <!-- Empty State -->
            <div class="empty-state">
                <i class="far fa-calendar-plus"></i>
                <h3>No Upcoming Events</h3>
                <p>There are currently no upcoming events scheduled. Please check back later or subscribe to our newsletter to stay updated.</p>
                <?php if (in_array($user_role, ['admin', 'pastor', 'leader'])): ?>
                    <a href="create.php" class="create-event-btn">
                        <i class="fas fa-plus"></i> Create Your First Event
                    </a>
                <?php else: ?>
                    <a href="../contact.php" class="btn btn-outline-primary">
                        <i class="fas fa-envelope me-2"></i> Contact Us
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Call to Action -->
    <section class="py-7 bg-primary text-white position-relative overflow-hidden">
        <div class="position-absolute top-0 start-0 w-100 h-100" style="opacity: 0.05;">
            <div class="position-absolute" style="top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, #fff 0%, transparent 50%);"></div>
        </div>
        <div class="container position-relative">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8">
                    <h2 class="display-5 fw-bold mb-4">Can't Find What You're Looking For?</h2>
                    <p class="lead mb-5">Contact us for more information about our events and how you can get involved in our community.</p>
                    <div class="d-flex flex-column flex-sm-row justify-content-center gap-3">
                        <a href="../contact.php" class="btn btn-light px-4 py-3 fw-medium">
                            <i class="fas fa-envelope me-2"></i> Contact Us
                        </a>
                        <a href="../about.php" class="btn btn-outline-light px-4 py-3 fw-medium">
                            <i class="fas fa-info-circle me-2"></i> Learn More
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white pt-6 pb-4 position-relative">
        <div class="container">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Church Management System. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5 class="text-uppercase mb-4">About Our Church</h5>
                    <p>We are a community of believers dedicated to spreading the love of Christ and serving our neighbors with compassion and grace.</p>
                    <div class="mt-4">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <h5 class="text-uppercase mb-4">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="../index.php" class="text-white text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="../about.php" class="text-white text-decoration-none">About Us</a></li>
                        <li class="mb-2"><a href="../sermons/list.php" class="text-white text-decoration-none">Sermons</a></li>
                        <li class="mb-2"><a href="list.php" class="text-white text-decoration-none">Events</a></li>
                        <li class="mb-2"><a href="../contact.php" class="text-white text-decoration-none">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <h5 class="text-uppercase mb-4">Contact Us</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Church Street, City, Country</p>
                    <p><i class="fas fa-phone me-2"></i> +1 234 567 890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@churchcommunity.com</p>
                    <div class="mt-4">
                        <h6 class="text-uppercase mb-3">Service Times</h6>
                        <p class="mb-1">Sunday: 9:00 AM - 12:00 PM</p>
                        <p class="mb-1">Wednesday: 7:00 PM - 8:30 PM</p>
                    </div>
                </div>
            </div>
            <hr class="my-4 bg-light">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> Church Community. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="../privacy-policy.php" class="text-white text-decoration-none me-3">Privacy Policy</a>
                    <a href="../terms.php" class="text-white text-decoration-none">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="btn btn-primary btn-lg back-to-top" id="backToTop">
        <i class="fas fa-arrow-up"></i>
    </a>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/noframework.waypoints.min.js"></script>
    <script>
        // Back to top button
        const backToTopButton = document.getElementById('backToTop');
        
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopButton.style.display = 'block';
            } else {
                backToTopButton.style.display = 'none';
            }
        });
        
        backToTopButton.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        
        // Initialize date picker for event search
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize any date pickers
            const datePickers = document.querySelectorAll('.date-picker');
            datePickers.forEach(function(element) {
                new Datepicker(element, {
                    format: 'yyyy-mm-dd',
                    autohide: true
                });
            });
            
            // Add animation to event cards on scroll
            const animateOnScroll = () => {
                const elements = document.querySelectorAll('.event-card');
                elements.forEach(element => {
                    const elementPosition = element.getBoundingClientRect().top;
                    const screenPosition = window.innerHeight / 1.3;
                    
                    if (elementPosition < screenPosition) {
                        element.style.opacity = '1';
                        element.style.transform = 'translateY(0)';
                    }
                });
            };
            
            // Initial check
            animateOnScroll();
            
            // Check on scroll
            window.addEventListener('scroll', animateOnScroll);
            
            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
        
        // Filter events by category
        function filterEvents(category) {
            const url = new URL(window.location.href);
            if (category) {
                url.searchParams.set('category', category);
            } else {
                url.searchParams.delete('category');
            }
            window.location.href = url.toString();
        }
        
        // Filter events by timeframe
        function filterTimeframe(timeframe) {
            const url = new URL(window.location.href);
            if (timeframe) {
                url.searchParams.set('timeframe', timeframe);
            } else {
                url.searchParams.delete('timeframe');
            }
            window.location.href = url.toString();
        }
    </script>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>